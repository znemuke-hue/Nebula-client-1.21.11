#!/usr/bin/env python3
"""
Nebula AimAssist "Нейро": trains the aim model on your recorded datasets and writes a .onnx file.

Needs ONLY numpy (works in Termux: `pkg install python-numpy`). No torch / onnx packages required - the .onnx file
is written by a tiny built-in exporter. If onnxruntime happens to be installed, the exported file is cross-checked.

    python train_neuro_aim.py combined.json -o my_model.onnx
    python train_neuro_aim.py datasets/ more.json -o my_model.onnx --epochs 600 --hidden 128,128

Put the resulting .onnx into  <game folder>/config/nebula/models/  and pick it in AimAssist -> "Выбрать модель".

MODEL CONTRACT (the client builds exactly these inputs, in this order):
  input  "features" float32 [1, 14]:
      0 delta_yaw      wrapped angle from the camera to the aim point (deg)
      1 delta_pitch    same for pitch (deg)
      2 distance       eye -> aim point (blocks)
      3 vel_yaw        camera yaw change of the previous tick (deg)
      4 vel_pitch      camera pitch change of the previous tick (deg)
      5 since_attack   ticks since your last attack (capped at 40)
      6 cooldown       attack charge 0..1
      7 target_height  8 tgt_rate_yaw   9 tgt_rate_pitch   (target angular rate per tick, deg)
      10 own_speed     horizontal speed (blocks/tick)
      11 sprint 0/1    12 on_ground 0/1    13 target_width
  output "out" float32 [1, 2]:  camera turn for THIS tick in degrees (yaw, pitch)
Normalisation is baked into the file, so the client feeds raw values and gets raw degrees.
Supported layers (what the client can run): Gemm/MatMul, Add, Sub, Mul, Div, Relu, LeakyRelu, Tanh, Sigmoid.
"""
import argparse, glob, json, os, struct, sys
import numpy as np

FEATURES = ["delta_yaw", "delta_pitch", "distance", "vel_yaw", "vel_pitch", "since_attack", "cooldown",
            "target_height", "tgt_rate_yaw", "tgt_rate_pitch", "own_speed", "sprint", "on_ground", "target_width"]
OUTPUTS = ["out_yaw", "out_pitch"]
YAW_FIELDS = {"delta_yaw", "vel_yaw", "tgt_rate_yaw", "out_yaw"}   # sign flips when the scene is mirrored


# ------------------------------------------------------------------------------------------------ data
def collect_files(paths):
    files = []
    for p in paths:
        if os.path.isdir(p):
            files += sorted(glob.glob(os.path.join(p, "**", "*.json"), recursive=True))
        else:
            files += sorted(glob.glob(p)) or [p]
    return files


def load_samples(files):
    """-> list of (X [n,14], Y [n,2]) one entry per recorded sample (a continuous fight)."""
    out = []
    for fn in files:
        with open(fn, "r", encoding="utf-8") as f:
            d = json.load(f)
        for s in d.get("samples", []):
            fr = s.get("frames", [])
            if len(fr) < 3:
                continue
            X = np.array([[float(x[k]) for k in FEATURES] for x in fr], dtype=np.float64)
            Y = np.array([[float(x[k]) for k in OUTPUTS] for x in fr], dtype=np.float64)
            out.append((X, Y))
    return out


def mirror(X, Y):
    X, Y = X.copy(), Y.copy()
    for i, k in enumerate(FEATURES):
        if k in YAW_FIELDS: X[:, i] *= -1
    Y[:, 0] *= -1
    return X, Y


# ------------------------------------------------------------------------------------------------ model
class MLP:
    def __init__(self, sizes, rng):
        self.W = [rng.normal(0, np.sqrt(2.0 / a), (a, b)) for a, b in zip(sizes[:-1], sizes[1:])]
        self.b = [np.zeros(b) for b in sizes[1:]]

    def params(self): return self.W + self.b

    def forward(self, x, keep=False):
        acts = [x]
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            z = acts[-1] @ W + b
            acts.append(z if i == len(self.W) - 1 else np.maximum(z, 0))
        return (acts[-1], acts) if keep else acts[-1]

    def grads(self, x, y, l2):
        out, acts = self.forward(x, True)
        n = x.shape[0]
        d = 2.0 * (out - y) / (n * y.shape[1])
        gW, gb = [None] * len(self.W), [None] * len(self.b)
        for i in range(len(self.W) - 1, -1, -1):
            gW[i] = acts[i].T @ d + l2 * self.W[i]
            gb[i] = d.sum(0)
            if i > 0:
                d = (d @ self.W[i].T) * (acts[i] > 0)
        return gW + gb


class Adam:
    def __init__(self, params, lr):
        self.lr, self.t = lr, 0
        self.m = [np.zeros_like(p) for p in params]
        self.v = [np.zeros_like(p) for p in params]

    def step(self, params, grads, lr):
        self.t += 1
        for p, g, m, v in zip(params, grads, self.m, self.v):
            m *= 0.9; m += 0.1 * g
            v *= 0.999; v += 0.001 * g * g
            p -= lr * (m / (1 - 0.9 ** self.t)) / (np.sqrt(v / (1 - 0.999 ** self.t)) + 1e-8)


# ------------------------------------------------------------------------------------------------ onnx writer
def _varint(n):
    n &= (1 << 64) - 1
    b = bytearray()
    while True:
        c = n & 0x7F; n >>= 7
        if n: b.append(c | 0x80)
        else: b.append(c); return bytes(b)

def _key(f, wt): return _varint((f << 3) | wt)
def _vi(f, v): return _key(f, 0) + _varint(v)
def _by(f, b): return _key(f, 2) + _varint(len(b)) + b
def _st(f, s): return _by(f, s.encode("utf-8"))
def _fl(f, x): return _key(f, 5) + struct.pack("<f", x)

def _tensor(name, arr):
    arr = np.asarray(arr, dtype="<f4")
    b = b"".join(_vi(1, int(d)) for d in arr.shape) + _vi(2, 1) + _st(8, name) + _by(9, arr.tobytes())
    return b

def _node(op, ins, outs, attrs=()):
    b = b"".join(_st(1, i) for i in ins) + b"".join(_st(2, o) for o in outs) + _st(3, outs[0] + "_n") + _st(4, op)
    for a in attrs: b += _by(5, a)
    return b

def _attr_i(name, v): return _st(1, name) + _vi(3, v) + _vi(20, 2)

def _value_info(name, dims):
    shape = b""
    for d in dims:
        shape += _by(1, _st(2, d) if isinstance(d, str) else _vi(1, d))
    tensor_type = _vi(1, 1) + _by(2, shape)
    return _st(1, name) + _by(2, _by(1, tensor_type))

def export_onnx(path, net, in_mean, in_std, out_mean, out_std):
    inits, nodes = [], []
    inits += [_tensor("in_mean", in_mean), _tensor("in_std", in_std),
              _tensor("out_mean", out_mean), _tensor("out_std", out_std)]
    nodes.append(_node("Sub", ["features", "in_mean"], ["x0"]))
    nodes.append(_node("Div", ["x0", "in_std"], ["x1"]))
    cur, last = "x1", len(net.W) - 1
    for i, (W, b) in enumerate(zip(net.W, net.b)):
        inits += [_tensor(f"W{i}", W), _tensor(f"b{i}", b)]
        nodes.append(_node("Gemm", [cur, f"W{i}", f"b{i}"], [f"g{i}"], [_attr_i("transB", 0)]))
        cur = f"g{i}"
        if i != last:
            nodes.append(_node("Relu", [cur], [f"r{i}"])); cur = f"r{i}"
    nodes.append(_node("Mul", [cur, "out_std"], ["m0"]))
    nodes.append(_node("Add", ["m0", "out_mean"], ["out"]))
    graph = b"".join(_by(1, n) for n in nodes) + _st(2, "nebula_aim")
    graph += b"".join(_by(5, t) for t in inits)
    graph += _by(11, _value_info("features", ["batch", len(FEATURES)])) + _by(12, _value_info("out", ["batch", 2]))
    meta = lambda k, v: _by(14, _st(1, k) + _st(2, v))
    model = _vi(1, 8) + _st(2, "nebula-train") + _by(7, graph) + _by(8, _st(1, "") + _vi(2, 13))
    model += meta("nebula_features", ",".join(FEATURES)) + meta("nebula_outputs", ",".join(OUTPUTS))
    with open(path, "wb") as f: f.write(model)


# ------------------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("data", nargs="+", help="dataset .json files, folders or globs")
    ap.add_argument("-o", "--out", default="nebula_aim.onnx")
    ap.add_argument("--hidden", default="64,64", help="hidden layer sizes, e.g. 128,128")
    ap.add_argument("--epochs", type=int, default=400)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--l2", type=float, default=1e-5)
    ap.add_argument("--patience", type=int, default=60, help="stop when validation does not improve for N epochs")
    ap.add_argument("--no-mirror", action="store_true", help="do not add the mirrored (yaw*-1) copy of the data")
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()

    files = collect_files(a.data)
    samples = load_samples(files)
    if not samples:
        sys.exit("no usable samples found in: " + ", ".join(a.data))
    nframes = sum(len(x) for x, _ in samples)
    print(f"{len(files)} file(s), {len(samples)} sample(s), {nframes} frames")

    rng = np.random.default_rng(a.seed)
    # validation split: whole samples when there are several, otherwise the last 15% of the frames
    if len(samples) >= 5:
        order = rng.permutation(len(samples)); nv = max(1, len(samples) // 6)
        val = [samples[i] for i in order[:nv]]; tr = [samples[i] for i in order[nv:]]
    else:
        tr, val = [], []
        for X, Y in samples:
            k = int(len(X) * 0.85); tr.append((X[:k], Y[:k])); val.append((X[k:], Y[k:]))
    Xtr = np.concatenate([x for x, _ in tr]); Ytr = np.concatenate([y for _, y in tr])
    Xva = np.concatenate([x for x, _ in val]); Yva = np.concatenate([y for _, y in val])
    if not a.no_mirror:
        mx, my = mirror(Xtr, Ytr); Xtr = np.concatenate([Xtr, mx]); Ytr = np.concatenate([Ytr, my])
    print(f"train {len(Xtr)} frames, validation {len(Xva)} frames")

    in_mean = Xtr.mean(0); in_std = Xtr.std(0); in_std[in_std < 1e-6] = 1.0      # constant features stay as they are
    out_mean = Ytr.mean(0); out_std = Ytr.std(0); out_std[out_std < 1e-6] = 1.0
    nx = lambda X: (X - in_mean) / in_std
    ny = lambda Y: (Y - out_mean) / out_std
    Xt, Yt, Xv, Yv = nx(Xtr), ny(Ytr), nx(Xva), ny(Yva)

    sizes = [len(FEATURES)] + [int(h) for h in a.hidden.split(",") if h.strip()] + [2]
    net = MLP(sizes, rng)
    opt = Adam(net.params(), a.lr)
    best, best_p, bad = 1e9, None, 0
    for ep in range(1, a.epochs + 1):
        lr = a.lr * (0.5 * (1 + np.cos(np.pi * ep / a.epochs)) * 0.95 + 0.05)
        idx = rng.permutation(len(Xt))
        for s in range(0, len(idx), a.batch):
            j = idx[s:s + a.batch]
            opt.step(net.params(), net.grads(Xt[j], Yt[j], a.l2), lr)
        vl = float(np.mean((net.forward(Xv) - Yv) ** 2))
        if vl < best - 1e-5:
            best, bad = vl, 0
            best_p = [p.copy() for p in net.params()]
        else:
            bad += 1
        if ep % 20 == 0 or ep == 1:
            tl = float(np.mean((net.forward(Xt) - Yt) ** 2))
            print(f"epoch {ep:4d}  train {tl:.4f}  val {vl:.4f}  best {best:.4f}")
        if bad >= a.patience:
            print(f"early stop at epoch {ep}"); break
    n = len(net.W)
    for p, q in zip(net.params(), best_p): p[...] = q

    pred = net.forward(Xv) * out_std + out_mean
    mae = np.abs(pred - Yva).mean(0)
    base = np.abs(Yva - Ytr.mean(0)).mean(0)
    print(f"validation MAE: yaw {mae[0]:.3f} deg, pitch {mae[1]:.3f} deg   (predicting the mean: {base[0]:.3f} / {base[1]:.3f})")

    export_onnx(a.out, net, in_mean, in_std, out_mean, out_std)
    print("saved", a.out, f"({os.path.getsize(a.out)} bytes)")

    try:   # optional cross-check with onnxruntime
        import onnxruntime as ort
        sess = ort.InferenceSession(a.out, providers=["CPUExecutionProvider"])
        got = sess.run(None, {"features": Xva[:64].astype(np.float32)})[0]
        ref = net.forward(nx(Xva[:64])) * out_std + out_mean
        print("onnxruntime check, max difference:", float(np.abs(got - ref).max()))
    except ImportError:
        pass


if __name__ == "__main__":
    main()
