Пользовательские изображения TargetESP: PNG/JPEG размещаются в config/hvhclient/targetesp.
