package dev.hvh.client;

import dev.hvh.client.gui.ClickGuiScreen;
import dev.hvh.client.cosmetics.Cosmetics;
import dev.hvh.client.cosmetics.CosmeticsRenderer;
import dev.hvh.client.gui.NebulaTitleScreen;
import dev.hvh.client.hud.Hud;
import dev.hvh.client.module.Binds;
import dev.hvh.client.module.ModuleManager;
import dev.hvh.client.module.Rotations;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class HvhClient implements ClientModInitializer {
    public static final Minecraft mc = Minecraft.getInstance();
    public static ModuleManager modules;
    private static KeyMapping openGui;

    private static volatile long tickStartNanos = System.nanoTime();

    public static float partialTick() {
        float f = (System.nanoTime() - tickStartNanos) / 50_000_000f;
        return f < 0f ? 0f : Math.min(f, 1f);
    }

    // ---- the partial tick of the frame being drawn (the same value vanilla uses for the camera / entity positions) ----
    private static volatile float renderPartial = -1f;
    private static java.lang.reflect.Method ptMethod;
    private static Class<?> ptClass;

    /** Once per frame, first thing in GameRenderer#render: reads the real partial tick from the frame's DeltaTracker. */
    public static void beginRender(Object deltaTracker) {
        float v = -1f;
        if (deltaTracker != null) {
            try {
                if (ptClass != deltaTracker.getClass()) {
                    ptClass = deltaTracker.getClass();
                    ptMethod = null;
                    for (java.lang.reflect.Method m : ptClass.getMethods())
                        if (m.getName().equals("getGameTimeDeltaPartialTick") && m.getParameterCount() == 1
                            && m.getParameterTypes()[0] == boolean.class) { ptMethod = m; m.setAccessible(true); break; }
                }
                if (ptMethod != null && ptMethod.invoke(deltaTracker, false) instanceof Number n) v = n.floatValue();
            } catch (Throwable t) { ptMethod = null; ptClass = null; }
        }
        renderPartial = v;
    }

    /** Partial tick of the current frame; falls back to the wall-clock estimate when the DeltaTracker is unreadable. */
    public static float framePartial() {
        float r = renderPartial;
        return r >= 0f ? Math.min(r, 1f) : partialTick();
    }

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        dev.hvh.client.friend.FriendsManager.load();
        Config.load();
        // Prepare user-editable directories and install built-in presets on first launch.
        dev.hvh.client.gui.CustomBackground.ensureFolder();
        dev.hvh.client.neuro.NeuroAim.ensureDir();
        dev.hvh.client.sound.ClientSounds.init();
        openGui = KeyBindingHelper.registerKeyBinding(
            new KeyMapping("key.hvhclient.gui", GLFW.GLFW_KEY_RIGHT_SHIFT, KeyMapping.Category.MISC));

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            tickStartNanos = System.nanoTime();
            if (dev.hvh.client.modules.GuiMove.inputLocked()) { dev.hvh.client.modules.GuiMove.silenceInput(); return; }
            dev.hvh.client.util.ActionLock.preTick();      // swap lock: quiet ticks around the click
            if (client.player != null && client.level != null) modules.preTick();
            dev.hvh.client.util.ActionLock.enforce();      // nothing a module did above may press a key during a swap
            dev.hvh.client.modules.FreeCam.enforce();      // FreeCam: the player itself stands still, whatever the modules pressed
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (dev.hvh.client.modules.GuiMove.inputLocked()) { dev.hvh.client.modules.GuiMove.silenceInput(); return; }
            Rotations.end(client.player);
            dev.hvh.client.sound.ClientSounds.tick();
            Binds.poll();
            while (openGui.consumeClick()) client.setScreen(new ClickGuiScreen());
            if (client.player != null && client.level != null) { modules.tick(); Hud.tick(); }
            Screen cur = client.screen;
            if (cur != null && cur.getClass() == TitleScreen.class)
                client.setScreen(new NebulaTitleScreen());
        });

        // ─── Раньше всех HUD-хуков — вызываем frame() для всех модулей каждый кадр ───
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("hvhclient", "frame_hook"),
            (g, delta) -> { if (!dev.hvh.client.modules.GuiMove.inputLocked()) modules.frame(); });

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("hvhclient", "nebula_hud"), (g, delta) -> Hud.render(g));
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(dev.hvh.client.modules.ESPWorldRenderer::onWorldRender);
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(CosmeticsRenderer::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            dev.hvh.client.modules.ESPWorldRenderer.close();
            CosmeticsRenderer.close();
        });
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("hvhclient", "entity_esp_2d"), (g, delta) -> dev.hvh.client.modules.ESP.render(g));
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("hvhclient", "entity_nametags"), (g, delta) -> { dev.hvh.client.util.Projector.beginFrame(delta); dev.hvh.client.modules.Nametags.render(g); });
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("hvhclient", "targetesp_image"), (g, delta) -> { dev.hvh.client.util.Projector.beginFrame(delta); dev.hvh.client.modules.TargetESP.render(g); });
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("hvhclient", "custom_crosshair"), (g, delta) -> dev.hvh.client.modules.Crosshair.render(g));
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("hvhclient", "aimassist_fov"), (g, delta) -> dev.hvh.client.modules.AimAssist.renderFov(g));
    }
}