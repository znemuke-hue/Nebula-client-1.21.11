package dev.hvh.client.command;

import dev.hvh.client.ConfigProfiles;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Locale;

/**
 * Chat commands, typed into the normal chat with a "." in front. A handled command is never sent to the server
 * (see ClientPacketListenerMixin#hvh$chatCommand).
 *
 *   .vclip <blocks>        move straight up (+) / down (-)
 *   .hclip <blocks>        move forward (+) / backward (-) along the direction you are looking
 *   .cfg save <name>       save the current modules / settings / theme as a profile
 *   .cfg load <name>       load a profile
 *   .cfg list              list saved profiles
 *
 * vclip / hclip only move the client position; the vanilla position packet follows on the next tick. Servers that
 * check movement will pull you back for long distances.
 */
public final class Commands {
    private static final Minecraft mc = Minecraft.getInstance();
    public static final String PREFIX = ".";
    private static final double MAX_CLIP = 200.0;

    private Commands() {}

    /** @return true when the message was a client command (and must not be sent to the server). */
    public static boolean handle(String raw) {
        if (raw == null) return false;
        String s = raw.trim();
        // ".word" is a command; "...", ".5" or a lone "." are normal chat
        if (s.length() < 2 || !s.startsWith(PREFIX) || !Character.isLetter(s.charAt(1))) return false;
        if (mc.player == null) return false;

        String[] a = s.substring(PREFIX.length()).split("\\s+");
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "vclip" -> vclip(a);
            case "hclip" -> hclip(a);
            case "proj" -> { for (String line : dev.hvh.client.util.Projector.report().split("\n")) info(line, ChatFormatting.GRAY); }
            case "cfg", "config" -> cfg(a);
            default -> info("Unknown command. Available: .vclip <blocks>, .hclip <blocks>, .cfg save|load <name>, .cfg list", ChatFormatting.RED);
        }
        return true;
    }

    // ---- .vclip / .hclip ----------------------------------------------------------------------------------------

    private static void vclip(String[] a) {
        Double blocks = clipArg(a, "vclip");
        if (blocks == null) return;
        LocalPlayer p = mc.player;
        p.setPos(p.getX(), p.getY() + blocks, p.getZ());
        p.setDeltaMovement(p.getDeltaMovement().x, 0.0, p.getDeltaMovement().z);
        info(String.format(Locale.ROOT, "VClip %+.2f blocks", blocks), ChatFormatting.GREEN);
    }

    private static void hclip(String[] a) {
        Double blocks = clipArg(a, "hclip");
        if (blocks == null) return;
        LocalPlayer p = mc.player;
        double yaw = Math.toRadians(p.getYRot());
        p.setPos(p.getX() - Math.sin(yaw) * blocks, p.getY(), p.getZ() + Math.cos(yaw) * blocks);
        p.setDeltaMovement(0.0, p.getDeltaMovement().y, 0.0);
        info(String.format(Locale.ROOT, "HClip %+.2f blocks", blocks), ChatFormatting.GREEN);
    }

    /** Parses "<blocks>" (comma or dot decimals); prints usage / errors and returns null when it is not usable. */
    private static Double clipArg(String[] a, String cmd) {
        if (a.length < 2) { info("Usage: ." + cmd + " <blocks>", ChatFormatting.RED); return null; }
        double v;
        try { v = Double.parseDouble(a[1].replace(',', '.')); }
        catch (NumberFormatException e) { info("'" + a[1] + "' is not a number. Usage: ." + cmd + " <blocks>", ChatFormatting.RED); return null; }
        if (Double.isNaN(v) || Double.isInfinite(v)) { info("Invalid number.", ChatFormatting.RED); return null; }
        if (Math.abs(v) > MAX_CLIP) { info("Maximum is " + (int) MAX_CLIP + " blocks.", ChatFormatting.RED); return null; }
        return v;
    }

    // ---- .cfg ---------------------------------------------------------------------------------------------------

    private static void cfg(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "save" -> {
                String name = name(a);
                if (name.isEmpty()) { info("Usage: .cfg save <name>", ChatFormatting.RED); return; }
                if (ConfigProfiles.save(name)) info("Config saved: " + name, ChatFormatting.GREEN);
                else info("Could not save config '" + name + "' (use letters, digits, space, _ or -).", ChatFormatting.RED);
            }
            case "load" -> {
                String name = name(a);
                if (name.isEmpty()) { info("Usage: .cfg load <name>", ChatFormatting.RED); return; }
                if (ConfigProfiles.load(name)) info("Config loaded: " + name, ChatFormatting.GREEN);
                else info("Config '" + name + "' not found or could not be loaded. See .cfg list", ChatFormatting.RED);
            }
            case "list" -> {
                List<String> names = ConfigProfiles.list();
                if (names.isEmpty()) info("No configs saved yet. Use .cfg save <name>", ChatFormatting.YELLOW);
                else info("Configs (" + names.size() + "): " + String.join(", ", names), ChatFormatting.AQUA);
            }
            default -> info("Usage: .cfg save <name> | .cfg load <name> | .cfg list", ChatFormatting.RED);
        }
    }

    /** Everything after "cfg <sub>" - profile names may contain spaces (ConfigProfiles turns them into "_"). */
    private static String name(String[] a) {
        return a.length > 2 ? String.join(" ", List.of(a).subList(2, a.length)).trim() : "";
    }

    // ---- output -------------------------------------------------------------------------------------------------

    private static void info(String text, ChatFormatting color) {
        if (mc.player == null) return;
        mc.player.displayClientMessage(
            Component.literal("[Nebula] ").withStyle(ChatFormatting.LIGHT_PURPLE)
                .append(Component.literal(text).withStyle(color)), false);
    }
}
