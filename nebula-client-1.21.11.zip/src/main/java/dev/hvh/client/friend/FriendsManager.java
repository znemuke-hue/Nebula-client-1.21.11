package dev.hvh.client.friend;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.world.entity.player.Player;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

/** Persistent friends list and client-only dyed-leather highlighting settings. */
public final class FriendsManager {
    private FriendsManager() {}

    public static final int DEFAULT_COLOR = 0x7CFC00; // lime
    private static final Pattern VALID_NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");
    private static final Map<String, Entry> FRIENDS = new LinkedHashMap<>();
    public static boolean highlightEnabled = false;
    public static int globalColor = DEFAULT_COLOR;

    public static final class Entry {
        public final String name;
        public boolean customColor;
        public int color = DEFAULT_COLOR;

        private Entry(String name) { this.name = name; }
    }

    private static String key(String name) {
        return name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
    }

    public static synchronized Collection<Entry> all() {
        return new ArrayList<>(FRIENDS.values());
    }

    public static synchronized Entry find(String name) {
        return FRIENDS.get(key(name));
    }

    public static synchronized boolean isFriend(String name) {
        return !key(name).isEmpty() && FRIENDS.containsKey(key(name));
    }

    public static boolean isFriend(Player player) {
        return player != null && isFriend(player.getName().getString());
    }

    public static synchronized boolean add(String name) {
        if (name == null) return false;
        String clean = name.trim();
        if (!VALID_NAME.matcher(clean).matches() || FRIENDS.containsKey(key(clean))) return false;
        FRIENDS.put(key(clean), new Entry(clean));
        save();
        return true;
    }

    public static synchronized void remove(String name) {
        FRIENDS.remove(key(name));
        save();
    }

    public static synchronized int colorFor(String name) {
        Entry entry = find(name);
        return entry != null && entry.customColor ? entry.color : globalColor;
    }

    public static synchronized boolean hasCustomColor(String name) {
        Entry entry = find(name);
        return entry != null && entry.customColor;
    }

    public static synchronized void setCustomColor(String name, boolean enabled) {
        Entry entry = find(name);
        if (entry == null) return;
        if (enabled && !entry.customColor) entry.color = globalColor;
        entry.customColor = enabled;
        save();
    }

    public static synchronized void setFriendColor(String name, int color) {
        Entry entry = find(name);
        if (entry != null) entry.color = color & 0xFFFFFF;
    }

    public static synchronized void setGlobalColor(int color) {
        globalColor = color & 0xFFFFFF;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("nebula-friends.properties");
    }

    public static synchronized void load() {
        FRIENDS.clear();
        highlightEnabled = false;
        globalColor = DEFAULT_COLOR;
        Path file = file();
        if (!Files.exists(file)) return;
        try (InputStream in = Files.newInputStream(file)) {
            Properties p = new Properties();
            p.load(in);
            highlightEnabled = Boolean.parseBoolean(p.getProperty("highlight.enabled", "false"));
            globalColor = parseColor(p.getProperty("color.global"), DEFAULT_COLOR);
            for (String property : p.stringPropertyNames()) {
                if (!property.startsWith("friend.") || !property.endsWith(".name")) continue;
                String prefix = property.substring(0, property.length() - "name".length());
                String name = p.getProperty(property, "").trim();
                if (!VALID_NAME.matcher(name).matches()) continue;
                Entry e = new Entry(name);
                e.customColor = Boolean.parseBoolean(p.getProperty(prefix + "custom", "false"));
                e.color = parseColor(p.getProperty(prefix + "color"), DEFAULT_COLOR);
                FRIENDS.put(key(name), e);
            }
        } catch (Exception ignored) {
            FRIENDS.clear();
            highlightEnabled = false;
            globalColor = DEFAULT_COLOR;
        }
    }

    public static synchronized void save() {
        try {
            Properties p = new Properties();
            p.setProperty("highlight.enabled", Boolean.toString(highlightEnabled));
            p.setProperty("color.global", String.format(Locale.ROOT, "%06X", globalColor & 0xFFFFFF));
            for (Entry e : FRIENDS.values()) {
                String prefix = "friend." + key(e.name) + ".";
                p.setProperty(prefix + "name", e.name);
                p.setProperty(prefix + "custom", Boolean.toString(e.customColor));
                p.setProperty(prefix + "color", String.format(Locale.ROOT, "%06X", e.color & 0xFFFFFF));
            }
            Files.createDirectories(file().getParent());
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Nebula Client friends and local armor colors"); }
        } catch (Exception ignored) {}
    }

    private static int parseColor(String value, int fallback) {
        if (value == null) return fallback;
        try { return Integer.parseInt(value.replace("#", "").trim(), 16) & 0xFFFFFF; }
        catch (Exception ignored) { return fallback; }
    }
}
