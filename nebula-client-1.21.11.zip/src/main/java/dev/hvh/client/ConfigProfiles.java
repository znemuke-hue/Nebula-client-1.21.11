package dev.hvh.client;

import dev.hvh.client.gui.Theme;
import dev.hvh.client.hud.Hud;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

/** Named Nebula profiles stored in config/nebula/configs/*.properties. */
public final class ConfigProfiles {
    private ConfigProfiles() {}
    private static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("nebula").resolve("configs"); }
    public static Path directory() { return dir(); }
    public static List<String> list() {
        try { Files.createDirectories(dir()); try (var s = Files.list(dir())) { return s.filter(p -> p.getFileName().toString().endsWith(".properties")).map(p -> p.getFileName().toString().replaceFirst("\\.properties$", "")).sorted().collect(Collectors.toList()); } }
        catch (Exception e) { return List.of(); }
    }
    private static String safe(String name) { String s = name == null ? "" : name.trim().replaceAll("[^A-Za-z0-9 _-]", "").replaceAll("\\s+", "_"); if (s.length() > 32) s = s.substring(0,32); return s; }
    public static String normalizeName(String name) { return safe(name); }
    private static Path file(String name) { return dir().resolve(safe(name) + ".properties"); }
    public static boolean save(String name) {
        String n = safe(name); if (n.isBlank()) return false;
        try {
            Files.createDirectories(dir()); Properties p = new Properties();
            for (Mod m : HvhClient.modules.all) {
                String k = "module." + m.name + "."; p.setProperty(k+"enabled", Boolean.toString(m.isEnabled())); p.setProperty(k+"bind", Integer.toString(m.bind));
                for (int i=0;i<m.settings.size();i++) { Setting<?> s=m.settings.get(i); p.setProperty(k+"setting."+i, String.valueOf(s.value)); }
            }
            p.setProperty("theme.mode", Theme.mode.name()); p.setProperty("theme.textColor",Integer.toHexString(Theme.TEXT&0xFFFFFF));
            for(int i=0;i<Theme.normal.length;i++) p.setProperty("theme.n"+i,Integer.toHexString(Theme.normal[i]));
            for(int i=0;i<Theme.grad.length;i++) p.setProperty("theme.g"+i,Integer.toHexString(Theme.grad[i]));
            p.setProperty("theme.blur",Double.toString(Theme.blurStrength)); p.setProperty("theme.angle",Double.toString(Theme.gradientAngle));
            p.setProperty("theme.guiBlur",Double.toString(Theme.guiBlurStrength)); p.setProperty("theme.moduleBlur",Double.toString(Theme.moduleBlurStrength)); p.setProperty("theme.hudBlur",Double.toString(Theme.hudBlurStrength));
            p.setProperty("theme.guiOpacity",Double.toString(Theme.guiOpacity)); p.setProperty("theme.moduleOpacity",Double.toString(Theme.moduleOpacity)); p.setProperty("theme.hudOpacity",Double.toString(Theme.hudOpacity));
            p.setProperty("theme.guiHighlight",Double.toString(Theme.guiHighlightStrength)); p.setProperty("theme.moduleHighlight",Double.toString(Theme.moduleHighlightStrength)); p.setProperty("theme.hudHighlight",Double.toString(Theme.hudHighlightStrength));
            p.setProperty("theme.menuOpacity",Double.toString(Theme.menuBackgroundOpacity));
            p.setProperty("theme.glowColor",Integer.toHexString(Theme.glowColor)); p.setProperty("theme.glow",Double.toString(Theme.glowStrength));
            p.setProperty("theme.scaleX",Double.toString(Theme.guiScaleX)); p.setProperty("theme.scaleY",Double.toString(Theme.guiScaleY));
            p.setProperty("theme.radius",Double.toString(Theme.cornerRadius)); p.setProperty("theme.outlineColor",Integer.toHexString(Theme.outlineColor)); p.setProperty("theme.outlineWidth",Double.toString(Theme.outlineWidth));
            p.setProperty("theme.outlineEnabled",Boolean.toString(Theme.outlineEnabled)); p.setProperty("theme.glowEnabled",Boolean.toString(Theme.glowEnabled));
            p.setProperty("theme.backgroundEnabled",Boolean.toString(Theme.backgroundEnabled)); p.setProperty("theme.loadingSeconds",Double.toString(Theme.loadingSeconds));
            p.setProperty("theme.hoverExpand",Double.toString(Theme.hoverExpand)); p.setProperty("theme.textScale",Double.toString(Theme.textScale)); p.setProperty("theme.modulesPerRow",Integer.toString(Theme.modulesPerRow));
            p.setProperty("theme.cornerTL",Boolean.toString(Theme.outlineTopLeft)); p.setProperty("theme.cornerTR",Boolean.toString(Theme.outlineTopRight));
            p.setProperty("theme.cornerBL",Boolean.toString(Theme.outlineBottomLeft)); p.setProperty("theme.cornerBR",Boolean.toString(Theme.outlineBottomRight));
            // CREATE + TRUNCATE_EXISTING makes repeated .cfg save <name> replace the same profile.
            try(OutputStream out=Files.newOutputStream(file(n), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) { p.store(out,"Nebula Client profile: "+n); }
            return true;
        } catch(Exception e) { return false; }
    }
    public static boolean load(String name) {
        try {
            Path f=file(name); if(!Files.isRegularFile(f)) return false; Properties p=new Properties(); try(InputStream in=Files.newInputStream(f)){p.load(in);}
            for(Mod m:HvhClient.modules.all) { String k="module."+m.name+"."; m.bind=Integer.parseInt(p.getProperty(k+"bind",Integer.toString(m.bind))); boolean enabled=Boolean.parseBoolean(p.getProperty(k+"enabled",Boolean.toString(m.isEnabled()))); if(enabled!=m.isEnabled()) m.setEnabled(enabled);
                for(int i=0;i<m.settings.size();i++){ Setting<?> s=m.settings.get(i); String v=p.getProperty(k+"setting."+i); if(v==null) continue; try { if(s instanceof Setting.Bool b) b.value=Boolean.parseBoolean(v); else if(s instanceof Setting.Num num) num.set(Double.parseDouble(v)); else if(s instanceof Setting.Key key) key.value=Integer.parseInt(v.trim()); else if(s instanceof Setting.Mode mode && List.of(mode.modes).contains(v)) mode.value=v; } catch(Exception ignored){} }
            }
            Theme.mode=Theme.Mode.valueOf(p.getProperty("theme.mode",Theme.mode.name()));
            for(int i=0;i<Theme.normal.length;i++) Theme.normal[i]=Integer.parseInt(p.getProperty("theme.n"+i,Integer.toHexString(Theme.normal[i])),16)&0xFFFFFF;
            for(int i=0;i<Theme.grad.length;i++) Theme.grad[i]=Integer.parseInt(p.getProperty("theme.g"+i,Integer.toHexString(Theme.grad[i])),16)&0xFFFFFF;
            Theme.blurStrength=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.blur",Double.toString(Theme.blurStrength))))); Theme.gradientAngle=Double.parseDouble(p.getProperty("theme.angle",Double.toString(Theme.gradientAngle)));
            Theme.guiBlurStrength=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.guiBlur",Double.toString(Theme.guiBlurStrength)))));
            Theme.moduleBlurStrength=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.moduleBlur",Double.toString(Theme.moduleBlurStrength)))));
            Theme.hudBlurStrength=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.hudBlur",Double.toString(Theme.hudBlurStrength)))));
            Theme.guiOpacity=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.guiOpacity",Double.toString(Theme.guiOpacity)))));
            Theme.moduleOpacity=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.moduleOpacity",Double.toString(Theme.moduleOpacity)))));
            Theme.hudOpacity=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.hudOpacity",Double.toString(Theme.hudOpacity)))));
            Theme.guiBackgroundOpacity=Theme.guiOpacity;
            Theme.guiHighlightStrength=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.guiHighlight",Double.toString(Theme.guiHighlightStrength)))));
            Theme.moduleHighlightStrength=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.moduleHighlight",Double.toString(Theme.moduleHighlightStrength)))));
            Theme.hudHighlightStrength=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.hudHighlight",Double.toString(Theme.hudHighlightStrength)))));
            Theme.menuBackgroundOpacity=Math.max(0.0,Math.min(1.0,Double.parseDouble(p.getProperty("theme.menuOpacity",Double.toString(Theme.menuBackgroundOpacity)))));
            Theme.glowColor=Integer.parseInt(p.getProperty("theme.glowColor",Integer.toHexString(Theme.glowColor)),16)&0xFFFFFF; Theme.glowStrength=Double.parseDouble(p.getProperty("theme.glow",Double.toString(Theme.glowStrength)));
            Theme.guiScaleX=Double.parseDouble(p.getProperty("theme.scaleX",Double.toString(Theme.guiScaleX))); Theme.guiScaleY=Double.parseDouble(p.getProperty("theme.scaleY",Double.toString(Theme.guiScaleY)));
            Theme.cornerRadius=Double.parseDouble(p.getProperty("theme.radius",Double.toString(Theme.cornerRadius))); Theme.outlineColor=Integer.parseInt(p.getProperty("theme.outlineColor",Integer.toHexString(Theme.outlineColor)),16)&0xFFFFFF; Theme.outlineWidth=Double.parseDouble(p.getProperty("theme.outlineWidth",Double.toString(Theme.outlineWidth)));
            Theme.outlineEnabled=Boolean.parseBoolean(p.getProperty("theme.outlineEnabled",Boolean.toString(Theme.outlineEnabled))); Theme.glowEnabled=Boolean.parseBoolean(p.getProperty("theme.glowEnabled",Boolean.toString(Theme.glowEnabled)));
            Theme.backgroundEnabled=Boolean.parseBoolean(p.getProperty("theme.backgroundEnabled",Boolean.toString(Theme.backgroundEnabled))); Theme.loadingSeconds=Double.parseDouble(p.getProperty("theme.loadingSeconds",Double.toString(Theme.loadingSeconds)));
            Theme.hoverExpand=Double.parseDouble(p.getProperty("theme.hoverExpand",Double.toString(Theme.hoverExpand))); Theme.textScale=Double.parseDouble(p.getProperty("theme.textScale",Double.toString(Theme.textScale))); Theme.modulesPerRow=Math.max(1,Math.min(4,Integer.parseInt(p.getProperty("theme.modulesPerRow",Integer.toString(Theme.modulesPerRow)))));
            Theme.outlineTopLeft=Boolean.parseBoolean(p.getProperty("theme.cornerTL",Boolean.toString(Theme.outlineTopLeft))); Theme.outlineTopRight=Boolean.parseBoolean(p.getProperty("theme.cornerTR",Boolean.toString(Theme.outlineTopRight)));
            Theme.outlineBottomLeft=Boolean.parseBoolean(p.getProperty("theme.cornerBL",Boolean.toString(Theme.outlineBottomLeft))); Theme.outlineBottomRight=Boolean.parseBoolean(p.getProperty("theme.cornerBR",Boolean.toString(Theme.outlineBottomRight)));
            try{Theme.setText(Integer.parseInt(p.getProperty("theme.textColor",Integer.toHexString(Theme.TEXT&0xFFFFFF)),16));}catch(Exception ignored){}
            Theme.save(); Config.save(); return true;
        } catch(Exception e) { return false; }
    }

    /** Imports an externally chosen properties/.cfg profile into the profiles folder. */
    public static String importFrom(Path source) {
        try {
            if (source == null || !Files.isRegularFile(source)) return null;
            String fileName = source.getFileName().toString();
            String lower = fileName.toLowerCase(java.util.Locale.ROOT);
            if (!lower.endsWith(".properties") && !lower.endsWith(".cfg")) return null;
            String base = fileName.substring(0, fileName.lastIndexOf('.'));
            String name = safe(base);
            if (name.isBlank()) return null;
            Files.createDirectories(dir());
            Path target = file(name);
            if (!source.toAbsolutePath().normalize().equals(target.toAbsolutePath().normalize())) {
                // Validate that the chosen file is readable as a Java-properties profile before importing it.
                Properties check = new Properties();
                try (InputStream in = Files.newInputStream(source)) { check.load(in); }
                Files.copy(source, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            return name;
        } catch (Exception e) { return null; }
    }
    public static boolean delete(String name) { try { return Files.deleteIfExists(file(name)); } catch(Exception e) { return false; } }
}
