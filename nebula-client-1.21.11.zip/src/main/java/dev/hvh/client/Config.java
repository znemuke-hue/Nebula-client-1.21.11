package dev.hvh.client;

import dev.hvh.client.hud.Hud;
import dev.hvh.client.module.Mod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saves module binds and HUD layout (position/scale of every element) to config/hvhclient-client.properties. */
public final class Config {
    private Config() {}

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("hvhclient-client.properties"); }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(file())) { p.load(in); }
            for (Mod m : HvhClient.modules.all) {
                String v = p.getProperty("bind." + m.name);
                if (v != null) m.bind = Integer.parseInt(v.trim());
                for (dev.hvh.client.setting.Setting<?> s : m.settings) {
                    if (s instanceof dev.hvh.client.setting.Setting.Key k) {
                        String kv = p.getProperty("keysetting." + m.name + "." + k.name);
                        if (kv != null) k.value = Integer.parseInt(kv.trim());
                        continue;
                    }
                    String sv = p.getProperty("setting." + m.name + "." + s.name);
                    if (sv == null) continue;
                    if (s instanceof dev.hvh.client.setting.Setting.Bool b) b.value = Boolean.parseBoolean(sv);
                    else if (s instanceof dev.hvh.client.setting.Setting.Num n) n.set(Double.parseDouble(sv));
                    else if (s instanceof dev.hvh.client.setting.Setting.Mode mode) {
                        for (String option : mode.modes) if (option.equals(sv)) { mode.value = option; break; }
                    }
                }
            }
            Hud.readLayout(p);
        } catch (Exception ignored) {}
    }

    public static void save() {
        try (OutputStream o = Files.newOutputStream(file())) {
            Properties p = new Properties();
            for (Mod m : HvhClient.modules.all) {
                if (m.bind >= 0) p.setProperty("bind." + m.name, Integer.toString(m.bind));
                for (dev.hvh.client.setting.Setting<?> s : m.settings) {
                    if (s instanceof dev.hvh.client.setting.Setting.Key k) {
                        if (k.value >= 0) p.setProperty("keysetting." + m.name + "." + k.name, Integer.toString(k.value));
                    } else if (s instanceof dev.hvh.client.setting.Setting.Bool b) {
                        p.setProperty("setting." + m.name + "." + s.name, Boolean.toString(b.value));
                    } else if (s instanceof dev.hvh.client.setting.Setting.Num n) {
                        p.setProperty("setting." + m.name + "." + s.name, Double.toString(n.value));
                    } else if (s instanceof dev.hvh.client.setting.Setting.Mode mode) {
                        p.setProperty("setting." + m.name + "." + s.name, mode.value);
                    }
                }
            }
            Hud.writeLayout(p);
            p.store(o, "Nebula Client");
        } catch (Exception ignored) {}
    }
}
