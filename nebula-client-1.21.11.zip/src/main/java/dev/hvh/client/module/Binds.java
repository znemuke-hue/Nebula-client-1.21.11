package dev.hvh.client.module;

import com.mojang.blaze3d.platform.InputConstants;
import dev.hvh.client.HvhClient;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/**
 * Module keybinds. Keys are polled (called every frame from the HUD and every tick) so quick taps are not missed.
 * Middle click on a module in the ClickGui starts capture (Binds.listening); the next key becomes the bind,
 * Backspace/Delete clears it, Esc cancels.
 */
public final class Binds {
    private static final Minecraft mc = Minecraft.getInstance();
    public static Mod listening;
    /** Key setting that is waiting for its key (clicked in the module's settings panel). */
    public static dev.hvh.client.setting.Setting.Key listeningSetting;

    private Binds() {}

    public static void poll() {
        if (HvhClient.modules == null) return;
        boolean inGame = mc.player != null && mc.screen == null;
        for (Mod m : HvhClient.modules.all) {
            if (m.bind < 0) m.bindDown = false;
            else {
                boolean down = InputConstants.isKeyDown(mc.getWindow(), m.bind);
                if (down && !m.bindDown && inGame) m.toggle();
                m.bindDown = down;
            }
            for (dev.hvh.client.setting.Setting<?> s : m.settings) {
                if (!(s instanceof dev.hvh.client.setting.Setting.Key k)) continue;
                if (k.value < 0) { k.down = false; continue; }
                boolean down = InputConstants.isKeyDown(mc.getWindow(), k.value);
                if (down && !k.down && inGame && m.isEnabled()) m.onKey(k);
                k.down = down;
            }
        }
    }

    public static String name(int key) {
        switch (key) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_ENTER: return "ENTER";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_BACKSPACE: return "BACKSPACE";
            case GLFW.GLFW_KEY_INSERT: return "INS";
            case GLFW.GLFW_KEY_DELETE: return "DEL";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_PAGE_UP: return "PGUP";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PGDN";
            case GLFW.GLFW_KEY_HOME: return "HOME";
            case GLFW.GLFW_KEY_END: return "END";
            case GLFW.GLFW_KEY_CAPS_LOCK: return "CAPS";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            default:
        }
        if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F25) return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
        String n = GLFW.glfwGetKeyName(key, 0);
        return n != null && !n.isEmpty() ? n.toUpperCase(java.util.Locale.ROOT) : "KEY" + key;
    }
}
