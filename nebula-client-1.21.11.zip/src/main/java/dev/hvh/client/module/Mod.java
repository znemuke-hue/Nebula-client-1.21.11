package dev.hvh.client.module;

import dev.hvh.client.setting.Setting;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;

public abstract class Mod {
    protected static final Minecraft mc = Minecraft.getInstance();
    public final String name;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    public boolean expanded;
    public int bind = -1;
    public boolean bindDown;

    protected Mod(String name, Category category) { this.name = name; this.category = category; }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }
    /** Adds a setting to a GUI section. */
    protected <S extends Setting<?>> S add(String group, S s) { s.group = group; return add(s); }
    /** Adds a setting to a GUI section; a Bool is shown there as a chip with this short text. */
    protected <S extends Setting<?>> S add(String group, String chip, S s) { s.group = group; s.chip = chip; return add(s); }

    /** Settings the GUI shows right now (some are hidden while the mode they belong to is not selected). */
    public List<Setting<?>> visibleSettings() {
        List<Setting<?>> out = new ArrayList<>(settings.size());
        for (Setting<?> s : settings) if (s.isVisible()) out.add(s);
        return out;
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (mc.player != null) dev.hvh.client.hud.Notifications.push(name, v ? "включён" : "выключен");
        dev.hvh.client.sound.ClientSounds.onModule(this, v);
        if (v) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onPreTick() {}
    public void onTick() {}
    /** Runs every rendered frame (before render). Use for smooth camera interpolation. */
    public void onFrame() {}
    public void onKey(dev.hvh.client.setting.Setting.Key key) {}
}