package dev.hvh.client.module;

public enum Category {
    ALL("All"), COMBAT("Бой"), MOVEMENT("Движение"), VISUALS("Визуалы"), WORLD("Мир"), PLAYER("Игрок"), MISC("Разное");
    public final String title;
    Category(String t) { title = t; }
}
