package dev.hvh.client.module;

import dev.hvh.client.modules.*;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Mod> all = new ArrayList<>();
    public final HudModule hud = new HudModule();
    public final Velocity velocity = new Velocity();
    public final Reach reach = new Reach();
    public final Hitboxes hitboxes = new Hitboxes();
    public final FullBright fullBright = new FullBright();
    public final Criticals criticals = new Criticals();
    public final KillAura killAura = new KillAura();
    public final TriggerBot triggerBot = new TriggerBot();
    public final AimAssist aimAssist = new AimAssist();
    public final TargetStrafe targetStrafe = new TargetStrafe();
    public final NoPush noPush = new NoPush();
    public final AutoTotem autoTotem = new AutoTotem();
    public final AutoSwap autoSwap = new AutoSwap();
    public final ClientSoundsMod clientSounds = new ClientSoundsMod();
    public final NoSlow noSlow = new NoSlow();
    public final GuiMove guiMove = new GuiMove();
    public final NoEffects noEffects = new NoEffects();
    public final TargetESP targetESP = new TargetESP();
    public final ESP esp = new ESP();
    public final BlockOutline blockOutline = new BlockOutline();
    public final Nametags nametags = new Nametags();
    public final NoRender noRender = new NoRender();
    public final NoOverlay noOverlay = new NoOverlay();
    public final Removals removals = new Removals();
    public final WorldAmbient worldAmbient = new WorldAmbient();
    public final Zoom zoom = new Zoom();
    public final CameraTweaks cameraTweaks = new CameraTweaks();
    public final Crosshair crosshair = new Crosshair();
    public final Trajectories trajectories = new Trajectories();

    public ModuleManager() {
        // Register modules here. One class = one module.
        all.add(hud);
        hud.setEnabled(true);
        all.add(clientSounds);
        all.add(noSlow);
        all.add(noEffects);
        all.add(targetESP);
        all.add(esp);
        all.add(blockOutline);
        all.add(nametags);
        all.add(noRender);
        all.add(noOverlay);
        all.add(removals);
        all.add(worldAmbient);
        all.add(zoom);
        all.add(new FreeLook());
        all.add(new FreeCam());
        all.add(cameraTweaks);
        all.add(crosshair);
        all.add(trajectories);
        clientSounds.setEnabled(true);
        all.add(criticals);
        all.add(killAura);
        all.add(triggerBot);
        all.add(aimAssist);
        all.add(autoTotem);
        all.add(autoSwap);
        all.add(hitboxes);
        all.add(velocity);
        all.add(new Sprint());
        all.add(guiMove);
        all.add(new Flight());
        all.add(new Strafe());
        all.add(new Speed());
        all.add(targetStrafe); // after Strafe and Speed: it overrides their velocity while it has a target
        all.add(new NoJumpDelay());
        all.add(reach);
        all.add(new Step());
        all.add(new Spider());
        all.add(new AirJump());
        all.add(new HighJump());
        all.add(new HighGravity());
        all.add(new NoFall());
        all.add(new FastUse());
        all.add(noPush);
        all.add(fullBright);
    }

    public List<Mod> in(Category c) {
        List<Mod> out = new ArrayList<>();
        for (Mod m : all) if (c == Category.ALL || m.category == c) out.add(m);
        return out;
    }

    @SuppressWarnings("unchecked")
    public <T extends Mod> T get(Class<T> c) {
        for (Mod m : all) if (c.isInstance(m)) return (T) m;
        return null;
    }

    public void preTick() {
        if (dev.hvh.client.modules.GuiMove.inputLocked()) return;
        for (Mod m : all) if (m.isEnabled()) m.onPreTick();
    }

    public void tick() {
        if (dev.hvh.client.modules.GuiMove.inputLocked()) return;
        for (Mod m : all) if (m.isEnabled()) m.onTick();
    }
    public void frame() {
        for (Mod m : all) if (m.isEnabled()) {
            try { m.onFrame(); } catch (Throwable t) { }
        }
    }

}
