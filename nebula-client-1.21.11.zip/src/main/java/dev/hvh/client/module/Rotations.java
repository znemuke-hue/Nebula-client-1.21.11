package dev.hvh.client.module;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/** Shared state for temporary gameplay rotations and the independent local camera view. */
public final class Rotations {
    private Rotations() {}

    public static boolean fix;
    public static float aimYaw, intentYaw;
    private static boolean lastFix;
    private static float lastIntent;

    private static boolean swapped;
    private static float camYaw, camPitch;
    private static float camYawO, camPitchO;
    private static boolean cameraOverridePending;
    private static boolean cameraOverrideForFrame;

    public static void setFix(float aim, float intent) { fix = true; aimYaw = aim; intentYaw = intent; }

    /**
     * Mouse input is applied to the saved local view while a module has temporarily swapped the player's angles.
     * The entity rotation itself stays untouched by the mouse event in that window.
     */
    public static boolean onTurn(double cursorDeltaX, double cursorDeltaY) {
        if (!swapped) return false;
        float oldYaw = camYaw, oldPitch = camPitch;
        camYaw += (float) cursorDeltaX * 0.15F;
        camPitch = Mth.clamp(camPitch + (float) cursorDeltaY * 0.15F, -90.0F, 90.0F);
        camYawO += camYaw - oldYaw;
        camPitchO += camPitch - oldPitch;
        return true;
    }

    /** Temporarily changes the player's gameplay rotation, preserving a separate view rotation for rendering. */
    public static void silent(Player p, float yaw, float pitch) {
        if (p == null) return;
        if (!swapped) {
            camYaw = p.getYRot();
            camPitch = p.getXRot();
            camYawO = p.yRotO;
            camPitchO = p.xRotO;
        }
        swapped = true;
        cameraOverridePending = true;
        p.setYRot(yaw);
        p.setXRot(pitch);
    }

    public static void beginRender() {
        cameraOverrideForFrame = cameraOverridePending || swapped;
        cameraOverridePending = false;
    }

    public static void endRender() { cameraOverrideForFrame = false; }

    /** True while temporary gameplay rotation is active and the rendered camera must use the local view. */
    public static boolean cameraOverrideActive() {
        return cameraOverrideForFrame || cameraOverridePending || swapped;
    }

    public static float cameraYaw(float vanilla, float partialTick) {
        return cameraOverrideActive() ? Mth.rotLerp(partialTick, camYawO, camYaw) : vanilla;
    }

    public static float cameraPitch(float vanilla, float partialTick) {
        return cameraOverrideActive() ? Mth.lerp(partialTick, camPitchO, camPitch) : vanilla;
    }

    public static void end(Player p) {
        lastFix = fix;
        lastIntent = intentYaw;
        fix = false;
        restoreCamera(p);
    }

    /** Restores the exact saved local view; never infer local pitch from the temporary aiming angle. */
    public static void restoreCamera(Player p) {
        if (!swapped) return;
        swapped = false;
        if (p == null) return;
        p.setYRot(camYaw);
        p.setXRot(camPitch);
        p.yRotO = camYawO;
        p.xRotO = camPitchO;
    }

    public static float moveYaw(Player p) { return lastFix ? lastIntent : p.getYRot(); }

    public static double[] inputDir(Player p) {
        double f = p.zza, s = p.xxa;
        if (f == 0 && s == 0) return null;
        double yaw = Math.toRadians(moveYaw(p));
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = s * cos - f * sin, z = f * cos + s * sin;
        double len = Math.sqrt(x * x + z * z);
        return len < 1.0E-4 ? null : new double[] { x / len, z / len };
    }
}
