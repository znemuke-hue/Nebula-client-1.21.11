package dev.hvh.client.setting;

public abstract class Setting<T> {
    public final String name;
    public T value;
    /** GUI section the setting belongs to ("Кого бить", "Не бить если", ...). Settings of one section are shown together. */
    public String group;
    /** Short text for the chip a Bool is shown as inside a section (null = the Bool stays a normal toggle row). */
    public String chip;
    /** The GUI (and only the GUI) hides the setting while this is false; its value is still saved and used. */
    private java.util.function.BooleanSupplier visible = () -> true;
    protected Setting(String name, T def) { this.name = name; this.value = def; }

    public void showWhen(java.util.function.BooleanSupplier v) { this.visible = v; }
    public boolean isVisible() { return visible.getAsBoolean(); }

    public static class Bool extends Setting<Boolean> {
        public Bool(String n, boolean d) { super(n, d); }
    }

    /** A button in the module's settings: runs something (e.g. opens a picker screen). */
    public static class Action extends Setting<Boolean> {
        public final Runnable run;
        public Action(String n, Runnable run) { super(n, false); this.run = run; }
    }

    /** A key bind inside a module's settings (GLFW key code, -1 = none). Click it in the GUI, then press a key. */
    public static class Key extends Setting<Integer> {
        public boolean down; // edge detection for Binds.poll()
        public Key(String n, int d) { super(n, d); }
    }

    public static class Num extends Setting<Double> {
        public final double min, max, step;
        public Num(String n, double d, double min, double max, double step) {
            super(n, d); this.min = min; this.max = max; this.step = step;
        }
        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            value = Math.round(v / step) * step;
        }
    }

    public static class Mode extends Setting<String> {
        public final String[] modes;
        public Mode(String n, String d, String... modes) { super(n, d); this.modes = modes; }
        public void next() {
            for (int i = 0; i < modes.length; i++)
                if (modes[i].equals(value)) { value = modes[(i + 1) % modes.length]; return; }
            value = modes[0]; // unknown value (renamed mode / old config): fall back instead of getting stuck
        }
    }
}
