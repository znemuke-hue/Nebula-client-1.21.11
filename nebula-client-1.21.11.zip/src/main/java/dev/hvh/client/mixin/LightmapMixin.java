package dev.hvh.client.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import dev.hvh.client.HvhClient;
import net.minecraft.client.renderer.LightTexture;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 1.21.11: the lightmap is LightTexture (26.x renamed it to Lightmap). */
@Mixin(LightTexture.class)
public abstract class LightmapMixin {
    @Shadow @Final private GpuTexture texture;
    /** Vanilla only recomputes the lightmap when this flag is set. */
    @Shadow private boolean updateLightTexture;

    /** FullBright (Gamma mode): fill the lightmap with pure white instead of computing it. */
    @Inject(method = "updateLightTexture", at = @At("HEAD"), cancellable = true)
    private void hvh$fullbright(float partialTick, CallbackInfo ci) {
        if (HvhClient.modules == null || !HvhClient.modules.fullBright.gamma()) return;
        RenderSystem.getDevice().createCommandEncoder().clearColorTexture(texture, -1);
        // make vanilla rebuild the real lightmap on the first frame after FullBright is switched off
        updateLightTexture = true;
        ci.cancel();
    }
}
