package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.NoSlow;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Hook 2 (fallback, independent of how Mojang implements the slowdown): the movement input that reaches travel()
 * for the local player has already been multiplied by 0.2 while using an item; scale it back up here.
 * Skipped when NoSlowMixin already removed the slowdown for this update.
 */
@Mixin(LivingEntity.class)
public abstract class NoSlowTravelMixin {
    @ModifyVariable(method = "travel", at = @At("HEAD"), argsOnly = true, require = 0)
    private Vec3 hvh$noSlowTravel(Vec3 input) {
        if ((Object) this != HvhClient.mc.player) return input;
        if (NoSlow.handled) { NoSlow.handled = false; return input; }
        double boost = NoSlow.boost(HvhClient.mc.player);
        if (boost <= 1.0) return input;
        return new Vec3(input.x * boost, input.y, input.z * boost);
    }
}
