package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.WorldAmbient;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * World Ambient hooks on Level. Every injection is optional (require = 0): a method that does not exist in the
 * running Minecraft version is skipped, the others still work. WorldAmbient#hit records which ones are alive.
 */
@Mixin(Level.class)
public abstract class LevelTimeMixin {
    /** Day time in ticks. 26.x may call it getDefaultClockTime; both names are long-returning. */
    @Inject(method = {"getDayTime", "getDefaultClockTime"}, at = @At("RETURN"), cancellable = true, require = 0)
    private void hvh$localWorldTime(CallbackInfoReturnable<Long> cir) {
        if (!((Object) this instanceof ClientLevel) || HvhClient.modules == null || HvhClient.modules.worldAmbient == null) return;
        WorldAmbient wa = HvhClient.modules.worldAmbient;
        if (!wa.isEnabled()) return;
        WorldAmbient.hit("Level.time");
        cir.setReturnValue(wa.overrideDayTime(cir.getReturnValue()));
    }

    @Inject(method = "getRainLevel", at = @At("RETURN"), cancellable = true, require = 0)
    private void hvh$localRain(float partialTick, CallbackInfoReturnable<Float> cir) {
        if (!((Object) this instanceof ClientLevel) || HvhClient.modules == null || HvhClient.modules.worldAmbient == null) return;
        WorldAmbient wa = HvhClient.modules.worldAmbient;
        if (!wa.isEnabled()) return;
        WorldAmbient.hit("Level.rain");
        cir.setReturnValue(wa.overrideRainLevel(cir.getReturnValue()));
    }

    @Inject(method = "getThunderLevel", at = @At("RETURN"), cancellable = true, require = 0)
    private void hvh$localThunder(float partialTick, CallbackInfoReturnable<Float> cir) {
        if (!((Object) this instanceof ClientLevel) || HvhClient.modules == null || HvhClient.modules.worldAmbient == null) return;
        WorldAmbient wa = HvhClient.modules.worldAmbient;
        if (!wa.isEnabled()) return;
        WorldAmbient.hit("Level.thunder");
        cir.setReturnValue(wa.overrideThunderLevel(cir.getReturnValue()));
    }
}
