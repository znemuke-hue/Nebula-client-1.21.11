package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.NoPush;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class NoPushPlayerMixin {
    /** Water: flowing water / lava does not carry you. */
    @Inject(method = "isPushedByFluid", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$noFluidPush(CallbackInfoReturnable<Boolean> cir) {
        if (HvhClient.modules == null || (Object) this != HvhClient.mc.player) return;
        NoPush np = HvhClient.modules.noPush;
        if (np.isEnabled() && np.water.value) cir.setReturnValue(false);
    }
}
