package dev.hvh.client.mixin;

import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(LivingEntity.class)
public interface LivingEntityAccessor {
    @Accessor("noJumpDelay") int hvh$getNoJumpDelay();
    @Accessor("noJumpDelay") void hvh$setNoJumpDelay(int v);
}
