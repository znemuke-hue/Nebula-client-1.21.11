package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.command.Commands;
import dev.hvh.client.modules.Velocity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundLoginPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Velocity. The packet handlers run twice (network thread -> re-queued on the main thread). We only
 * measure on the main-thread run (isSameThread) and scale whatever the vanilla handler added to the
 * player's motion when it returns.
 */
@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {
    @Unique private static Vec3 hvh$kbBefore;
    @Unique private static Vec3 hvh$exBefore;

    @Inject(method = "handleSetEntityMotion", at = @At("HEAD"))
    private void hvh$motionHead(ClientboundSetEntityMotionPacket packet, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        hvh$kbBefore = (mc.isSameThread() && p != null && packet.getId() == p.getId()) ? p.getDeltaMovement() : null;
    }

    @Inject(method = "handleSetEntityMotion", at = @At("RETURN"))
    private void hvh$motionReturn(ClientboundSetEntityMotionPacket packet, CallbackInfo ci) {
        Vec3 before = hvh$kbBefore;
        hvh$kbBefore = null;
        LocalPlayer p = Minecraft.getInstance().player;
        if (before == null || p == null || HvhClient.modules == null) return;
        Velocity v = HvhClient.modules.velocity;
        if (!v.isEnabled() || !v.knockback.value) return;
        Vec3 delta = p.getDeltaMovement().subtract(before);
        p.setDeltaMovement(before.add(delta.multiply(v.kbH.value, v.kbV.value, v.kbH.value)));
    }

    @Inject(method = "handleExplosion", at = @At("HEAD"))
    private void hvh$explosionHead(ClientboundExplodePacket packet, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        hvh$exBefore = (mc.isSameThread() && mc.player != null) ? mc.player.getDeltaMovement() : null;
    }

    @Inject(method = "handleExplosion", at = @At("RETURN"))
    private void hvh$explosionReturn(ClientboundExplodePacket packet, CallbackInfo ci) {
        Vec3 before = hvh$exBefore;
        hvh$exBefore = null;
        LocalPlayer p = Minecraft.getInstance().player;
        if (before == null || p == null || HvhClient.modules == null) return;
        Velocity v = HvhClient.modules.velocity;
        if (!v.isEnabled() || !v.explosions.value) return;
        Vec3 delta = p.getDeltaMovement().subtract(before);
        p.setDeltaMovement(before.add(delta.multiply(v.exH.value, v.exV.value, v.exH.value)));
    }

    /** Client Sounds: totem pop (entity event 35). Main-thread run only. */
    @Inject(method = "handleEntityEvent", at = @At("HEAD"), require = 0)
    private void hvh$entityEvent(ClientboundEntityEventPacket packet, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (!mc.isSameThread() || mc.level == null || packet.getEventId() != 35) return;
        dev.hvh.client.sound.ClientSounds.onTotemPop(packet.getEntity(mc.level));
    }

    /** Client Sounds: joined a world / server. */
    @Inject(method = "handleLogin", at = @At("RETURN"), require = 0)
    private void hvh$login(ClientboundLoginPacket packet, CallbackInfo ci) {
        if (Minecraft.getInstance().isSameThread()) dev.hvh.client.sound.ClientSounds.onJoin();
    }

    /** Chat commands (.vclip / .hclip / .cfg): a handled ".command" never reaches the server. */
    @Inject(method = "sendChat", at = @At("HEAD"), cancellable = true)
    private void hvh$chatCommand(String message, CallbackInfo ci) {
        if (Commands.handle(message)) ci.cancel();
    }
}
