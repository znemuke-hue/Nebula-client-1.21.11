package dev.hvh.client.mixin;

import dev.hvh.client.modules.GuiMove;
import net.minecraft.client.multiplayer.ClientCommonPacketListenerImpl;
import net.minecraft.network.protocol.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Captures the actual vanilla container-click packet after the local menu has been predicted. */
@Mixin(ClientCommonPacketListenerImpl.class)
public abstract class ClientCommonPacketListenerMixin {
    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void hvh$guiMovePacket(Packet<?> packet, CallbackInfo ci) {
        if (GuiMove.interceptOutgoing(packet)) ci.cancel();
    }
}
