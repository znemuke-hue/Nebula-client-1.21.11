package dev.hvh.client.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Minecraft.class)
public interface MinecraftAccessor {
    @Accessor("rightClickDelay") int hvh$getRightClickDelay();
    @Accessor("rightClickDelay") void hvh$setRightClickDelay(int v);
}
