package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.NoPush;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public abstract class NoPushLocalPlayerMixin {
    /** Walls: being inside / against a block does not push you out of it. */
    @Inject(method = "moveTowardsClosestSpace", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$noWallPush(double x, double z, CallbackInfo ci) {
        if (HvhClient.modules == null) return;
        NoPush np = HvhClient.modules.noPush;
        if (np.isEnabled() && np.walls.value) ci.cancel();
    }
}
