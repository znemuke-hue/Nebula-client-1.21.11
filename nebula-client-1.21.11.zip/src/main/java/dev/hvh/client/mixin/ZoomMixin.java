package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.Zoom;
import dev.hvh.client.util.Projector;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class ZoomMixin {
    /**
     * Zoom + field-of-view capture. The return type differs between versions (float / double), so the value is
     * handled as a Number and written back with the same boxed type it came in with.
     */
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void hvh$zoom(CallbackInfoReturnable<Object> cir) {
        Object ret = cir.getReturnValue();
        if (!(ret instanceof Number n)) return;
        double v = n.doubleValue();
        Zoom z = HvhClient.modules == null ? null : HvhClient.modules.zoom;
        if (z != null && z.isEnabled()) {
            v = z.apply(v);
            Object boxed = ret instanceof Float ? (Object) Float.valueOf((float) v) : (Object) Double.valueOf(v);
            cir.setReturnValue(boxed);
        }
        Projector.onFov(v);
    }
}
