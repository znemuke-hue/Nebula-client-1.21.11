package dev.hvh.client.mixin;

import dev.hvh.client.modules.GuiMove;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Advances GuiMove's FIFO state machine without cancelling vanilla physics ticks.
 * During the two stop phases GuiMove blocks outgoing packets, while normal gravity and
 * friction continue so existing momentum is not erased or artificially frozen.
 */
@Mixin(value = Minecraft.class, priority = 1200)
public abstract class MinecraftTickMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void hvh$guiMoveQueueTick(CallbackInfo ci) {
        GuiMove.handleClientTickHead();
    }

    /** Vanilla keybind handling dereferences player while processing use-item state. During disconnect
     * transitions some launchers briefly tick with no player; skip only keybind handling for that tick. */
    @Inject(method = "handleKeybinds", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$skipKeybindsWithoutPlayer(CallbackInfo ci) {
        if (net.minecraft.client.Minecraft.getInstance().player == null) ci.cancel();
    }
}
