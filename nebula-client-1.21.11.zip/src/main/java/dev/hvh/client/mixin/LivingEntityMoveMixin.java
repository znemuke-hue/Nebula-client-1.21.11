package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Rotations;
import dev.hvh.client.modules.TargetStrafe;
import dev.hvh.client.util.SprintGate;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMoveMixin {
    /**
     * Movement correction (KillAura): re-express WASD relative to the aim yaw and snap it to
     * one of the eight server-valid directional combinations.
     */
    @ModifyVariable(method = "travel", at = @At("HEAD"), argsOnly = true, require = 0)
    private Vec3 hvh$moveFix(Vec3 input) {
        if ((Object) this != HvhClient.mc.player) return input;
        // TargetStrafe sets the exact velocity itself: drop the key acceleration so it is not bent off the circle.
        if (TargetStrafe.active) return new Vec3(0.0, input.y, 0.0);
        if (!Rotations.fix) { SprintGate.moveHold = false; return input; }
        double mag = Math.max(Math.abs(input.x), Math.abs(input.z));     // 0.98, or less while sneaking / using an item
        double d = Math.toRadians(Rotations.intentYaw - Rotations.aimYaw);
        if (mag < 1.0E-4 || Math.abs(d) < 1.0E-4) { SprintGate.moveHold = false; return input; }

        // the direction you meant, as an angle relative to the aim yaw (x = strafe, z = forward, like the input itself)
        double s = Math.sin(d), c = Math.cos(d);
        double want = Math.atan2(input.x * c - input.z * s, input.z * c + input.x * s);

        double best = Double.MAX_VALUE; int bx = 0, bz = 0;
        for (int kx = -1; kx <= 1; kx++) for (int kz = -1; kz <= 1; kz++) {
            if (kx == 0 && kz == 0) continue;
            double diff = Math.abs(Mth.wrapDegrees(Math.toDegrees(Math.atan2(kx, kz) - want)));
            if (diff < best - 1.0E-6 || (Math.abs(diff - best) <= 1.0E-6 && kz > bz)) { best = diff; bx = kx; bz = kz; }   // tie: prefer W
        }
        boolean noForward = bz <= 0;
        SprintGate.moveHold = noForward;
        if (noForward && HvhClient.mc.player.isSprinting()) HvhClient.mc.player.setSprinting(false);
        return new Vec3(bx * mag, input.y, bz * mag);
    }
}
