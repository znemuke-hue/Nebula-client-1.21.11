package dev.hvh.client.mixin;

import dev.hvh.client.modules.NoSlow;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

/**
 * Hook 1 (exact): the 0.2 multiplier vanilla applies to movement input while using an item. Only the player's own
 * input method is targeted, so no unrelated 0.2 constant can be touched. When this hook fires it tells
 * NoSlowTravelMixin (hook 2, a method-name independent fallback) not to compensate a second time.
 */
@Mixin(LocalPlayer.class)
public abstract class NoSlowMixin {
    @ModifyConstant(method = "modifyInput", constant = @Constant(floatValue = 0.2F), require = 0)
    private float hvh$removeUseSlowdown(float original) {
        double boost = NoSlow.boost((LocalPlayer) (Object) this);
        if (boost <= 1.0) return original;
        NoSlow.handled = true;
        return (float) (original * boost);
    }
}
