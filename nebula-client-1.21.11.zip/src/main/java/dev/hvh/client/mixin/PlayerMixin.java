package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.Reach;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class PlayerMixin {
    @Inject(method = "entityInteractionRange", at = @At("RETURN"), cancellable = true)
    private void hvh$entityReach(CallbackInfoReturnable<Double> cir) {
        if (HvhClient.modules == null || (Object) this != HvhClient.mc.player) return;
        Reach r = HvhClient.modules.reach;
        if (r.isEnabled()) cir.setReturnValue(Math.max(0, cir.getReturnValue() + r.entityExtra()));
    }

    @Inject(method = "blockInteractionRange", at = @At("RETURN"), cancellable = true)
    private void hvh$blockReach(CallbackInfoReturnable<Double> cir) {
        if (HvhClient.modules == null || (Object) this != HvhClient.mc.player) return;
        Reach r = HvhClient.modules.reach;
        if (r.isEnabled()) cir.setReturnValue(Math.max(0, cir.getReturnValue() + r.blockExtra()));
    }
}
