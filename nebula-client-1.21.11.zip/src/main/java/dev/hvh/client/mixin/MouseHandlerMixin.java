package dev.hvh.client.mixin;

import dev.hvh.client.hud.Hud;
import dev.hvh.client.modules.GuiMove;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import java.nio.file.Path;
import java.util.List;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Inject(method = "onButton", at = @At("HEAD"), cancellable = true)
    private void hvh$guiMoveMouseButton(long window, MouseButtonInfo input, int action, CallbackInfo ci) {
        if (GuiMove.inputLocked()) { GuiMove.silenceInput(); ci.cancel(); }
    }
    @Inject(method = "onDrop", at = @At("HEAD"), cancellable = true)
    private void hvh$guiMoveDrop(long window, List<Path> paths, int invalidFilesCount, CallbackInfo ci) {
        if (GuiMove.inputLocked()) ci.cancel();
    }
    @Inject(method = "turnPlayer", at = @At("HEAD"), cancellable = true)
    private void hvh$guiMoveTurn(double timeDelta, CallbackInfo ci) {
        if (GuiMove.inputLocked()) ci.cancel();
    }
    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void hvh$scroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
        if (GuiMove.inputLocked() || Hud.onScroll(yOffset)) ci.cancel();
    }
}
