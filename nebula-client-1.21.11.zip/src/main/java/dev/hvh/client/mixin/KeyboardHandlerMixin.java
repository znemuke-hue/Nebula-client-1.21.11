package dev.hvh.client.mixin;

import dev.hvh.client.modules.GuiMove;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Drops all keyboard events while GuiMove drains its queue. */
@Mixin(KeyboardHandler.class)
public abstract class KeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    private void hvh$guiMoveKey(long window, int action, KeyEvent event, CallbackInfo ci) {
        if (GuiMove.inputLocked()) {
            GuiMove.silenceInput();
            ci.cancel();
        }
    }

    @Inject(method = "charTyped", at = @At("HEAD"), cancellable = true)
    private void hvh$guiMoveCharacter(long window, CharacterEvent event, CallbackInfo ci) {
        if (GuiMove.inputLocked()) ci.cancel();
    }
}
