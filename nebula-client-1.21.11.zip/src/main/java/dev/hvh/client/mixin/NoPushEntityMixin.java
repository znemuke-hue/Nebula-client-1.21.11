package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.NoPush;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class NoPushEntityMixin {
    /** Entities: other entities (players, mobs, boats...) can not shove you around. */
    @Inject(method = "push(Lnet/minecraft/world/entity/Entity;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$noEntityPush(Entity other, CallbackInfo ci) {
        if (HvhClient.modules == null || (Object) this != HvhClient.mc.player) return;
        NoPush np = HvhClient.modules.noPush;
        if (np.isEnabled() && np.entities.value) ci.cancel();
    }
}
