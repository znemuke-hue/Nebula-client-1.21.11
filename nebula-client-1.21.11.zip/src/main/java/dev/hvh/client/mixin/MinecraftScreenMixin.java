package dev.hvh.client.mixin;

import dev.hvh.client.modules.GuiMove;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** GuiMove lifecycle hook. Never cancel vanilla screen changes: disconnect, death,
 * respawn and connection screens must be allowed to initialize even while a queue drains. */
@Mixin(Minecraft.class)
public abstract class MinecraftScreenMixin {
    @Inject(method = "setScreen", at = @At("RETURN"))
    private void hvh$screenChanged(Screen screen, CallbackInfo ci) {
        GuiMove.onScreenChanged();
    }
}
