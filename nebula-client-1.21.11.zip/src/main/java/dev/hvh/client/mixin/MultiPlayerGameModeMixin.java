package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.hud.Hud;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "attack", at = @At("HEAD"))
    private void hvh$attack(Player player, Entity target, CallbackInfo ci) {
        if (HvhClient.modules == null || player != HvhClient.mc.player) return;
        Hud.hit(target);
        if (HvhClient.modules.criticals.isEnabled()) HvhClient.modules.criticals.onAttack(target);
    }
}
