package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import net.minecraft.client.gui.Gui;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hides the vanilla crosshair only while Nebula's replacement is enabled. */
@Mixin(Gui.class)
public abstract class CrosshairMixin {
    @Inject(method = {"renderCrosshair", "extractCrosshair"}, at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$hideVanillaCrosshair(CallbackInfo ci) {
        if (HvhClient.modules != null && HvhClient.modules.crosshair != null && HvhClient.modules.crosshair.isEnabled()) ci.cancel();
    }
}
