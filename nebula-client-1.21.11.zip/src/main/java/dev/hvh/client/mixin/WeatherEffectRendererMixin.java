package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import net.minecraft.client.renderer.WeatherEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WeatherEffectRenderer.class)
public abstract class WeatherEffectRendererMixin {
    // The method is overloaded in 26.2. A callback without captured parameters works for both overloads.
    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$hideWeather(CallbackInfo ci) {
        if (HvhClient.modules != null && HvhClient.modules.noRender != null && HvhClient.modules.noRender.hideWeather()) ci.cancel();
    }
}
