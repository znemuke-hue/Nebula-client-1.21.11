package dev.hvh.client.mixin;

import dev.hvh.client.util.SprintGate;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(LivingEntity.class)
public abstract class LivingEntitySprintMixin {
    /** SprintGate: the local player cannot start sprinting while a W-tap is running. */
    @ModifyVariable(method = "setSprinting", at = @At("HEAD"), argsOnly = true, require = 0)
    private boolean hvh$sprintGate(boolean sprinting) {
        if (sprinting && (SprintGate.hold || SprintGate.moveHold) && (Object) this == Minecraft.getInstance().player) return false;
        return sprinting;
    }
}
