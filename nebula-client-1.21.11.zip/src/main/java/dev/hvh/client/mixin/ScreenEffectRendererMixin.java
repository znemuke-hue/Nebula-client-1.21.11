package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.NoRender;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenEffectRenderer.class)
public abstract class ScreenEffectRendererMixin {
    // Mojang renamed renderScreenEffect to submit in the 26.x rendering refactor; require=0 keeps minor API variants safe.
    @Inject(method = {"submit", "renderScreenEffect"}, at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$hideScreenOverlay(CallbackInfo ci) {
        if (HvhClient.modules != null && HvhClient.modules.noOverlay != null && HvhClient.modules.noOverlay.hideOverlays()) {
            ci.cancel();
            return;
        }
        // Lets NoRender drop only the fire overlay (see EntityMixin#hvh$noFireOverlay) while water/in-wall stay vanilla.
        NoRender.inScreenEffects = true;
    }

    @Inject(method = {"submit", "renderScreenEffect"}, at = @At("RETURN"), require = 0)
    private void hvh$endScreenOverlay(CallbackInfo ci) {
        NoRender.inScreenEffects = false;
    }
}
