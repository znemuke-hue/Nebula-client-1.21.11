package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import net.minecraft.client.particle.ParticleEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleEngine.class)
public abstract class ParticleEngineMixin {
    @Inject(method = {"extract", "render"}, at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$hideParticleExtraction(CallbackInfo ci) {
        if (HvhClient.modules != null && HvhClient.modules.noRender != null && HvhClient.modules.noRender.hideParticles()) ci.cancel();
    }
}
