package dev.hvh.client.mixin;

import dev.hvh.client.modules.CameraTweaks;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** CameraTweaks: дистанция камеры от третьего лица. require = 0 - если в этой версии метод называется иначе, хук просто не сработает. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyVariable(method = "getMaxZoom", at = @At("HEAD"), argsOnly = true, require = 0)
    private float hvh$cameraDistance(float maxZoom) {
        return CameraTweaks.distanceFor(maxZoom);
    }

    /** "Сквозь блоки": вместо проверки столкновений камера сразу получает нужную дистанцию. */
    @Inject(method = "getMaxZoom", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$cameraNoClip(float maxZoom, CallbackInfoReturnable<Float> cir) {
        if (CameraTweaks.clip()) cir.setReturnValue(CameraTweaks.distanceFor(maxZoom));
    }
}
