package dev.hvh.client.mixin;

import dev.hvh.client.friend.FriendsManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.DyedItemColor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Tints only the client-side render state of registered friends; no equipment or packets are changed. */
@Mixin(AvatarRenderer.class)
public abstract class FriendArmorRenderMixin {
    @Inject(method = "extractRenderState", at = @At("RETURN"), require = 1)
    private void hvh$dyedFriendArmor(Avatar entity, AvatarRenderState state, float partialTick, CallbackInfo ci) {
        if (!FriendsManager.highlightEnabled || !(entity instanceof Player player)) return;
        Minecraft client = Minecraft.getInstance();
        if (player == client.player || !FriendsManager.isFriend(player)) return;
        // The Friends-tab mannequin is a detached RemotePlayer used only for GUI rendering;
        // its armor is controlled by the selected preview color, not by the live-world friend filter.
        if (client.level == null || client.level.getEntity(player.getId()) != player) return;

        int color = FriendsManager.colorFor(player.getName().getString());
        state.headEquipment = dyed(Items.LEATHER_HELMET, color);
        state.chestEquipment = dyed(Items.LEATHER_CHESTPLATE, color);
        state.legsEquipment = dyed(Items.LEATHER_LEGGINGS, color);
        state.feetEquipment = dyed(Items.LEATHER_BOOTS, color);
    }

    private static ItemStack dyed(Item item, int color) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.DYED_COLOR, new DyedItemColor(color & 0xFFFFFF));
        return stack;
    }
}
