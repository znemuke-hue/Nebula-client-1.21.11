package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.GlassBlur;
import dev.hvh.client.module.Rotations;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    /** NoRender: skips the big totem-of-undying animation in front of the screen. */
    @Inject(method = "displayItemActivation", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$noTotemAnimation(CallbackInfo ci) {
        if (HvhClient.modules != null && HvhClient.modules.noRender != null && HvhClient.modules.noRender.hideTotemAnimation()) ci.cancel();
    }

    /**
     * Every frame BEFORE the camera is drawn:
     *  0) beginRender — remember the real partial tick of this frame (HvhClient.framePartial)
     *  1) restoreCamera — give real camera back after silent aim
     *  2) modules.frame() — smooth aim interpolation (AimAssist / KillAura onFrame)
     */
    @Inject(method = "render", at = @At("HEAD"), require = 1)
    private void hvh$frameHook(net.minecraft.client.DeltaTracker deltaTracker, boolean renderLevel, CallbackInfo ci) {
        GlassBlur.beginFrame();
        HvhClient.beginRender(deltaTracker);   // real partial tick of THIS frame, before any module reads it
        if (HvhClient.mc.player != null) {
            Rotations.restoreCamera(HvhClient.mc.player);
        }
        Rotations.beginRender();
        if (HvhClient.modules != null) {
            HvhClient.modules.frame();
        }
        dev.hvh.client.modules.FreeLook.beginFrame();   // FreeLook: the frame is drawn from the camera rotation
        dev.hvh.client.modules.FreeCam.beginFrame();    // FreeCam: the frame is drawn from the free camera (position + rotation)
    }

    /** FreeLook: the real player rotation comes back right after the frame (the server never sees the camera rotation). */
    @Inject(method = "render", at = @At("RETURN"), require = 1)
    private void hvh$frameEnd(net.minecraft.client.DeltaTracker deltaTracker, boolean renderLevel, CallbackInfo ci) {
        dev.hvh.client.modules.FreeCam.endFrame();      // (reverse order of beginFrame)
        dev.hvh.client.modules.FreeLook.endFrame();
        Rotations.endRender();
    }
}
