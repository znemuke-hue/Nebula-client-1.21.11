package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.modules.Hitboxes;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    /** Removals hides selected entities on the client without deleting them from world simulation. */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$removeVisualEntity(CallbackInfoReturnable<Boolean> cir) {
        if (HvhClient.modules == null) return;
        if (HvhClient.modules.removals != null && HvhClient.modules.removals.shouldHide((Entity) (Object) this)) { cir.setReturnValue(false); return; }
        if (HvhClient.modules.noRender != null && HvhClient.modules.noRender.shouldHide((Entity) (Object) this)) cir.setReturnValue(false);
    }

    /** NoRender: the burning animation drawn on entities (including yourself in third person). */
    @Inject(method = "displayFireAnimation", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$noEntityFire(CallbackInfoReturnable<Boolean> cir) {
        if (HvhClient.modules != null && HvhClient.modules.noRender != null && HvhClient.modules.noRender.hideEntityFire()) cir.setReturnValue(false);
    }

    /** NoRender: the fire overlay in front of the camera is chosen from isOnFire() while screen effects are drawn. */
    @Inject(method = "isOnFire", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$noFireOverlay(CallbackInfoReturnable<Boolean> cir) {
        if (!dev.hvh.client.modules.NoRender.inScreenEffects || HvhClient.modules == null || HvhClient.modules.noRender == null) return;
        if (HvhClient.modules.noRender.hideFireOverlay() && (Object) this == net.minecraft.client.Minecraft.getInstance().player) cir.setReturnValue(false);
    }

    /** NoEffects: your own glowing outline (set by an entity flag, so removing the effect alone is not enough). */
    @Inject(method = "isCurrentlyGlowing", at = @At("HEAD"), cancellable = true, require = 0)
    private void hvh$noOwnGlow(CallbackInfoReturnable<Boolean> cir) {
        if (HvhClient.modules == null || HvhClient.modules.noEffects == null) return;
        if ((Object) this == net.minecraft.client.Minecraft.getInstance().player && HvhClient.modules.noEffects.hideGlow()) cir.setReturnValue(false);
    }

    /** FreeCam / FreeLook: while on, the mouse turns only the camera; the real player rotation (what the server sees) stays put. */
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void hvh$freeLookTurn(double yRot, double xRot, CallbackInfo ci) {
        if ((Object) this != net.minecraft.client.Minecraft.getInstance().player) return;
        if (dev.hvh.client.module.Rotations.onTurn(yRot, xRot)
            || dev.hvh.client.modules.FreeCam.onTurn(yRot, xRot)
            || dev.hvh.client.modules.FreeLook.onTurn(yRot, xRot)) ci.cancel();
    }

    /** Hitboxes: bigger pick radius = easier to hit / target the entity. */
    @Inject(method = "getPickRadius", at = @At("HEAD"), cancellable = true)
    private void hvh$pickRadius(CallbackInfoReturnable<Float> cir) {
        if (HvhClient.modules == null) return;
        Hitboxes hb = HvhClient.modules.hitboxes;
        if (!hb.isEnabled()) return;
        double v = hb.expandFor((Entity) (Object) this);
        if (v != 0) cir.setReturnValue((float) v);
    }
}
