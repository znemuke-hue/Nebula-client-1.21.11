package dev.hvh.client.mixin;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Rotations;
import dev.hvh.client.modules.FreeCam;
import dev.hvh.client.modules.FreeLook;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * Separates the view used by Camera.setup from the temporary rotation used during a gameplay tick.
 * We replace the arguments of Camera's FIRST setRotation call. Doing this at the camera's own
 * rotation setter is more reliable than redirecting Entity getters: the same setup method can use
 * other rotation getters or apply a second rotation for front-facing third-person view.
 */
@Mixin(Camera.class)
public abstract class CameraRotationMixin {
    @Shadow private Entity entity;

    @ModifyArgs(
        method = "setup",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/Camera;setRotation(FF)V",
            ordinal = 0
        ),
        require = 1
    )
    private void hvh$useLocalCameraRotation(Args args) {
        if (HvhClient.mc.player == null || entity != HvhClient.mc.player) return;
        if (FreeCam.active() || FreeLook.active() || !Rotations.cameraOverrideActive()) return;

        float partialTick = HvhClient.framePartial();
        float vanillaYaw = (float) args.get(0);
        float vanillaPitch = (float) args.get(1);
        args.set(0, Rotations.cameraYaw(vanillaYaw, partialTick));
        args.set(1, Rotations.cameraPitch(vanillaPitch, partialTick));
    }
}
