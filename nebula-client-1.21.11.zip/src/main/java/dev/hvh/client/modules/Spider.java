package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;

/** Climb walls while pushing into them. */
public class Spider extends Mod {
    private final Setting.Num speed = add(new Setting.Num("Скорость", 0.2, 0.05, 1, 0.05));

    public Spider() { super("Spider", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || !p.horizontalCollision || p.onClimbable()) return;
        var v = p.getDeltaMovement();
        p.setDeltaMovement(v.x, speed.value, v.z);
    }
}
