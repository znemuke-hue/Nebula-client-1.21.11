package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.MaceItem;

/**
 * No Fall: tells the server you are on the ground once you have fallen far enough to take damage.
 *
 * Own fall tracker: the client's p.fallDistance is reset to 0 every tick while creative-style flight is on (Flight in
 * "Abilities" mode), but the SERVER keeps counting the drop from the position packets - so after flying down and
 * touching the ground you used to die. We therefore count the real downward movement ourselves and use whichever of
 * the two values is bigger.
 *
 * Mace smash: the onGround spoof resets the server-side fall distance, and the mace's bonus damage is calculated from
 * it. While a mace is in your hand and a living entity is close enough to be hit, the spoof is paused so the smash
 * keeps its damage (a mace hit also cancels your own fall damage). If you miss and land anyway you take normal fall
 * damage - turn "Удар булавой" off if you would rather always be safe.
 */
public class NoFall extends Mod {
    private final Setting.Bool maceSmash = add("Булава", "Удар булавой", new Setting.Bool("Удар булавой", true));
    private final Setting.Num maceRange = add("Булава", new Setting.Num("Дистанция цели для булавы", 5.0, 3.0, 12.0, 0.5));

    private static final double TRIGGER = 2.0; // fall damage starts after 3 blocks, spoof a bit earlier
    private static final double MACE_MIN = 1.5; // the smash needs more than 1.5 blocks of fall

    private double fall;           // our own fall tracker (blocks)
    private double lastY = Double.NaN;

    public NoFall() { super("No Fall", Category.MOVEMENT); }

    @Override protected void onEnable() { fall = 0; lastY = Double.NaN; }

    @Override public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { lastY = Double.NaN; return; }

        double y = p.getY();
        double dy = Double.isNaN(lastY) ? 0 : y - lastY;
        lastY = y;

        // Same conditions that reset the fall distance in vanilla (ground, fluids, ladders, riding) + elytra.
        if (p.onGround() || p.isInWater() || p.isInLava() || p.onClimbable() || p.isPassenger() || p.isFallFlying()) {
            fall = 0;
            return;
        }
        if (dy < 0) fall -= dy; // vanilla only counts the downward part

        double dist = Math.max(fall, p.fallDistance);
        if (dist <= TRIGGER) return;

        // Do not wipe the server's fall distance while a mace smash is possible.
        if (maceSmash.value && dist > MACE_MIN && p.getMainHandItem().getItem() instanceof MaceItem && targetNear(p)) return;

        p.connection.send(new ServerboundMovePlayerPacket.StatusOnly(true, false));
    }

    private boolean targetNear(Player p) {
        double r = maceRange.value;
        return !mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
            e -> e != p && e.isAlive() && !e.isSpectator() && p.distanceTo(e) <= r).isEmpty();
    }
}
