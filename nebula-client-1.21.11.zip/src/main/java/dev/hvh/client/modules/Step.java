package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.entity.ai.attributes.Attributes;

/** Walk up blocks without jumping (step height attribute). */
public class Step extends Mod {
    private final Setting.Num height = add(new Setting.Num("Высота", 1.0, 0.6, 20, 0.1));
    private double previous = 0.6;

    public Step() { super("Step", Category.MOVEMENT); }

    @Override protected void onEnable() {
        if (mc.player != null) previous = mc.player.getAttribute(Attributes.STEP_HEIGHT).getBaseValue();
    }

    @Override public void onTick() {
        if (mc.player != null) mc.player.getAttribute(Attributes.STEP_HEIGHT).setBaseValue(height.value);
    }

    @Override protected void onDisable() {
        if (mc.player != null) mc.player.getAttribute(Attributes.STEP_HEIGHT).setBaseValue(previous);
    }
}
