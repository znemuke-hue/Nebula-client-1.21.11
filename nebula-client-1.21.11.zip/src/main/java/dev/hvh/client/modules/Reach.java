package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;

/** Extra interaction range added in PlayerMixin. */
public class Reach extends Mod {
    private final Setting.Num entity = add(new Setting.Num("Дистанция до сущностей", 1.0, 0, 3, 0.1));
    private final Setting.Num block = add(new Setting.Num("Дистанция до блоков", 0.0, 0, 4, 0.1));

    public Reach() { super("Reach", Category.PLAYER); }

    public double entityExtra() { return entity.value; }
    public double blockExtra() { return block.value; }
}
