package dev.hvh.client.modules;

import dev.hvh.client.hud.Notifications;
import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.ActionLock;
import dev.hvh.client.util.InvUtil;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Auto Totem.
 *
 * Обычный: when health drops to the set value (or lower) and the offhand holds no usable totem, a totem from the
 *          inventory is swapped in. Plain totems first, enchanted ones only when no plain one is left.
 * Система: the same swap, plus the logic of the System client: gold hearts count as health, the totem is also taken
 *          when a crystal / active TNT / incoming trident is near or you are falling, elytra flight has its own HP,
 *          and the swap waits while you are using an item or a firework is in the offhand.
 *
 * Every swap goes through ActionLock: for 4 ticks everything that could count as a Multi Action is stopped, the click
 * is sent inside that quiet window, and afterwards the keys you are still holding are pressed again.
 */
public class AutoTotem extends Mod {
    private static final String NORMAL = "Обычный", SYSTEM = "Система";

    public final Setting.Mode mode = add(new Setting.Mode("Режим", NORMAL, NORMAL, SYSTEM));
    public final Setting.Num health = add(new Setting.Num("Здоровье", 6, 1, 20, 1));
    public final Setting.Bool checkEnchanted = add(new Setting.Bool("Проверять зачарование", true));
    public final Setting.Bool checkCooldown = add(new Setting.Bool("Учитывать задержку", false));

    public final Setting.Bool goldHearts = add(new Setting.Bool("Золотые сердца", true));
    public final Setting.Bool noEat = add(new Setting.Bool("Не свапать при еде", true));
    public final Setting.Bool noFireworks = add(new Setting.Bool("Без фейерверков", false));
    public final Setting.Bool crystals = add(new Setting.Bool("Кристаллы рядом", true));
    public final Setting.Bool tridents = add(new Setting.Bool("Трезубец (15 блоков)", true));
    public final Setting.Bool tnt = add(new Setting.Bool("ТНТ рядом", true));
    public final Setting.Num tntRadius = add(new Setting.Num("Радиус ТНТ", 6, 1, 16, 0.5));
    public final Setting.Bool fall = add(new Setting.Bool("Падение", false));
    public final Setting.Bool elytra = add(new Setting.Bool("Элитра", false));
    public final Setting.Num elytraHealth = add(new Setting.Num("HP c элитрой", 10, 0, 20, 0.5));

    private int lastSwapTick = -10;
    private int retryTick = -1;   // after a failed swap: no new attempt before this tick (never freeze you in a loop)
    private long lastWarn;        // "no totem" is reported at most every 3 seconds

    public AutoTotem() {
        super("Auto Totem", Category.COMBAT);
        goldHearts.showWhen(this::system);
        noEat.showWhen(this::system);
        noFireworks.showWhen(this::system);
        crystals.showWhen(this::system);
        tridents.showWhen(this::system);
        tnt.showWhen(this::system);
        tntRadius.showWhen(() -> system() && tnt.value);
        fall.showWhen(this::system);
        elytra.showWhen(this::system);
        elytraHealth.showWhen(() -> system() && elytra.value);
    }

    private boolean system() { return SYSTEM.equals(mode.value); }

    /** HP threshold: the elytra value while gliding in Система mode, otherwise the normal one. */
    private float threshold(LocalPlayer p) {
        return system() && elytra.value && p.isFallFlying() ? elytraHealth.value.floatValue() : health.value.floatValue();
    }

    /** Health the threshold is compared with; gold hearts count only in Система mode. */
    private float hpNow(LocalPlayer p) {
        return p.getHealth() + (system() && goldHearts.value ? p.getAbsorptionAmount() : 0f);
    }

    /** True when the totem should be in the offhand right now: low health, or a threat in Система mode. */
    private boolean wantsSwap(LocalPlayer p) {
        return hpNow(p) <= threshold(p) || threat(p);
    }

    /** Система only: something dangerous is near, so the totem is taken before the hit lands. */
    private boolean threat(LocalPlayer p) {
        if (!system()) return false;
        if (crystals.value && !mc.level.getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(6.0)).isEmpty()) return true;
        if (tnt.value) {
            double r = tntRadius.value;
            for (PrimedTnt t : mc.level.getEntitiesOfClass(PrimedTnt.class, p.getBoundingBox().inflate(r)))
                if (t.distanceToSqr(p) <= r * r) return true;
        }
        if (tridents.value) {
            for (Projectile t : mc.level.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(15.0)))
                if (t.getType() == EntityType.TRIDENT && t.getOwner() != p) return true;
        }
        return fall.value && !p.onGround() && !p.isFallFlying() && p.fallDistance > 10.0;
    }

    /** Система only: the swap waits while you eat / use an item, or a firework is in the offhand. */
    private boolean blocked(LocalPlayer p) {
        if (!system()) return false;
        if (noEat.value && p.isUsingItem()) return true;
        return noFireworks.value && p.getOffhandItem().is(Items.FIREWORK_ROCKET);
    }

    /** True while Auto Totem is working: Auto Swap stays out of the offhand. */
    public boolean active() {
        LocalPlayer p = mc.player;
        return isEnabled() && p != null && wantsSwap(p);
    }

    private boolean onCooldown(LocalPlayer p, ItemStack s) {
        return checkCooldown.value && p.getCooldowns().isOnCooldown(s);
    }

    @Override protected void onEnable() { lastSwapTick = -10; retryTick = -1; }

    @Override protected void onDisable() { if (ActionLock.ownedBy(name)) ActionLock.cancel(); }

    @Override public void onPreTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || !p.isAlive()) return;
        // p.tickCount restarts from 0 after a respawn / new world: stale values would block every swap for a long time
        if (p.tickCount < lastSwapTick) lastSwapTick = -10;
        if (p.tickCount + 40 < retryTick) retryTick = -1;
        if (!wantsSwap(p) || blocked(p)) return;
        if (p.tickCount - lastSwapTick < 2) return; // one swap per ~2 ticks, lets the server sync the slot

        int slot = pick(p);
        if (slot < 0) {
            if (noTotemLeft(p)) warn("нет тотема в инвентаре");
            return;
        }

        if (ActionLock.ownedBy(name)) return;                 // already preparing
        if (ActionLock.active) ActionLock.cancel();           // a (less urgent) Auto Swap lock: the totem goes first
        if (p.tickCount < retryTick) return;
        if (!InvUtil.canClick()) { warn("нельзя свапнуть: открыт контейнер / нет доступа к клику"); return; }
        if (!ActionLock.request(name, this::swap)) warn("свап занят другим действием");
    }

    /** Runs inside the quiet window: everything is looked at again, the situation may have changed while waiting. */
    private boolean swap() {
        LocalPlayer p = mc.player;
        if (p == null || !p.isAlive() || !wantsSwap(p) || blocked(p)) return false;
        int slot = pick(p);
        ItemStack off = p.getOffhandItem();
        boolean saving = off.is(Items.TOTEM_OF_UNDYING) && off.hasFoil();   // an enchanted totem goes back to the inventory
        if (slot >= 0 && InvUtil.swapToOffhand(slot)) {
            lastSwapTick = p.tickCount;
            Notifications.push(name, saving ? "зачарованный тотем сохранён" : "тотем в левой руке");
            return true;
        }
        retryTick = p.tickCount + 20;
        warn("свап не удался");
        return false;
    }

    /** True when the offhand holds no usable totem and the inventory has none to bring (nothing for pick() to do). */
    private boolean noTotemLeft(LocalPlayer p) {
        ItemStack off = p.getOffhandItem();
        if (off.is(Items.TOTEM_OF_UNDYING) && !onCooldown(p, off)) return false;
        return findTotem(p) < 0;
    }

    private void warn(String text) {
        long now = System.currentTimeMillis();
        if (now - lastWarn < 3000L) return;
        lastWarn = now;
        Notifications.push(name, text);
    }

    /** Inventory index of the totem that has to go to the offhand right now, or -1 when nothing has to be swapped. */
    private int pick(LocalPlayer p) {
        ItemStack off = p.getOffhandItem();
        if (off.is(Items.TOTEM_OF_UNDYING) && !onCooldown(p, off)) {
            // a usable totem is already there; only an enchanted one is replaced (by a plain one), to save it
            if (checkEnchanted.value && off.hasFoil()) return findPlain(p);
            return -1;
        }
        return findTotem(p);
    }

    private int findPlain(LocalPlayer p) {
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (!s.isEmpty() && s.is(Items.TOTEM_OF_UNDYING) && !s.hasFoil() && !onCooldown(p, s)) return i;
        }
        return -1;
    }

    /** Inventory index (hotbar first, then main inventory) of the totem to use, or -1. */
    private int findTotem(LocalPlayer p) {
        int firstAny = -1, firstPlain = -1, firstEnchanted = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.isEmpty() || !s.is(Items.TOTEM_OF_UNDYING) || onCooldown(p, s)) continue;
            if (firstAny < 0) firstAny = i;
            if (s.hasFoil()) { if (firstEnchanted < 0) firstEnchanted = i; }
            else if (firstPlain < 0) firstPlain = i;
        }
        if (!checkEnchanted.value) return firstAny;
        return firstPlain >= 0 ? firstPlain : firstEnchanted; // plain first, enchanted afterwards
    }
}
