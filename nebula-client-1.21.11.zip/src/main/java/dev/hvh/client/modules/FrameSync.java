package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;

/**
 * FrameSync (порт из Javafiles/FrameSync.java).
 * Ограничивает FPS частотой обновления монитора. В оригинале лимитер жил в нативном рендер-цикле
 * (accumulatedNanos / frameIntervalNanos), здесь используется штатный лимит кадров игры:
 * при включении запоминается старое значение, при выключении возвращается.
 */
public final class FrameSync extends Mod {
    private static final int VANILLA_MAX = 260;   // 260 в слайдере ванильных настроек = "без лимита"
    private int saved = -1;

    public FrameSync() { super("FrameSync", Category.VISUALS); }

    @Override protected void onEnable() {
        if (mc.options == null) return;
        saved = mc.options.framerateLimit().get();
        mc.options.framerateLimit().set(Math.min(refreshRate(), VANILLA_MAX));
    }

    @Override protected void onDisable() {
        if (mc.options == null || saved < 0) return;
        mc.options.framerateLimit().set(saved);
        saved = -1;
    }

    /** Частота монитора, на котором сейчас окно (fallback - основной монитор, потом 60). */
    public static int refreshRate() {
        try {
            long win = mc.getWindow().handle();
            long mon = GLFW.glfwGetWindowMonitor(win);
            if (mon == 0L) mon = GLFW.glfwGetPrimaryMonitor();
            GLFWVidMode vm = mon == 0L ? null : GLFW.glfwGetVideoMode(mon);
            if (vm != null && vm.refreshRate() > 0) return vm.refreshRate();
        } catch (Throwable ignored) { }
        return 60;
    }
}
