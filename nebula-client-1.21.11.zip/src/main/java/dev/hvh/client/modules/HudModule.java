package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;

/** Master switch + per-element toggles for the Nebula HUD (drawn by dev.hvh.client.hud.Hud). */
public class HudModule extends Mod {
    public final Setting.Bool watermark = add(new Setting.Bool("Водяной знак", true));
    public final Setting.Bool info = add(new Setting.Bool("Информационная панель", true));
    public final Setting.Bool coords = add(new Setting.Bool("Координаты", true));
    public final Setting.Bool modules = add(new Setting.Bool("Список биндов", true));
    public final Setting.Bool swapItems = add(new Setting.Bool("Предметы (ZXCV)", true));
    public final Setting.Bool cooldown = add(new Setting.Bool("Кулдаун атаки", true));
    public final Setting.Bool potions = add(new Setting.Bool("Эффекты зелий", true));
    public final Setting.Bool target = add(new Setting.Bool("Интерфейс цели", true));
    public final Setting.Bool team = add(new Setting.Bool("Команда", true));
    public final Setting.Bool inventory = add(new Setting.Bool("Инвентарь", true));
    public final Setting.Bool notifications = add(new Setting.Bool("Уведомления", true));

    public HudModule() { super("HUD", Category.VISUALS); }
}
