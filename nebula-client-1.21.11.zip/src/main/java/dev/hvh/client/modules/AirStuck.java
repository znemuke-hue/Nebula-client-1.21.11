package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.Keys;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

/**
 * AirStuck (порт из Javafiles/AirStuck.java, режим Vanilla).
 * Замораживает скорость и гравитацию - ты висишь в воздухе. При выключении скорость возвращается.
 *
 * Режим "Packet" из оригинала - нативный, в Java его логики нет, поэтому не портирован.
 * Счётчики стека (registerAirStuck / airStuckCounter...) - внутренняя кухня нативной части, тоже не нужны.
 */
public final class AirStuck extends Mod {
    private static final long KICK_PROTECTION_NANOS = 28_000_000_000L;

    public final Setting.Bool fallCheck = add(new Setting.Bool("Только в воздухе", true));
    /** В оригинале это читалось из внешней настройки "ft" (которой нет в самом модуле) - здесь это обычная галочка. */
    public final Setting.Bool kickProtection = add(new Setting.Bool("Защита от кика (28с)", false));

    private Vec3 savedVelocity = Vec3.ZERO;
    private long enableTime;

    public AirStuck() { super("AirStuck", Category.MOVEMENT); }

    @Override public void setEnabled(boolean v) {
        var p = mc.player;
        if (v && fallCheck.value && p != null && p.onGround()) {
            p.displayClientMessage(Component.literal("§cВам нужно находиться в воздухе"), false);
            return;
        }
        super.setEnabled(v);
    }

    @Override protected void onEnable() {
        var p = mc.player;
        if (p == null) return;
        enableTime = System.nanoTime();
        savedVelocity = p.getDeltaMovement();
        p.setNoGravity(true);
    }

    @Override protected void onDisable() {
        var p = mc.player;
        if (p == null) return;
        p.setNoGravity(false);
        giveKeysBack();
        if (fallCheck.value && p.onGround()) return;       // как в оригинале: на земле старую скорость не возвращаем
        p.setDeltaMovement(savedVelocity);
    }

    /** Начало тика: ввод обнуляется до того, как игрок его прочитает, иначе он разгонялся бы от нажатых клавиш. */
    @Override public void onPreTick() {
        var p = mc.player;
        if (p == null) return;
        var o = mc.options;
        for (KeyMapping k : new KeyMapping[] { o.keyUp, o.keyDown, o.keyLeft, o.keyRight, o.keyJump, o.keySprint, o.keyShift }) k.setDown(false);
        p.setSprinting(false);
        p.setDeltaMovement(Vec3.ZERO);
        p.setNoGravity(true);
    }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (kickProtection.value && System.nanoTime() - enableTime >= KICK_PROTECTION_NANOS) {
            p.displayClientMessage(Component.literal("§c[AirStuck] Автоматически выключен (защита от кика)"), false);
            setEnabled(false);
            return;
        }
        p.setDeltaMovement(Vec3.ZERO);
        p.setNoGravity(true);
    }

    private void giveKeysBack() {
        if (mc.screen != null) return;
        var o = mc.options;
        for (KeyMapping k : new KeyMapping[] { o.keyUp, o.keyDown, o.keyLeft, o.keyRight, o.keyJump, o.keySprint, o.keyShift })
            if (!k.isDown() && Keys.physical(k)) k.setDown(true);
    }
}
