package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;

/** Disables the vanilla first-person screen overlay layer (fire/liquid/powder-snow/block overlays). */
public final class NoOverlay extends Mod {
    public final Setting.Bool screenOverlays = add(new Setting.Bool("Убрать оверлеи экрана", true));
    public NoOverlay() { super("NoOverlay", Category.VISUALS); }
    public boolean hideOverlays() { return isEnabled() && screenOverlays.value; }
}
