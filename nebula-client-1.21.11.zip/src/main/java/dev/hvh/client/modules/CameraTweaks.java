package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;

/**
 * CameraTweaks (порт из Javafiles/CameraTweaks.java).
 * Дистанция камеры от третьего лица, опция "сквозь блоки" и плавный выезд камеры.
 * Хук: CameraMixin (Camera#getMaxZoom).
 */
public final class CameraTweaks extends Mod {
    public final Setting.Num distance = add(new Setting.Num("Дистанция", 4.0, 0.0, 20.0, 0.5));
    public final Setting.Bool clipThrough = add(new Setting.Bool("Сквозь блоки", false));
    public final Setting.Num animationMs = add(new Setting.Num("Анимация (мс)", 0, 0, 2000, 50));

    private double current = 4.0, from = 4.0, lastTarget = Double.NaN;
    private long changeTime;

    public CameraTweaks() { super("CameraTweaks", Category.VISUALS); }

    @Override protected void onEnable() { current = from = distance.value; lastTarget = Double.NaN; }

    /** Каждый кадр: от первого лица цель 0 (камера "внутри" головы), от третьего - заданная дистанция. */
    @Override public void onFrame() {
        boolean third = mc.options != null && !mc.options.getCameraType().isFirstPerson();
        double target = third ? distance.value : 0.0;
        if (Double.isNaN(lastTarget)) { lastTarget = target; current = target; }
        if (target != lastTarget) { from = current; lastTarget = target; changeTime = System.nanoTime(); }
        double ms = animationMs.value;
        if (ms <= 0.0) { current = target; return; }
        double k = Math.min(1.0, (System.nanoTime() - changeTime) / 1.0E6 / ms);
        current = from + (target - from) * k;
    }

    // ---- вызывается из CameraMixin ----

    public static float distanceFor(float vanilla) {
        CameraTweaks m = HvhClient.modules == null ? null : HvhClient.modules.cameraTweaks;
        return m != null && m.isEnabled() ? (float) Math.max(0.0, m.current) : vanilla;
    }

    public static boolean clip() {
        CameraTweaks m = HvhClient.modules == null ? null : HvhClient.modules.cameraTweaks;
        return m != null && m.isEnabled() && m.clipThrough.value;
    }
}
