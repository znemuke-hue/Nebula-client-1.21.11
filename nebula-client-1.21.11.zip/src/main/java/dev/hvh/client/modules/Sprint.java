package dev.hvh.client.modules;

import dev.hvh.client.module.*;

/** Keeps you sprinting while moving forward (same conditions as vanilla: food, collisions, water). */
public class Sprint extends Mod {
    public Sprint() { super("Sprint", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || (mc.screen != null && !GuiMove.passing()) || p.isPassenger()) return;
        float forward = (float) (p.zza * NoSlow.boost(p)); // NoSlow: zza is still the slowed value while using an item
        if (forward <= (p.isUnderWater() ? 1.0E-5F : 0.8F)) return;
        boolean ok = !p.isInShallowWater()
            && !p.isMobilityRestricted()
            && p.getFoodData().hasEnoughFood()
            && (!p.horizontalCollision || p.minorHorizontalCollision);
        if (ok) p.setSprinting(true);
    }
}
