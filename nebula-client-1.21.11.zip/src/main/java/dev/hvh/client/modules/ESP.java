package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.Draw;
import dev.hvh.client.gui.Theme;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * Screen-space projected entity ESP. Since it is drawn in a final HUD layer, it is not depth-tested
 * and therefore remains visible through walls and other entities. The 3D box geometry is projected
 * from the entity's bounding box, rather than using Minecraft's glowing flag.
 */
public final class ESP extends Mod {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final String[] COLORS = {"Красный", "Оранжевый", "Жёлтый", "Зелёный", "Бирюзовый", "Синий", "Фиолетовый", "Розовый", "Белый", "По теме"};

    public final Setting.Mode mode = add(new Setting.Mode("Режим", "3D-бокс", "3D-бокс", "2D-бокс"));
    public final Setting.Bool players = add(new Setting.Bool("Игроки", true));
    public final Setting.Bool items = add(new Setting.Bool("Предметы на земле", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Мобы и животные", false));
    public final Setting.Bool invisible = add(new Setting.Bool("Невидимые сущности", true));
    public final Setting.Bool ignoreSelf = add(new Setting.Bool("Показывать себя", false));
    public final Setting.Num maxDistance = add(new Setting.Num("Дистанция", 96, 8, 256, 8));

    public final Setting.Bool playerFill = add(new Setting.Bool("Заливка игроков", true));
    public final Setting.Mode playerFillColor = add(new Setting.Mode("Цвет заливки игроков", "Фиолетовый", COLORS));
    public final Setting.Num playerFillAlpha = add(new Setting.Num("Прозрачность заливки игроков", 28, 0, 100, 1));
    public final Setting.Mode playerOutlineColor = add(new Setting.Mode("Цвет контура игроков", "Розовый", COLORS));
    public final Setting.Num playerOutlineWidth = add(new Setting.Num("Толщина контура игроков", 1.5, 0.5, 4, 0.5));

    public final Setting.Bool itemFill = add(new Setting.Bool("Заливка предметов", true));
    public final Setting.Mode itemFillColor = add(new Setting.Mode("Цвет заливки предметов", "Бирюзовый", COLORS));
    public final Setting.Num itemFillAlpha = add(new Setting.Num("Прозрачность заливки предметов", 24, 0, 100, 1));
    public final Setting.Mode itemOutlineColor = add(new Setting.Mode("Цвет контура предметов", "Зелёный", COLORS));
    public final Setting.Num itemOutlineWidth = add(new Setting.Num("Толщина контура предметов", 1.5, 0.5, 4, 0.5));

    public final Setting.Bool otherFill = add(new Setting.Bool("Заливка мобов", true));
    public final Setting.Mode otherFillColor = add(new Setting.Mode("Цвет заливки мобов", "Оранжевый", COLORS));
    public final Setting.Mode otherOutlineColor = add(new Setting.Mode("Цвет контура мобов", "Жёлтый", COLORS));
    public final Setting.Num otherFillAlpha = add(new Setting.Num("Прозрачность заливки мобов", 22, 0, 100, 1));
    public final Setting.Num otherOutlineWidth = add(new Setting.Num("Толщина контура мобов", 1.5, 0.5, 4, 0.5));

    public ESP() { super("ESP", Category.VISUALS); }

    public static void render(GuiGraphics g) {
        if (HvhClient.modules == null || MC.player == null || MC.level == null || MC.options.hideGui) return;
        ESP esp = HvhClient.modules.esp;
        if (esp == null || !esp.isEnabled() || MC.screen != null) return;
        // 3D Box is rendered in world space by ESPWorldRenderer. The HUD renderer remains only for 2D Box.
        if (!esp.mode.value.equals("2D-бокс")) return;

        double range = esp.maxDistance.value;
        // Keep the nearest eligible entities in a fixed-size heap; avoid rendering the first world-list entries only.
        PriorityQueue<Entity> nearest = new PriorityQueue<>(128,
            (a, b) -> Double.compare(b.distanceToSqr(MC.player), a.distanceToSqr(MC.player)));
        for (Entity candidate : MC.level.getEntitiesOfClass(Entity.class,
                MC.player.getBoundingBox().inflate(range), e -> e != MC.player || esp.ignoreSelf.value)) {
            if (!esp.eligible2D(candidate, range)) continue;
            if (nearest.size() < 128) nearest.add(candidate);
            else if (candidate.distanceToSqr(MC.player) < nearest.peek().distanceToSqr(MC.player)) {
                nearest.poll(); nearest.add(candidate);
            }
        }
        List<Entity> entities = new ArrayList<>(nearest);
        entities.sort(Comparator.comparingDouble(e -> e.distanceToSqr(MC.player)));
        int sw = MC.getWindow().getGuiScaledWidth();
        int sh = MC.getWindow().getGuiScaledHeight();
        int rendered = 0;
        float pt = HvhClient.partialTick();
        for (Entity entity : entities) {
            if (rendered >= 128) break;
            if (entity.isRemoved() || entity == MC.getCameraEntity() && MC.options.getCameraType().isFirstPerson()) continue;
            if (!esp.invisible.value && entity.isInvisible()) continue;
            double dist = entity.distanceTo(MC.player);
            if (dist > range) continue;
            boolean isPlayer = entity instanceof Player && entity != MC.player;
            boolean isItem = entity instanceof ItemEntity;
            boolean isOther = entity instanceof LivingEntity && !(entity instanceof Player);
            if (isPlayer && !esp.players.value || isItem && !esp.items.value || isOther && !esp.mobs.value) continue;
            if (!(isPlayer || isItem || isOther || entity == MC.player && esp.ignoreSelf.value)) continue;
            int fillBase, outlineBase;
            double alpha, lineWidth;
            boolean fill;
            if (isPlayer || entity == MC.player) {
                fillBase = esp.color(esp.playerFillColor.value, entity, true);
                outlineBase = esp.color(esp.playerOutlineColor.value, entity, false);
                alpha = esp.playerFillAlpha.value / 100.0;
                lineWidth = esp.playerOutlineWidth.value;
                fill = esp.playerFill.value;
            } else if (isItem) {
                fillBase = esp.color(esp.itemFillColor.value, entity, true);
                outlineBase = esp.color(esp.itemOutlineColor.value, entity, false);
                alpha = esp.itemFillAlpha.value / 100.0;
                lineWidth = esp.itemOutlineWidth.value;
                fill = esp.itemFill.value;
            } else {
                fillBase = esp.color(esp.otherFillColor.value, entity, true);
                outlineBase = esp.color(esp.otherOutlineColor.value, entity, false);
                alpha = esp.otherFillAlpha.value / 100.0;
                lineWidth = esp.otherOutlineWidth.value;
                fill = esp.otherFill.value;
            }
            AABB b = dev.hvh.client.util.Interp.box(entity, pt);
            if (!projectBounds(b, sw, sh)) continue;
            int fillColor = withAlpha(fillBase, alpha);
            int outlineColor = 0xFF000000 | (outlineBase & 0xFFFFFF);
            double minX=PROJECTED_BOUNDS[0], minY=PROJECTED_BOUNDS[1], maxX=PROJECTED_BOUNDS[2], maxY=PROJECTED_BOUNDS[3];
            int x = (int)Math.floor(minX), y = (int)Math.floor(minY);
            int w = Math.max(1, (int)Math.ceil(maxX) - x), h = Math.max(1, (int)Math.ceil(maxY) - y);
            if (fill) g.fill(x, y, x + w, y + h, fillColor);
            // GuiGraphics outlines are batched HUD commands: no per-pixel loop for each edge.
            int stroke = Math.max(1, Math.min(4, (int)Math.round(lineWidth)));
            for (int i = 0; i < stroke && w - i * 2 > 0 && h - i * 2 > 0; i++) {
                g.renderOutline(x + i, y + i, w - i * 2, h - i * 2, outlineColor);
            }
            rendered++;
        }
    }

    private boolean eligible2D(Entity entity, double range) {
        if (entity == null || entity.isRemoved()) return false;
        if (entity == MC.getCameraEntity() && MC.options.getCameraType().isFirstPerson()) return false;
        if (!invisible.value && entity.isInvisible()) return false;
        if (entity.distanceToSqr(MC.player) > range * range) return false;
        boolean player = entity instanceof Player && entity != MC.player;
        boolean item = entity instanceof ItemEntity;
        boolean mob = entity instanceof LivingEntity && !(entity instanceof Player);
        boolean self = entity == MC.player && ignoreSelf.value;
        return (player && players.value) || (item && items.value) || (mob && mobs.value) || self;
    }

    int color(String value, Entity entity, boolean fill) {
        return switch (value) {
            case "Красный" -> 0xFFFF4545;
            case "Оранжевый" -> 0xFFFF9638;
            case "Жёлтый" -> 0xFFFFD84A;
            case "Зелёный" -> 0xFF48E06D;
            case "Бирюзовый" -> 0xFF31DAD0;
            case "Синий" -> 0xFF438CFF;
            case "Фиолетовый" -> 0xFF9D5CFF;
            case "Розовый" -> 0xFFFF4FBC;
            case "Белый" -> 0xFFF4F5FF;
            default -> Theme.accent();
        };
    }

    private static int withAlpha(int rgb, double a) {
        int alpha = (int)Math.max(0,Math.min(255,Math.round(a*255)));
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    // Reused scratch data: the HUD pass is single-threaded and consumes these bounds immediately.
    private static final double[] PROJECTED_BOUNDS = new double[4];

    /** Project the eight corners of the actual AABB without allocating corner/output arrays per entity. */
    private static boolean projectBounds(AABB b, int sw, int sh) {
        double minX=Double.MAX_VALUE, minY=Double.MAX_VALUE;
        double maxX=-Double.MAX_VALUE, maxY=-Double.MAX_VALUE;
        for (int i=0; i<8; i++) {
            double x=(i&1)==0?b.minX:b.maxX;
            double y=(i&2)==0?b.minY:b.maxY;
            double z=(i&4)==0?b.minZ:b.maxZ;
            Vec3 v=MC.gameRenderer.projectPointToScreen(new Vec3(x,y,z));
            if (v==null || !Double.isFinite(v.x) || !Double.isFinite(v.y) || !Double.isFinite(v.z) || v.z < -1 || v.z > 1) return false;
            double sx=(v.x+1)*0.5*sw, sy=(1-v.y)*0.5*sh;
            if (!Double.isFinite(sx) || !Double.isFinite(sy) || Math.abs(sx)>sw*3.0 || Math.abs(sy)>sh*3.0) return false;
            minX=Math.min(minX,sx); minY=Math.min(minY,sy); maxX=Math.max(maxX,sx); maxY=Math.max(maxY,sy);
        }
        PROJECTED_BOUNDS[0]=minX; PROJECTED_BOUNDS[1]=minY; PROJECTED_BOUNDS[2]=maxX; PROJECTED_BOUNDS[3]=maxY;
        return true;
    }

}
