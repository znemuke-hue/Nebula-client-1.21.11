package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.Theme;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Predicted flight path of the projectile you are about to shoot / throw.
 *
 * Bows and tridents are previewed while charging; crossbows while loaded; pearls, snowballs, eggs, potions and
 * experience bottles while held (main hand or off hand). The simulation mirrors vanilla: spawn point 0.1 below the
 * eyes, your own movement is added to the launch velocity (vertical part only in the air), per-item gravity and drag
 * (slower in water), block collision and entity collision. The end of the path is marked: a square on the block face,
 * or a red box around the entity that would be hit.
 */
public final class Trajectories extends Mod {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final String[] COLORS = {"По теме", "Бирюзовый", "Розовый", "Зелёный", "Жёлтый", "Белый"};
    private static final int HIT_COLOR = 0xFFFF4545;

    public final Setting.Bool bows = add(new Setting.Bool("Лук и арбалет", true));
    public final Setting.Bool tridents = add(new Setting.Bool("Трезубец", true));
    public final Setting.Bool throwables = add(new Setting.Bool("Жемчуг, снежки, яйца", true));
    public final Setting.Bool potions = add(new Setting.Bool("Зелья", true));
    public final Setting.Bool experience = add(new Setting.Bool("Пузыри опыта", true));
    public final Setting.Mode color = add(new Setting.Mode("Цвет траектории", "По теме", COLORS));
    public final Setting.Num thickness = add(new Setting.Num("Толщина траектории", 1.5, 0.5, 4, 0.5));
    public final Setting.Num opacity = add(new Setting.Num("Прозрачность линии (%)", 100, 0, 100, 5));
    public final Setting.Num maxTicks = add(new Setting.Num("Длина прогноза", 100, 20, 140, 10));
    public final Setting.Bool fade = add(new Setting.Bool("Затухание к концу", true));
    public final Setting.Bool marker = add(new Setting.Bool("Маркер падения", true));
    public final Setting.Bool entityHit = add(new Setting.Bool("Подсвечивать цель", true));

    public Trajectories() { super("Trajectories", Category.VISUALS); }

    /** Physics of one projectile type (all numbers are vanilla's). */
    private record Physics(double speed, double gravity, double drag, double waterDrag, double pitchOffset, double margin) {}

    private enum Kind { BOW, CROSSBOW, TRIDENT, THROWN, POTION, EXPERIENCE }

    private static Physics physics(Kind kind, double bowSpeed) {
        return switch (kind) {
            case BOW -> new Physics(bowSpeed, 0.05, 0.99, 0.6, 0.0, 0.3);
            case CROSSBOW -> new Physics(3.15, 0.05, 0.99, 0.6, 0.0, 0.3);
            case TRIDENT -> new Physics(2.5, 0.05, 0.99, 0.99, 0.0, 0.3);
            case THROWN -> new Physics(1.5, 0.03, 0.99, 0.8, 0.0, 0.3);
            case POTION -> new Physics(0.5, 0.05, 0.99, 0.8, -20.0, 0.3);
            case EXPERIENCE -> new Physics(0.7, 0.07, 0.99, 0.8, -20.0, 0.3);
        };
    }

    public List<Segment> collectSegments() {
        if (!isEnabled() || MC.player == null || MC.level == null || MC.screen != null || MC.options.hideGui) return List.of();
        if (!MC.options.getCameraType().isFirstPerson() && !MC.player.isUsingItem() && !holdsThrowable(MC.player)) return List.of();
        Player player = MC.player;

        Kind kind = null;
        double bowSpeed = 0.0;
        if (player.isUsingItem()) {
            ItemStack use = player.getUseItem();
            if (use.is(Items.BOW) && bows.value) {
                double charge = Math.max(0.0, player.getTicksUsingItem() / 20.0);
                double power = Math.min(1.0, (charge * charge + 2.0 * charge) / 3.0);
                if (power >= 0.1) { kind = Kind.BOW; bowSpeed = power * 3.0; }
            } else if (use.is(Items.TRIDENT) && tridents.value) {
                kind = Kind.TRIDENT;
            } else if (use.is(Items.CROSSBOW) && bows.value) {
                kind = Kind.CROSSBOW;
            }
        }
        if (kind == null) kind = heldKind(player);
        if (kind == null) return List.of();
        Physics ph = physics(kind, bowSpeed);

        float pt = HvhClient.partialTick();
        double yaw = Math.toRadians(player.getYRot());
        double pitch = Math.toRadians(player.getXRot());
        double offset = Math.toRadians(ph.pitchOffset());
        double cp = Math.cos(pitch);
        Vec3 direction = new Vec3(-Math.sin(yaw) * cp, -Math.sin(pitch + offset), Math.cos(yaw) * cp).normalize();
        Vec3 eye = player.getEyePosition(pt);
        Vec3 position = eye.subtract(0.0, 0.1, 0.0);
        Vec3 motion = player.getDeltaMovement();
        // Vanilla adds the thrower's movement to the launch velocity; vertical movement only while airborne.
        Vec3 velocity = direction.scale(ph.speed()).add(motion.x, player.onGround() ? 0.0 : motion.y, motion.z);

        int ticks = Math.max(20, Math.min(140, (int) Math.round(maxTicks.value)));

        // ---- pass 1: path against blocks
        double[] px = new double[ticks + 2], py = new double[ticks + 2], pz = new double[ticks + 2];
        int n = 0;
        px[n] = position.x; py[n] = position.y; pz[n] = position.z; n++;
        BlockHitResult blockHit = null;
        for (int i = 0; i < ticks; i++) {
            Vec3 next = position.add(velocity);
            BlockHitResult hit = MC.level.clip(new ClipContext(position, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            boolean blocked = hit.getType() == HitResult.Type.BLOCK;
            if (blocked) next = hit.getLocation();
            px[n] = next.x; py[n] = next.y; pz[n] = next.z; n++;
            if (blocked) { blockHit = hit; break; }
            position = next;
            boolean inFluid = !MC.level.getFluidState(BlockPos.containing(position)).isEmpty();
            double drag = inFluid ? ph.waterDrag() : ph.drag();
            velocity = new Vec3(velocity.x * drag, velocity.y * drag - ph.gravity(), velocity.z * drag);
            if (position.y < -128.0) break;
        }

        // ---- pass 2: first entity along the path (entities are looked up once for the whole path box)
        LivingEntity hitEntity = null;
        int hitSegment = -1;
        Vec3 hitPoint = null;
        if (n >= 2) {
            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, minZ = Double.MAX_VALUE;
            double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                minX = Math.min(minX, px[i]); maxX = Math.max(maxX, px[i]);
                minY = Math.min(minY, py[i]); maxY = Math.max(maxY, py[i]);
                minZ = Math.min(minZ, pz[i]); maxZ = Math.max(maxZ, pz[i]);
            }
            AABB area = new AABB(minX, minY, minZ, maxX, maxY, maxZ).inflate(ph.margin() + 1.0);
            List<LivingEntity> candidates = MC.level.getEntitiesOfClass(LivingEntity.class, area,
                e -> e != player && e.isAlive() && !e.isSpectator());
            if (!candidates.isEmpty()) {
                search:
                for (int i = 0; i + 1 < n; i++) {
                    Vec3 from = new Vec3(px[i], py[i], pz[i]);
                    Vec3 to = new Vec3(px[i + 1], py[i + 1], pz[i + 1]);
                    double best = Double.MAX_VALUE;
                    for (LivingEntity e : candidates) {
                        AABB box = e.getBoundingBox().inflate(ph.margin());
                        Vec3 point = null;
                        if (box.contains(from)) point = from;
                        else {
                            Optional<Vec3> clip = box.clip(from, to);
                            if (clip.isPresent()) point = clip.get();
                        }
                        if (point == null) continue;
                        double d = point.distanceToSqr(from);
                        if (d < best) { best = d; hitEntity = e; hitPoint = point; hitSegment = i; }
                    }
                    if (hitEntity != null) break search;
                }
            }
        }
        if (hitEntity != null) {
            // Cut the path at the entity.
            n = hitSegment + 1;
            px[n] = hitPoint.x; py[n] = hitPoint.y; pz[n] = hitPoint.z; n++;
        }

        // ---- build segments
        int baseColor = colorValue();
        int hitColor = hitEntity != null && entityHit.value ? HIT_COLOR : baseColor;
        double baseWidth = thickness.value * 0.0075;
        List<Segment> result = new ArrayList<>(n + 20);
        for (int i = 0; i + 1 < n; i++) {
            int a = fade.value ? Math.max(64, 255 - (int) (150.0 * i / Math.max(1, n - 2))) : 255;
            a = (int) Math.round(a * opacity.value / 100.0);   // line opacity 0..100 %
            int c = (a << 24) | (hitColor & 0xFFFFFF);
            double dx = px[i] - eye.x, dy = py[i] - eye.y, dz = pz[i] - eye.z;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double width = Math.min(0.2, baseWidth * (1.0 + dist * 0.05));
            result.add(new Segment(px[i], py[i], pz[i], px[i + 1], py[i + 1], pz[i + 1], c, width));
        }

        if (marker.value) {
            double lw = Math.max(0.01, baseWidth * 1.4);
            if (hitEntity != null && entityHit.value) {
                addBoxOutline(result, hitEntity.getBoundingBox().inflate(0.02), HIT_COLOR, lw * 1.6);
            } else if (blockHit != null) {
                addFaceSquare(result, blockHit, baseColor | 0xFF000000, lw * 1.4);
            }
        }
        return List.copyOf(result);
    }

    // ------------------------------------------------------------------ helpers

    /** Which projectile (if any) the player holds ready to throw / loaded. */
    private Kind heldKind(Player player) {
        for (ItemStack s : new ItemStack[] {player.getMainHandItem(), player.getOffhandItem()}) {
            if (s == null || s.isEmpty()) continue;
            if (s.is(Items.CROSSBOW)) {
                var loaded = s.get(DataComponents.CHARGED_PROJECTILES);
                if (bows.value && loaded != null && !loaded.isEmpty()) return Kind.CROSSBOW;
                continue;
            }
            if (s.is(Items.ENDER_PEARL) || s.is(Items.SNOWBALL) || s.is(Items.EGG)) { if (throwables.value) return Kind.THROWN; continue; }
            if (s.is(Items.SPLASH_POTION) || s.is(Items.LINGERING_POTION)) { if (potions.value) return Kind.POTION; continue; }
            if (s.is(Items.EXPERIENCE_BOTTLE)) { if (experience.value) return Kind.EXPERIENCE; continue; }
        }
        return null;
    }

    private static boolean holdsThrowable(Player p) {
        for (ItemStack s : new ItemStack[] {p.getMainHandItem(), p.getOffhandItem()}) {
            if (s == null || s.isEmpty()) continue;
            if (s.is(Items.ENDER_PEARL) || s.is(Items.SNOWBALL) || s.is(Items.EGG) || s.is(Items.SPLASH_POTION)
                || s.is(Items.LINGERING_POTION) || s.is(Items.EXPERIENCE_BOTTLE) || s.is(Items.CROSSBOW)) return true;
        }
        return false;
    }

    private static void addBoxOutline(List<Segment> out, AABB b, int color, double w) {
        double x0 = b.minX, y0 = b.minY, z0 = b.minZ, x1 = b.maxX, y1 = b.maxY, z1 = b.maxZ;
        int c = color | 0xFF000000;
        out.add(new Segment(x0, y0, z0, x1, y0, z0, c, w)); out.add(new Segment(x0, y0, z1, x1, y0, z1, c, w));
        out.add(new Segment(x0, y1, z0, x1, y1, z0, c, w)); out.add(new Segment(x0, y1, z1, x1, y1, z1, c, w));
        out.add(new Segment(x0, y0, z0, x0, y0, z1, c, w)); out.add(new Segment(x1, y0, z0, x1, y0, z1, c, w));
        out.add(new Segment(x0, y1, z0, x0, y1, z1, c, w)); out.add(new Segment(x1, y1, z0, x1, y1, z1, c, w));
        out.add(new Segment(x0, y0, z0, x0, y1, z0, c, w)); out.add(new Segment(x1, y0, z0, x1, y1, z0, c, w));
        out.add(new Segment(x0, y0, z1, x0, y1, z1, c, w)); out.add(new Segment(x1, y0, z1, x1, y1, z1, c, w));
    }

    /** A small square lying on the face of the block that was hit. */
    private static void addFaceSquare(List<Segment> out, BlockHitResult hit, int color, double w) {
        Vec3 p = hit.getLocation();
        Direction d = hit.getDirection();
        double nx = d.getStepX() * 0.012, ny = d.getStepY() * 0.012, nz = d.getStepZ() * 0.012;
        double ux, uy, uz, vx, vy, vz;
        if (d.getStepY() != 0) { ux = 1; uy = 0; uz = 0; vx = 0; vy = 0; vz = 1; }
        else if (d.getStepX() != 0) { ux = 0; uy = 1; uz = 0; vx = 0; vy = 0; vz = 1; }
        else { ux = 1; uy = 0; uz = 0; vx = 0; vy = 1; vz = 0; }
        double r = 0.2;
        double[][] c = {{-r, -r}, {r, -r}, {r, r}, {-r, r}};
        for (int i = 0; i < 4; i++) {
            double[] a = c[i], b = c[(i + 1) % 4];
            out.add(new Segment(
                p.x + nx + ux * a[0] + vx * a[1], p.y + ny + uy * a[0] + vy * a[1], p.z + nz + uz * a[0] + vz * a[1],
                p.x + nx + ux * b[0] + vx * b[1], p.y + ny + uy * b[0] + vy * b[1], p.z + nz + uz * b[0] + vz * b[1],
                color, w));
        }
    }

    private int colorValue() {
        return switch (color.value) {
            case "Бирюзовый" -> 0xFF35E0D3;
            case "Розовый" -> 0xFFFF55BC;
            case "Зелёный" -> 0xFF58EE7D;
            case "Жёлтый" -> 0xFFFFD64F;
            case "Белый" -> 0xFFF6F7FF;
            default -> Theme.accent();
        };
    }

    public record Segment(double x0, double y0, double z0, double x1, double y1, double z1, int color, double width) {}
}
