package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;

/**
 * NoServerRotate (порт из Javafiles/NoServerRotate.java).
 * Сервер больше не разворачивает твою камеру при телепортах / откатах позиции.
 * Сам модуль пустой, работа - в ClientPacketListenerMixin (handleMovePlayer): поворот сохраняется до пакета и
 * возвращается после него. В оригинале так же: onEnable только регистрирует модуль в нативной части.
 */
public final class NoServerRotate extends Mod {
    public NoServerRotate() { super("NoServerRotate", Category.PLAYER); }
}
