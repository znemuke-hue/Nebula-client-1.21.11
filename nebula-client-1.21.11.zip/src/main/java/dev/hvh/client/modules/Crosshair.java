package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.Theme;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Custom crosshair, drawn in real screen pixels (GUI scale undone) so every line is exactly centered and crisp
 * at any GUI scale. The vanilla crosshair is hidden by CrosshairMixin while this module is enabled.
 * A handful of rectangles per frame; no per-pixel work.
 */
public final class Crosshair extends Mod {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final String[] COLORS = {"По теме", "Белый", "Красный", "Зелёный", "Голубой", "Розовый", "Жёлтый"};

    public final Setting.Mode style = add(new Setting.Mode("Стиль", "Крест", "Крест", "Тонкий крест", "Т-образный", "Точка", "Квадрат"));
    public final Setting.Num length = add(new Setting.Num("Длина", 5, 2, 20, 1));
    public final Setting.Num gap = add(new Setting.Num("Зазор", 3, 0, 14, 1));
    public final Setting.Num thickness = add(new Setting.Num("Толщина", 2, 1, 6, 1));
    public final Setting.Mode color = add(new Setting.Mode("Цвет", "По теме", COLORS));
    public final Setting.Num alpha = add(new Setting.Num("Прозрачность", 100, 20, 100, 5));
    public final Setting.Bool outline = add(new Setting.Bool("Чёрная обводка", true));
    public final Setting.Bool centerDot = add(new Setting.Bool("Точка в центре", false));
    public final Setting.Bool dynamic = add(new Setting.Bool("Динамический зазор", true));
    public final Setting.Bool targetColor = add(new Setting.Bool("Красный при наведении на сущность", true));
    public final Setting.Bool cooldown = add(new Setting.Bool("Индикатор перезарядки", false));

    // Smoothed extra gap (real-pixel units before UI scaling), animated every frame.
    private static float animGap;
    private static long lastFrame = System.nanoTime();

    public Crosshair() { super("Crosshair", Category.VISUALS); }

    public static void render(GuiGraphics g) {
        if (HvhClient.modules == null || MC.player == null || MC.level == null || MC.options.hideGui || MC.screen != null) return;
        Crosshair c = HvhClient.modules.crosshair;
        if (c == null || !c.isEnabled()) return;
        // Vanilla only shows its crosshair in first person; so do we.
        if (!MC.options.getCameraType().isFirstPerson()) return;

        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrame) / 1.0E9f);
        lastFrame = now;

        float gs = (float) Math.max(1, MC.getWindow().getGuiScale());
        int rw = MC.getWindow().getWidth(), rh = MC.getWindow().getHeight();
        // UI scale in real pixels: 1x at 720p, 2x at 1440p, never below 1.
        float S = Math.max(1f, Math.min(4f, rh / 720f));
        int cx = rw / 2, cy = rh / 2;

        boolean onEntity = MC.hitResult instanceof EntityHitResult;
        float targetExtra = 0f;
        if (c.dynamic.value) {
            Vec3 v = MC.player.getDeltaMovement();
            double speed = Math.sqrt(v.x * v.x + v.z * v.z);
            targetExtra += (float) Math.min(5.0, speed * 14.0);          // moving
            if (!MC.player.onGround()) targetExtra += 2f;               // airborne
            if (onEntity) targetExtra -= 1.5f;                           // snap tighter on a target
        }
        // Frame-rate independent exponential smoothing.
        animGap += (targetExtra - animGap) * (1f - (float) Math.exp(-14.0 * dt));

        int len = Math.max(1, Math.round(c.length.value.floatValue() * S));
        int thick = Math.max(1, Math.round(c.thickness.value.floatValue() * S * 0.75f));
        int space = Math.max(0, Math.round((c.gap.value.floatValue() + animGap) * S));
        int col = c.colorValue(onEntity);
        int a = Math.max(0, Math.min(255, Math.round(c.alpha.value.floatValue() * 2.55f)));
        col = (a << 24) | (col & 0xFFFFFF);
        int ol = c.outline.value ? ((a * 217 / 255) << 24) : 0;
        int o = Math.max(1, Math.round(S * 0.75f)); // outline width

        g.pose().pushMatrix();
        g.pose().scale(1f / gs, 1f / gs);

        String st = c.style.value;
        int half = thick / 2;
        if ("Точка".equals(st)) {
            int s = Math.max(thick, Math.round(c.length.value.floatValue() * S * 0.5f));
            c.box(g, cx - s / 2, cy - s / 2, s, s, col, ol, o);
        } else if ("Квадрат".equals(st)) {
            int s = Math.max(6, len * 2 + space);
            int x0 = cx - s / 2, y0 = cy - s / 2;
            if (ol != 0) { // outside + inside edge of the hollow square
                g.fill(x0 - o, y0 - o, x0 + s + o, y0, ol);
                g.fill(x0 - o, y0 + s, x0 + s + o, y0 + s + o, ol);
                g.fill(x0 - o, y0, x0, y0 + s, ol);
                g.fill(x0 + s, y0, x0 + s + o, y0 + s, ol);
            }
            // hollow square: four bars
            g.fill(x0, y0, x0 + s, y0 + thick, col);
            g.fill(x0, y0 + s - thick, x0 + s, y0 + s, col);
            g.fill(x0, y0 + thick, x0 + thick, y0 + s - thick, col);
            g.fill(x0 + s - thick, y0 + thick, x0 + s, y0 + s - thick, col);
        } else {
            if ("Тонкий крест".equals(st)) { thick = Math.max(1, Math.round(S * 0.75f)); half = thick / 2; }
            boolean t = "Т-образный".equals(st);
            // Outline pass first, fill pass second: the outline of one arm never paints over its neighbour.
            for (int pass = 0; pass < 2; pass++) {
                int grow = pass == 0 ? o : 0;
                int color = pass == 0 ? ol : col;
                if (pass == 0 && ol == 0) continue;
                // vertical: up (skipped for the T style), down
                if (!t) g.fill(cx - half - grow, cy - space - len - grow, cx - half + thick + grow, cy - space + grow, color);
                g.fill(cx - half - grow, cy + space - grow, cx - half + thick + grow, cy + space + len + grow, color);
                // horizontal: left, right
                g.fill(cx - space - len - grow, cy - half - grow, cx - space + grow, cy - half + thick + grow, color);
                g.fill(cx + space - grow, cy - half - grow, cx + space + len + grow, cy - half + thick + grow, color);
            }
        }
        if (c.centerDot.value && !"Точка".equals(st)) c.box(g, cx - half, cy - half, thick, thick, col, ol, o);

        if (c.cooldown.value) {
            float p = Math.max(0f, Math.min(1f, MC.player.getAttackStrengthScale(0.0f)));
            if (p < 0.999f) {
                int bw = Math.round(28 * S), bh = Math.max(2, Math.round(2 * S));
                int bx = cx - bw / 2, by = cy + space + len + Math.round(6 * S);
                g.fill(bx - o, by - o, bx + bw + o, by + bh + o, 0xB0000000);
                g.fill(bx, by, bx + Math.round(bw * p), by + bh, col);
            }
        }
        g.pose().popMatrix();
    }

    private void box(GuiGraphics g, int x, int y, int w, int h, int fill, int outlineColor, int o) {
        if (outlineColor != 0) g.fill(x - o, y - o, x + w + o, y + h + o, outlineColor);
        g.fill(x, y, x + w, y + h, fill);
    }

    private int colorValue(boolean onEntity) {
        if (onEntity && targetColor.value) return 0xFFFF4E5D;
        return switch (color.value) {
            case "Белый" -> 0xFFF5F7FF;
            case "Красный" -> 0xFFFF4E5D;
            case "Зелёный" -> 0xFF56F28A;
            case "Голубой" -> 0xFF57D8FF;
            case "Розовый" -> 0xFFFF67C8;
            case "Жёлтый" -> 0xFFFFD54D;
            default -> Theme.accent();
        };
    }
}
