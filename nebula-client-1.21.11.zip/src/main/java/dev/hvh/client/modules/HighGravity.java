package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * High Gravity.
 *
 * "Притяжение" (default) - pulls you to the ground at once: as soon as you are in the air (from the top of the
 * jump, or right away) your downward speed is set to "Скорость" blocks per tick. The normal block collision
 * stops you at the ground, so with the default 9 blocks/tick any drop up to ~9 blocks ends in one tick, and
 * higher drops take a few ticks. Fall distance is counted as usual, so a mace smash after High Jump keeps its
 * damage bonus. Vanilla servers rubber-band moves of roughly 10+ blocks per tick, so the speed is capped below that.
 *
 * "Усиление" - gravity is multiplied: "Гравитация, % от обычной" (200 = twice as strong).
 */
public class HighGravity extends Mod {
    private static final double GRAVITY = 0.08, DRAG = 0.98;

    private final Setting.Mode mode = add(new Setting.Mode("Режим", "Притяжение", "Притяжение", "Усиление"));
    private final Setting.Mode start = add(new Setting.Mode("Начало притяжения", "С вершины прыжка", "С вершины прыжка", "Сразу в воздухе"));
    private final Setting.Num speed = add(new Setting.Num("Скорость притяжения (блок/тик)", 9.0, 0.5, 9.9, 0.1));
    private final Setting.Num gravity = add(new Setting.Num("Гравитация, % от обычной", 300, 100, 1000, 25));

    public HighGravity() { super("High Gravity", Category.MOVEMENT); }

    @Override public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        if (p.onGround() || p.isInWater() || p.isInLava() || p.onClimbable() || p.isPassenger()
            || p.isFallFlying() || p.isCreative() || p.isSpectator()) return;
        Flight flight = dev.hvh.client.HvhClient.modules == null ? null : dev.hvh.client.HvhClient.modules.get(Flight.class);
        if (flight != null && flight.isEnabled()) return; // Flight owns the vertical speed

        Vec3 v = p.getDeltaMovement();
        if (mode.value.equals("Усиление")) {
            // vanilla already applied (y - 0.08) * 0.98 this tick; add the extra pull of the stronger gravity
            double extra = GRAVITY * (gravity.value / 100.0 - 1.0) * DRAG;
            double vy = Math.max(-speed.value, v.y - extra);
            p.setDeltaMovement(v.x, vy, v.z);
            return;
        }

        if (start.value.equals("С вершины прыжка") && v.y > 0.0) return; // still rising: let the jump finish
        double down = -speed.value;
        if (v.y > down) p.setDeltaMovement(v.x, down, v.z);
    }
}
