package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.MaceItem;

/**
 * Criticals: right before an attack is sent, spoof a tiny jump with position packets so the hit counts as a crit.
 * Works while you stand on the ground (not in water/lava/ladders). Hook: MultiPlayerGameModeMixin.
 *
 * A sprinting player can never crit on the server, so for hits made outside KillAura (manual clicks) the sprint
 * state is dropped for the hit and restored at the end of the same tick. KillAura manages sprint itself and sets
 * {@link #externalSprint} while it attacks.
 */
public class Criticals extends Mod {
    private final Setting.Mode mode = add("Режим", new Setting.Mode("Режим", "Пакеты", "Пакеты", "Обновлённый NCP", "Старый NCP"));
    private final Setting.Bool mace = add("Булава", "Удар булавой", new Setting.Bool("Удар булавой", true));
    private final Setting.Num maceHeight = add("Булава", new Setting.Num("Доп. высота булавы", 0, 0, 100, 1));
    private final Setting.Bool maceMinFall = add("Булава", "С 1.5 блока", new Setting.Bool("Булава: бить только с 1.5 блока", true));

    /** Set by KillAura while it performs an attack and takes care of the sprint state on its own. */
    public static boolean externalSprint;
    /** Set by KillAura / TriggerBot for a hit that must NOT be a packet crit (crit randomization). */
    public static boolean suppress;
    private boolean restoreSprint;

    public Criticals() { super("Criticals", Category.COMBAT); }

    /** True when a packet crit can be produced right now (on the ground, not in fluid / on a ladder / riding). */
    public static boolean canSpoof(Player p) {
        return p != null && p.onGround() && !p.isInWater() && !p.isInLava() && !p.onClimbable() && !p.isPassenger() && !p.isFallFlying();
    }

    public void onAttack(Entity target) {
        var p = mc.player;
        if (p == null || mc.level == null || suppress) return;

        if (mace.value && p.getMainHandItem().getItem() instanceof MaceItem) {
            if (p.isFallFlying()) return;
            if (maceMinFall.value && p.fallDistance < 1.5) return;   // smash only after a real fall of 1.5+ blocks
            send(0);
            send(1.501 + maceHeight.value);
            send(0);
            return;
        }

        if (!(target instanceof LivingEntity)) return;
        if (!canSpoof(p)) return; // already in the air: a falling hit is a natural crit, nothing to spoof

        if (!externalSprint && p.isSprinting() && mc.getConnection() != null) {
            mc.getConnection().send(new ServerboundPlayerCommandPacket(p, ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
            restoreSprint = true;
        }
        spoofNow();
    }

    /** Sends the crit packets of the selected mode (also used by KillAura's "Пакеты" crit method). */
    public void spoofNow() {
        switch (mode.value) {
            case "Обновлённый NCP" -> { send(0.0000008); send(0); }
            case "Старый NCP" -> { send(0.11); send(0.1100013579); send(0.0000013579); }
            default -> { send(0.0625); send(0); }
        }
    }

    @Override public void onTick() {
        if (restoreSprint) {
            restoreSprint = false;
            var p = mc.player;
            if (p != null && p.isSprinting() && mc.getConnection() != null)
                mc.getConnection().send(new ServerboundPlayerCommandPacket(p, ServerboundPlayerCommandPacket.Action.START_SPRINTING));
        }
    }

    @Override protected void onDisable() {
        // never leave the server thinking we stopped sprinting
        if (restoreSprint) onTick();
    }

    private void send(double height) {
        var p = mc.player;
        p.connection.send(new ServerboundMovePlayerPacket.Pos(p.getX(), p.getY() + height, p.getZ(), false, false));
    }
}
