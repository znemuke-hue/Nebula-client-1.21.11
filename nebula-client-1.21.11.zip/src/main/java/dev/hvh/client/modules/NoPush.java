package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;

/** No Push: choose what is not allowed to push you. The work is done by the NoPush* mixins, which read these toggles. */
public class NoPush extends Mod {
    public final Setting.Bool water = add(new Setting.Bool("Вода", true));
    public final Setting.Bool walls = add(new Setting.Bool("Стены", true));
    public final Setting.Bool entities = add(new Setting.Bool("Сущности", true));

    public NoPush() { super("No Push", Category.PLAYER); }
}
