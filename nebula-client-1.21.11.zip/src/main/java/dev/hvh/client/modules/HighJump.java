package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * High Jump: every jump from the ground takes you higher than vanilla.
 *
 * "Высота" - you choose how many blocks the jump should reach (the needed launch speed is calculated with the
 * vanilla gravity/drag, so 3.0 really means about 3 blocks). "Множитель" - the vanilla jump speed is multiplied.
 * The boost is applied on the tick you leave the ground, so it also works with No Jump Delay / bunny hopping.
 * Pair it with High Gravity ("Притяжение") for jump-then-slam combos (e.g. with a mace).
 */
public class HighJump extends Mod {
    private final Setting.Mode mode = add(new Setting.Mode("Режим", "Высота", "Высота", "Множитель"));
    private final Setting.Num height = add(new Setting.Num("Высота (блоков)", 3.0, 1.0, 30.0, 0.5));
    private final Setting.Num multiplier = add(new Setting.Num("Множитель", 2.0, 1.0, 10.0, 0.1));

    private boolean wasOnGround;
    private double groundY;

    public HighJump() { super("High Jump", Category.MOVEMENT); }

    @Override protected void onEnable() {
        LocalPlayer p = mc.player;
        wasOnGround = p != null && p.onGround();
        groundY = p == null ? 0 : p.getY();
    }

    @Override public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null) return;
        boolean ground = p.onGround();
        if (ground) groundY = p.getY();
        Vec3 v = p.getDeltaMovement();

        // The tick the player left the ground going up = a jump (vanilla leaves a speed of ~0.33 after it).
        boolean jumped = wasOnGround && !ground && v.y > 0.1
            && !p.isInWater() && !p.isInLava() && !p.onClimbable() && !p.isPassenger() && !p.isFallFlying()
            && !p.isCreative() && !p.isSpectator();
        if (jumped) {
            double vy;
            if (mode.value.equals("Множитель")) {
                vy = v.y * multiplier.value;
            } else {
                double gained = Math.max(0.0, p.getY() - groundY); // what the first jump tick already climbed
                vy = launchSpeedFor(Math.max(0.05, height.value - gained));
            }
            p.setDeltaMovement(v.x, Math.max(v.y, vy), v.z);
        }
        wasOnGround = ground;
    }

    /** Peak height (blocks) of a rise that starts at upward speed vy, vanilla physics: y = (y - 0.08) * 0.98 per tick. */
    private static double peak(double vy) {
        double sum = 0, y = vy;
        for (int i = 0; i < 600 && y > 0; i++) {
            sum += y;
            y = (y - 0.08) * 0.98;
        }
        return sum;
    }

    /** Upward speed for the next tick that makes the rise reach the given height. */
    private static double launchSpeedFor(double h) {
        double lo = 0, hi = 15;
        for (int i = 0; i < 40; i++) {
            double mid = (lo + hi) * 0.5;
            if (peak(mid) < h) lo = mid; else hi = mid;
        }
        return hi;
    }
}
