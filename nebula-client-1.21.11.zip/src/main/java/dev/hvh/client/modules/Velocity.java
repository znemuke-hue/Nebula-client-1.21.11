package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;

/** Scales knockback / explosion push. 0 = no push at all, 1 = vanilla. Logic lives in ClientPacketListenerMixin. */
public class Velocity extends Mod {
    public final Setting.Bool knockback = add(new Setting.Bool("Отбрасывание", true));
    public final Setting.Num kbH = add(new Setting.Num("Горизонтальное отбрасывание", 0, 0, 1, 0.05));
    public final Setting.Num kbV = add(new Setting.Num("Вертикальное отбрасывание", 0, 0, 1, 0.05));
    public final Setting.Bool explosions = add(new Setting.Bool("Взрывы", true));
    public final Setting.Num exH = add(new Setting.Num("Горизонтальная сила взрывов", 0, 0, 1, 0.05));
    public final Setting.Num exV = add(new Setting.Num("Вертикальная сила взрывов", 0, 0, 1, 0.05));

    public Velocity() { super("Velocity", Category.MOVEMENT); }
}
