package dev.hvh.client.modules;

import dev.hvh.client.mixin.MinecraftAccessor;
import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Removes (or shortens) the delay between right clicks: placing blocks, throwing pearls/potions, etc. */
public class FastUse extends Mod {
    private final Setting.Num delay = add(new Setting.Num("Задержка (тики)", 0, 0, 4, 1));
    /** When on, the delay is only removed while holding an experience bottle; everything else stays vanilla. */
    private final Setting.Bool xpOnly = add(new Setting.Bool("Только пузыри опыта", false));

    public FastUse() { super("Fast Use", Category.PLAYER); }

    private static boolean isXpBottle(ItemStack s) { return s != null && s.is(Items.EXPERIENCE_BOTTLE); }

    @Override public void onTick() {
        if (mc.player == null) return;
        if (xpOnly.value && !isXpBottle(mc.player.getMainHandItem()) && !isXpBottle(mc.player.getOffhandItem())) return;
        MinecraftAccessor acc = (MinecraftAccessor) mc;
        int max = (int) Math.round(delay.value);
        if (acc.hvh$getRightClickDelay() > max) acc.hvh$setRightClickDelay(max);
    }
}
