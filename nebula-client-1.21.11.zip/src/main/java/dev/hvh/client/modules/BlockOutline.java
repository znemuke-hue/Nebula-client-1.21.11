package dev.hvh.client.modules;

import dev.hvh.client.gui.Theme;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;

/** Custom block-selection highlight: outline + translucent fill on the selected block. */
public final class BlockOutline extends Mod {
    private static final String[] COLORS = {"По теме", "Белый", "Красный", "Оранжевый", "Жёлтый", "Зелёный", "Бирюзовый", "Синий", "Фиолетовый", "Розовый"};
    private static final String[] FILL_COLORS = {"Как контур", "По теме", "Белый", "Красный", "Оранжевый", "Жёлтый", "Зелёный", "Бирюзовый", "Синий", "Фиолетовый", "Розовый"};

    public final Setting.Bool outline = add(new Setting.Bool("Контур", true));
    public final Setting.Mode color = add(new Setting.Mode("Цвет контура", "По теме", COLORS));
    public final Setting.Num width = add(new Setting.Num("Толщина контура", 1.5, 0.5, 4.0, 0.5));
    public final Setting.Bool fill = add(new Setting.Bool("Заливка", true));
    public final Setting.Mode fillColor = add(new Setting.Mode("Цвет заливки", "Как контур", FILL_COLORS));
    public final Setting.Num fillAlpha = add(new Setting.Num("Прозрачность заливки", 25, 0, 100, 1));
    public final Setting.Num expand = add(new Setting.Num("Отступ от блока", 0.0, 0.0, 0.08, 0.005));
    public final Setting.Bool throughWalls = add(new Setting.Bool("Сквозь стены", false));

    public BlockOutline() { super("Block Outline", Category.VISUALS); }

    public int colorValue() { return palette(color.value); }

    /** Fill color (RGB). "Как контур" follows the outline color. */
    public int fillColorValue() {
        return "Как контур".equals(fillColor.value) ? colorValue() : palette(fillColor.value);
    }

    private static int palette(String name) {
        return switch (name) {
            case "Белый" -> 0xFFF5F7FF;
            case "Красный" -> 0xFFFF4545;
            case "Оранжевый" -> 0xFFFF9638;
            case "Жёлтый" -> 0xFFFFD84A;
            case "Зелёный" -> 0xFF48E06D;
            case "Бирюзовый" -> 0xFF31DAD0;
            case "Синий" -> 0xFF438CFF;
            case "Фиолетовый" -> 0xFF9D5CFF;
            case "Розовый" -> 0xFFFF4FBC;
            default -> Theme.accent();
        };
    }
}
