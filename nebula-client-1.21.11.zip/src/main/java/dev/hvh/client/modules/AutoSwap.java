package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.hud.Notifications;
import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.ActionLock;
import dev.hvh.client.util.InvUtil;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;

/**
 * Auto Swap: the Swap bind flips your offhand between "Свап 1" and "Свап 2".
 *
 *  Ball        - player_head that has attribute modifiers for the OFFHAND slot ("when in off hand: +1 damage" ...)
 *  Totem       - plain totem of undying        Ench. Totem - enchanted (glint) totem
 *  Damage      - the item in the inventory with the biggest attack damage bonus while held in the offhand
 *                (totems and balls are both eligible, whatever has the most damage wins)
 *  Armor       - same, but for the armor attribute
 *
 * Offhand already holds Swap 1 -> swaps to Swap 2; holds Swap 2 -> swaps to Swap 1; holds neither -> Swap 1.
 *
 * Every swap goes through ActionLock: for 4 ticks everything that could count as a Multi Action is stopped (aim, attacks,
 * movement, sprint, sneak, item use, mining), the click is sent inside that quiet window, and afterwards the keys you are
 * still holding (W/A/S/D, Space, Sneak, LMB, RMB, sprint) are pressed again.
 */
public class AutoSwap extends Mod {
    private static final String BALL = "Шар", TOTEM = "Тотем", ETOTEM = "Зачар. тотем", DAMAGE = "Урон", ARMOR = "Броня";

    public final Setting.Key key = add(new Setting.Key("Клавиша свапа", -1));
    public final Setting.Mode swap1 = add(new Setting.Mode("Свап 1", BALL, BALL, TOTEM, ETOTEM, DAMAGE, ARMOR));
    public final Setting.Mode swap2 = add(new Setting.Mode("Свап 2", TOTEM, BALL, TOTEM, ETOTEM, DAMAGE, ARMOR));

    private boolean pending;
    private int lastSwapTick = -10;

    public AutoSwap() { super("Auto Swap", Category.COMBAT); }

    @Override public void onKey(Setting.Key k) { if (k == key) pending = true; }
    @Override protected void onDisable() { pending = false; if (ActionLock.ownedBy(name)) ActionLock.cancel(); }

    /** START of the tick (same place as Auto Totem): the key press of the previous tick is turned into a quiet window + swap. */
    @Override public void onPreTick() {
        if (!pending) return;
        pending = false;
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || !p.isAlive()) return;
        if (p.tickCount < lastSwapTick) lastSwapTick = -10;   // tickCount restarts after a respawn / new world

        // a second press while a swap is being prepared is ignored
        if (ActionLock.active || !InvUtil.canClick()) return;
        if (p.tickCount - lastSwapTick < 2 || HvhClient.modules.autoTotem.active()) return;
        String[] wanted = new String[1];
        if (pickSlot(p, wanted) < 0) { Notifications.push(name, "Нет в инвентаре: " + wanted[0]); return; }   // nothing to swap: do not freeze you for nothing
        ActionLock.request(name, this::swapNow);
    }

    /** Inventory index of the item the swap would bring to the offhand right now, or -1 ({@code wantedOut[0]} = what was looked for). */
    private int pickSlot(LocalPlayer p, String[] wantedOut) {
        ItemStack off = p.getOffhandItem();
        boolean in1 = matches(p, off, swap1.value), in2 = matches(p, off, swap2.value);
        int slot;
        String wanted;
        if (in1) { wanted = swap2.value; slot = find(p, wanted); }
        else if (in2) { wanted = swap1.value; slot = find(p, wanted); }
        else {
            wanted = swap1.value; slot = find(p, wanted);
            if (slot < 0) { wanted = swap2.value; slot = find(p, wanted); }
        }
        wantedOut[0] = wanted;
        return slot;
    }

    /** The swap itself (everything is looked at right now). Returns true when a click was sent. */
    private boolean swapNow() {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || !p.isAlive()) return false;
        if (p.tickCount - lastSwapTick < 2) return false;
        AutoTotem totem = HvhClient.modules.autoTotem;
        if (totem.active()) return false; // Auto Totem owns the offhand while your health is low

        String[] wanted = new String[1];
        int slot = pickSlot(p, wanted);
        if (slot < 0) { Notifications.push(name, "Нет в инвентаре: " + wanted[0]); return false; }
        if (InvUtil.swapToOffhand(slot)) { lastSwapTick = p.tickCount; return true; }
        return false;
    }

    // ------------------------------------------------------------------ item checks

    private static boolean isTotem(ItemStack s) { return !s.isEmpty() && s.is(Items.TOTEM_OF_UNDYING); }

    /** Player head that carries attribute modifiers for the offhand slot. */
    private static boolean isBall(ItemStack s) {
        if (s.isEmpty() || !s.is(Items.PLAYER_HEAD)) return false;
        ItemAttributeModifiers m = s.get(DataComponents.ATTRIBUTE_MODIFIERS);
        if (m == null) return false;
        for (ItemAttributeModifiers.Entry e : m.modifiers()) if (e.slot() == EquipmentSlotGroup.OFFHAND) return true;
        return false;
    }

    /** Sum of the (flat) bonuses of an attribute that apply while the item is in the offhand. */
    private static double value(ItemStack s, Holder<Attribute> attr) {
        if (s.isEmpty()) return 0;
        ItemAttributeModifiers m = s.get(DataComponents.ATTRIBUTE_MODIFIERS);
        if (m == null) return 0;
        double sum = 0;
        for (ItemAttributeModifiers.Entry e : m.modifiers()) {
            if (!e.attribute().equals(attr) || !e.slot().test(EquipmentSlot.OFFHAND)) continue;
            if (e.modifier().operation() == AttributeModifier.Operation.ADD_VALUE) sum += e.modifier().amount();
        }
        return sum;
    }

    private static Holder<Attribute> attrOf(String type) { return DAMAGE.equals(type) ? Attributes.ATTACK_DAMAGE : Attributes.ARMOR; }

    /** Is this stack what the given swap type describes? (Damage / Armor: positive and not worse than anything in the inventory.) */
    private boolean matches(LocalPlayer p, ItemStack s, String type) {
        if (s.isEmpty()) return false;
        return switch (type) {
            case BALL -> isBall(s);
            case TOTEM -> isTotem(s) && !s.hasFoil();
            case ETOTEM -> isTotem(s) && s.hasFoil();
            default -> {
                double v = value(s, attrOf(type));
                yield v > 0 && v >= bestValue(p, attrOf(type));
            }
        };
    }

    private double bestValue(LocalPlayer p, Holder<Attribute> attr) {
        double best = 0;
        for (int i = 0; i < 36; i++) best = Math.max(best, value(p.getInventory().getItem(i), attr));
        return best;
    }

    /** Inventory index (0-35, hotbar first) of the item for this swap type, or -1. The offhand itself is not searched. */
    private int find(LocalPlayer p, String type) {
        int best = -1;
        double bestV = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.isEmpty()) continue;
            switch (type) {
                case BALL -> { if (isBall(s)) return i; }
                case TOTEM -> { if (isTotem(s) && !s.hasFoil()) return i; }
                case ETOTEM -> { if (isTotem(s) && s.hasFoil()) return i; }
                default -> {
                    double v = value(s, attrOf(type));
                    if (v > bestV) { bestV = v; best = i; }
                }
            }
        }
        return best;
    }
}
