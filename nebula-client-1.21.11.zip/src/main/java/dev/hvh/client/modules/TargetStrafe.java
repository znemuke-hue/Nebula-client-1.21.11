package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

/**
 * TargetStrafe: runs around the KillAura target.
 *
 *  Circle - keeps a fixed radius around the target. When a wall (or an edge / void) is in the way, the direction of
 *           rotation is flipped so you go around the target the other way.
 *  Random - radius is picked at random between the min and max radius and the direction (left / right) is re-rolled
 *           at random moments. Wall avoidance works the same way, and now and then you cut straight THROUGH the
 *           target and continue on its other side.
 *
 * Standalone: it does not need the Strafe or Speed module. It has its own Strafe-like movement - a fixed speed
 * ("Скорость (блок/с)"), no sliding (stops dead when you let go of the keys, in the air and on the ground) and an
 * "Только в воздухе" option. The velocity is set at the END of the tick, and LivingEntityMoveMixin drops the key
 * acceleration while {@link #active} so the circle is not bent by it. If Strafe / Speed are also on, this module
 * (registered after them) wins while there is a target.
 */
public class TargetStrafe extends Mod {
    /** True while this module owns the horizontal velocity of the coming tick (read by LivingEntityMoveMixin). */
    public static boolean active;

    private static final double EDGE_DROP = 3.0;   // a drop deeper than this counts as an edge / void

    private final Setting.Mode mode = add(new Setting.Mode("Режим", "Круг", "Круг", "Случайный"));
    private final Setting.Num radius = add(new Setting.Num("Радиус", 2.5, 0.5, 6.0, 0.1));
    private final Setting.Num minRadius = add(new Setting.Num("Мин. случайный радиус", 1.5, 0.5, 6.0, 0.1));
    private final Setting.Num maxRadius = add(new Setting.Num("Макс. случайный радиус", 3.5, 0.5, 6.0, 0.1));
    private final Setting.Num switchTicks = add(new Setting.Num("Смена стороны (тики)", 15, 5, 60, 1));
    private final Setting.Bool cross = add(new Setting.Bool("Иногда пересекать цель", true));
    private final Setting.Num crossChance = add(new Setting.Num("Шанс пересечения (%)", 25, 0, 100, 5));
    private final Setting.Bool autoJump = add(new Setting.Bool("Автопрыжок", true));
    private final Setting.Num speed = add(new Setting.Num("Скорость (блок/с)", 9, 1, 30, 0.5));
    private final Setting.Bool onlyAir = add(new Setting.Bool("Только в воздухе", false));
    private final Setting.Bool noSlide = add(new Setting.Bool("Убрать скольжение", true));
    private final Setting.Bool needKey = add(new Setting.Bool("Требовать клавишу движения", true));
    private final Setting.Bool avoidWalls = add(new Setting.Bool("Избегать стен", true));
    private final Setting.Bool avoidEdges = add(new Setting.Bool("Избегать краёв и пустоты", true));

    private final Random rng = new Random();
    private int dir = 1;              // +1 / -1 = which way round the target we run
    private double curRadius;         // radius currently held (Random: re-rolled now and then)
    private int switchLeft;           // Random: ticks until the next radius / direction / cross roll
    private boolean crossing;         // Random: running straight through the target
    private double crossAngle;        // angle (target -> me) at the moment the cross started
    private int crossTicks;

    public TargetStrafe() { super("Target Strafe", Category.MOVEMENT); }

    @Override protected void onEnable() { resetState(); active = false; }
    @Override protected void onDisable() { resetState(); active = false; }

    private void resetState() {
        crossing = false;
        switchLeft = 0;
        curRadius = 0;
    }

    @Override public void onTick() {
        active = false;
        Player p = mc.player;
        if (p == null || mc.level == null) return;

        KillAura aura = HvhClient.modules.killAura;
        LivingEntity t = aura.isEnabled() ? aura.currentTarget() : null;
        if (t == null || !t.isAlive() || t.isRemoved()) { resetState(); return; }
        if (!Speed.canMove(p) || p.hurtTime > 0) return;                    // let knockback through, like Strafe
        if (onlyAir.value && p.onGround()) return;

        Vec3 m = p.getDeltaMovement();
        if (needKey.value && p.xxa == 0 && p.zza == 0) {
            // no key held: stop dead instead of sliding (same as Strafe), on the ground and in the air
            if (noSlide.value) { p.setDeltaMovement(0.0, m.y, 0.0); active = true; }
            return;
        }

        double v = speed.value / 20.0;                                       // blocks per tick

        // target position one tick ahead (its real per-tick movement, getDeltaMovement is useless for other players)
        double tx = t.getX() + (t.getX() - t.xo);
        double tz = t.getZ() + (t.getZ() - t.zo);
        double px = p.getX(), pz = p.getZ();
        double dx = px - tx, dz = pz - tz;
        double dist = Math.sqrt(dx * dx + dz * dz);
        double ang = dist < 1.0E-3 ? Math.toRadians(p.getYRot() + 90.0) : Math.atan2(dz, dx); // angle target -> me

        if (mode.value.equals("Случайный")) {
            double lo = Math.min(minRadius.value, maxRadius.value), hi = Math.max(minRadius.value, maxRadius.value);
            tickRandom(ang, dist, lo, hi);
        } else {
            crossing = false;
            curRadius = radius.value;
        }

        double[] u = pick(p, tx, tz, px, pz, ang, dist, v);
        active = true;
        if (u == null) {                                  // boxed in on every side: stand still instead of ramming a wall
            p.setDeltaMovement(0.0, m.y, 0.0);
            return;
        }
        double y = m.y;
        if (autoJump.value && p.onGround()) y = p.getAttributeValue(Attributes.JUMP_STRENGTH);
        p.setDeltaMovement(u[0] * v, y, u[1] * v);
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Random mode: radius / direction / cross rolls
    // ---------------------------------------------------------------------------------------------------------------

    private void tickRandom(double ang, double dist, double lo, double hi) {
        if (curRadius <= 0) curRadius = lo + rng.nextDouble() * (hi - lo);
        if (crossing) {
            crossTicks++;
            // done once we are about on the opposite side (or it takes too long)
            if (Math.abs(wrapRad(ang - crossAngle)) > 2.6 || crossTicks > 40) {
                crossing = false;
                dir = rng.nextBoolean() ? 1 : -1;
            }
        }
        if (--switchLeft > 0) return;
        int base = switchTicks.value.intValue();
        switchLeft = Math.max(3, (int) Math.round(base * (0.5 + rng.nextDouble())));
        curRadius = lo + rng.nextDouble() * (hi - lo);
        if (crossing) return;
        if (cross.value && dist < hi + 2.0 && rng.nextInt(100) < crossChance.value.intValue()) {
            crossing = true;
            crossAngle = ang;
            crossTicks = 0;
        } else if (rng.nextBoolean()) {
            dir = -dir;                                   // left <-> right
        }
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Direction choice
    // ---------------------------------------------------------------------------------------------------------------

    /** Unit direction (x, z) to run in this tick, or null when every way is blocked. Flips {@link #dir} around walls. */
    private double[] pick(Player p, double tx, double tz, double px, double pz, double ang, double dist, double v) {
        if (crossing) {
            // straight line to the point opposite of where the cross started, through the target
            double[] c = norm(tx - Math.cos(crossAngle) * curRadius - px, tz - Math.sin(crossAngle) * curRadius - pz);
            if (c != null && !blocked(p, c[0], c[1], v)) return c;
            crossing = false;                             // wall in the way: give up the cross and circle again
        }
        double[] a = circleDir(tx, tz, px, pz, ang, curRadius, v, dir);
        if (!blocked(p, a[0], a[1], v)) return a;
        double[] b = circleDir(tx, tz, px, pz, ang, curRadius, v, -dir);
        if (!blocked(p, b[0], b[1], v)) { dir = -dir; return b; }   // wall: go round the target the other way

        // both tangents blocked (corner / pocket): back off from or push towards the target
        double[] in = { -Math.cos(ang), -Math.sin(ang) };
        double[] out = { Math.cos(ang), Math.sin(ang) };
        boolean tooFar = dist > curRadius;
        double[] first = tooFar ? in : out, second = tooFar ? out : in;
        if (!blocked(p, first[0], first[1], v)) return first;
        if (!blocked(p, second[0], second[1], v)) return second;
        return null;
    }

    /**
     * Aims at the point one tick further round the circle (radius r, direction d). Because the point lies ON the circle,
     * a wrong distance is corrected by itself: too close -> the path bends outwards, too far -> inwards.
     */
    private static double[] circleDir(double tx, double tz, double px, double pz, double ang, double r, double v, int d) {
        double step = Math.min(v / Math.max(r, 0.6), 0.9);
        double a2 = ang + d * step;
        double[] n = norm(tx + Math.cos(a2) * r - px, tz + Math.sin(a2) * r - pz);
        return n != null ? n : new double[] { -Math.sin(ang) * d, Math.cos(ang) * d };
    }

    /** True when running that way for the next ~2 ticks hits a wall (steppable ledges do not count) or an edge. */
    private boolean blocked(Player p, double ux, double uz, double v) {
        if (!avoidWalls.value && !avoidEdges.value) return false;
        double probe = Math.max(v * 2.0, 0.7);
        double stepH = Math.min(p.getAttributeValue(Attributes.STEP_HEIGHT), 2.5);
        AABB base = p.getBoundingBox();
        for (int i = 1; i <= 6; i++) {                    // several samples so a thin wall can not be jumped over
            double f = probe * i / 6.0;
            AABB box = base.move(ux * f, 0.0, uz * f).deflate(1.0E-4);
            if (avoidWalls.value && !mc.level.noCollision(p, box)) {
                boolean steppable = p.onGround() && stepH > 0 && mc.level.noCollision(p, box.move(0.0, stepH, 0.0));
                if (!steppable) return true;
            }
            if (avoidEdges.value && mc.level.noCollision(p, box.expandTowards(0.0, -EDGE_DROP, 0.0))) return true;
        }
        return false;
    }

    private static double[] norm(double x, double z) {
        double len = Math.sqrt(x * x + z * z);
        return len < 1.0E-6 ? null : new double[] { x / len, z / len };
    }

    private static double wrapRad(double a) {
        while (a > Math.PI) a -= 2.0 * Math.PI;
        while (a < -Math.PI) a += 2.0 * Math.PI;
        return a;
    }
}
