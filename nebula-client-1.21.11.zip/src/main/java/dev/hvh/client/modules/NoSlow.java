package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Removes the movement slowdown while using an item (eating, drinking, blocking, charging a bow...).
 *
 * Vanilla multiplies the movement input by 0.2 while an item is in use. Two independent hooks undo it
 * (see NoSlowMixin and NoSlowTravelMixin); {@link #boost} says by which factor the slowed input must be scaled.
 * The slowdown is removed completely (100 % speed).
 */
public final class NoSlow extends Mod {
    /** The factor vanilla applies to movement input while using an item. */
    public static final double VANILLA_FACTOR = 0.2;

    /** Set by NoSlowMixin when it already restored the speed during the current movement update. */
    public static boolean handled;

    public final Setting.Bool food = add(new Setting.Bool("Еда и зелья", true));
    public final Setting.Bool shield = add(new Setting.Bool("Щит", true));
    public final Setting.Bool bows = add(new Setting.Bool("Лук и арбалет", true));
    public final Setting.Bool trident = add(new Setting.Bool("Трезубец", true));
    public final Setting.Bool other = add(new Setting.Bool("Прочие предметы", true));

    public NoSlow() { super("No Slow", Category.MOVEMENT); }

    /** Kept for older callers: true when the module fully removes the slowdown. */
    public static boolean active() {
        if (HvhClient.modules == null) return false;
        NoSlow m = HvhClient.modules.noSlow;
        return m != null && m.isEnabled();
    }

    private boolean appliesTo(ItemStack stack) {
        if (stack.is(Items.SHIELD)) return shield.value;
        if (stack.is(Items.BOW) || stack.is(Items.CROSSBOW)) return bows.value;
        if (stack.is(Items.TRIDENT)) return trident.value;
        String anim;
        try { anim = stack.getUseAnimation().name(); } catch (Throwable t) { anim = ""; }
        if (anim.equals("EAT") || anim.equals("DRINK")) return food.value;
        return other.value;
    }

    /**
     * Multiplier to apply to the (already slowed) movement input of this player: 1.0 = leave it alone.
     * Slowed input = normal * 0.2, so a full restore is 1 / 0.2 = 5.
     */
    public static double boost(Player p) {
        if (HvhClient.modules == null || p == null) return 1.0;
        NoSlow m = HvhClient.modules.noSlow;
        if (m == null || !m.isEnabled() || !p.isUsingItem() || p.isPassenger()) return 1.0;
        if (!m.appliesTo(p.getUseItem())) return 1.0;
        return 1.0 / VANILLA_FACTOR;
    }
}
