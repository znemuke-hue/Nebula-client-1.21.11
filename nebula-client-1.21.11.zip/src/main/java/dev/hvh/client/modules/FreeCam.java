package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.Keys;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;

/**
 * FreeCam: the camera leaves your body and flies on its own (through blocks too), the player stays where it is.
 *
 * Packet-free by design: nothing is ever sent because of FreeCam. Your real position, rotation and inputs are the ones the
 * server already knows - the movement keys, jump, sneak, sprint, attack and use are simply held released for the player
 * while FreeCam is on (the keys are read straight from GLFW to fly the camera instead), and the mouse turns only the
 * camera. The player's position / rotation are swapped to the camera's for the duration of one rendered frame
 * ({@link #beginFrame} / {@link #endFrame}, the same trick FreeLook uses for the rotation) and put back right after it,
 * so the game never ticks with the swapped values.
 *
 * Controls: W/A/S/D fly relative to where the camera looks (horizontal), Space up, Sneak down.
 */
public final class FreeCam extends Mod {
    public final Setting.Num speed = add(new Setting.Num("Скорость полёта", 1.0, 0.1, 10.0, 0.1));
    public final Setting.Num verticalSpeed = add(new Setting.Num("Вертикальная скорость", 1.0, 0.1, 10.0, 0.1));

    /** Blocks per tick at speed 1.0 (about creative flight, same scale as Flight). */
    private static final double BASE = 0.5;

    private static boolean active;
    private static LocalPlayer owner;
    private static double x, y, z, ox, oy, oz;        // camera position now / one tick ago
    private static float camYaw, camPitch;

    private static boolean swapped;
    private static double sx, sy, sz, sxo, syo, szo;  // the real player position, saved while the camera is swapped in
    private static float sYaw, sPitch, sYawO, sPitchO;

    public FreeCam() { super("FreeCam", Category.VISUALS); }

    public static boolean active() { return active; }

    @Override protected void onEnable() {
        active = false;
        owner = null;
        init(mc.player);
    }

    @Override protected void onDisable() {
        endFrame();
        boolean was = active;
        active = false;
        owner = null;
        if (was) giveKeysBack();
    }

    /** The camera starts at the player's eyes, looking where the player looks. */
    private static void init(LocalPlayer p) {
        if (p == null) return;
        x = ox = p.getX();
        y = oy = p.getEyeY();
        z = oz = p.getZ();
        camYaw = p.getYRot();
        camPitch = p.getXRot();
        owner = p;
        active = true;
    }

    /** START of the tick, before the player is ticked: the camera moves one step. */
    @Override public void onPreTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { active = false; owner = null; return; }
        if (owner != p || !active) init(p);   // joined another world / respawned: start again from the new body

        ox = x; oy = y; oz = z;
        if (mc.screen != null || mc.options == null) return;
        Options o = mc.options;

        double fwd = (Keys.physical(o.keyUp) ? 1 : 0) - (Keys.physical(o.keyDown) ? 1 : 0);
        double side = (Keys.physical(o.keyLeft) ? 1 : 0) - (Keys.physical(o.keyRight) ? 1 : 0);   // left = +
        double up = (Keys.physical(o.keyJump) ? 1 : 0) - (Keys.physical(o.keyShift) ? 1 : 0);

        double yaw = Math.toRadians(camYaw);
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        // yaw 0 looks along +z; forward = (-sin, cos), left = (cos, sin)
        double dx = -sin * fwd + cos * side;
        double dz = cos * fwd + sin * side;
        double len = Math.sqrt(dx * dx + dz * dz);
        double step = speed.value * BASE;
        if (len > 1.0E-4) { x += dx / len * step; z += dz / len * step; }
        y += up * verticalSpeed.value * BASE;
    }

    /**
     * HvhClient calls this every tick right after the modules: the player must not act while the camera flies, whatever a
     * module (KillAura's W-tap, ActionLock giving keys back, ...) did to the keys before.
     */
    public static void enforce() {
        if (!active) return;
        LocalPlayer p = mc.player;
        Options o = mc.options;
        if (p == null || o == null) return;
        for (KeyMapping k : keys(o)) k.setDown(false);
        while (o.keyAttack.consumeClick()) { }
        while (o.keyUse.consumeClick()) { }
        if (p.isSprinting()) p.setSprinting(false);
    }

    private static KeyMapping[] keys(Options o) {
        return new KeyMapping[] { o.keyUp, o.keyDown, o.keyLeft, o.keyRight, o.keyJump, o.keySprint, o.keyShift, o.keyAttack, o.keyUse };
    }

    /** FreeCam is switched off: the keys you are still holding act on the player again (the game does not know they are down). */
    private static void giveKeysBack() {
        Options o = mc.options;
        if (o == null || mc.screen != null) return;
        for (KeyMapping k : keys(o)) if (!k.isDown() && Keys.physical(k)) k.setDown(true);
    }

    /** From Entity#turn: while FreeCam is on the mouse turns the camera only. true = the event is eaten. */
    public static boolean onTurn(double yawDelta, double pitchDelta) {
        if (!active) return false;
        camYaw += (float) (yawDelta * 0.15);
        camPitch = Mth.clamp(camPitch + (float) (pitchDelta * 0.15), -90.0F, 90.0F);
        return true;
    }

    /** Start of a rendered frame: the player "stands" where the camera is (the camera is built from the player). */
    public static void beginFrame() {
        if (!active || swapped) return;
        LocalPlayer p = mc.player;
        if (p == null || p != owner) return;
        float t = HvhClient.framePartial();
        double fx = Mth.lerp(t, ox, x), fy = Mth.lerp(t, oy, y), fz = Mth.lerp(t, oz, z);
        sx = p.getX(); sy = p.getY(); sz = p.getZ();
        sxo = p.xo; syo = p.yo; szo = p.zo;
        sYaw = p.getYRot(); sPitch = p.getXRot(); sYawO = p.yRotO; sPitchO = p.xRotO;

        double feetY = fy - p.getEyeHeight();
        p.setPosRaw(fx, feetY, fz);
        p.xo = fx; p.yo = feetY; p.zo = fz;     // no interpolation: the camera sits exactly at (fx, fy, fz)
        p.setYRot(camYaw); p.setXRot(camPitch);
        p.yRotO = camYaw; p.xRotO = camPitch;
        swapped = true;
    }

    /** End of the frame: the real player position and rotation come back (the game never ticks with the camera's). */
    public static void endFrame() {
        if (!swapped) return;
        swapped = false;
        LocalPlayer p = mc.player;
        if (p == null) return;
        p.setPosRaw(sx, sy, sz);
        p.xo = sxo; p.yo = syo; p.zo = szo;
        p.setYRot(sYaw); p.setXRot(sPitch);
        p.yRotO = sYawO; p.xRotO = sPitchO;
    }
}
