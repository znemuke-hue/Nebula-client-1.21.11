package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.Draw;
import dev.hvh.client.gui.Shapes;
import dev.hvh.client.gui.Theme;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Comparator;
import java.util.PriorityQueue;

/** Screen-space nametags: compact glass pill with name, health, a health bar, info row and item icons. */
public final class Nametags extends Mod {
    private static final Minecraft MC = Minecraft.getInstance();

    public final Setting.Bool players = add(new Setting.Bool("Игроки", true));
    public final Setting.Bool items = add(new Setting.Bool("Предметы", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Мобы", false));
    public final Setting.Num scale = add(new Setting.Num("Масштаб", 1.0, 0.5, 2.0, 0.05));
    public final Setting.Bool dynamicScale = add(new Setting.Bool("Масштаб по дистанции", true));
    public final Setting.Num maxDistance = add(new Setting.Num("Макс. дистанция", 128, 8, 256, 8));
    public final Setting.Bool culling = add(new Setting.Bool("Отсечение вне экрана", true));
    public final Setting.Bool skipInvisible = add(new Setting.Bool("Скрывать невидимых", false));

    public final Setting.Bool displayHealth = add(new Setting.Bool("Здоровье", true));
    public final Setting.Bool displayAbsorption = add(new Setting.Bool("Поглощение", true));
    public final Setting.Bool displayGameMode = add(new Setting.Bool("Режим игры", false));
    public final Setting.Bool displayPing = add(new Setting.Bool("Пинг", true));
    public final Setting.Bool displayDistance = add(new Setting.Bool("Дистанция", true));
    public final Setting.Bool displayItemInHand = add(new Setting.Bool("Предмет в руке", true));
    public final Setting.Bool displayArmor = add(new Setting.Bool("Экипировка", true));
    public final Setting.Bool displayDurability = add(new Setting.Bool("Прочность предметов", true));
    public final Setting.Bool displayEnchantments = add(new Setting.Bool("Зачарования предметов", true));
    public final Setting.Bool displayItemCount = add(new Setting.Bool("Количество предметов", true));
    public final Setting.Bool displayItemName = add(new Setting.Bool("Название предметов", true));
    public final Setting.Bool displayEntityName = add(new Setting.Bool("Название сущностей", true));
    public final Setting.Num itemSpacing = add(new Setting.Num("Расстояние между предметами", 2, 0, 10, 1));

    public final Setting.Bool background = add(new Setting.Bool("Фон плашки", true));
    public final Setting.Mode backgroundStyle = add(new Setting.Mode("Стиль плашки", "Стекло", "Стекло", "Ванильный", "Плоский", "Чёрный", "Прозрачный"));
    public final Setting.Mode healthColor = add(new Setting.Mode("Цвет здоровья", "По здоровью", "По здоровью", "Красный", "Зелёный", "По теме"));
    public final Setting.Mode nameColor = add(new Setting.Mode("Цвет имени", "Белый", "Белый", "По теме", "Голубой", "Зелёный", "Розовый", "Фиолетовый"));
    public final Setting.Mode itemNameColor = add(new Setting.Mode("Цвет предмета", "Белый", "Белый", "По теме", "Голубой", "Зелёный", "Розовый", "Фиолетовый"));
    public final Setting.Mode pingColor = add(new Setting.Mode("Цвет пинга", "По пингу", "По пингу", "По теме", "Белый", "Зелёный", "Жёлтый", "Красный"));
    public final Setting.Bool healthBar = add(new Setting.Bool("Полоска здоровья", true));
    public final Setting.Bool border = add(new Setting.Bool("Рамка плашки", true));
    public final Setting.Bool shadow = add(new Setting.Bool("Тень текста", true));
    public final Setting.Num backgroundOpacity = add(new Setting.Num("Непрозрачность фона", 75, 0, 100, 1));
    public final Setting.Bool hideSelf = add(new Setting.Bool("Не показывать себя", true));
    public final Setting.Bool showOnlyPlayers = add(new Setting.Bool("Только игроки", false));
    public final Setting.Num maxCount = add(new Setting.Num("Макс. количество тегов", 32, 1, 128, 1));
    /** Item icons are the most expensive part of a tag (one GUI item render each): only the nearest tags get them. */
    public final Setting.Num itemsMaxTags = add(new Setting.Num("Предметы: у ближайших тегов", 8, 0, 32, 1));
    public final Setting.Num itemsMaxDistance = add(new Setting.Num("Предметы: макс. дистанция", 40, 8, 128, 4));
    /** Shared by Nametags and TargetESP (see util/Projector). */
    public final Setting.Mode projSource = add(new Setting.Mode("Источник проекции", "Авто", "Авто", "Калибровка", "Хук FOV", "Движок"));
    public final Setting.Num fovFix = add(new Setting.Num("Поправка FOV (°)", 0, -30, 30, 0.5));

    public Nametags() { super("Nametags", Category.VISUALS); }

    private record Seg(String text, int color) {}

    private static final int ENCHANT_BADGE = 0xFFC77DFF;
    private static final int GOLD = 0xFFFFD84A;

    /**
     * Everything about one tag that can only change once per game tick: texts, colors, health, item list.
     * Built by {@link #rebuild()} ~20 times a second; the per-frame code only projects and draws it.
     */
    private static final class Tag {
        Entity entity;
        boolean player, item, hasHeader;
        String header = "", hpText, absText;
        int headerColor = Theme.TEXT, hpColor = 0xFFFFFFFF;
        double hpFrac = -1;
        final List<Seg> sub = new ArrayList<>();
        final List<ItemStack> stacks = new ArrayList<>();
    }

    private static final long REBUILD_NANOS = 45_000_000L;
    private static final List<Tag> CACHE = new ArrayList<>();
    private static long cacheAt;
    private static Object cacheLevel;

    public static void render(GuiGraphics g) {
        if (HvhClient.modules == null || MC.player == null || MC.level == null || MC.options.hideGui) return;
        Nametags tags = HvhClient.modules.nametags;
        if (tags == null || !tags.isEnabled() || MC.screen != null) return;

        // Entity search, text building and filtering are done once per tick, not every frame.
        long now = System.nanoTime();
        if (cacheLevel != MC.level || now - cacheAt >= REBUILD_NANOS) {
            tags.rebuild();
            cacheAt = now;
            cacheLevel = MC.level;
        }
        if (CACHE.isEmpty()) return;

        double range = tags.maxDistance.value;
        int itemTags = (int) Math.round(tags.itemsMaxTags.value);
        double itemRange = tags.itemsMaxDistance.value;

        // Like the rest of the Nebula HUD, nametags are drawn in REAL screen pixels (GUI scale undone),
        // so text is crisp and its size no longer depends on the vanilla GUI scale.
        float gs = (float) Math.max(1, MC.getWindow().getGuiScale());
        int rw = Math.round(MC.getWindow().getGuiScaledWidth() * gs), rh = Math.round(MC.getWindow().getGuiScaledHeight() * gs);
        float ui = Math.max(0.75f, Math.min(3f, MC.getWindow().getHeight() / 720f));

        g.pose().pushMatrix();
        g.pose().scale(1f / gs, 1f / gs);
        int drawn = 0;
        float pt = dev.hvh.client.util.Projector.partial();
        Vec3 me = dev.hvh.client.util.Interp.pos(MC.player, pt);
        for (int i = 0; i < CACHE.size(); i++) {
            Tag t = CACHE.get(i);
            Entity entity = t.entity;
            if (entity.isRemoved()) continue;
            Vec3 ip = dev.hvh.client.util.Interp.pos(entity, pt);
            double ddx = ip.x - me.x, ddy = ip.y - me.y, ddz = ip.z - me.z;
            // per-frame distance (from the interpolated positions), so the distance scaling does not step at 20 Hz
            double distance = Math.sqrt(ddx * ddx + ddy * ddy + ddz * ddz);
            if (distance > range) continue;
            double y = ip.y + entity.getBbHeight() + 0.25;
            Vec3 screen = dev.hvh.client.util.Projector.project(new Vec3(ip.x, y, ip.z));
            if (screen == null || !Double.isFinite(screen.x) || !Double.isFinite(screen.y) || !Double.isFinite(screen.z) || screen.z < -1 || screen.z > 1) continue;
            double cx = (screen.x + 1) * 0.5 * rw, sy = (1 - screen.y) * 0.5 * rh;
            if (tags.culling.value && (cx < -120 || cx > rw + 120 || sy < -120 || sy > rh + 120)) continue;
            boolean withItems = drawn < itemTags && distance <= itemRange;
            if (tags.drawTag(g, t, withItems, cx, sy, rw, rh, ui, distance)) drawn++;
        }
        Draw.flush();
        g.pose().popMatrix();
    }

    /** Picks the nearest eligible entities and prebuilds their tags (runs once per tick). */
    private void rebuild() {
        CACHE.clear();
        double range = maxDistance.value;
        int max = Math.max(1, Math.min(128, (int) Math.round(maxCount.value)));
        // Keep only the nearest candidates in a bounded max-heap instead of sorting every entity.
        int candidateLimit = Math.min(128, Math.max(max, max * 2));
        PriorityQueue<Entity> nearest = new PriorityQueue<>(candidateLimit,
            (a, b) -> Double.compare(b.distanceToSqr(MC.player), a.distanceToSqr(MC.player)));
        for (Entity candidate : MC.level.getEntitiesOfClass(Entity.class, MC.player.getBoundingBox().inflate(range), e -> true)) {
            if (!eligible(candidate, range)) continue;
            if (nearest.size() < candidateLimit) nearest.add(candidate);
            else if (candidate.distanceToSqr(MC.player) < nearest.peek().distanceToSqr(MC.player)) {
                nearest.poll(); nearest.add(candidate);
            }
        }
        if (nearest.isEmpty()) return;
        List<Entity> entities = new ArrayList<>(nearest);
        entities.sort(Comparator.comparingDouble(e -> e.distanceToSqr(MC.player)));
        for (Entity entity : entities) {
            if (CACHE.size() >= max) break;
            if (entity.isRemoved() || entity == MC.player && hideSelf.value
                || entity == MC.getCameraEntity() && MC.options.getCameraType().isFirstPerson()
                || skipInvisible.value && entity.isInvisible()) continue;
            double distance = entity.distanceTo(MC.player);
            if (distance > range) continue;
            boolean player = entity instanceof Player;
            boolean item = entity instanceof ItemEntity;
            boolean mob = entity instanceof LivingEntity && !(entity instanceof Player);
            if (showOnlyPlayers.value && !player) continue;
            if (player && !players.value || item && !items.value || mob && !mobs.value || !(player || item || mob)) continue;
            Tag t = build(entity, distance, player, item);
            if (t != null) CACHE.add(t);
        }
    }

    /** Builds the per-tick data of one tag. Returns null when there is nothing to show. */
    private Tag build(Entity entity, double distance, boolean player, boolean item) {
        Tag t = new Tag();
        t.entity = entity;
        t.player = player;
        t.item = item;
        List<Seg> sub = t.sub;
        List<ItemStack> stacks = t.stacks;

        if (item) {
            ItemStack stack = ((ItemEntity) entity).getItem();
            stacks.add(stack);
            if (displayItemName.value) t.header = stack.getHoverName().getString();
            t.headerColor = selectedColor(itemNameColor.value);
            if (displayDurability.value && stack.isDamageableItem()) {
                int max = Math.max(1, stack.getMaxDamage());
                int left = Math.max(0, max - stack.getDamageValue());
                sub.add(new Seg(left + "/" + max, durabilityColor(left / (double) max)));
            }
            if (displayEnchantments.value && hasEnchantments(stack)) sub.add(new Seg("Зачарован", ENCHANT_BADGE));
        } else {
            if (displayEntityName.value) t.header = entity.getName().getString();
            t.headerColor = selectedColor(nameColor.value);
            if (entity instanceof LivingEntity living) {
                if (displayHealth.value) {
                    float hp = Math.max(0f, living.getHealth());
                    t.hpFrac = Math.max(0.0, Math.min(1.0, hp / (double) Math.max(1f, living.getMaxHealth())));
                    t.hpText = fmtHealth(hp);
                    t.hpColor = healthColorFor(t.hpFrac);
                }
                if (displayAbsorption.value && living.getAbsorptionAmount() > 0.1f)
                    t.absText = "+" + fmtHealth(living.getAbsorptionAmount());
            }
            PlayerInfo info = null;
            if (player) {
                Player p = (Player) entity;
                info = MC.getConnection() == null ? null : MC.getConnection().getPlayerInfo(p.getUUID());
                if (displayPing.value && info != null) {
                    int ping = info.getLatency();
                    sub.add(new Seg(ping + " ms", pingColorFor(ping)));
                }
            }
            if (displayDistance.value) sub.add(new Seg(Math.round(distance) + "m", Theme.TEXT_DIM));
            if (player && displayGameMode.value && info != null && info.getGameMode() != null)
                sub.add(new Seg(info.getGameMode().toString().toLowerCase(Locale.ROOT), Theme.TEXT_DIM));
            if (player) {
                Player p = (Player) entity;
                if (displayItemInHand.value && !p.getMainHandItem().isEmpty()) stacks.add(p.getMainHandItem());
                if (displayArmor.value) {
                    EquipmentSlot[] armorOrder = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
                    for (EquipmentSlot slot : armorOrder) {
                        ItemStack stack = p.getItemBySlot(slot);
                        if (!stack.isEmpty()) stacks.add(stack);
                    }
                    if (!p.getOffhandItem().isEmpty()) stacks.add(p.getOffhandItem());
                }
            }
        }
        t.hasHeader = !t.header.isBlank() || t.hpText != null;
        if (!t.hasHeader && sub.isEmpty() && stacks.isEmpty()) return null;
        return t;
    }

    /** Draws one prebuilt nametag. Returns false when there is nothing to show. */
    private boolean drawTag(GuiGraphics g, Tag t, boolean withItems, double cx, double sy, int rw, int rh,
                            float ui, double distance) {
        String header = t.header, hpText = t.hpText, absText = t.absText;
        int headerColor = t.headerColor, hpColor = t.hpColor;
        double hpFrac = t.hpFrac;
        List<Seg> sub = t.sub;
        List<ItemStack> stacks = withItems ? t.stacks : List.of();
        boolean hasHeader = t.hasHeader;
        if (!hasHeader && sub.isEmpty() && stacks.isEmpty()) return false;

        // ---- metrics (real pixels). Sizes follow the window height, the user scale and distance.
        float k = ui * scale.value.floatValue();
        if (dynamicScale.value) k *= (float) Math.max(0.6, Math.min(1.0, 3.5 / Math.sqrt(distance + 1.0)));
        float th = 0.92f * k, ts = 0.68f * k, tc = 0.55f * k;
        int padX = Math.round(6 * k), padY = Math.round(4 * k), gap = Math.max(2, Math.round(3 * k));
        int hH = Draw.height(th), sH = Draw.height(ts);

        int nameW = header.isBlank() ? 0 : Draw.boldWidth(header, th);
        int hpW = hpText == null ? 0 : Draw.boldWidth(hpText, th);
        int absW = absText == null ? 0 : Draw.boldWidth(absText, th);
        int headerW = nameW;
        if (hpText != null) headerW += (nameW > 0 ? gap * 2 : 0) + hpW;
        if (absText != null) headerW += (headerW > 0 ? gap : 0) + absW;

        int dot = Math.max(2, Math.round(1.6f * k)), sepW = gap * 2 + dot, subW = 0;
        for (int i = 0; i < sub.size(); i++) subW += Draw.width(sub.get(i).text(), ts) + (i > 0 ? sepW : 0);

        boolean bar = healthBar.value && hpFrac >= 0;
        int barH = Math.max(2, Math.round(2 * k));
        int itemPx = Math.max(10, Math.round(14 * k));
        int itemGap = Math.max(1, Math.round((float) (itemSpacing.value * k)));
        boolean durRow = displayDurability.value;
        int durH = Math.max(2, Math.round(1.5f * k)), durPad = durRow ? durH + 2 : 0;
        int itemsW = stacks.isEmpty() ? 0 : stacks.size() * itemPx + (stacks.size() - 1) * itemGap;
        int itemsH = stacks.isEmpty() ? 0 : itemPx + durPad;

        int contentW = Math.max(headerW, Math.max(subW, itemsW));
        int width = contentW + padX * 2;
        int height = padY * 2;
        if (hasHeader) height += hH;
        if (bar) height += (hasHeader ? gap : 0) + barH;
        if (!sub.isEmpty()) height += (hasHeader || bar ? gap : 0) + sH;
        if (!stacks.isEmpty()) height += (height > padY * 2 ? gap : 0) + itemsH;

        int x = (int) Math.round(cx - width / 2.0), y = (int) Math.round(sy - height - 6 * k);
        x = Math.max(0, Math.min(rw - width, x));
        y = Math.max(0, Math.min(rh - height, y));

        // ---- background
        if (background.value) drawPanel(g, x, y, width, height, k);

        int ty = y + padY;
        if (hasHeader) {
            int hx = x + (width - headerW) / 2;
            if (nameW > 0) { text(g, true, header, hx, ty, headerColor, th); hx += nameW + (hpText != null ? gap * 2 : 0); }
            if (hpText != null) { text(g, true, hpText, hx, ty, hpColor, th); hx += hpW + gap; }
            if (absText != null) text(g, true, absText, hx, ty, GOLD, th);
            ty += hH + gap;
        }
        if (bar) {
            int bx = x + padX, bw = width - padX * 2;
            Draw.rect(g, bx, ty, bw, barH, 0x70000000);
            int fw = (int) Math.round(bw * hpFrac);
            if (fw > 0) Draw.rect(g, bx, ty, fw, barH, hpColor);
            ty += barH + gap;
        }
        if (!sub.isEmpty()) {
            int sx = x + (width - subW) / 2;
            for (int i = 0; i < sub.size(); i++) {
                if (i > 0) {
                    Draw.rect(g, sx + gap, ty + (sH - dot) / 2, dot, dot, Draw.alpha(Theme.TEXT_DIM, 0.7));
                    sx += sepW;
                }
                Seg seg = sub.get(i);
                text(g, false, seg.text(), sx, ty, seg.color(), ts);
                sx += Draw.width(seg.text(), ts);
            }
            ty += sH + gap;
        }
        if (!stacks.isEmpty()) {
            int ix = x + (width - itemsW) / 2;
            float f = itemPx / 16f;
            for (ItemStack stack : stacks) {
                g.pose().pushMatrix();
                g.pose().translate((float) ix, (float) ty);
                g.pose().scale(f, f);
                g.renderItem(stack, 0, 0);
                g.pose().popMatrix();
                if (displayItemCount.value && stack.getCount() > 1) {
                    String count = Integer.toString(stack.getCount());
                    text(g, true, count, ix + itemPx - Draw.boldWidth(count, tc), ty + itemPx - Draw.height(tc), 0xFFFFFFFF, tc);
                }
                if (displayEnchantments.value && hasEnchantments(stack)) {
                    int b = Math.max(3, Math.round(3 * k));
                    int bx = ix + itemPx - b;
                    Draw.rect(g, bx - 1, ty - 1, b + 2, b + 2, 0xCC000000);
                    Draw.rect(g, bx, ty, b, b, ENCHANT_BADGE);
                }
                if (durRow && stack.isDamageableItem()) {
                    int max = Math.max(1, stack.getMaxDamage());
                    double rem = Math.max(0, max - stack.getDamageValue()) / (double) max;
                    int by = ty + itemPx + 2;
                    Draw.rect(g, ix, by, itemPx, durH, 0x90000000);
                    int fw = Math.max(1, (int) Math.round(itemPx * rem));
                    Draw.rect(g, ix, by, fw, durH, durabilityColor(rem));
                }
                ix += itemPx + itemGap;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ drawing helpers

    private void text(GuiGraphics g, boolean bold, String s, float x, float y, int color, float t) {
        if (s.isEmpty()) return;
        if (shadow.value) {
            float o = Math.max(1f, Math.round(t * 0.9f));
            if (bold) Draw.textBold(g, s, x + o, y + o, 0x99000000, t); else Draw.text(g, s, x + o, y + o, 0x99000000, t);
        }
        if (bold) Draw.textBold(g, s, x, y, color, t); else Draw.text(g, s, x, y, color, t);
    }

    private void drawPanel(GuiGraphics g, int x, int y, int w, int h, float k) {
        String style = backgroundStyle.value;
        if (style.equals("Прозрачный")) return;
        int a = (int) Math.round(backgroundOpacity.value * 2.55);
        int base, r;
        boolean ring = border.value;
        int ringColor;
        switch (style) {
            case "Чёрный" -> { base = 0x000000; r = Math.round(2 * k); ring = false; ringColor = 0; }
            case "Ванильный" -> { base = 0x000000; r = 0; ring = false; ringColor = 0; }
            case "Плоский" -> { base = Theme.panelAt(0.5) & 0xFFFFFF; r = Math.round(2 * k);
                ringColor = Draw.alpha(0xFF000000 | (Theme.accent() & 0xFFFFFF), 0.45); }
            default -> { base = Theme.mix(Theme.panelAt(0.5) & 0xFFFFFF, 0x000000, 0.35); r = Math.round(5 * k);
                ringColor = Draw.alpha(0xFF000000 | (Theme.accent() & 0xFFFFFF), 0.75); }
        }
        roundFill(g, x, y, w, h, r, (Math.max(0, Math.min(255, a)) << 24) | (base & 0xFFFFFF));
        if (ring) roundRing(g, x, y, w, h, r, ringColor);
    }

    /** Rounded rectangle from cached corner textures: 3 fills + 4 corner blits (instead of a fill per corner row). */
    private static void roundFill(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x + r, y, x + w - r, y + r, c);
        g.fill(x, y + r, x + w, y + h - r, c);
        g.fill(x + r, y + h - r, x + w - r, y + h, c);
        Shapes.corner(g, 0, x, y, r, c);
        Shapes.corner(g, 1, x + w - r, y, r, c);
        Shapes.corner(g, 2, x, y + h - r, r, c);
        Shapes.corner(g, 3, x + w - r, y + h - r, r, c);
    }

    /** 1px outline: 4 straight fills + 4 cached hairline corner arcs. */
    private static void roundRing(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) {
            g.fill(x, y, x + w, y + 1, c); g.fill(x, y + h - 1, x + w, y + h, c);
            g.fill(x, y + 1, x + 1, y + h - 1, c); g.fill(x + w - 1, y + 1, x + w, y + h - 1, c);
            return;
        }
        g.fill(x + r, y, x + w - r, y + 1, c);
        g.fill(x + r, y + h - 1, x + w - r, y + h, c);
        g.fill(x, y + r, x + 1, y + h - r, c);
        g.fill(x + w - 1, y + r, x + w, y + h - r, c);
        Shapes.cornerArc(g, 0, x, y, r, c);
        Shapes.cornerArc(g, 1, x + w - r, y, r, c);
        Shapes.cornerArc(g, 2, x, y + h - r, r, c);
        Shapes.cornerArc(g, 3, x + w - r, y + h - r, r, c);
    }

    // ------------------------------------------------------------------ filters / colors

    private boolean eligible(Entity entity, double range) {
        if (entity == null || entity.isRemoved()) return false;
        if (entity == MC.player && hideSelf.value) return false;
        if (entity == MC.getCameraEntity() && MC.options.getCameraType().isFirstPerson()) return false;
        if (skipInvisible.value && entity.isInvisible()) return false;
        if (entity.distanceToSqr(MC.player) > range * range) return false;
        boolean player = entity instanceof Player;
        boolean item = entity instanceof ItemEntity;
        boolean mob = entity instanceof LivingEntity && !(entity instanceof Player);
        if (showOnlyPlayers.value && !player) return false;
        return player && players.value || item && items.value || mob && mobs.value;
    }

    private int healthColorFor(double frac) {
        return switch (healthColor.value) {
            case "Красный" -> 0xFFFF5555;
            case "Зелёный" -> 0xFF54FF70;
            case "По теме" -> Theme.accent();
            default -> frac > 0.66 ? 0xFF54FF70 : frac > 0.33 ? 0xFFFFD84A : 0xFFFF5555;
        };
    }

    private int pingColorFor(int ping) {
        return switch (pingColor.value) {
            case "По теме" -> Theme.accent();
            case "Белый" -> 0xFFFFFFFF;
            case "Зелёный" -> 0xFF54FF70;
            case "Жёлтый" -> 0xFFFFD84A;
            case "Красный" -> 0xFFFF5555;
            default -> ping <= 80 ? 0xFF54FF70 : ping <= 150 ? 0xFFFFD84A : 0xFFFF5555;
        };
    }

    private static int durabilityColor(double remaining) {
        return remaining > 0.5 ? 0xFF55E06D : remaining > 0.2 ? 0xFFFFD34D : 0xFFFF4D5A;
    }

    private static int selectedColor(String mode) {
        return switch (mode) {
            case "По теме" -> Theme.accent();
            case "Голубой" -> 0xFF65D8FF;
            case "Зелёный" -> 0xFF54FF70;
            case "Розовый" -> 0xFFFF65C8;
            case "Фиолетовый" -> 0xFFBA8AFF;
            default -> 0xFFFFFFFF;
        };
    }

    private static boolean hasEnchantments(ItemStack stack) {
        ItemEnchantments regular = stack.get(DataComponents.ENCHANTMENTS);
        ItemEnchantments stored = stack.get(DataComponents.STORED_ENCHANTMENTS);
        return regular != null && !regular.isEmpty() || stored != null && !stored.isEmpty();
    }

    private static String fmtHealth(float h) { return String.format(Locale.ROOT, "%.1f", Math.max(0, h)); }
}
