package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Speed.
 *  Vanilla - sets your horizontal speed (blocks per second) in the direction you are walking.
 *  Timer   - movement-only timer: you cover ground "multiplier" times faster, but the game itself is NOT sped up,
 *            so attack cooldown, item use, jumps and gravity stay exactly as they are.
 */
public class Speed extends Mod {
    private final Setting.Mode mode = add(new Setting.Mode("Режим", "Ванильный", "Ванильный", "Таймер"));
    private final Setting.Num speed = add(new Setting.Num("Скорость (блок/с)", 9, 4, 30, 0.5));
    private final Setting.Num timer = add(new Setting.Num("Множитель таймера", 1.5, 1.0, 4.0, 0.05));
    private final Setting.Bool groundOnly = add(new Setting.Bool("Только на земле", false));

    private double lastX, lastZ;
    private boolean hasLast;

    public Speed() { super("Speed", Category.MOVEMENT); }

    @Override protected void onEnable() { hasLast = false; }
    @Override protected void onDisable() { hasLast = false; }

    static boolean canMove(Player p) {
        return !p.isPassenger() && !p.isFallFlying() && !p.isInWater() && !p.isInLava() && !p.onClimbable()
            && !p.isShiftKeyDown() && (mc.screen == null || GuiMove.passing());
    }

    @Override public void onTick() {
        Player p = mc.player;
        if (p == null || mc.level == null) { hasLast = false; return; }
        if (!canMove(p) || (groundOnly.value && !p.onGround())) { hasLast = false; return; }
        if (mode.value.equals("Таймер")) timer(p); else vanilla(p);
    }

    private void vanilla(Player p) {
        double[] d = Rotations.inputDir(p);
        if (d == null) return;
        double target = speed.value / 20.0;                       // wanted distance per tick
        // the next tick adds its own acceleration on top of the velocity we set, so take it off
        double accel = p.onGround() ? p.getSpeed() * 1.33 : (p.isSprinting() ? 0.026 : 0.02);
        double v = Math.max(0.0, target - accel);
        Vec3 m = p.getDeltaMovement();
        p.setDeltaMovement(d[0] * v, m.y, d[1] * v);
    }

    /** Extra horizontal steps taken only by the player's position: nothing else in the game runs faster. */
    private void timer(Player p) {
        if (hasLast && (p.xxa != 0 || p.zza != 0)) {
            double dx = p.getX() - lastX, dz = p.getZ() - lastZ;
            double len = Math.sqrt(dx * dx + dz * dz);
            double extra = timer.value - 1.0;
            if (extra > 0 && len > 1.0E-3 && len < 2.0)
                p.move(MoverType.SELF, new Vec3(dx * extra, 0, dz * extra));
        }
        lastX = p.getX();   // measured AFTER our extra step, so it never compounds
        lastZ = p.getZ();
        hasLast = true;
    }
}
