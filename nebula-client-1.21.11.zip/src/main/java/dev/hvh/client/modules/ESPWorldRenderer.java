package dev.hvh.client.modules;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.hvh.client.HvhClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import org.lwjgl.system.MemoryUtil;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * 3D ESP renderer for Minecraft 1.21.11. Uses the entities' actual world AABBs and a single batched
 * color pipeline. No-depth pipeline state intentionally makes the boxes visible through blocks and entities.
 */
public final class ESPWorldRenderer {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final RenderPipeline THROUGH_WALLS = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("hvhclient", "pipeline/esp_through_walls"))
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .build()
    );
    /** Same pipeline but with the default depth test: used by Block Outline when "through walls" is off. */
    private static final RenderPipeline DEPTH_TESTED = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("hvhclient", "pipeline/block_outline_depth"))
            .build()
    );
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    /** One CPU-side vertex builder + a GPU ring buffer per pipeline (see the Fabric 1.21.11 "Rendering in the World" page). */
    private static final class Batch {
        final String name; final RenderPipeline pipeline;
        final ByteBufferBuilder allocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
        BufferBuilder builder; MappableRingBuffer ring; int vertices;
        Batch(String name, RenderPipeline pipeline) { this.name = name; this.pipeline = pipeline; }

        VertexConsumer begin() {
            if (builder == null) builder = new BufferBuilder(allocator, pipeline.getVertexFormatMode(), pipeline.getVertexFormat());
            return builder;
        }

        /** Builds, uploads and draws everything added since the last flush. */
        void flush(Minecraft mc) {
            if (builder == null) return;
            BufferBuilder b = builder; builder = null;
            if (vertices == 0) { try { b.build(); } catch (Throwable ignored) {} return; }
            vertices = 0;
            MeshData mesh = b.buildOrThrow();
            MeshData.DrawState state = mesh.drawState();
            VertexFormat format = state.format();
            int size = state.vertexCount() * format.getVertexSize();
            if (ring == null || ring.size() < size) {
                if (ring != null) ring.close();
                ring = new MappableRingBuffer(() -> "hvhclient " + name, GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
            }
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            try (GpuBuffer.MappedView view = encoder.mapBuffer(ring.currentBuffer().slice(0, mesh.vertexBuffer().remaining()), false, true)) {
                MemoryUtil.memCopy(mesh.vertexBuffer(), view.data());
            }
            GpuBuffer vertexBuffer = ring.currentBuffer();

            GpuBuffer indices; VertexFormat.IndexType indexType;
            if (pipeline.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
                mesh.sortQuads(allocator, RenderSystem.getProjectionType().vertexSorting());
                indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(mesh.indexBuffer());
                indexType = mesh.drawState().indexType();
            } else {
                RenderSystem.AutoStorageIndexBuffer seq = RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
                indices = seq.getBuffer(state.indexCount());
                indexType = seq.type();
            }
            GpuBufferSlice transforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);
            try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> "hvhclient " + name + " rendering",
                mc.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
                mc.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
                pass.setPipeline(pipeline);
                RenderSystem.bindDefaultUniforms(pass);
                pass.setUniform("DynamicTransforms", transforms);
                pass.setVertexBuffer(0, vertexBuffer);
                pass.setIndexBuffer(indices, indexType);
                pass.drawIndexed(0, 0, state.indexCount(), 1);
            }
            mesh.close();
            ring.rotate();
        }

        void close() { allocator.close(); if (ring != null) { ring.close(); ring = null; } }
    }

    private static final Batch BUFFER = new Batch("esp through walls", THROUGH_WALLS);
    private static final Batch BLOCK_BUFFER = new Batch("block outline", DEPTH_TESTED);
    private static volatile List<BoxState> snapshot = List.of();
    private static volatile BoxState blockOutlineSnapshot;
    private static volatile boolean blockOutlineThrough;
    private static volatile List<Trajectories.Segment> trajectorySnapshot = List.of();
    // Reused scratch storage: the world render callback is non-reentrant, so no per-segment arrays are needed.
    private static final double[] SEGMENT_A = new double[12];
    private static final double[] SEGMENT_B = new double[12];

    // Entity selection cache (see extract()).
    private static List<Entity> selected = List.of();
    private static long selectedAt;

    private ESPWorldRenderer() {}

    /** Nearest eligible entities (max 128), sorted by distance. Runs ~20x per second, not every frame. */
    private static List<Entity> selectEntities(ESP esp) {
        double range = esp.maxDistance.value;
        List<Entity> entities = MC.level.getEntitiesOfClass(Entity.class,
            MC.player.getBoundingBox().inflate(range), e -> e != MC.player || esp.ignoreSelf.value);
        PriorityQueue<Entity> nearest = new PriorityQueue<>(128,
            (a, b) -> Double.compare(b.distanceToSqr(MC.player), a.distanceToSqr(MC.player)));
        for (Entity entity : entities) {
            if (entity == null || entity.isRemoved()) continue;
            if (entity == MC.getCameraEntity() && MC.options.getCameraType().isFirstPerson()) continue;
            if (!esp.invisible.value && entity.isInvisible()) continue;
            double distSq = entity.distanceToSqr(MC.player);
            if (distSq > range * range) continue;
            boolean player = entity instanceof Player && entity != MC.player;
            boolean item = entity instanceof ItemEntity;
            boolean mob = entity instanceof LivingEntity && !(entity instanceof Player);
            boolean self = entity == MC.player && esp.ignoreSelf.value;
            if (player && !esp.players.value || item && !esp.items.value || mob && !esp.mobs.value) continue;
            if (!(player || item || mob || self)) continue;
            if (nearest.size() < 128) nearest.add(entity);
            else if (distSq < nearest.peek().distanceToSqr(MC.player)) { nearest.poll(); nearest.add(entity); }
        }
        List<Entity> list = new ArrayList<>(nearest);
        list.sort(Comparator.comparingDouble(e -> e.distanceToSqr(MC.player)));
        return list;
    }

    public static void close() { BUFFER.close(); BLOCK_BUFFER.close(); }

    /** Extraction phase: only immutable primitive data crosses into the drawing phase. */
    public static void extract() {
        if (HvhClient.modules == null || MC.player == null || MC.level == null) {
            snapshot = List.of();
            blockOutlineSnapshot = null;
            trajectorySnapshot = List.of();
            return;
        }
        Trajectories trajectories = HvhClient.modules.trajectories;
        trajectorySnapshot = trajectories != null && trajectories.isEnabled() && !MC.options.hideGui
            ? trajectories.collectSegments() : List.of();
        blockOutlineSnapshot = extractBlockOutline();
        ESP esp = HvhClient.modules.esp;
        if (esp == null || !esp.isEnabled() || !"3D-бокс".equals(esp.mode.value) || MC.screen != null || MC.options.hideGui) {
            snapshot = List.of();
            selected = List.of();
            return;
        }

        // The expensive part (world query, filtering, nearest-128 heap, sort) only runs every ~50 ms.
        // The cheap part (interpolated boxes) runs every frame, so boxes follow entities at the real frame rate
        // instead of jumping once per 20 Hz game tick.
        long now = System.nanoTime();
        if (now - selectedAt > 50_000_000L || selected.isEmpty() && now - selectedAt > 10_000_000L) {
            selected = selectEntities(esp);
            selectedAt = now;
        }
        float pt = HvhClient.partialTick();
        List<BoxState> out = new ArrayList<>(selected.size());
        for (Entity entity : selected) {
            if (entity.isRemoved()) continue;
            boolean player = entity instanceof Player && entity != MC.player;
            boolean item = entity instanceof ItemEntity;
            boolean self = entity == MC.player && esp.ignoreSelf.value;

            int fillBase, outlineBase;
            int alpha;
            boolean fill;
            double lineWidth;
            if (player || self) {
                fillBase = esp.color(esp.playerFillColor.value, entity, true);
                outlineBase = esp.color(esp.playerOutlineColor.value, entity, false);
                alpha = (int)Math.round(esp.playerFillAlpha.value * 2.55);
                fill = esp.playerFill.value;
                lineWidth = esp.playerOutlineWidth.value;
            } else if (item) {
                fillBase = esp.color(esp.itemFillColor.value, entity, true);
                outlineBase = esp.color(esp.itemOutlineColor.value, entity, false);
                alpha = (int)Math.round(esp.itemFillAlpha.value * 2.55);
                fill = esp.itemFill.value;
                lineWidth = esp.itemOutlineWidth.value;
            } else {
                fillBase = esp.color(esp.otherFillColor.value, entity, true);
                outlineBase = esp.color(esp.otherOutlineColor.value, entity, false);
                alpha = (int)Math.round(esp.otherFillAlpha.value * 2.55);
                fill = esp.otherFill.value;
                lineWidth = esp.otherOutlineWidth.value;
            }
            AABB box = dev.hvh.client.util.Interp.box(entity, pt);
            out.add(new BoxState(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ,
                withAlpha(fillBase, alpha), 0xFF000000 | (outlineBase & 0xFFFFFF), fill, lineWidth));
        }
        snapshot = List.copyOf(out);
    }

    /** Single world-render callback: snapshot the entities, then draw everything in one batched pass. */
    public static void onWorldRender(WorldRenderContext context) {
        extract();
        renderWorld(context);
    }

    /** Drawing phase: all boxes are submitted in one upload/pass instead of thousands of HUD fills. */
    public static void renderWorld(WorldRenderContext context) {
        List<BoxState> boxes = snapshot;
        BoxState blockOutline = blockOutlineSnapshot;
        boolean blockThrough = blockOutlineThrough;
        List<Trajectories.Segment> trajectories = trajectorySnapshot;
        if (boxes.isEmpty() && blockOutline == null && trajectories.isEmpty()) return;
        if (HvhClient.modules == null) return;

        boolean mainPass = !boxes.isEmpty() || !trajectories.isEmpty() || blockOutline != null && blockThrough;
        PoseStack poseStack = context.matrices();
        Vec3 camera = context.worldState().cameraRenderState.pos;
        if (mainPass) {
            poseStack.pushPose();
            poseStack.translate(-camera.x, -camera.y, -camera.z);
            Matrix4fc matrix = poseStack.last().pose();
            VertexConsumer vertices = BUFFER.begin();
            for (BoxState b : boxes) {
                if (b.fill && (b.fillColor >>> 24) != 0) addBox(vertices, matrix,
                    b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, b.fillColor);
                addOutline(vertices, matrix, b, camera);
            }
            if (blockOutline != null && blockThrough) addBlockHighlight(vertices, matrix, blockOutline, camera, 0.0);
            for (Trajectories.Segment segment : trajectories) addSegment(vertices, matrix, segment);
            poseStack.popPose();
            BUFFER.vertices = 1; // something was written (empty batches are skipped)
            BUFFER.flush(MC);
        }
        if (blockOutline != null && !blockThrough) renderBlockDepthTested(poseStack, camera, blockOutline);
    }

    /** Block Outline with the normal depth test (hidden behind other blocks) in its own tiny pass. */
    private static void renderBlockDepthTested(PoseStack poseStack, Vec3 camera, BoxState block) {
        poseStack.pushPose();
        poseStack.translate(-camera.x, -camera.y, -camera.z);
        Matrix4fc matrix = poseStack.last().pose();
        VertexConsumer vertices = BLOCK_BUFFER.begin();
        // The fill is pushed out by a hair so it does not z-fight with the faces of the block itself.
        addBlockHighlight(vertices, matrix, block, camera, 0.002);
        poseStack.popPose();
        BLOCK_BUFFER.vertices = 1;
        BLOCK_BUFFER.flush(MC);
    }

    private static void addBlockHighlight(VertexConsumer v, Matrix4fc m, BoxState b, Vec3 camera, double eps) {
        if (b.fill && (b.fillColor >>> 24) != 0) addBox(v, m,
            b.minX - eps, b.minY - eps, b.minZ - eps, b.maxX + eps, b.maxY + eps, b.maxZ + eps, b.fillColor);
        if (b.lineWidth > 0) addOutline(v, m, b, camera);
    }

    /** Snapshots the actual selected block outline shape; no HUD projection or per-pixel rasterization. */
    private static BoxState extractBlockOutline() {
        if (MC.player == null || MC.level == null || MC.options.hideGui || MC.screen != null
            || HvhClient.modules == null || HvhClient.modules.blockOutline == null
            || !HvhClient.modules.blockOutline.isEnabled()) return null;
        if (!(MC.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return null;
        BlockPos pos = hit.getBlockPos();
        BlockState state = MC.level.getBlockState(pos);
        var shape = state.getShape(MC.level, pos);
        if (shape.isEmpty()) return null;
        BlockOutline bo = HvhClient.modules.blockOutline;
        AABB box = shape.bounds().move(pos).inflate(bo.expand.value);
        int color = 0xFF000000 | (bo.colorValue() & 0xFFFFFF);
        int fillColor = withAlpha(bo.fillColorValue(), (int) Math.round(bo.fillAlpha.value * 2.55));
        blockOutlineThrough = bo.throughWalls.value;
        return new BoxState(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ,
            fillColor, color, bo.fill.value, bo.outline.value ? bo.width.value : 0);
    }

    private static void addOutline(VertexConsumer v, Matrix4fc m, BoxState b, Vec3 camera) {
        // Treat the width setting as approximate screen pixels: scale world-space geometry with distance
        // so the outline remains legible instead of shrinking to sub-pixel size across the 96-block range.
        double cx=(b.minX+b.maxX)*0.5, cy=(b.minY+b.maxY)*0.5, cz=(b.minZ+b.maxZ)*0.5;
        double dx=cx-camera.x, dy=cy-camera.y, dz=cz-camera.z;
        double distance=Math.sqrt(dx*dx+dy*dy+dz*dz);
        float width = (float)Math.max(0.004, Math.min(0.25, b.lineWidth * Math.max(1.0, distance) * 0.0015));
        double x0=b.minX, y0=b.minY, z0=b.minZ, x1=b.maxX, y1=b.maxY, z1=b.maxZ;
        int c=b.outlineColor;
        // 12 world-space rectangular prisms: 4 vertical, 4 along X, 4 along Z.
        edge(v,m,x0,y0,z0,x0,y1,z0,width,c); edge(v,m,x1,y0,z0,x1,y1,z0,width,c);
        edge(v,m,x1,y0,z1,x1,y1,z1,width,c); edge(v,m,x0,y0,z1,x0,y1,z1,width,c);
        edge(v,m,x0,y0,z0,x1,y0,z0,width,c); edge(v,m,x0,y1,z0,x1,y1,z0,width,c);
        edge(v,m,x0,y0,z1,x1,y0,z1,width,c); edge(v,m,x0,y1,z1,x1,y1,z1,width,c);
        edge(v,m,x0,y0,z0,x0,y0,z1,width,c); edge(v,m,x1,y0,z0,x1,y0,z1,width,c);
        edge(v,m,x0,y1,z0,x0,y1,z1,width,c); edge(v,m,x1,y1,z0,x1,y1,z1,width,c);
    }

    private static void edge(VertexConsumer v, Matrix4fc m, double x0,double y0,double z0,double x1,double y1,double z1,float w,int color) {
        double hx=(x0==x1?w*0.5:0), hy=(y0==y1?w*0.5:0), hz=(z0==z1?w*0.5:0);
        addBox(v,m,Math.min(x0,x1)-hx,Math.min(y0,y1)-hy,Math.min(z0,z1)-hz,
            Math.max(x0,x1)+hx,Math.max(y0,y1)+hy,Math.max(z0,z1)+hz,color);
    }

    /** A short oriented square prism; many trajectory ticks batch into the same GPU upload. */
    private static void addSegment(VertexConsumer v, Matrix4fc m, Trajectories.Segment s) {
        double dx=s.x1()-s.x0(), dy=s.y1()-s.y0(), dz=s.z1()-s.z0();
        double length=Math.sqrt(dx*dx+dy*dy+dz*dz);
        if (length < 1.0E-5) return;
        double nx=dx/length, ny=dy/length, nz=dz/length;
        double rx=Math.abs(ny)>0.92?1.0:0.0, ry=Math.abs(ny)>0.92?0.0:1.0, rz=0.0;
        double ux=ny*rz-nz*ry, uy=nz*rx-nx*rz, uz=nx*ry-ny*rx;
        double ul=Math.sqrt(ux*ux+uy*uy+uz*uz);
        if (ul < 1.0E-8) return;
        ux/=ul; uy/=ul; uz/=ul;
        double vx=ny*uz-nz*uy, vy=nz*ux-nx*uz, vz=nx*uy-ny*ux;
        double half=Math.max(0.002, s.width()*0.5);
        ux*=half; uy*=half; uz*=half; vx*=half; vy*=half; vz*=half;
        double ax=s.x0(), ay=s.y0(), az=s.z0(), bx=s.x1(), by=s.y1(), bz=s.z1();
        double[] a=SEGMENT_A, b=SEGMENT_B;
        for (int i=0;i<4;i++) {
            double su=(i==0||i==3)?1.0:-1.0, sv=(i<2)?1.0:-1.0;
            int k=i*3;
            a[k]=ax+su*ux+sv*vx; a[k+1]=ay+su*uy+sv*vy; a[k+2]=az+su*uz+sv*vz;
            b[k]=bx+su*ux+sv*vx; b[k+1]=by+su*uy+sv*vy; b[k+2]=bz+su*uz+sv*vz;
        }
        int c=s.color(); float r=((c>>16)&255)/255f, g=((c>>8)&255)/255f, blue=(c&255)/255f, alpha=((c>>>24)&255)/255f;
        face(v,m,a[0],a[1],a[2],a[3],a[4],a[5],b[3],b[4],b[5],b[0],b[1],b[2],r,g,blue,alpha);
        face(v,m,a[3],a[4],a[5],a[6],a[7],a[8],b[6],b[7],b[8],b[3],b[4],b[5],r,g,blue,alpha);
        face(v,m,a[6],a[7],a[8],a[9],a[10],a[11],b[9],b[10],b[11],b[6],b[7],b[8],r,g,blue,alpha);
        face(v,m,a[9],a[10],a[11],a[0],a[1],a[2],b[0],b[1],b[2],b[9],b[10],b[11],r,g,blue,alpha);
        face(v,m,a[0],a[1],a[2],a[9],a[10],a[11],a[6],a[7],a[8],a[3],a[4],a[5],r,g,blue,alpha);
        face(v,m,b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7],b[8],b[9],b[10],b[11],r,g,blue,alpha);
    }

    private static void addBox(VertexConsumer v, Matrix4fc m, double x0,double y0,double z0,double x1,double y1,double z1,int color) {
        float r=((color>>16)&255)/255f, g=((color>>8)&255)/255f, b=(color&255)/255f, a=((color>>>24)&255)/255f;
        face(v,m,x0,y0,z1,x1,y0,z1,x1,y1,z1,x0,y1,z1,r,g,b,a);
        face(v,m,x1,y0,z0,x0,y0,z0,x0,y1,z0,x1,y1,z0,r,g,b,a);
        face(v,m,x0,y0,z0,x0,y0,z1,x0,y1,z1,x0,y1,z0,r,g,b,a);
        face(v,m,x1,y0,z1,x1,y0,z0,x1,y1,z0,x1,y1,z1,r,g,b,a);
        face(v,m,x0,y1,z1,x1,y1,z1,x1,y1,z0,x0,y1,z0,r,g,b,a);
        face(v,m,x0,y0,z0,x1,y0,z0,x1,y0,z1,x0,y0,z1,r,g,b,a);
    }

    private static void face(VertexConsumer v, Matrix4fc m,
            double x0,double y0,double z0,double x1,double y1,double z1,
            double x2,double y2,double z2,double x3,double y3,double z3,
            float r,float g,float b,float a) {
        v.addVertex(m,(float)x0,(float)y0,(float)z0).setColor(r,g,b,a);
        v.addVertex(m,(float)x1,(float)y1,(float)z1).setColor(r,g,b,a);
        v.addVertex(m,(float)x2,(float)y2,(float)z2).setColor(r,g,b,a);
        v.addVertex(m,(float)x3,(float)y3,(float)z3).setColor(r,g,b,a);
    }

    private static int withAlpha(int rgb, int alpha) { return (Math.max(0,Math.min(255,alpha)) << 24) | (rgb & 0xFFFFFF); }
    private record BoxState(double minX,double minY,double minZ,double maxX,double maxY,double maxZ,
                            int fillColor,int outlineColor,boolean fill,double lineWidth) {}
}
