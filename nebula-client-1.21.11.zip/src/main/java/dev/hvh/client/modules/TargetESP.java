package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.Theme;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import com.mojang.blaze3d.platform.NativeImage;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Image-based TargetESP. The sprite is placed in the HUD layer at the projected target position,
 * so it is intentionally not depth-tested and remains visible through blocks and entities.
 */
public final class TargetESP extends Mod {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final Identifier TEXTURE_ID = Identifier.fromNamespaceAndPath("hvhclient", "targetesp/sprite");
    private static final int MAX_IMAGE_SIDE = 1024;

    public final Setting.Mode mode = add(new Setting.Mode("Режим", "Изображение", "Изображение", "Цвет темы"));
    public final Setting.Num size = add(new Setting.Num("Размер", 1.45, 0.50, 3.00, 0.05));
    public final Setting.Num yOffset = add(new Setting.Num("Смещение по Y", 0.0, -1.0, 1.0, 0.05));
    public final Setting.Num opacity = add(new Setting.Num("Прозрачность", 100, 10, 100, 5));
    public final Setting.Mode spinMode = add(new Setting.Mode("Вращение", "Туда-сюда", "Выкл", "Постоянно", "Туда-сюда"));
    public final Setting.Num spinSpeed = add(new Setting.Num("Макс. скорость (°/с)", 360, 30, 1440, 30));
    public final Setting.Num spinPhase = add(new Setting.Num("Смена направления (сек)", 2.0, 0.5, 15.0, 0.5));
    public final Setting.Num spinSmooth = add(new Setting.Num("Плавность разгона (%)", 70, 0, 100, 5));
    public final Setting.Action choose = add(new Setting.Action("Выбрать своё изображение", dev.hvh.client.gui.TargetImagePicker::open));

    private final Path imageDir = FabricLoader.getInstance().getConfigDir().resolve("hvhclient/targetesp");
    private Path loadedPath;
    private FileTime loadedModified;
    private long loadedSize = -1;
    private int loadedTint = Integer.MIN_VALUE;
    private long nextScanAt;
    private DynamicTexture texture;
    private int imageWidth, imageHeight;
    private boolean directoryReady;

    public TargetESP() {
        super("TargetESP", Category.VISUALS);
        ensureDirectory();
    }

    public Path imageDirectory() { return imageDir; }

    private void ensureDirectory() {
        if (directoryReady) return;
        directoryReady = true;
        try {
            Files.createDirectories(imageDir);
            Path readme = imageDir.resolve("README.txt");
            if (!Files.exists(readme)) {
                Files.writeString(readme,
                    "Nebula Client - TargetESP\n\n" +
                    "Drop .png, .jpg or .jpeg images here. Use the in-game picker to choose one.\n" +
                    "Built-in presets: default-target.png, default-target-orbit.png, default-target-corners.png and default-target-plus.png.\n" +
                    "The sprite is drawn over the world (through walls and entities).\n");
            }
            for (String preset : List.of("default-target.png", "default-target-orbit.png", "default-target-corners.png", "default-target-plus.png")) {
                Path builtIn = imageDir.resolve(preset);
                if (!Files.exists(builtIn)) {
                    try (InputStream in = TargetESP.class.getResourceAsStream("/targetesp-assets/" + preset)) {
                        if (in != null) Files.copy(in, builtIn);
                    }
                }
            }
        } catch (Exception ignored) { }
    }

    private static boolean supported(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg");
    }

    private static final String DEFAULT_NAME = "default-target.png";
    private volatile String lastError = "";
    private volatile boolean forceReload;

    public String lastError() { return lastError; }

    /** Name of the explicitly chosen image ("" = none chosen: the newest custom image wins). */
    public String selectedName() {
        try {
            Path f = imageDir.resolve("selected.txt");
            if (Files.isRegularFile(f)) return Files.readString(f).trim();
        } catch (Exception ignored) { }
        return "";
    }

    /** Extra places a phone/PC user is likely to have pictures in. Only existing, readable folders are listed. */
    public static List<Path> extraFolders() {
        List<Path> out = new java.util.ArrayList<>();
        String[] guesses = {
            "/storage/emulated/0/Download", "/storage/emulated/0/Pictures", "/storage/emulated/0/DCIM",
            System.getProperty("user.home", "") + "/Downloads", System.getProperty("user.home", "") + "/Pictures",
            System.getProperty("user.home", "") + "/Desktop"
        };
        for (String g : guesses) {
            try {
                Path p = Path.of(g);
                if (Files.isDirectory(p) && Files.isReadable(p) && !out.contains(p)) out.add(p);
            } catch (Exception ignored) { }
        }
        return out;
    }

    /** Every selectable image: the TargetESP folder first, then the extra folders (not recursive, capped). */
    public List<Path> candidates() {
        ensureDirectory();
        List<Path> out = new java.util.ArrayList<>();
        List<Path> dirs = new java.util.ArrayList<>();
        dirs.add(imageDir);
        dirs.addAll(extraFolders());
        for (Path dir : dirs) {
            try (Stream<Path> paths = Files.list(dir)) {
                paths.filter(Files::isRegularFile).filter(TargetESP::supported)
                    .filter(p -> !p.getFileName().toString().equalsIgnoreCase(DEFAULT_NAME))
                    .sorted(Comparator.comparing((Path p) -> p.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .limit(200).forEach(out::add);
            } catch (Exception ignored) { }
            if (out.size() >= 400) break;
        }
        return out;
    }

    /** Picks an image. Files from other folders are copied into the TargetESP folder. Returns null on success. */
    public String select(Path file) {
        ensureDirectory();
        try {
            if (file == null) { Files.writeString(imageDir.resolve("selected.txt"), DEFAULT_NAME); forceReload = true; return null; }
            if (!Files.isRegularFile(file) || !supported(file)) return "Нужен файл .png, .jpg или .jpeg";
            Path target = file;
            if (!file.toAbsolutePath().normalize().getParent().equals(imageDir.toAbsolutePath().normalize())) {
                String name = file.getFileName().toString();
                target = imageDir.resolve(name);
                // Import the exact file the user picked, even when a same-named image already exists.
                // This lets users deliberately replace a preset or update a previously imported image.
                if (!file.toAbsolutePath().normalize().equals(target.toAbsolutePath().normalize()))
                    Files.copy(file, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            Files.writeString(imageDir.resolve("selected.txt"), target.getFileName().toString());
            forceReload = true;
            lastError = "";
            return null;
        } catch (Exception e) {
            return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        }
    }

    private Path selectedImage() {
        ensureDirectory();
        String chosen = selectedName();
        if (!chosen.isEmpty()) {
            Path p = imageDir.resolve(chosen).normalize();
            if (p.startsWith(imageDir.normalize()) && Files.isRegularFile(p) && supported(p)) return p;
        }
        try (Stream<Path> paths = Files.list(imageDir)) {
            List<Path> custom = paths.filter(Files::isRegularFile)
                .filter(TargetESP::supported)
                .filter(p -> !p.getFileName().toString().toLowerCase(Locale.ROOT).startsWith("default-target"))
                .sorted(Comparator.comparing((Path p) -> {
                    try { return Files.getLastModifiedTime(p); }
                    catch (Exception e) { return FileTime.fromMillis(0); }
                }).reversed())
                .toList();
            if (!custom.isEmpty()) return custom.get(0);
        } catch (Exception ignored) { }
        Path fallback = imageDir.resolve("default-target.png");
        return Files.isRegularFile(fallback) ? fallback : null;
    }

    // File scanning and image decoding run on a background thread: stat() on phone storage and ImageIO can take
    // tens of milliseconds, and doing that on the render thread once a second made the sprite hitch.
    private static final java.util.concurrent.ExecutorService LOADER = java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "nebula-targetesp-loader");
        t.setDaemon(true);
        return t;
    });
    private final java.util.concurrent.atomic.AtomicBoolean loading = new java.util.concurrent.atomic.AtomicBoolean();
    private volatile Loaded ready;

    private record Loaded(NativeImage pixels, Path path, FileTime modified, long size, int tint) {}

    /** Render thread, cheap: uploads a finished image and (at most once a second) asks the loader to re-check the file. */
    private void refreshImageIfNeeded() {
        Loaded done = ready;
        if (done != null) {
            ready = null;
            applyLoaded(done);
        }
        long now = System.nanoTime();
        if ((now < nextScanAt && !forceReload) || loading.get()) return;
        forceReload = false;
        nextScanAt = now + 1_000_000_000L;
        final int tint = mode.value.equals("Цвет темы") ? Theme.accent() & 0xFFFFFF : -1;
        final Path curPath = loadedPath;
        final FileTime curModified = loadedModified;
        final long curSize = loadedSize;
        final int curTint = loadedTint;
        final boolean hasTexture = texture != null;
        loading.set(true);
        LOADER.execute(() -> {
            try {
                Path selected = selectedImage();
                if (selected == null) return;
                FileTime modified = Files.getLastModifiedTime(selected);
                long fileSize = Files.size(selected);
                if (hasTexture && selected.equals(curPath) && modified.equals(curModified) && fileSize == curSize && curTint == tint) return;
                NativeImage pixels = readImage(selected, tint);
                ready = new Loaded(pixels, selected, modified, fileSize, tint);
                lastError = "";
            } catch (Throwable e) {
                // Keep the last known-good texture if a file is incomplete while being copied.
                lastError = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            } finally {
                loading.set(false);
            }
        });
    }

    private void applyLoaded(Loaded r) {
        try {
            DynamicTexture replacement = new DynamicTexture(() -> "hvhclient_targetesp_sprite", r.pixels());
            replacement.upload();
            MC.getTextureManager().register(TEXTURE_ID, replacement);
            texture = replacement;
            imageWidth = r.pixels().getWidth();
            imageHeight = r.pixels().getHeight();
            loadedPath = r.path();
            loadedModified = r.modified();
            loadedSize = r.size();
            loadedTint = r.tint();
            lastError = "";
        } catch (Throwable e) {
            lastError = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        }
    }

    private static NativeImage readImage(Path path, int tint) throws Exception {
        BufferedImage source;
        try (InputStream input = Files.newInputStream(path)) { source = ImageIO.read(input); }
        if (source == null) throw new IllegalArgumentException("Unsupported image: " + path.getFileName());
        int sw = source.getWidth(), sh = source.getHeight();
        if (sw < 1 || sh < 1) throw new IllegalArgumentException("Empty image");
        double scale = Math.min(1.0, MAX_IMAGE_SIDE / (double) Math.max(sw, sh));
        int w = Math.max(1, (int) Math.round(sw * scale));
        int h = Math.max(1, (int) Math.round(sh * scale));
        BufferedImage converted = source;
        if (w != sw || h != sh) {
            converted = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = converted.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(source, 0, 0, w, h, null);
            g.dispose();
        }
        int[] rgb = converted.getRGB(0, 0, w, h, null, 0, w);
        NativeImage out = new NativeImage(NativeImage.Format.RGBA, w, h, false);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int p = rgb[y * w + x];
                int a = p >>> 24, r = (p >>> 16) & 255, g = (p >>> 8) & 255, b = p & 255;
                if (tint >= 0) {
                    int intensity = Math.max(r, Math.max(g, b));
                    r = ((tint >>> 16) & 255) * intensity / 255;
                    g = ((tint >>> 8) & 255) * intensity / 255;
                    b = (tint & 255) * intensity / 255;
                }
                out.setPixelABGR(x, y, (a << 24) | (b << 16) | (g << 8) | r);
            }
        }
        return out;
    }

    @Override public void onTick() {
        // Image IO only runs on the render layer; it polls periodically to support dropping files while in-game.
    }

    @Override protected void onDisable() { }

    /** Called by a dedicated last HUD layer registered from HvhClient. */
    public static void render(GuiGraphics g) {
        if (HvhClient.modules == null) return;
        TargetESP esp = HvhClient.modules.targetESP;
        if (esp == null || !esp.isEnabled() || MC.player == null || MC.level == null || MC.options.hideGui) return;
        if (MC.screen != null) return;

        // Prefer AimAssist's selected target. Previously TargetESP only queried KillAura,
        // so an AimAssist-only setup never had a target to render.
        AimAssist aimAssist = HvhClient.modules.aimAssist;
        LivingEntity target = aimAssist != null && aimAssist.isEnabled()
            ? aimAssist.currentTarget()
            : null;

        // Keep backward compatibility with KillAura setups. If AimAssist is enabled but has
        // no valid target for this tick, fall back to KillAura's active target.
        if (target == null || target == MC.player || target.isRemoved() || !target.isAlive()) {
            KillAura aura = HvhClient.modules.killAura;
            target = aura != null && aura.isEnabled() ? aura.currentTarget() : null;
        }
        if (target == null || target == MC.player || target.isRemoved() || !target.isAlive()) return;

        esp.refreshImageIfNeeded();
        if (esp.texture == null || esp.imageWidth <= 0 || esp.imageHeight <= 0) return;

        // Interpolated position: the target moves smoothly every frame, not once per 20 Hz tick.
        float pt = dev.hvh.client.util.Projector.partial();
        Vec3 pos = dev.hvh.client.util.Interp.pos(target, pt);
        double x = pos.x, z = pos.z;
        double baseY = pos.y + esp.yOffset.value;
        double h = target.getBbHeight();
        Vec3 centerWorld = new Vec3(x, baseY + h * 0.5, z);
        Vec3 center = dev.hvh.client.util.Projector.project(centerWorld);
        if (!validProjection(center)) return;

        int screenW = MC.getWindow().getGuiScaledWidth();
        int screenH = MC.getWindow().getGuiScaledHeight();
        double cx = (center.x + 1.0) * 0.5 * screenW;
        double cy = (1.0 - center.y) * 0.5 * screenH;

        // Size from a camera-facing measure (pixels per block at the target's depth), not from the on-screen height of the
        // vertical top->bottom segment: seen from straight above / below that segment is foreshortened to almost nothing.
        double ppb = dev.hvh.client.util.Projector.pixelsPerBlock(centerWorld, screenW, screenH);
        double projectedHeight;
        if (ppb > 0) {
            projectedHeight = ppb * h;
        } else {
            Vec3 top = dev.hvh.client.util.Projector.project(new Vec3(x, baseY + h, z));
            Vec3 bottom = dev.hvh.client.util.Projector.project(new Vec3(x, baseY, z));
            if (!validProjection(top) || !validProjection(bottom)) return;
            projectedHeight = Math.abs((1.0 - bottom.y) * 0.5 * screenH - (1.0 - top.y) * 0.5 * screenH);
        }
        if (!Double.isFinite(cx) || !Double.isFinite(cy) || !Double.isFinite(projectedHeight) || projectedHeight < 1.0) return;

        double drawH = Math.min(screenH * 1.2, projectedHeight * esp.size.value);
        double drawW = drawH * (esp.imageWidth / (double) esp.imageHeight);
        double reach = Math.max(drawW, drawH) * 0.75;
        if (cx + reach < 0 || cx - reach > screenW || cy + reach < 0 || cy - reach > screenH) return;

        int alpha = (int) Math.round(esp.opacity.value * 2.55);
        int color = (Math.max(0, Math.min(255, alpha)) << 24) | 0xFFFFFF;
        int iw = esp.imageWidth, ih = esp.imageHeight;
        // The sprite is always blitted at its own pixel size and scaled through the pose matrix, so position, size
        // and rotation move in sub-pixel steps every frame (integer-rounded sizes made it shimmer).
        g.pose().pushMatrix();
        g.pose().translate((float) cx, (float) cy);
        double deg = esp.spinAngle(System.nanoTime() / 1.0E9);
        if (deg != 0.0) g.pose().rotate((float) Math.toRadians(deg));
        g.pose().scale((float) (drawW / iw), (float) (drawH / ih));
        g.pose().translate(-iw / 2f, -ih / 2f);
        g.blit(RenderPipelines.GUI_TEXTURED, TEXTURE_ID, 0, 0, 0.0F, 0.0F, iw, ih, iw, ih, iw, ih, color);
        g.pose().popMatrix();
    }

    /**
     * Rotation angle in degrees at time t (seconds).
     * "Постоянно": one direction at the max speed.
     * "Туда-сюда": a fan. Each phase lasts "Смена направления" seconds; the sprite speeds up, spins at max speed,
     * slows down to a stop, then the next phase spins the other way (back to the start), and so on forever.
     * "Плавность" is the share of a phase spent speeding up / slowing down (0 = instant, 100 = pure bell curve).
     */
    private double spinAngle(double t) {
        double w = spinSpeed.value;
        if ("Выкл".equals(spinMode.value)) return 0.0;
        if ("Постоянно".equals(spinMode.value)) return (t * w) % 360.0;
        double period = Math.max(0.1, spinPhase.value);
        double r = Math.max(0.0, Math.min(1.0, spinSmooth.value / 100.0)) * 0.5; // ramp share on each side
        double k = Math.floor(t / period);
        double u = t / period - k;
        double total = (1.0 - r) * period * w;           // degrees turned during one full phase
        double part = ramp(u, r) * period * w;           // degrees turned so far in this phase
        return (((long) k) & 1L) == 0L ? part : total - part;
    }

    /** Integral of the speed profile (smoothstep ramps of length r, flat in between) from 0 to u, u in 0..1. */
    private static double ramp(double u, double r) {
        if (r <= 1.0E-6) return u;
        if (u < r) { double x = u / r; return r * (x * x * x - x * x * x * x * 0.5); }
        if (u <= 1.0 - r) return r * 0.5 + (u - r);
        double y = (1.0 - u) / r;
        return (1.0 - r) - r * (y * y * y - y * y * y * y * 0.5);
    }

    private static boolean validProjection(Vec3 p) {
        return p != null && Double.isFinite(p.x) && Double.isFinite(p.y) && Double.isFinite(p.z)
            && p.z >= -1.0 && p.z <= 1.0;
    }
}
