package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.NeuroModelPicker;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.module.Rotations;
import dev.hvh.client.neuro.NeuroAim;
import dev.hvh.client.neuro.NeuroTracker;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.ActionLock;
import dev.hvh.client.util.Keys;
import dev.hvh.client.util.SprintGate;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

public class KillAura extends Mod {
    private static final String SILENT = "ХвХ", NEURO = "Нейро";
    private static final String SINGLE = "Бить одного", MULTI = "Множеств. целей";
    // ---- Цели
    private final Setting.Bool players = add("Кого бить", "Игроки", new Setting.Bool("Игроки", true));
    private final Setting.Bool mobs = add("Кого бить", "Мобы", new Setting.Bool("Мобы", false));
    private final Setting.Bool villagers = add("Кого бить", "Жители", new Setting.Bool("Жители", false));
    private final Setting.Bool invisible = add("Кого бить", "Невидимые", new Setting.Bool("Невидимые", false));
    private final Setting.Bool naked = add("Кого бить", "Голые", new Setting.Bool("Игроки без брони", false));
    // ---- Не бить если
    private final Setting.Bool skipContainer = add("Не бить если", "В интерфейсе", new Setting.Bool("Не атаковать в интерфейсе", true));
    private final Setting.Bool skipEating = add("Не бить если", "Во время еды", new Setting.Bool("Не атаковать во время еды", true));
    private final Setting.Bool skipElytra = add("Не бить если", "В полёте", new Setting.Bool("Не атаковать в полёте", true));
    private final Setting.Bool weaponOnly = add("Не бить если", "Без оружия", new Setting.Bool("Только с оружием", false));
    private final Setting.Bool onlyCrits = add("Не бить если", "Без крита", new Setting.Bool("Только критические удары", false));
    // ---- Проверки видимости и луча
    private final Setting.Bool throughWalls = add("Проверки", new Setting.Bool("Сквозь стены", true));
    private final Setting.Bool rayCheck = add("Проверки", new Setting.Bool("Проверять луч", true));
    // ---- Сортировка
    private final Setting.Mode priority = add("Сортировка", new Setting.Mode("Приоритет", "Авто", "Дистанция", "Угол обзора", "Здоровье", "Броня", "Авто"));
    // ---- Ротация
    private final Setting.Mode aimMode = add("Ротация", new Setting.Mode("Режим наведения", SILENT, SILENT, NEURO));
    private final Setting.Action chooseModel = add("Ротация", new Setting.Action("Выбрать модель (Нейро)", NeuroModelPicker::open));
    private final Setting.Num neuroStrength = add("Ротация", new Setting.Num("Сила нейро (%)", 100, 10, 150, 5));
    private final Setting.Num neuroHitError = add("Ротация", new Setting.Num("Макс. ошибка наводки для удара (°)", 15, 2, 60, 1));
    private final Setting.Mode moveFix = add("Ротация", new Setting.Mode("Коррекция движения", "По серверной", "По серверной", "По камере", "По цели"));
    // ---- Тип
    private final Setting.Mode targetType = add("Тип", new Setting.Mode("Тип", MULTI, SINGLE, MULTI));
    // ---- Булава
    private final Setting.Bool maceFull = add("Булава", "Полная зарядка", new Setting.Bool("Булава: бить только на 100% перезарядки", true));
    private final Setting.Bool maceItemCd = add("Булава", "Не на кулдауне", new Setting.Bool("Булава: не бить при кулдауне предмета", true));
    private final Setting.Bool maceMinFall = add("Булава", "С 1.5 блока", new Setting.Bool("Булава: бить только с 1.5 блока", true));
    // ---- Остальное
    private final Setting.Num attackRange = add("Остальное", new Setting.Num("Дистанция атаки", 3.2, 3.0, 6.0, 0.1));
    private final Setting.Num aimExtra = add("Остальное", new Setting.Num("Доп. дистанция наведения", 1.0, 0.0, 4.0, 0.1));
    private final Setting.Num fov = add("Остальное", new Setting.Num("Угол обзора", 180, 10, 360, 5));
    private final Setting.Num aps = add("Остальное", new Setting.Num("Атак в секунду", 10, 1, 20, 1));
    private final Setting.Num stickDist = add("Остальное", new Setting.Num("Дистанция удержания цели", 2.5, 1.0, 4.0, 0.1));
    private final Setting.Num predict = add("Остальное", new Setting.Num("Предсказание (тики)", 1, 0, 3, 1));
    private final Setting.Bool predictSelf = add("Остальное", new Setting.Bool("Предсказывать своё движение", true));
    private final Setting.Bool smartCrits = add("Остальное", new Setting.Bool("Умные криты", false));
    private final Setting.Mode sprint = add("Остальное", new Setting.Mode("Спринт", "Умный", "Умный", "Всегда", "Сохранять"));
    private final Setting.Num tapGap = add("Остальное", new Setting.Num("Пауза между в-тапами (мс)", 150, 0, 500, 50));
    private final Setting.Bool breakShield = add("Остальное", new Setting.Bool("Ломать щит", true));
    private final Setting.Bool autoAxe = add("Остальное", new Setting.Bool("Автоматически брать топор", true));
    private final Setting.Bool requireCooldown = add("Остальное", new Setting.Bool("Ждать перезарядки атаки", true));
    private final Setting.Num critCooldown = add("Остальное", new Setting.Num("Кулдаун удара: крит (%)", 92, 0, 100, 1));
    private final Setting.Num comboCooldown = add("Остальное", new Setting.Num("Кулдаун удара: комбо (%)", 92, 0, 100, 1));
    private final Setting.Bool randomize = add("Остальное", new Setting.Bool("Рандомизация ударов/критов", false));
    private final Setting.Num randomDelay = add("Остальное", new Setting.Num("Разброс задержки (%)", 25, 0, 60, 5));
    private final Setting.Num critChance = add("Остальное", new Setting.Num("Шанс крита (%)", 85, 0, 100, 5));

    private final NeuroTracker tracker = new NeuroTracker();
    private boolean haveNeuro, warnedNoModel;
    private float neuroYaw, neuroPitch;
    private double neuroErr = 999;
    private long lastTapAt;

    private long nextDelay = -1;
    private boolean wantCrit = true;
    private LivingEntity target;
    private java.util.UUID lockedTarget;
    private long lastAttackAt;

    private float serverYaw, serverPitch;
    private boolean haveServer;

    private int wTapReleaseTicks = 0;
    private int tapPhase;
    private int tapAge;

    public KillAura() {
        super("KillAura", Category.COMBAT);
        // the Neuro settings only exist while the Neuro rotation is selected
        chooseModel.showWhen(this::neuroSelected);
        neuroStrength.showWhen(this::neuroSelected);
        neuroHitError.showWhen(this::neuroSelected);
    }
    private boolean neuroSelected() { return NEURO.equals(aimMode.value); }
    /** "Бить одного": the first target is kept until it is gone; "Множеств. целей": the target is chosen again by the sorting. */
    private boolean single() { return SINGLE.equals(targetType.value); }
    public LivingEntity currentTarget() { return target; }
    public String selectedMode() { return aimMode.value; }

    private boolean canRun(Player p) {
        if (ActionLock.active) return false;   // swap in progress: no aim, no attacks
        if (skipContainer.value && mc.screen instanceof AbstractContainerScreen<?>) return false;
        if (skipEating.value && p.isUsingItem()) {
            ItemUseAnimation anim = p.getUseItem().getUseAnimation();
            if (anim == ItemUseAnimation.EAT || anim == ItemUseAnimation.DRINK) return false;
        }
        if (skipElytra.value && p.isFallFlying()) return false;
        if (weaponOnly.value && !isWeapon(p.getMainHandItem())) return false;
        return true;
    }

    @Override public void onPreTick() {
        if (wTapReleaseTicks > 0) {
            wTapReleaseTicks--;
            if (wTapReleaseTicks == 0) mc.options.keyUp.setDown(Keys.restoreState(mc.options.keyUp));
        }
        haveServer = false;
        aimStep();
        attackStep();
    }

    private void aimStep() {
        Player p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || !canRun(p)) { target = null; return; }
        List<LivingEntity> targets = findTargets();
        if (single()) {
            if (lockedTarget == null && !targets.isEmpty()) {
                LivingEntity first = chooseTarget(targets);
                if (first != null) lockedTarget = first.getUUID();
            }
            final java.util.UUID id = lockedTarget;
            target = id == null ? null : targets.stream().filter(e -> e.getUUID().equals(id)).findFirst().orElse(null);
            if (target == null) {
                lockedTarget = null;
                LivingEntity replacement = chooseTarget(targets);
                if (replacement != null) { lockedTarget = replacement.getUUID(); target = replacement; }
            }
        } else {
            lockedTarget = null;
            target = targets.isEmpty() ? null : chooseTarget(targets);
        }
        if (neuroSelected()) {
            if (target == null) { haveNeuro = false; neuroErr = 999; tracker.forgetTarget(); tracker.track(p, p.getYRot(), p.getXRot()); return; }
            neuroSilent(p);
            return;
        }
        haveNeuro = false;
        if (target == null) return;

        // Silent: the player uses the aim rotation for this tick only, the real camera is given back at the end of the tick
        float camYaw = p.getYRot(), camPitch = p.getXRot();
        float[] r = rotations(target, true, true);
        float aimYaw = camYaw + Mth.wrapDegrees(r[0] - camYaw);
        float aimPitch = Mth.clamp(r[1], -90.0F, 90.0F);
        serverYaw = aimYaw;
        serverPitch = aimPitch;
        haveServer = true;
        applyMovementFix(p, serverYaw, camYaw);
        Rotations.silent(p, aimYaw, aimPitch);
    }

    private void neuroSilent(Player p) {
        NeuroAim.ensureLoaded();
        if (NeuroAim.model() == null) {
            neuroErr = 999;
            if (!warnedNoModel) { warnedNoModel = true; dev.hvh.client.hud.Notifications.push(name, "нейро-модель не выбрана"); }
            return;
        }
        float camYaw = p.getYRot(), camPitch = p.getXRot();
        if (!haveNeuro) { neuroYaw = camYaw; neuroPitch = camPitch; haveNeuro = true; }
        tracker.track(p, neuroYaw, neuroPitch);
        float[] d = tracker.infer(p, target, neuroYaw, neuroPitch, neuroStrength.value);
        if (d != null) { neuroYaw += d[0]; neuroPitch = Mth.clamp(neuroPitch + d[1], -90.0F, 90.0F); }
        float[] r = rotations(target, true, true);
        neuroErr = Math.hypot(Mth.wrapDegrees(r[0] - neuroYaw), Mth.clamp(r[1], -90.0F, 90.0F) - neuroPitch);
        float sendYaw = camYaw + Mth.wrapDegrees(neuroYaw - camYaw);
        serverYaw = sendYaw;
        serverPitch = neuroPitch;
        haveServer = true;
        applyMovementFix(p, sendYaw, camYaw);
        Rotations.silent(p, sendYaw, neuroPitch);
    }

    /** Movement fix: yaw only. Pitch never affects movement direction. */
    private void applyMovementFix(Player p, float sendYaw, float camYaw) {
        switch (moveFix.value) {
            case "По серверной" -> Rotations.setFix(sendYaw, sendYaw);
            case "По камере"    -> Rotations.setFix(sendYaw, camYaw);
            case "По цели"      -> Rotations.setFix(sendYaw, sendYaw + Mth.wrapDegrees(targetedYaw() - sendYaw));
            default -> { }
        }
    }

    private float targetedYaw() {
        Player p = mc.player;
        Vec3 c = predictedPoint(target, false);
        Vec3 me = p.position();
        if (predictSelf.value) me = me.add(p.getDeltaMovement().x, 0, p.getDeltaMovement().z);
        double dx = c.x - me.x, dz = c.z - me.z;
        float toTarget = (float)(Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        double dist = Math.sqrt(dx * dx + dz * dz);
        int side = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
        float bias = (float) Mth.clamp(6.0 + (dist - stickDist.value) * 30.0, 0.0, 60.0);
        return toTarget - side * bias;
    }

    private void attackStep() {
        Player p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) { target = null; abortTap(); return; }
        if (tapPhase == 2) { endTap(p); return; }
        if (tapPhase == 1 && ++tapAge > 4) { abortTap(); return; }
        if (target == null || !target.isAlive() || target.isRemoved() || !canRun(p)) return;

        if (!throughWalls.value && !p.hasLineOfSight(target)) return;
        if (p.getEyePosition().distanceTo(target.getBoundingBox().getCenter()) > attackRange.value) return;
        if (neuroSelected() && (NeuroAim.model() == null || neuroErr > neuroHitError.value)) return;
        // Ray validation checks geometric intersection with the target hitbox; wall visibility is controlled separately.
        if (rayCheck.value && !looksAtTarget(p)) return;

        long now = System.currentTimeMillis();
        long delay = Math.max(50L, Math.round(1000.0 / aps.value));
        if (randomize.value) {
            if (nextDelay < 0) roll(delay);
            delay = nextDelay;
        }
        if (now - lastAttackAt < delay) return;
        boolean crits = !randomize.value || wantCrit;

        boolean natural = canCrit(p);
        boolean spoofed = HvhClient.modules.criticals.isEnabled() && Criticals.canSpoof(p);
        if (crits && onlyCrits.value && !natural && !spoofed) return;
        if (crits && smartCrits.value && !p.onGround() && !natural && inFreeAir(p)) return;
        boolean critHit = crits && (natural || spoofed);
        double needCharge = (critHit ? critCooldown.value : comboCooldown.value) / 100.0;
        if (requireCooldown.value && !maceSmallCharge(p, target) && p.getAttackStrengthScale(0.5F) < needCharge) return;
        if (maceBlocked(p, target)) return;
        if (tapPhase == 0 && p.isSprinting() && wantsTap(critHit)) {
            if (tapBlocked()) return;
            beginTap(p);
            return;
        }
        if (tapPhase == 1) {
            SprintGate.hold = true;
            if (p.isSprinting()) { p.setSprinting(false); }
        }
        lastAttackAt = now;
        boolean wasSprinting = p.isSprinting();
        attack(target, crits);
        if (tapPhase == 1) tapPhase = 2;
        else if (wasSprinting && sprint.value.equals("Сохранять")) tapPhase = 2;
        if (randomize.value) roll(Math.max(50L, Math.round(1000.0 / aps.value)));
    }

    private boolean looksAtTarget(Player p) {
        float yaw = haveServer ? serverYaw : p.getYRot();
        float pitch = haveServer ? serverPitch : p.getXRot();
        double yr = Math.toRadians(yaw);
        double pr = Math.toRadians(pitch);
        double cp = Math.cos(pr);
        Vec3 dir = new Vec3(-Math.sin(yr) * cp, -Math.sin(pr), Math.cos(yr) * cp);
        Vec3 eye = p.getEyePosition();
        AABB box = target.getBoundingBox();
        if (box.contains(eye)) return true;
        Vec3 end = eye.add(dir.scale(attackRange.value));
        return box.clip(eye, end).isPresent();
    }

    private void roll(long base) {
        java.util.concurrent.ThreadLocalRandom r = java.util.concurrent.ThreadLocalRandom.current();
        double spread = randomDelay.value / 100.0;
        nextDelay = Math.max(50L, Math.round(base * (1.0 + (r.nextDouble() * 2.0 - 1.0) * spread)));
        wantCrit = r.nextDouble() * 100.0 < critChance.value;
    }

    /** Mace in hand with "100% only" OFF: the normal charge wait does not apply, a small charge is enough. */
    private boolean maceSmallCharge(Player p, LivingEntity victim) {
        if (maceFull.value || !(p.getMainHandItem().getItem() instanceof MaceItem)) return false;
        boolean axeSwap = breakShield.value && autoAxe.value && victim instanceof Player other && other.isBlocking() && findHotbarAxe() >= 0;
        return !axeSwap;
    }

    private boolean maceBlocked(Player p, LivingEntity victim) {
        ItemStack held = p.getMainHandItem();
        if (!(held.getItem() instanceof MaceItem)) return false;
        boolean axeSwap = breakShield.value && autoAxe.value && victim instanceof Player other && other.isBlocking() && findHotbarAxe() >= 0;
        if (axeSwap) return false;
        if (maceMinFall.value && p.fallDistance < 1.5) return true;   // a mace hit needs a fall of 1.5+ blocks
        // ON: only a full charge. OFF: a small charge (10%) is enough, no waiting for the full bar.
        if (p.getAttackStrengthScale(0.0F) < (maceFull.value ? 1.0F : 0.1F)) return true;
        return maceItemCd.value && p.getCooldowns().isOnCooldown(held);
    }

    private List<LivingEntity> findTargets() {
        Player p = mc.player;
        double max = attackRange.value + aimExtra.value;
        return mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(max), e -> validTarget(e, max))
            .stream().sorted(Comparator.comparingDouble(this::scoreDistance)).toList();
    }

    private boolean validTarget(LivingEntity e, double maxRange) {
        Player p = mc.player;
        if (e == p || !e.isAlive() || e.isRemoved() || e.isSpectator()) return false;
        if (p.distanceTo(e) > maxRange || (e.isInvisible() && !invisible.value)) return false;
        boolean pl = e instanceof Player;
        boolean villager = "entity.minecraft.villager".equals(e.getType().getDescriptionId());
        boolean mob = e instanceof Mob && !villager;
        if (!(pl && players.value) && !(villager && villagers.value) && !(mob && mobs.value)) return false;
        // "Игроки без брони": ON = bare players are targets too (armored ones always are); OFF = bare players are skipped.
        if (!naked.value && e instanceof Player other && isBare(other)) return false;
        return angleTo(e) <= fov.value / 2.0;
    }

    /** A player with nothing in any of the four armor slots. */
    private static boolean isBare(Player o) {
        return o.getItemBySlot(EquipmentSlot.HEAD).isEmpty() && o.getItemBySlot(EquipmentSlot.CHEST).isEmpty()
            && o.getItemBySlot(EquipmentSlot.LEGS).isEmpty() && o.getItemBySlot(EquipmentSlot.FEET).isEmpty();
    }

    private LivingEntity chooseTarget(List<LivingEntity> targets) {
        return targets.stream().min(this::compareTargets).orElse(null);
    }

    private int compareTargets(LivingEntity a, LivingEntity b) {
        return switch (priority.value) {
            case "Здоровье" -> Double.compare(a.getHealth(), b.getHealth());
            case "Броня" -> Integer.compare(a.getArmorValue(), b.getArmorValue());
            case "Угол обзора" -> Double.compare(angleTo(a), angleTo(b));
            case "Авто" -> { int angle = Double.compare(angleTo(a), angleTo(b)); yield angle != 0 ? angle : Double.compare(scoreDistance(a), scoreDistance(b)); }
            default -> Double.compare(scoreDistance(a), scoreDistance(b));
        };
    }

    private double scoreDistance(Entity e) { return mc.player.distanceTo(e); }

    private double angleTo(Entity e) {
        Player p = mc.player;
        double dx = e.getX() - p.getX(), dz = e.getZ() - p.getZ();
        float yaw = (float)(Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        return Math.abs(Mth.wrapDegrees(yaw - p.getYRot()));
    }

    private Vec3 predictedPoint(Entity e, boolean head) {
        Vec3 c = head && e instanceof LivingEntity living ? living.getEyePosition() : e.getBoundingBox().getCenter();
        double k = predict.value;
        if (k > 0) c = c.add((e.getX() - e.xo) * k, 0, (e.getZ() - e.zo) * k);
        return c;
    }

    private float[] rotations(Entity e, boolean head, boolean selfPred) {
        Player p = mc.player;
        Vec3 eye = p.getEyePosition();
        if (selfPred && predictSelf.value) eye = eye.add(p.getDeltaMovement().x, 0, p.getDeltaMovement().z);
        Vec3 c = predictedPoint(e, head);
        double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        return new float[] {(float)(Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F,
            (float)(-(Mth.atan2(dy, h) * 180.0 / Math.PI))};
    }

    private boolean inFreeAir(Player p) {
        return !p.isInWater() && !p.isInLava() && !p.onClimbable() && !p.isPassenger() && !p.isFallFlying();
    }

    private boolean canCrit(Player p) {
        return !p.onGround() && p.fallDistance > 0.0F && !p.isInWater() && !p.isInLava() && !p.onClimbable() && !p.isPassenger();
    }

    private boolean isWeapon(ItemStack s) { Item i = s.getItem(); return s.is(ItemTags.SWORDS) || i instanceof AxeItem || i instanceof MaceItem; }

    private boolean wantsTap(boolean critHit) {
        return switch (sprint.value) {
            case "Всегда" -> true;
            case "Умный" -> critHit;
            case "Сохранять" -> critHit;
            default -> false;
        };
    }

    private boolean tapBlocked() {
        return !sprint.value.equals("Всегда") && System.currentTimeMillis() - lastTapAt < tapGap.value;
    }

    private void beginTap(Player p) {
        SprintGate.hold = true;
        mc.options.keyUp.setDown(false);
        wTapReleaseTicks = 1;
        tapPhase = 1;
        tapAge = 0;
        lastTapAt = System.currentTimeMillis();
    }

    private void endTap(Player p) {
        SprintGate.hold = false;
        tapPhase = 0;
        if (wTapReleaseTicks > 0) {
            wTapReleaseTicks--;
            if (wTapReleaseTicks == 0) mc.options.keyUp.setDown(Keys.restoreState(mc.options.keyUp));
        }
    }

    private void abortTap() {
        SprintGate.hold = false;
        tapPhase = 0;
        if (wTapReleaseTicks > 0) {
            mc.options.keyUp.setDown(Keys.restoreState(mc.options.keyUp));
            wTapReleaseTicks = 0;
        }
    }

    private void attack(LivingEntity victim, boolean allowSpoof) {
        Player p = mc.player;
        int oldSlot = p.getInventory().getSelectedSlot();
        int axeSlot = -1;
        if (breakShield.value && autoAxe.value && victim instanceof Player other && other.isBlocking()) axeSlot = findHotbarAxe();
        boolean changedSlot = axeSlot >= 0 && axeSlot != oldSlot;
        if (changedSlot) setSlot(axeSlot);
        Criticals.externalSprint = true;
        Criticals.suppress = !allowSpoof;
        try {
            mc.gameMode.attack(p, victim);
        } finally {
            Criticals.externalSprint = false;
            Criticals.suppress = false;
        }
        p.swing(InteractionHand.MAIN_HAND);
        if (changedSlot) setSlot(oldSlot);
    }

    private int findHotbarAxe() {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).getItem() instanceof AxeItem) return i;
        return -1;
    }

    private void setSlot(int slot) {
        mc.player.getInventory().setSelectedSlot(slot);
        if (mc.getConnection() != null) mc.getConnection().send(new ServerboundSetCarriedItemPacket(slot));
    }

    @Override protected void onEnable() {
        lockedTarget = null;
        nextDelay = -1;
        tapPhase = 0;
        haveNeuro = false;
        warnedNoModel = false;
        tracker.reset();
        wTapReleaseTicks = 0;
        haveServer = false;
        NeuroAim.ensureLoaded();
    }

    @Override protected void onDisable() {
        target = null;
        lockedTarget = null;
        haveNeuro = false;
        abortTap();
        SprintGate.moveHold = false;
        haveServer = false;
        Rotations.end(mc.player);
    }
}
