package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/** Expands entity pick radius (see EntityMixin). */
public class Hitboxes extends Mod {
    private final Setting.Num expand = add(new Setting.Num("Расширение", 0.5, 0, 2, 0.05));
    private final Setting.Bool playersOnly = add(new Setting.Bool("Только игроки", true));

    public Hitboxes() { super("Hitboxes", Category.COMBAT); }

    public double expandFor(Entity e) {
        if (mc.player == null || e == mc.player) return 0;
        if (playersOnly.value && !(e instanceof Player)) return 0;
        return expand.value;
    }
}
