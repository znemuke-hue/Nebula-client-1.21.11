package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import java.lang.reflect.Field;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundPlayerAbilitiesPacket;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.phys.Vec3;

/**
 * Flight.
 *  Abilities - gives you the creative-flight abilities (may fly + flying + fly speed) and sends the abilities packet
 *              to the server, exactly like the vanilla client does when you toggle flight.
 *  Motion    - flies by setting your velocity yourself (no abilities involved).
 * Jump = up, Sneak = down. "Защита от кика" makes a tiny drop every second so the vanilla "floating too long" check does not
 * fire on servers that do not allow flight.
 */
public class Flight extends Mod {
    private final Setting.Mode mode = add(new Setting.Mode("Режим", "Способности", "Способности", "Движение"));
    private final Setting.Num speed = add(new Setting.Num("Скорость", 1.0, 0.1, 10.0, 0.1));
    private final Setting.Bool antiKick = add(new Setting.Bool("Защита от кика", true));

    // Abilities fields are read by name so this compiles whatever they are called/visible as in this version.
    private static final Field MAYFLY = find("mayfly", "mayFly", "allowFlying");
    private static final Field FLYING = find("flying", "isFlying");
    private static final Field SPEED = find("flyingSpeed", "flySpeed");

    private boolean saved, prevMayfly, prevFlying;
    private float prevSpeed = 0.05F;
    private int ticks;

    public Flight() { super("Flight", Category.MOVEMENT); }

    private static Field find(String... names) {
        for (String n : names) {
            try { Field f = Abilities.class.getDeclaredField(n); f.setAccessible(true); return f; } catch (Throwable ignored) { }
        }
        return null;
    }
    private static boolean getB(Field f, Abilities a) { try { return f != null && f.getBoolean(a); } catch (Throwable t) { return false; } }
    private static void setB(Field f, Abilities a, boolean v) { try { if (f != null) f.setBoolean(a, v); } catch (Throwable ignored) { } }
    private static float getF(Field f, Abilities a, float def) { try { return f != null ? f.getFloat(a) : def; } catch (Throwable t) { return def; } }
    private static void setF(Field f, Abilities a, float v) { try { if (f != null) f.setFloat(a, v); } catch (Throwable ignored) { } }

    private static boolean abilitiesAvailable() { return MAYFLY != null && FLYING != null; }

    @Override protected void onEnable() {
        ticks = 0;
        saved = false;
        LocalPlayer p = mc.player;
        if (p == null || !abilitiesAvailable()) return;
        Abilities a = p.getAbilities();
        prevMayfly = getB(MAYFLY, a);
        prevFlying = getB(FLYING, a);
        prevSpeed = getF(SPEED, a, 0.05F);
        saved = true;
    }

    @Override public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        ticks++;
        if (mode.value.equals("Способности") && abilitiesAvailable()) abilities(p); else motion(p);
    }

    private boolean antiKickTick() {
        return antiKick.value && ticks % 20 == 0 && !mc.options.keyJump.isDown() && !mc.options.keyShift.isDown();
    }

    private void abilities(LocalPlayer p) {
        Abilities a = p.getAbilities();
        setB(MAYFLY, a, true);
        setF(SPEED, a, (float) (0.05 * speed.value));
        if (!p.onGround() && !getB(FLYING, a)) {            // left the ground (jump): start flying and tell the server
            setB(FLYING, a, true);
            p.connection.send(new ServerboundPlayerAbilitiesPacket(a));
        }
        if (getB(FLYING, a) && antiKickTick()) {
            Vec3 m = p.getDeltaMovement();
            p.setDeltaMovement(m.x, -0.04, m.z);
        }
    }

    private void motion(LocalPlayer p) {
        double s = speed.value * 0.5;                        // blocks per tick (1.0 ~ creative flight)
        double[] d = Rotations.inputDir(p);
        double vx = d == null ? 0 : d[0] * s, vz = d == null ? 0 : d[1] * s;
        double vy = mc.options.keyJump.isDown() ? s * 0.8 : mc.options.keyShift.isDown() ? -s * 0.8 : 0;
        if (vy == 0 && antiKickTick()) vy = -0.04;
        p.setDeltaMovement(vx, vy, vz);
    }

    @Override protected void onDisable() {
        LocalPlayer p = mc.player;
        if (p == null || !saved || !abilitiesAvailable()) return;
        Abilities a = p.getAbilities();
        boolean wasFlying = getB(FLYING, a);
        setB(MAYFLY, a, prevMayfly);
        setF(SPEED, a, prevSpeed);
        if (wasFlying && !prevFlying) {
            setB(FLYING, a, false);
            p.connection.send(new ServerboundPlayerAbilitiesPacket(a));
        }
        saved = false;
    }
}
