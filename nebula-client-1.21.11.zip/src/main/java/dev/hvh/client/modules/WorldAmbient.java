package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Client-local time and weather presentation controls; never sends changes to the server.
 *
 * Time and weather are read through several hooks (see LevelTimeMixin / ClockMixin): Minecraft 26.x moved the day
 * time to world clocks, so more than one entry point is covered. {@link #hit} counts every hook that actually
 * fires, and the "Диагностика" button writes that report to config/hvhclient/world-ambient-debug.txt.
 */
public final class WorldAmbient extends Mod {
    public final Setting.Mode timeMode = add(new Setting.Mode("Время мира", "Сервер", "Сервер", "День", "Рассвет", "Закат", "Ночь", "Своё время", "Ускоренное"));
    public final Setting.Num hour = add(new Setting.Num("Час", 12, 0, 23.5, 0.5));
    public final Setting.Num timeSpeed = add(new Setting.Num("Скорость (Ускоренное)", 10, 1, 100, 1));
    public final Setting.Mode weatherMode = add(new Setting.Mode("Погода", "Сервер", "Сервер", "Ясно", "Дождь", "Гроза"));
    public final Setting.Action diagnose = add(new Setting.Action("Диагностика (отчёт в файл)", WorldAmbient::writeDiagnostics));

    private static final Map<String, Integer> HITS = new ConcurrentHashMap<>();

    public WorldAmbient() { super("World Ambient", Category.WORLD); }

    /** Called by the mixins: proves a hook is alive. */
    public static void hit(String hook) { HITS.merge(hook, 1, Integer::sum); }

    public boolean clearWeather() { return isEnabled() && "Ясно".equals(weatherMode.value); }

    public long overrideDayTime(long vanilla) {
        if (!isEnabled() || "Сервер".equals(timeMode.value)) return vanilla;
        double hours = switch (timeMode.value) {
            case "День" -> 12.0;
            case "Рассвет" -> 6.0;
            case "Закат" -> 18.0;
            case "Ночь" -> 0.0;
            case "Своё время" -> hour.value;
            case "Ускоренное" -> {
                // timeSpeed = in-game hours per real minute
                double elapsedMinutes = System.nanoTime() / 6.0E10;
                yield (hour.value + elapsedMinutes * timeSpeed.value) % 24.0;
            }
            default -> Double.NaN;
        };
        if (!Double.isFinite(hours)) return vanilla;
        // Minecraft daytime starts at 06:00; preserve the world day counter while changing local time.
        long day = Math.floorDiv(vanilla, 24000L) * 24000L;
        long target = Math.floorMod(Math.round((hours - 6.0) * 1000.0), 24000L);
        return day + target;
    }

    public float overrideRainLevel(float vanilla) {
        if (!isEnabled()) return vanilla;
        return switch (weatherMode.value) {
            case "Ясно" -> 0.0F;
            case "Дождь", "Гроза" -> 1.0F;
            default -> vanilla;
        };
    }

    public float overrideThunderLevel(float vanilla) {
        if (!isEnabled()) return vanilla;
        return switch (weatherMode.value) {
            case "Ясно", "Дождь" -> 0.0F;
            case "Гроза" -> 1.0F;
            default -> vanilla;
        };
    }

    // ------------------------------------------------------------------ diagnostics

    private static final String[] GUESSED_CLASSES = {
        "net.minecraft.world.clock.ClockManager", "net.minecraft.world.clock.ServerClockManager",
        "net.minecraft.world.clock.WorldClock", "net.minecraft.client.multiplayer.ClientClockManager",
        "net.minecraft.client.clock.ClientClockManager", "net.minecraft.world.clock.ClientClockManager",
        "net.minecraft.client.renderer.WeatherEffectRenderer", "net.minecraft.client.renderer.SkyRenderer"
    };

    private static boolean interesting(String name) {
        String n = name.toLowerCase();
        return n.contains("time") || n.contains("clock") || n.contains("rain") || n.contains("thunder") || n.contains("weather");
    }

    private static void dump(StringBuilder sb, Class<?> start) {
        for (Class<?> c = start; c != null && c != Object.class; c = c.getSuperclass()) {
            sb.append("  ").append(c.getName()).append('\n');
            for (Method m : c.getDeclaredMethods()) {
                if (!interesting(m.getName())) continue;
                sb.append("    ").append(m.getReturnType().getSimpleName()).append(' ').append(m.getName()).append('(');
                Class<?>[] p = m.getParameterTypes();
                for (int i = 0; i < p.length; i++) sb.append(i > 0 ? ", " : "").append(p[i].getSimpleName());
                sb.append(")\n");
            }
        }
    }

    public static void writeDiagnostics() {
        Minecraft mc = Minecraft.getInstance();
        StringBuilder sb = new StringBuilder("Nebula World Ambient diagnostics\n\n== Hooks that fired (name = calls) ==\n");
        if (HITS.isEmpty()) sb.append("  (none yet: enable World Ambient, pick a time/weather mode, look at the sky for a few seconds, then run this again)\n");
        for (Map.Entry<String, Integer> e : new TreeMap<>(HITS).entrySet()) sb.append("  ").append(e.getKey()).append(" = ").append(e.getValue()).append('\n');
        sb.append("\n== Candidate classes ==\n");
        for (String name : GUESSED_CLASSES) {
            boolean present;
            try { Class.forName(name, false, WorldAmbient.class.getClassLoader()); present = true; } catch (Throwable t) { present = false; }
            sb.append("  ").append(present ? "present " : "missing ").append(name).append('\n');
        }
        try {
            if (mc.level != null) { sb.append("\n== Level methods about time/clock/weather ==\n"); dump(sb, mc.level.getClass()); }
            sb.append("\n== Minecraft / GameRenderer ==\n");
            dump(sb, mc.getClass());
        } catch (Throwable t) { sb.append("reflection failed: ").append(t).append('\n'); }
        try {
            Path dir = FabricLoader.getInstance().getConfigDir().resolve("hvhclient");
            Files.createDirectories(dir);
            Path file = dir.resolve("world-ambient-debug.txt");
            Files.writeString(file, sb.toString());
            dev.hvh.client.hud.Notifications.push("World Ambient", "Отчёт: " + file.toAbsolutePath());
        } catch (Throwable t) {
            dev.hvh.client.hud.Notifications.push("World Ambient", "Не удалось записать отчёт");
        }
    }
}
