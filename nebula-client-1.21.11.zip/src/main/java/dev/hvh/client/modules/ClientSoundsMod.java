package dev.hvh.client.modules;

import dev.hvh.client.gui.SoundPickerScreen;
import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;

/** Client Sounds: custom .ogg sounds for the menu, module toggles, hits... Files live in config/nebula/sounds. */
public class ClientSoundsMod extends Mod {
    public final Setting.Num volume = add(new Setting.Num("Громкость", 70, 0, 100, 1));
    @SuppressWarnings("unused")
    private final Setting.Action choose = add(new Setting.Action("Выбрать звуки", SoundPickerScreen::open));

    /** Totem pop sounds: only for totems of entities you hit in the last moments (off = every pop you can see). */
    public final Setting.Bool onlyMyPops = add(new Setting.Bool("Только мои срабатывания тотема", true));

    public ClientSoundsMod() { super("Client Sounds", Category.MISC); }
}
