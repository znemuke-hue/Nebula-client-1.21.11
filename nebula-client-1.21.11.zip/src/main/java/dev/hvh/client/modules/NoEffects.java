package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.ArrayList;

/**
 * Strips chosen potion effects from the local player on the client every tick, so their penalties (slowdown,
 * blindness, darkness fog, nausea wobble...) are not applied. The server still thinks the effect is active, so
 * a strict server may correct your movement.
 *
 * Effects are matched by their translation key (effect.minecraft.slowness ...), which does not depend on how the
 * constants are named in the Minecraft version.
 */
public final class NoEffects extends Mod {
    public final Setting.Bool slowness = add(new Setting.Bool("Замедление", true));
    public final Setting.Bool blindness = add(new Setting.Bool("Слепота", true));
    public final Setting.Bool darkness = add(new Setting.Bool("Тьма", true));
    public final Setting.Bool glowing = add(new Setting.Bool("Свечение", true));
    public final Setting.Bool nausea = add(new Setting.Bool("Тошнота", true));
    public final Setting.Bool fatigue = add(new Setting.Bool("Усталость (добыча)", true));
    public final Setting.Bool highJump = add(new Setting.Bool("High Jump (прыгучесть)", true));
    public final Setting.Bool weakness = add(new Setting.Bool("Слабость", false));
    public final Setting.Bool hunger = add(new Setting.Bool("Голод", false));
    public final Setting.Bool levitation = add(new Setting.Bool("Левитация", false));

    public NoEffects() { super("NoEffects", Category.PLAYER); }

    /** Used by EntityMixin: hides your own glowing outline (it comes from an entity flag, not from the effect). */
    public boolean hideGlow() { return isEnabled() && glowing.value; }

    private boolean wanted(String key) {
        return switch (key) {
            case "effect.minecraft.slowness" -> slowness.value;
            case "effect.minecraft.blindness" -> blindness.value;
            case "effect.minecraft.darkness" -> darkness.value;
            case "effect.minecraft.glowing" -> glowing.value;
            case "effect.minecraft.nausea" -> nausea.value;
            case "effect.minecraft.mining_fatigue" -> fatigue.value;
            case "effect.minecraft.jump_boost" -> highJump.value;
            case "effect.minecraft.weakness" -> weakness.value;
            case "effect.minecraft.hunger" -> hunger.value;
            case "effect.minecraft.levitation" -> levitation.value;
            default -> false;
        };
    }

    private void strip() {
        if (mc.player == null || HvhClient.modules == null) return;
        for (MobEffectInstance e : new ArrayList<>(mc.player.getActiveEffects())) {
            if (wanted(e.getDescriptionId())) mc.player.removeEffect(e.getEffect());
        }
    }

    // Start of the tick (before the player moves) and end of the tick (after the server may have re-sent an effect).
    @Override public void onPreTick() { strip(); }
    @Override public void onTick() { strip(); }
}
