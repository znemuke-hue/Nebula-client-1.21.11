package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.ClickGuiScreen;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.ActionLock;
import dev.hvh.client.util.InvUtil;
import dev.hvh.client.util.Keys;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Options;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.ShulkerBoxScreen;
import net.minecraft.client.gui.screens.inventory.SignEditScreen;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ServerboundPongPacket;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.ShulkerBoxBlock;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * GuiMove. While a container is open, normal vanilla clicks still update the local menu immediately.
 *
 * LEGIT: only the resulting ordinary ServerboundContainerClickPacket is queued. After the screen closes,
 * the FIFO is sent one click per client tick with random idle gaps between items: two packet-silent ticks
 * before the first click, 1-4 idle ticks between consecutive clicks, two packet-silent ticks after the last
 * click, and the container-close packet alone in its own tick. No two container actions share a tick.
 *
 * HVH: clicks pass through untouched, movement keys pass through as well.
 *
 * System: the InvMove state machine. Clicks and the close packet are held while the player moves (or while
 * the held-click timers run), replayed one per tick, and movement keys are mirrored from the real keyboard
 * while the player inventory or the Nebula GUI is open. Shulker-box pickups get their own 2-tick delay.
 */
public class GuiMove extends Mod {
    public static final String LEGIT = "Легит", HVH = "ХвХ", SYSTEM = "System", STOP = "Стоп";

    public final Setting.Mode mode = add(new Setting.Mode("Режим", LEGIT, LEGIT, HVH, SYSTEM, STOP));
    public final Setting.Bool jump = add(new Setting.Bool("Прыжок", true));
    public final Setting.Bool sprint = add(new Setting.Bool("Спринт", true));
    public final Setting.Bool sneak = add(new Setting.Bool("Приседание", false));
    public final Setting.Bool inInventory = add(new Setting.Bool("Бегать в инвентаре", true));
    public final Setting.Bool inGui = add(new Setting.Bool("Бегать в гуи", true));

    private static final int EDGE_TICKS = 1;

    // ---- Стоп mode state ----
    private boolean stopHold;
    private int stopCloseCd;
    private boolean isStop() { return STOP.equals(mode.value); }
    private static final int GAP_MIN = 1, GAP_MAX = 4;

    private enum QueuePhase { IDLE, START_STOP, SEND_PACKET, GAP, END_STOP, CLOSE_SEND, CLOSE_WAIT, RELEASE_UNLOCK }

    /** Remaining client ticks in the current stop phase. */
    private int phaseTicks;

    private static volatile boolean replayingPacket;
    /** True for the entire render interval belonging to a packet-silent stop tick, not just while tick() is on the stack. */
    private static volatile boolean suppressAllOutgoingThisTick;

    private final ArrayDeque<ServerboundContainerClickPacket> queue = new ArrayDeque<>();
    private volatile QueuePhase phase = QueuePhase.IDLE;
    private Packet<?> deferredClose;
    private boolean passing;
    private final boolean[] edge = new boolean[2];

    // ---- System mode state (InvMove) ----
    private final ArrayDeque<ServerboundContainerClickPacket> sysQueue = new ArrayDeque<>();
    /** One held-back click (shulker box pickup). */
    private ServerboundContainerClickPacket sysClick;
    /** Close packet held until the queued clicks have drained. */
    private ServerboundContainerClosePacket sysClose;
    /** Toggles on every pickup click (InvMove.flag). */
    private boolean sysFlag;
    /** A held click or close is pending (InvMove.flag2). */
    private boolean sysBusy;
    /** Ticks until the next queued click may leave (InvMove.value235). */
    private int sysSendCd;
    /** Busy hold after the last queued action (InvMove.value236). */
    private int sysHoldCd;
    /** Delay before the held shulker click goes out (InvMove.value237). */
    private int sysClickCd;
    /** Delay between the last click and the close packet (InvMove.value238). */
    private int sysCloseCd;
    /** Movement grace after the player stopped moving (InvMove.value239). */
    private int sysMoveCd;

    public GuiMove() {
        super("GuiMove", Category.MOVEMENT);
        jump.showWhen(() -> !SYSTEM.equals(mode.value));
        sprint.showWhen(() -> !SYSTEM.equals(mode.value));
        sneak.showWhen(() -> !SYSTEM.equals(mode.value));
        inInventory.showWhen(() -> SYSTEM.equals(mode.value));
        inGui.showWhen(() -> SYSTEM.equals(mode.value));
    }

    /** True from closing the container through the final stop tick / release boundary. */
    public static boolean inputLocked() {
        GuiMove g = module();
        return g != null && g.phase != QueuePhase.IDLE;
    }

    /** Used by the existing Speed and Sprint modules when a container screen is open. */
    public static boolean passing() {
        GuiMove g = module();
        return g != null && g.passing && !inputLocked();
    }

    /** True only during the two empty stop ticks (also during any remaining frames of that tick). */
    public static boolean emptyStopTick() { return suppressAllOutgoingThisTick; }

    private static GuiMove module() {
        return HvhClient.modules == null ? null : HvhClient.modules.guiMove;
    }

    private boolean isSystem() { return SYSTEM.equals(mode.value); }

    /**
     * Hooked at the HEAD of ClientCommonPacketListenerImpl.send(Packet). Returning true cancels the
     * original send. Packet objects are kept intact: the 1.21.11 click packet already contains the
     * container id, state id, slot/button/type, changed-slot snapshot and cursor snapshot.
     */
    public static boolean interceptOutgoing(Packet<?> packet) {
        GuiMove g = module();
        if (g == null || packet == null) return false;

        if (g.isSystem() && g.isEnabled()) return g.systemIntercept(packet);
        if (g.isStop() && g.isEnabled()) return false; // стоп-режим не трогает пакеты

        // our own replayed packets always pass
        if (replayingPacket) return false;

        // close never leaves while clicks are pending or the fifo is running. It is held and sent
        // one tick after the last click, once the cursor is empty (item placed) or the screen is closed
        if (packet instanceof ServerboundContainerClosePacket) {
            if (g.phase != QueuePhase.IDLE || !g.queue.isEmpty()) {
                if (g.deferredClose == null) g.deferredClose = packet;
                return true;
            }
            return false;
        }

        // container click: the first click (pickup or number-key swap) opens the session with a 1 tick stop,
        // then the fifo is fed one click per tick while the window is open
        if (packet instanceof ServerboundContainerClickPacket click) {
            boolean queueActive = !g.queue.isEmpty() || g.phase != QueuePhase.IDLE;
            boolean startNew = g.isEnabled() && LEGIT.equals(g.mode.value) && !InvUtil.internal && g.containerOpen();
            if (queueActive || startNew) {
                g.queue.addLast(click);
                if (g.phase == QueuePhase.IDLE) {
                    g.phase = QueuePhase.START_STOP;
                    g.phaseTicks = EDGE_TICKS;
                    silenceInput();
                }
                return true;
            }
        }

        // packet-silent stop ticks drop everything that is not a click or close
        if (suppressAllOutgoingThisTick || g.phase == QueuePhase.START_STOP || g.phase == QueuePhase.END_STOP) return true;

        // while draining, only connection liveness replies pass
        if (g.phase != QueuePhase.IDLE) {
            return !(packet instanceof ServerboundKeepAlivePacket || packet instanceof ServerboundPongPacket);
        }
        return false;
    }

    /** Called at Minecraft.tick HEAD. Returns true for a packet-silent stop tick; vanilla tick still runs. */
    public static boolean handleClientTickHead() {
        GuiMove g = module();
        if (g == null) { suppressAllOutgoingThisTick = false; return false; }
        return g.advanceQueueTick();
    }

    private boolean advanceQueueTick() {
        suppressAllOutgoingThisTick = false;
        if (phase == QueuePhase.IDLE) return false;
        silenceInput();

        if (mc.player == null || mc.getConnection() == null) {
            // World/connection teardown: do not hold controls or a close packet across a disconnect.
            queue.clear();
            deferredClose = null;
            phase = QueuePhase.IDLE;
            phaseTicks = 0;
            suppressAllOutgoingThisTick = false;
            return false;
        }

        switch (phase) {
            case START_STOP -> {
                // EDGE_TICKS packet-silent ticks before the first queued click packet.
                suppressAllOutgoingThisTick = true;
                if (--phaseTicks <= 0) phase = QueuePhase.SEND_PACKET;
                return true;
            }
            case SEND_PACKET -> {
                ServerboundContainerClickPacket next = queue.pollFirst();
                if (next == null) {
                    // Defensive: queue emptied unexpectedly. Still finish with silent ticks, then the close.
                    phase = QueuePhase.END_STOP;
                    phaseTicks = EDGE_TICKS;
                    return false;
                }
                sendReplay(next);
                if (queue.isEmpty()) {
                    phase = QueuePhase.END_STOP;
                    phaseTicks = EDGE_TICKS;
                } else {
                    phase = QueuePhase.GAP;
                    phaseTicks = gapFor(queue.peekFirst());
                }
                return false;
            }
            case GAP -> {
                // Random 1-4 idle ticks between items. Gameplay packets stay blocked by interceptOutgoing.
                if (--phaseTicks <= 0) phase = QueuePhase.SEND_PACKET;
                return false;
            }
            case END_STOP -> {
                // EDGE_TICKS packet-silent ticks after the last queued click packet.
                suppressAllOutgoingThisTick = true;
                if (--phaseTicks <= 0) phase = QueuePhase.CLOSE_SEND;
                return true;
            }
            case CLOSE_SEND -> {
                if (!queue.isEmpty()) { phase = QueuePhase.SEND_PACKET; return false; }
                // item still on the cursor with the window open: keep the window open on the server
                if (deferredClose == null && containerOpen() && !cursorEmpty()) { phase = QueuePhase.CLOSE_WAIT; return false; }
                Packet<?> close = deferredClose;
                deferredClose = null;
                if (close != null) sendReplay(close);
                phase = QueuePhase.RELEASE_UNLOCK;
                return false;
            }
            case CLOSE_WAIT -> {
                if (!queue.isEmpty()) phase = QueuePhase.SEND_PACKET;
                else if (deferredClose != null || !containerOpen() || cursorEmpty()) phase = QueuePhase.CLOSE_SEND;
                return false;
            }
            case RELEASE_UNLOCK -> {
                phase = QueuePhase.IDLE;
                silenceInput();
                return false;
            }
            default -> { return false; }
        }
    }

    private static boolean cursorEmpty() {
        return mc.player == null || mc.player.containerMenu == null || mc.player.containerMenu.getCarried().isEmpty();
    }

    /** Number-key swaps are single atomic actions: fixed 1 tick. Everything else keeps the random idle gap. */
    private static int gapFor(ServerboundContainerClickPacket next) {
        if (next != null && next.clickType() == ClickType.SWAP) return 1;
        return ThreadLocalRandom.current().nextInt(GAP_MIN, GAP_MAX + 1);
    }

    private static void sendReplay(Packet<?> packet) {
        if (packet == null || mc.getConnection() == null) return;
        replayingPacket = true;
        try { mc.getConnection().send(packet); }
        catch (Throwable ignored) { }
        finally { replayingPacket = false; }
    }

    /** Every user-initiated key is discarded while the queue runs; reset mappings to avoid stale held keys. */
    public static void silenceInput() {
        GuiMove g = module();
        if (g != null) {
            g.passing = false;
            g.edge[0] = g.edge[1] = false;
        }
        Options options = mc.options;
        if (options == null) return;
        Set<KeyMapping> mappings = Collections.newSetFromMap(new IdentityHashMap<>());
        try {
            for (Field field : Options.class.getFields()) {
                if (Modifier.isStatic(field.getModifiers())) continue;
                Object value = field.get(options);
                if (value instanceof KeyMapping key) mappings.add(key);
                else if (value instanceof KeyMapping[] keys) Collections.addAll(mappings, keys);
            }
        } catch (Throwable ignored) { }
        for (KeyMapping key : mappings) {
            if (key != null) {
                try { key.setDown(false); } catch (Throwable ignored) { }
            }
        }
    }

    @Override protected void onDisable() {
        // System: flush what it holds, the same way InvMove's onDisable does.
        sysFlush();
        // If a FIFO already contains clicks, preserve it until the container closes and drain it using
        // the same one-packet-per-tick state machine. Do not flush several queued clicks in one tick.
        if (phase == QueuePhase.IDLE) stop(); else silenceInput();
    }

    private boolean containerOpen() {
        return mc.screen instanceof AbstractContainerScreen<?>;
    }

    /** Movement passthrough is disabled while typing in a GUI search/text field. */
    private boolean eligible() {
        Screen screen = mc.screen;
        if (!(screen instanceof AbstractContainerScreen<?>)) return false;
        return !(screen.getFocused() instanceof EditBox box && box.isFocused());
    }

    @Override public void onPreTick() {
        if (isStop()) { stopTick(); return; }
        if (isSystem()) return; // System drives its own keys from onTick
        if (inputLocked()) { silenceInput(); return; }
        Player player = mc.player;
        if (player == null || mc.options == null) { passing = false; return; }
        if (ActionLock.active) { stop(); return; }
        if (!eligible()) { stop(); return; }
        pass();
    }

    @Override public void onTick() {
        if (!isSystem()) {
            if (sysPending()) sysFlush();
            return;
        }
        systemTick();
    }

    /** Called at the end of Minecraft.setScreen. A non-empty queue starts only when the container really closes. */
    public static void onScreenChanged() {
        GuiMove g = module();
        if (g == null) return;
        // A disconnect, respawn transition, or return to title can clear player/level before the
        // next client tick. Do not leave the FIFO lock active across that lifecycle boundary.
        if (mc.player == null || mc.level == null || mc.getConnection() == null) {
            g.queue.clear();
            g.deferredClose = null;
            g.phase = QueuePhase.IDLE;
            g.phaseTicks = 0;
            suppressAllOutgoingThisTick = false;
            g.passing = false;
            g.edge[0] = g.edge[1] = false;
            g.sysReset();
            return;
        }
        if (mc.options == null) return;
        if (g.isStop()) return; // Стоп drives its own keys from onPreTick
        if (g.isSystem()) return; // System keeps its own key mirror, driven from onTick
        if (g.phase != QueuePhase.IDLE) { silenceInput(); return; }
        if (!g.queue.isEmpty() && !(mc.screen instanceof AbstractContainerScreen<?>)) {
            g.phase = QueuePhase.START_STOP;
            g.phaseTicks = EDGE_TICKS;
            silenceInput();
            return;
        }
        if (!g.isEnabled() || ActionLock.active) { g.stop(); return; }
        if (g.eligible()) g.pass(); else g.stop();
    }

    private void stopTick() {
        if (mc.player == null || mc.options == null || mc.getConnection() == null) {
            stopHold = false; stopCloseCd = 0; return;
        }
        boolean open = mc.screen instanceof AbstractContainerScreen<?>;
        boolean holding = open && !cursorEmpty();
        if (holding) {
            // item in hand: the inventory is open for the server, movement is frozen
            stopHold = true;
            passing = false;
            releaseMoveKeys();
            return;
        }
        if (stopHold) {
            stopHold = false;
            if (open) stopCloseCd = 2; // item placed: server-side close one tick later
        }
        if (stopCloseCd > 0 && --stopCloseCd == 0) {
            sendReplay(new ServerboundContainerClosePacket(containerId()));
        }
        if (eligible()) pass(); else stop();
    }

    /** Pass movement keys through while a supported container GUI is open. */
    private void pass() {
        passing = true;
        Options options = mc.options;
        mirror(options.keyUp);
        mirror(options.keyDown);
        mirror(options.keyLeft);
        mirror(options.keyRight);
        if (jump.value) mirror(options.keyJump); else options.keyJump.setDown(false);
        edge(options.keySprint, 0, sprint.value);
        edge(options.keyShift, 1, sneak.value);
    }

    private static void mirror(KeyMapping key) {
        boolean real = Keys.physical(key);
        if (real != key.isDown()) key.setDown(real);
    }

    private void edge(KeyMapping key, int index, boolean enabled) {
        boolean real = enabled && Keys.physical(key);
        if (real && !edge[index]) key.setDown(true);
        else if (!real && edge[index]) key.setDown(false);
        edge[index] = real;
    }

    private void stop() {
        passing = false;
        if (mc.options == null) return;
        Options options = mc.options;
        boolean live = mc.screen == null && !inputLocked();
        KeyMapping[] plain = { options.keyUp, options.keyDown, options.keyLeft, options.keyRight, options.keyJump };
        for (KeyMapping key : plain) {
            boolean want = live && Keys.physical(key);
            if (want != key.isDown()) key.setDown(want);
        }
        KeyMapping[] toggles = { options.keySprint, options.keyShift };
        for (int i = 0; i < 2; i++) {
            if (edge[i] && !(live && Keys.physical(toggles[i]))) toggles[i].setDown(false);
            edge[i] = false;
        }
    }

    // ================================================================================================
    // System mode: InvMove logic
    // ================================================================================================

    private static int containerId() {
        return mc.player == null || mc.player.containerMenu == null ? -1 : mc.player.containerMenu.containerId;
    }

    /** InvMove.check6 / check4: the player is moving, or sprinting, from keys or from input. */
    private static boolean movingNow() {
        if (mc.player == null || mc.options == null) return false;
        Options o = mc.options;
        return mc.player.isSprinting()
            || Keys.physical(o.keyUp) || Keys.physical(o.keyDown)
            || Keys.physical(o.keyLeft) || Keys.physical(o.keyRight)
            || Keys.physical(o.keyJump);
    }

    private static boolean isShulker(ItemStack stack) {
        return stack.getItem() instanceof BlockItem block && block.getBlock() instanceof ShulkerBoxBlock;
    }

    /** InvMove.isInt: a shulker box in the clicked slot or on the cursor. */
    private static boolean shulkerAt(int slot) {
        if (mc.player == null || mc.player.containerMenu == null) return false;
        var menu = mc.player.containerMenu;
        if (slot < 0 || slot >= menu.slots.size()) return false;
        return isShulker(menu.slots.get(slot).getItem()) || isShulker(menu.getCarried());
    }

    private static boolean inventoryOpen() {
        return mc.screen instanceof InventoryScreen;
    }

    private static boolean focusedEdit(Screen s) {
        return s.getFocused() instanceof EditBox box && box.isFocused();
    }

    private boolean sysPending() {
        return !sysQueue.isEmpty() || sysClick != null || sysClose != null;
    }

    /** InvMove.onPacketEvent for SEND packets. Returns true to cancel the packet. */
    private boolean systemIntercept(Packet<?> packet) {
        if (replayingPacket || mc.player == null) return false;

        if (packet instanceof ServerboundContainerClosePacket close) {
            boolean pending = !sysQueue.isEmpty() || sysClick != null;
            if (!pending && !movingNow()) return false;
            sysClose = close;
            sysCloseCd = 0;
            sysBusy = true;
            sysHoldCd = Math.max(sysHoldCd, pending ? 4 : 2);
            return true;
        }

        if (packet instanceof ServerboundContainerClickPacket click) {
            if (InvUtil.internal || !inventoryOpen()) return false;
            ClickType type = click.clickType();
            boolean held = sysMoveCd > 0 || movingNow();
            if (!held) {
                if (type == ClickType.PICKUP) sysFlag = !sysFlag;
                return false;
            }
            if (type == ClickType.PICKUP && !sysFlag && shulkerAt(click.slotNum())) {
                sysClick = click;
                sysClickCd = 2;
                sysBusy = true;
                sysHoldCd = 4;
                return true;
            }
            if (type == ClickType.PICKUP || type == ClickType.QUICK_MOVE || type == ClickType.SWAP
                || type == ClickType.THROW || type == ClickType.QUICK_CRAFT) {
                sysQueue.addLast(click);
                if (type == ClickType.PICKUP) sysFlag = !sysFlag;
                sysBusy = true;
                sysHoldCd = 4;
                if (sysSendCd == 0) sysSendCd = 1;
                return true;
            }
        }
        return false;
    }

    /** InvMove.onTick, run once per client tick while the module is on. */
    private void systemTick() {
        if (mc.player == null || mc.getConnection() == null) { sysReset(); return; }

        if (movingNow()) sysMoveCd = 4; else if (sysMoveCd > 0) sysMoveCd--;

        if (sysCloseCd > 0 && --sysCloseCd == 0 && sysClose == null) sysUnlock();

        if (sysSendCd > 0) {
            sysSendCd--;
        } else if (!sysQueue.isEmpty()) {
            ServerboundContainerClickPacket next = sysQueue.pollFirst();
            if (next.containerId() == containerId()) sendReplay(next);
            sysSendCd = 1;
            if (!sysQueue.isEmpty()) sysHoldCd = Math.max(sysHoldCd, 4);
        }

        if (sysHoldCd > 0 && --sysHoldCd == 0 && sysQueue.isEmpty()) sysFinish();

        if (sysClickCd > 0 && --sysClickCd == 0 && sysClick != null) {
            if (sysClick.containerId() == containerId()) sendReplay(sysClick);
            sysClick = null;
        }

        systemKeys();
    }

    /** InvMove.update11: after the queue drained, send the held close (if any), otherwise unlock. */
    private void sysFinish() {
        if (sysClose != null) {
            sendReplay(sysClose);
            sysClose = null;
            sysCloseCd = 1;
        } else {
            sysUnlock();
        }
    }

    private void sysUnlock() { sysBusy = false; }

    /** InvMove.update16 on enable/disable: send everything that is still held, then reset. */
    private void sysFlush() {
        int id = containerId();
        while (!sysQueue.isEmpty()) {
            ServerboundContainerClickPacket p = sysQueue.pollFirst();
            if (p.containerId() == id) sendReplay(p);
        }
        if (sysClick != null && sysClick.containerId() == id) sendReplay(sysClick);
        if (sysClose != null) sendReplay(sysClose);
        sysReset();
    }

    /** Drops held state without sending (world/connection teardown). */
    private void sysReset() {
        sysQueue.clear();
        sysClick = null;
        sysClose = null;
        sysFlag = false;
        sysBusy = false;
        sysSendCd = 0;
        sysHoldCd = 0;
        sysClickCd = 0;
        sysCloseCd = 0;
        sysMoveCd = 0;
        passing = false;
    }

    /**
     * InvMove.onTick key handling. While busy nothing is touched. In the client GUI or the player
     * inventory the six movement/sprint keys are mirrored from the real keyboard. In a shulker box or
     * an active text field the movement keys are released. Outside GUIs (or chat/sign/anvil) nothing is changed.
     */
    private void systemKeys() {
        passing = false;
        if (sysBusy) return;
        Screen s = mc.screen;
        if (s == null || s instanceof ChatScreen || s instanceof SignEditScreen || s instanceof AnvilScreen) return;
        if (s instanceof ShulkerBoxScreen || focusedEdit(s)) { releaseMoveKeys(); return; }
        boolean want = (inventoryOpen() && inInventory.value) || (s instanceof ClickGuiScreen && inGui.value);
        if (!want || mc.options == null) return;
        Options o = mc.options;
        mirror(o.keyUp);
        mirror(o.keyDown);
        mirror(o.keyLeft);
        mirror(o.keyRight);
        mirror(o.keyJump);
        mirror(o.keySprint);
        passing = true;
    }

    private static void releaseMoveKeys() {
        if (mc.options == null) return;
        Options o = mc.options;
        KeyMapping[] keys = { o.keyUp, o.keyDown, o.keyLeft, o.keyRight, o.keyJump, o.keySprint, o.keyShift };
        for (KeyMapping k : keys) if (k.isDown()) k.setDown(false);
    }
}
