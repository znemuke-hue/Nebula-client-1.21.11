package dev.hvh.client.modules;

import dev.hvh.client.mixin.LivingEntityAccessor;
import dev.hvh.client.module.*;

/** Removes the 10-tick delay between jumps when holding space. */
public class NoJumpDelay extends Mod {
    public NoJumpDelay() { super("No Jump Delay", Category.MOVEMENT); }

    @Override public void onTick() {
        if (mc.player != null) ((LivingEntityAccessor) mc.player).hvh$setNoJumpDelay(0);
    }
}
