package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.friend.FriendsManager;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.ActionLock;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import dev.hvh.client.util.SprintGate;
import java.util.concurrent.ThreadLocalRandom;

/**
 * TriggerBot: same attack logic as KillAura (crits, sprint handling, shield breaking, mace rules), but there is no
 * aiming at all - it only hits when the crosshair is already on a valid target.
 */
public class TriggerBot extends Mod {
    // ---- Цели
    private final Setting.Bool players = add("Кого бить", "Игроки", new Setting.Bool("Игроки", true));
    private final Setting.Bool friends = add("Кого бить", "Друзья", new Setting.Bool("Друзья", false));
    private final Setting.Bool mobs = add("Кого бить", "Мобы", new Setting.Bool("Мобы", false));
    private final Setting.Bool villagers = add("Кого бить", "Жители", new Setting.Bool("Жители", false));
    private final Setting.Bool invisible = add("Кого бить", "Невидимые", new Setting.Bool("Невидимые", false));
    private final Setting.Bool naked = add("Кого бить", "Голые", new Setting.Bool("Игроки без брони", false));
    // ---- Не бить если
    private final Setting.Bool skipContainer = add("Не бить если", "В интерфейсе", new Setting.Bool("Не атаковать в интерфейсе", true));
    private final Setting.Bool skipEating = add("Не бить если", "Во время еды", new Setting.Bool("Не атаковать во время еды", true));
    private final Setting.Bool skipElytra = add("Не бить если", "В полёте", new Setting.Bool("Не атаковать в полёте", true));
    private final Setting.Bool weaponOnly = add("Не бить если", "Без оружия", new Setting.Bool("Только с оружием", false));
    private final Setting.Bool onlyCrits = add("Не бить если", "Без крита", new Setting.Bool("Только критические удары", false));
    // ---- Булава
    private final Setting.Bool maceFull = add("Булава", "Полная зарядка", new Setting.Bool("Булава: бить только на 100% перезарядки", true));
    private final Setting.Bool maceItemCd = add("Булава", "Не на кулдауне", new Setting.Bool("Булава: не бить при кулдауне предмета", true));
    private final Setting.Bool maceMinFall = add("Булава", "С 1.5 блока", new Setting.Bool("Булава: бить только с 1.5 блока", true));
    // ---- Остальное
    private final Setting.Num range = add("Остальное", new Setting.Num("Дистанция атаки", 3.0, 2.0, 6.0, 0.1));
    private final Setting.Num aps = add("Остальное", new Setting.Num("Атак в секунду", 10, 1, 20, 1));
    private final Setting.Bool smartCrits = add("Остальное", new Setting.Bool("Умные криты", false));
    private final Setting.Mode sprint = add("Остальное", new Setting.Mode("Спринт", "Умный", "Умный", "Всегда", "Сохранять"));
    private final Setting.Num tapGap = add("Остальное", new Setting.Num("Пауза между в-тапами (мс)", 150, 0, 500, 50));
    private final Setting.Bool breakShield = add("Остальное", new Setting.Bool("Ломать щит", true));
    private final Setting.Bool autoAxe = add("Остальное", new Setting.Bool("Автоматически брать топор", true));
    private final Setting.Bool requireCooldown = add("Остальное", new Setting.Bool("Ждать перезарядки атаки", true));
    private final Setting.Num critCooldown = add("Остальное", new Setting.Num("Кулдаун удара: крит (%)", 92, 0, 100, 1));
    private final Setting.Num comboCooldown = add("Остальное", new Setting.Num("Кулдаун удара: комбо (%)", 92, 0, 100, 1));
    private final Setting.Bool randomize = add("Остальное", new Setting.Bool("Рандомизация ударов/критов", true));
    private final Setting.Num randomDelay = add("Остальное", new Setting.Num("Разброс задержки (%)", 25, 0, 60, 5));
    private final Setting.Num critChance = add("Остальное", new Setting.Num("Шанс крита (%)", 85, 0, 100, 5));

    private long lastTapAt;

    private long lastAttackAt;
    private long nextDelay = -1;
    private boolean wantCrit = true;

    public TriggerBot() { super("TriggerBot", Category.COMBAT); }

    private boolean canRun(Player p) {
        if (ActionLock.active) return false;   // swap in progress: no attacks
        if (FreeCam.active()) return false;    // FreeCam: the crosshair is the camera's, not the player's
        if (mc.screen != null) return false;
        if (skipContainer.value && mc.screen instanceof AbstractContainerScreen<?>) return false;
        if (skipEating.value && p.isUsingItem()) {
            ItemUseAnimation anim = p.getUseItem().getUseAnimation();
            if (anim == ItemUseAnimation.EAT || anim == ItemUseAnimation.DRINK) return false;
        }
        if (skipElytra.value && p.isFallFlying()) return false;
        if (weaponOnly.value && !isWeapon(p.getMainHandItem())) return false;
        return true;
    }

    private boolean valid(Entity e) {
        Player p = mc.player;
        if (!(e instanceof LivingEntity) || e == p || !e.isAlive() || e.isRemoved() || e.isSpectator()) return false;
        boolean friend = e instanceof Player otherPlayer && FriendsManager.isFriend(otherPlayer);
        if (friend && !friends.value) return false;
        if (e.isInvisible() && !invisible.value) return false;
        boolean pl = e instanceof Player;
        boolean villager = "entity.minecraft.villager".equals(e.getType().getDescriptionId());
        boolean mob = e instanceof Mob && !villager;
        if (!((pl && (players.value || friend)) || (villager && villagers.value) || (mob && mobs.value))) return false;
        // Friends form their own target group. The generic "naked players" filter does not cancel it.
        if (!friend && !naked.value && e instanceof Player other && isBare(other)) return false;
        return true;
    }

    /** A player with nothing in any of the four armor slots. */
    private static boolean isBare(Player o) {
        return o.getItemBySlot(EquipmentSlot.HEAD).isEmpty() && o.getItemBySlot(EquipmentSlot.CHEST).isEmpty()
            && o.getItemBySlot(EquipmentSlot.LEGS).isEmpty() && o.getItemBySlot(EquipmentSlot.FEET).isEmpty();
    }

    /** Distance from the eye to the closest point of the target's hitbox. */
    private double reachTo(Player p, Entity e) {
        Vec3 eye = p.getEyePosition();
        AABB b = e.getBoundingBox();
        double x = Mth.clamp(eye.x, b.minX, b.maxX), y = Mth.clamp(eye.y, b.minY, b.maxY), z = Mth.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3(x, y, z));
    }

    /** START of the tick, before the player ticks: the hit is sent before this tick's movement packet. */
    @Override public void onPreTick() {
        Player p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) { abortTap(); return; }
        if (tapPhase == 2) { endTap(p); return; }                  // tick 3 of a W-tap: sprint comes back
        if (tapPhase == 1 && ++tapAge > 4) { abortTap(); return; }  // the hit did not happen in time: give up
        if (!canRun(p)) return;

        // The only "aiming" rule: the crosshair has to be on the target right now.
        if (!(mc.hitResult instanceof EntityHitResult hit) || !valid(hit.getEntity())) return;
        LivingEntity victim = (LivingEntity) hit.getEntity();
        if (reachTo(p, victim) > range.value) return;

        long now = System.currentTimeMillis();
        long base = Math.max(50L, Math.round(1000.0 / aps.value));
        long delay = base;
        if (randomize.value) {
            if (nextDelay < 0) roll(base);
            delay = nextDelay;
        }
        if (now - lastAttackAt < delay) return;
        boolean crits = !randomize.value || wantCrit;

        boolean natural = canCrit(p);
        boolean spoofed = HvhClient.modules.criticals.isEnabled() && Criticals.canSpoof(p);
        if (crits && onlyCrits.value && !natural && !spoofed) return;
        if (crits && smartCrits.value && !p.onGround() && !natural && inFreeAir(p)) return;
        boolean critHit = crits && (natural || spoofed);
        double needCharge = (critHit ? critCooldown.value : comboCooldown.value) / 100.0;
        if (requireCooldown.value && !maceSmallCharge(p, victim) && p.getAttackStrengthScale(0.5F) < needCharge) return;
        if (maceBlocked(p, victim)) return;
        if (tapPhase == 0 && p.isSprinting() && wantsTap(critHit)) {
            if (tapBlocked()) return;   // too soon after the last W-tap: wait
            beginTap(p);                // tick 1: sprint off, the hit follows next tick
            return;
        }
        if (tapPhase == 1) {
            // The hit must land on a tick where the client is NOT sprinting, even if something switched the sprint back on.
            SprintGate.hold = true;
            if (p.isSprinting()) { p.setSprinting(false); }
        }
        lastAttackAt = now;
        boolean wasSprinting = p.isSprinting();
        attack(victim, crits);
        if (tapPhase == 1) tapPhase = 2;                                          // tick 3: the sprint comes back
        else if (wasSprinting && sprint.value.equals("Сохранять")) tapPhase = 2;  // Keep: sprint comes back next tick
        if (randomize.value) roll(base);
    }

    /** Rolls the delay until the next hit (+-spread %) and whether that hit should be a crit. */
    private void roll(long base) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double spread = randomDelay.value / 100.0;
        nextDelay = Math.max(50L, Math.round(base * (1.0 + (r.nextDouble() * 2.0 - 1.0) * spread)));
        wantCrit = r.nextDouble() * 100.0 < critChance.value;
    }

    /** Mace in hand with "100% only" OFF: the normal charge wait does not apply, a small charge is enough. */
    private boolean maceSmallCharge(Player p, LivingEntity victim) {
        if (maceFull.value || !(p.getMainHandItem().getItem() instanceof MaceItem)) return false;
        boolean axeSwap = breakShield.value && autoAxe.value && victim instanceof Player other && other.isBlocking() && findHotbarAxe() >= 0;
        return !axeSwap;
    }

    private boolean maceBlocked(Player p, LivingEntity victim) {
        ItemStack held = p.getMainHandItem();
        if (!(held.getItem() instanceof MaceItem)) return false;
        boolean axeSwap = breakShield.value && autoAxe.value && victim instanceof Player other && other.isBlocking() && findHotbarAxe() >= 0;
        if (axeSwap) return false;
        if (maceMinFall.value && p.fallDistance < 1.5) return true;   // a mace hit needs a fall of 1.5+ blocks
        // ON: only a full charge. OFF: a small charge (10%) is enough, no waiting for the full bar.
        if (p.getAttackStrengthScale(0.0F) < (maceFull.value ? 1.0F : 0.1F)) return true;
        return maceItemCd.value && p.getCooldowns().isOnCooldown(held);
    }

    private boolean inFreeAir(Player p) {
        return !p.isInWater() && !p.isInLava() && !p.onClimbable() && !p.isPassenger() && !p.isFallFlying();
    }
    private boolean canCrit(Player p) {
        return !p.onGround() && p.fallDistance > 0.0F && !p.isInWater() && !p.isInLava() && !p.onClimbable() && !p.isPassenger();
    }
    private boolean isWeapon(ItemStack s) { Item i = s.getItem(); return s.is(ItemTags.SWORDS) || i instanceof AxeItem || i instanceof MaceItem; }

    // ---- W-tap, spread over three ticks. The sprint packets are produced by the vanilla client itself, so they leave in
    // the normal place (right before the movement packet of a tick) and never in the same tick as the hit:
    //   tick 1  sprint is switched off      (vanilla sends STOP_SPRINTING, then the movement packet)
    //   tick 2  the hit                      (the server sees "not sprinting" -> crit)
    //   tick 3  sprint is switched back on  (vanilla sends START_SPRINTING, then the movement packet)
    // Умный = W-tap only for hits that crit.  Всегда = W-tap for every hit.  Сохранять = no W-tap, the sprint is just
    // switched back on one tick after the hit.
    private int tapPhase;   // 0 idle, 1 waiting for the hit, 2 waiting to give the sprint back
    private int tapAge;

    private boolean wantsTap(boolean critHit) {
        return switch (sprint.value) { case "Всегда" -> true; case "Умный" -> critHit; default -> false; };
    }

    /** A W-tap is wanted but the pause since the last one has not passed yet ("Всегда" ignores the pause). */
    private boolean tapBlocked() {
        return !sprint.value.equals("Всегда") && System.currentTimeMillis() - lastTapAt < tapGap.value;
    }

    private void beginTap(Player p) {
        SprintGate.hold = true;          // nothing may start the sprint again until the hit is done
        p.setSprinting(false);
        tapPhase = 1; tapAge = 0;
        lastTapAt = System.currentTimeMillis();
    }

    private void endTap(Player p) {
        SprintGate.hold = false;
        tapPhase = 0;
        if (!p.isSprinting() && canResprint(p)) p.setSprinting(true);
    }

    private void abortTap() {
        Player p = mc.player;
        SprintGate.hold = false;
        tapPhase = 0;
        if (p != null && !p.isSprinting() && canResprint(p)) p.setSprinting(true);
    }

    /** Sprint may only come back when the vanilla sprint rules still allow it. */
    private boolean canResprint(Player p) {
        return mc.options.keyUp.isDown() && !p.isUsingItem() && p.getFoodData().getFoodLevel() > 6;
    }

    /** One hit. The sprint is not touched here - see the W-tap above. */
    private void attack(LivingEntity victim, boolean allowSpoof) {
        Player p = mc.player;
        int oldSlot = p.getInventory().getSelectedSlot();
        int axeSlot = -1;
        if (breakShield.value && autoAxe.value && victim instanceof Player other && other.isBlocking()) axeSlot = findHotbarAxe();
        boolean changedSlot = axeSlot >= 0 && axeSlot != oldSlot;
        if (changedSlot) setSlot(axeSlot);
        Criticals.externalSprint = true;   // Criticals must not send its own sprint packets
        Criticals.suppress = !allowSpoof;
        try {
            mc.gameMode.attack(p, victim);
        } finally {
            Criticals.externalSprint = false;
            Criticals.suppress = false;
        }
        p.swing(InteractionHand.MAIN_HAND);
        if (changedSlot) setSlot(oldSlot);
    }

    private int findHotbarAxe() {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).getItem() instanceof AxeItem) return i;
        return -1;
    }
    private void setSlot(int slot) {
        mc.player.getInventory().setSelectedSlot(slot);
        if (mc.getConnection() != null) mc.getConnection().send(new ServerboundSetCarriedItemPacket(slot));
    }

    @Override protected void onEnable() { nextDelay = -1; tapPhase = 0; }
    @Override protected void onDisable() { abortTap(); }
}
