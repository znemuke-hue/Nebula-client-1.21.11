package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.decoration.painting.Painting;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.entity.vehicle.boat.Boat;

/** Client-side visibility filters; entities remain present for physics and server interaction. */
public final class Removals extends Mod {
    public final Setting.Bool items = add(new Setting.Bool("Предметы на земле", false));
    public final Setting.Bool experience = add(new Setting.Bool("Сферы опыта", false));
    public final Setting.Bool armorStands = add(new Setting.Bool("Стойки для брони", false));
    public final Setting.Bool itemFrames = add(new Setting.Bool("Рамки и светящиеся рамки", false));
    public final Setting.Bool paintings = add(new Setting.Bool("Картины", false));
    public final Setting.Bool projectiles = add(new Setting.Bool("Снаряды", false));
    public final Setting.Bool vehicles = add(new Setting.Bool("Лодки и вагонетки", false));

    public Removals() { super("Removals", Category.VISUALS); }

    public boolean shouldHide(Entity e) {
        if (!isEnabled() || e == null) return false;
        return items.value && e instanceof ItemEntity
            || experience.value && e instanceof ExperienceOrb
            || armorStands.value && e instanceof ArmorStand
            || itemFrames.value && e instanceof ItemFrame
            || paintings.value && e instanceof Painting
            || projectiles.value && e instanceof Projectile
            || vehicles.value && (e instanceof Boat || e instanceof AbstractMinecart);
    }
}
