package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Strafe: no sliding. Your movement keys decide the direction instantly, and the moment you let go of them you stop
 * dead - in the air and on the ground (like walking on air).
 */
public class Strafe extends Mod {
    private final Setting.Bool onlyAir = add(new Setting.Bool("Только в воздухе", false));
    private final Setting.Bool noSlide = add(new Setting.Bool("Убрать скольжение", true));
    private final Setting.Num setSpeed = add(new Setting.Num("Заданная скорость (блок/с, 0 = без изменений)", 0, 0, 30, 0.5));
    private final Setting.Num minSpeed = add(new Setting.Num("Минимальная скорость (блок/с)", 0, 0, 30, 0.5));

    public Strafe() { super("Strafe", Category.MOVEMENT); }

    @Override public void onTick() {
        Player p = mc.player;
        if (p == null || mc.level == null || !Speed.canMove(p)) return;
        if (onlyAir.value && p.onGround()) return;
        if (p.hurtTime > 0) return;                       // let knockback through
        Vec3 m = p.getDeltaMovement();
        double[] d = Rotations.inputDir(p);
        if (d == null) {                                  // no keys: stop instead of sliding
            if (noSlide.value) p.setDeltaMovement(0, m.y, 0);
            return;
        }
        double current = Math.sqrt(m.x * m.x + m.z * m.z);
        double target = setSpeed.value > 0 ? setSpeed.value / 20.0 : current;
        target = Math.max(target, minSpeed.value / 20.0);
        if (target < 0.01) return;
        p.setDeltaMovement(d[0] * target, m.y, d[1] * target);
    }
}
