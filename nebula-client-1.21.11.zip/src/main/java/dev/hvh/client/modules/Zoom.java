package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;

/** FOV-based zoom; does not permanently modify the player's video settings. */
public final class Zoom extends Mod {
    public final Setting.Num factor = add(new Setting.Num("Увеличение", 3.0, 1.5, 12.0, 0.5));
    public Zoom() { super("Zoom", Category.VISUALS); }
    public double apply(double fov) { return isEnabled() ? Math.max(1.0, fov / factor.value) : fov; }
}
