package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.Keys;
import net.minecraft.client.KeyMapping;
import net.minecraft.world.phys.Vec3;

/**
 * JumpReset (порт из Javafiles/JumpReset.java).
 * Когда тебя ударили (hurtTime вырос), ты на земле и бежишь - на один тик нажимается прыжок,
 * чтобы сбить горизонтальный откидывающий импульс.
 */
public final class JumpReset extends Mod {
    /** Из оригинала: минимальный квадрат силы отброса (0.0064 = 0.08^2). */
    private static final double MIN_KNOCKBACK_SQ = 0.0064;

    public final Setting.Bool useChance = add(new Setting.Bool("Использовать шанс", true));
    public final Setting.Num chance = add(new Setting.Num("Шанс (%)", 100, 0, 100, 1));

    private int lastHurt;
    private boolean jumpHeld;

    public JumpReset() { super("JumpReset", Category.COMBAT); }

    @Override protected void onEnable() { lastHurt = 0; jumpHeld = false; }

    @Override protected void onDisable() { releaseJump(); lastHurt = 0; }

    @Override public void onTick() {
        if (jumpHeld) releaseJump();                       // прыжок держится ровно один тик

        var p = mc.player;
        int current = p == null ? 0 : p.hurtTime;
        int previous = lastHurt;
        lastHurt = current;
        if (p == null || previous >= current) return;      // не получали удар на этом тике

        if (mc.screen != null || mc.isPaused()) return;
        if (!p.onGround() || !p.isSprinting() || p.isPassenger() || p.isInWater()) return;
        if (mc.options.keyAttack.isDown()) return;         // как в оригинале: пока зажата атака - не прыгаем

        Vec3 m = p.getDeltaMovement();                     // реальный отброс, который мы получили
        if (m.x * m.x + m.y * m.y + m.z * m.z < MIN_KNOCKBACK_SQ) return;

        if (useChance.value && Math.random() * 100.0 > chance.value) return;

        mc.options.keyJump.setDown(true);
        jumpHeld = true;
    }

    private void releaseJump() {
        if (!jumpHeld) return;
        jumpHeld = false;
        KeyMapping jump = mc.options.keyJump;
        jump.setDown(mc.screen == null && Keys.physical(jump));   // вернуть то, что реально зажато руками
    }
}
