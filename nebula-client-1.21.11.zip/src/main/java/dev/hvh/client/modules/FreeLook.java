package dev.hvh.client.modules;

import com.mojang.blaze3d.platform.InputConstants;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.client.CameraType;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

/**
 * FreeLook (порт из Javafiles/FreeLook.java).
 * Пока зажата клавиша, мышь крутит только КАМЕРУ, а реальный поворот игрока (куда бьёшь, куда бежишь, что видит
 * сервер) остаётся замороженным. Отпустил - камера возвращается к направлению игрока.
 *
 * Хуки: EntityMixin#turn (мышь -> {@link #onTurn}) и GameRendererMixin#render (на время кадра в игрока подставляется
 * поворот камеры: {@link #beginFrame} / {@link #endFrame}).
 *
 * ВАЖНО про клавишу: в оригинале код 164 - это Windows VK (Left Alt), здесь используются коды GLFW: Left Alt = 342.
 */
public final class FreeLook extends Mod {
    public final Setting.Key lookKey = add(new Setting.Key("Клавиша", GLFW.GLFW_KEY_LEFT_ALT));
    public final Setting.Bool autoThird = add(new Setting.Bool("Авто 3-е лицо", true));

    private static boolean active;
    private static float camYaw, camPitch;
    private static boolean swapped;
    private static float sYaw, sPitch, sYawO, sPitchO;

    private boolean thirdApplied;
    private CameraType prevCamera = CameraType.FIRST_PERSON;

    public FreeLook() { super("FreeLook", Category.VISUALS); }

    public static boolean active() { return active; }

    @Override protected void onEnable() { active = false; thirdApplied = false; }
    @Override protected void onDisable() { stop(); }

    @Override public void onTick() {
        LocalPlayer p = mc.player;
        boolean down = p != null && mc.screen == null && lookKey.value >= 0
            && InputConstants.isKeyDown(mc.getWindow(), lookKey.value);
        if (!down) { stop(); return; }
        if (active) return;
        camYaw = p.getYRot();
        camPitch = p.getXRot();
        active = true;
        prevCamera = mc.options.getCameraType();
        thirdApplied = false;
        if (autoThird.value && prevCamera.isFirstPerson()) {
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            thirdApplied = true;
        }
    }

    private void stop() {
        if (!active) return;
        active = false;
        endFrame();
        if (thirdApplied && mc.options != null) mc.options.setCameraType(prevCamera);
        thirdApplied = false;
    }

    /** Из Entity#turn: пока FreeLook активен, мышь двигает камеру вместо игрока. true = съесть событие. */
    public static boolean onTurn(double yawDelta, double pitchDelta) {
        if (!active) return false;
        camYaw += (float) (yawDelta * 0.15);
        camPitch = Mth.clamp(camPitch + (float) (pitchDelta * 0.15), -90.0F, 90.0F);
        return true;
    }

    /** Начало кадра: на время отрисовки игрок "смотрит" туда, куда повёрнута камера. */
    public static void beginFrame() {
        if (!active || swapped) return;
        LocalPlayer p = net.minecraft.client.Minecraft.getInstance().player;
        if (p == null) return;
        sYaw = p.getYRot(); sPitch = p.getXRot(); sYawO = p.yRotO; sPitchO = p.xRotO;
        p.setYRot(camYaw); p.setXRot(camPitch);
        p.yRotO = camYaw; p.xRotO = camPitch;
        swapped = true;
    }

    /** Конец кадра: реальный поворот игрока возвращается. */
    public static void endFrame() {
        if (!swapped) return;
        swapped = false;
        LocalPlayer p = net.minecraft.client.Minecraft.getInstance().player;
        if (p == null) return;
        p.setYRot(sYaw); p.setXRot(sPitch);
        p.yRotO = sYawO; p.xRotO = sPitchO;
    }
}
