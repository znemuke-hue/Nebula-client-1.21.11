package dev.hvh.client.modules;

import dev.hvh.client.HvhClient;
import dev.hvh.client.friend.FriendsManager;
import dev.hvh.client.gui.NeuroModelPicker;
import dev.hvh.client.module.Category;
import dev.hvh.client.neuro.NeuroAim;
import dev.hvh.client.neuro.NeuroDriver;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.util.ActionLock;
import dev.hvh.client.util.Interp;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.MaceItem;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.UUID;

public class AimAssist extends Mod {
    private static final String SINGLE = "Бить одного", MULTI = "Множеств. целей";
    // ---- Цели
    private final Setting.Bool players = add("Кого бить", "Игроки", new Setting.Bool("Игроки", true));
    private final Setting.Bool friends = add("Кого бить", "Друзья", new Setting.Bool("Друзья", false));
    private final Setting.Bool mobs = add("Кого бить", "Мобы", new Setting.Bool("Мобы", false));
    private final Setting.Bool villagers = add("Кого бить", "Жители", new Setting.Bool("Жители", false));
    private final Setting.Bool invisible = add("Кого бить", "Невидимые", new Setting.Bool("Невидимые", false));
    private final Setting.Bool naked = add("Кого бить", "Голые", new Setting.Bool("Игроки без брони", false));
    private final Setting.Bool throughWalls = add("Кого бить", "Сквозь стены", new Setting.Bool("Сквозь стены", false));
    // ---- Не наводить если
    private final Setting.Bool skipContainer = add("Не наводить если", "В интерфейсе", new Setting.Bool("Не наводить в интерфейсе", true));
    private final Setting.Bool skipEating = add("Не наводить если", "Во время еды", new Setting.Bool("Не наводить во время еды", true));
    private final Setting.Bool skipElytra = add("Не наводить если", "В полёте", new Setting.Bool("Не наводить в полёте", true));
    private final Setting.Bool weaponOnly = add("Не наводить если", "Без оружия", new Setting.Bool("Только с оружием", false));
    private final Setting.Bool onlyClick = add("Не наводить если", "Без ЛКМ", new Setting.Bool("Только при зажатой ЛКМ", false));
    // ---- Сортировка
    private final Setting.Mode priority = add("Сортировка", new Setting.Mode("Приоритет", "Авто", "Дистанция", "Угол обзора", "Здоровье", "Броня", "Авто"));
    // ---- Ротация
    private final Setting.Mode aimMode = add("Ротация", new Setting.Mode("Режим наведения", "Легит", "Легит", "Доводка", "Нейро"));
    private final Setting.Action chooseModel = add("Ротация", new Setting.Action("Выбрать модель (Нейро)", NeuroModelPicker::open));
    private final Setting.Num neuroStrength = add("Ротация", new Setting.Num("Сила нейро (%)", 100, 10, 150, 5));
    // ---- Легит
    private final Setting.Num aimSpeed = add("Легит", new Setting.Num("Скорость аима (%)", 35, 1, 100, 1));
    private final Setting.Num aimNoise = add("Легит", new Setting.Num("Шум (°)", 0.4, 0, 5, 0.1));
    private final Setting.Num aimHeight = add("Легит", new Setting.Num("Высота аима (%)", 60, 0, 100, 1));
    private final Setting.Bool multiPoint = add("Легит", new Setting.Bool("Мультипойнт", false));
    private final Setting.Num multiSpread = add("Легит", new Setting.Num("Разброс мультипойнта (%)", 30, 0, 50, 1));
    private final Setting.Num speedRandom = add("Легит", new Setting.Num("Рандом скорости (%)", 20, 0, 100, 1));
    // ---- Тип
    private final Setting.Mode targetType = add("Тип", new Setting.Mode("Тип", MULTI, SINGLE, MULTI));
    // ---- Остальное
    private final Setting.Num range = add("Остальное", new Setting.Num("Дистанция наведения", 4.0, 1.0, 8.0, 0.1));
    private final Setting.Num fov = add("Остальное", new Setting.Num("Угол обзора", 90, 10, 360, 5));
    private final Setting.Mode aimPoint = add("Остальное", new Setting.Mode("Точка наведения", "Голова", "Голова", "Центр"));
    private final Setting.Bool vertical = add("Остальное", new Setting.Bool("Наводиться по вертикали", true));
    private final Setting.Num predict = add("Остальное", new Setting.Num("Предсказание (тики)", 1, 0, 3, 1));
    private final Setting.Bool predictSelf = add("Остальное", new Setting.Bool("Предсказывать своё движение", true));
    private final Setting.Bool showFov = add("Остальное", new Setting.Bool("Отображать круг FOV", false));


    private LivingEntity target;
    private UUID lockedTarget;
    private boolean warnedNoModel;
    // ---- Легит state
    private LivingEntity legitTarget;
    private float legitYaw, legitPitch;
    private float legitOffset;
    private int legitRollCd;

    /** "Нейро": модель раз в тик, но её поворот проигрывается по кадрам (flush -> track -> step | frame). */
    private final NeuroDriver driver = new NeuroDriver();

    // ---- нейро: покадровое проигрывание поворота ----
    // Цель выбирается раз в тик (поиск сущностей дорогой), а сам поворот считается КАЖДЫЙ КАДР по интерполированным
    // позициям - камера двигается с частотой кадров, а не 20 раз в секунду.
    private boolean aiming;        // классические режимы: на этот тик есть цель, кадры её догоняют
    private boolean neuroActive;   // нейро: на этот тик модель вернула поворот, кадры его проигрывают
    private long lastFrameNanos;
    private static final double TICK_NANOS = 50_000_000.0;

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
        // the Neuro settings only exist while the Neuro rotation is selected
        chooseModel.showWhen(this::neuroSelected);
        neuroStrength.showWhen(this::neuroSelected);
        aimSpeed.showWhen(this::legitSelected);
        aimNoise.showWhen(this::legitSelected);
        aimHeight.showWhen(this::legitSelected);
        multiPoint.showWhen(this::legitSelected);
        multiSpread.showWhen(() -> legitSelected() && multiPoint.value);
        speedRandom.showWhen(this::legitSelected);
    }
    private boolean neuroSelected() { return aimMode.value.equals("Нейро"); }
    private boolean legitSelected() { return aimMode.value.equals("Легит") || aimMode.value.equals("Доводка"); }
    public LivingEntity currentTarget() { return target; }

    private boolean canRun(Player p) {
        if (ActionLock.active) return false;   // swap in progress: no aim
        if (FreeCam.active()) return false;    // FreeCam: the crosshair / camera is not the player's
        if (mc.screen != null) return false;
        if (skipContainer.value && mc.screen instanceof AbstractContainerScreen<?>) return false;
        if (skipEating.value && p.isUsingItem()) {
            ItemUseAnimation anim = p.getUseItem().getUseAnimation();
            if (anim == ItemUseAnimation.EAT || anim == ItemUseAnimation.DRINK) return false;
        }
        if (skipElytra.value && p.isFallFlying()) return false;
        if (weaponOnly.value && !isWeapon(p.getMainHandItem())) return false;
        if (onlyClick.value && !mc.options.keyAttack.isDown()) return false;
        return true;
    }

    @Override public void onPreTick() {
        Player p = mc.player;
        aiming = false;
        neuroActive = false;
        if (p == null || mc.level == null) { target = null; driver.cancel(); return; }

        driver.flush(p);   // дотянуть остаток поворота прошлого тика - ничего не теряется
        driver.track(p);   // скорость камеры за прошлый тик + тайминг атаки (нужно нейро-модели)
        if (!canRun(p)) { target = null; driver.cancel(); return; }

        List<LivingEntity> targets = findTargets();
        if (SINGLE.equals(targetType.value)) {
            final UUID id = lockedTarget;
            target = id == null ? null : targets.stream().filter(e -> e.getUUID().equals(id)).findFirst().orElse(null);
            if (target == null) {
                LivingEntity next = chooseTarget(targets);
                lockedTarget = next == null ? null : next.getUUID();
                target = next;
            }
        } else {
            lockedTarget = null;
            target = chooseTarget(targets);
        }
        if (target == null) { driver.cancel(); return; }

        if (aimMode.value.equals("Нейро")) {
            NeuroAim.ensureLoaded();
            if (NeuroAim.model() == null) {
                if (!warnedNoModel) { warnedNoModel = true; dev.hvh.client.hud.Notifications.push(name, "нейро-модель не выбрана"); }
                driver.cancel();
                return;
            }
            // модель запускается РОВНО раз в тик (так она обучалась), поворот проиграют кадры в onFrame()
            neuroActive = driver.step(p, target, vertical.value, neuroStrength.value / 100.0);
        } else {
            driver.cancel();
            legitAim(p);     // Легит: камера плавно доводится до цели в onFrame
        }
    }

    /**
     * Каждый отрисованный кадр (вызывается из GameRendererMixin перед камерой, а также из HUD-хука - второй вызов в
     * том же кадре безвреден: поворот считается по времени, а не по числу вызовов).
     */
    @Override public void onFrame() {
        long now = System.nanoTime();
        // сколько ТИКОВ прошло с прошлого кадра (при 120 FPS ~0.17); ограничено, чтобы после лага не было рывка
        double ticks = lastFrameNanos == 0L ? 0.0 : Math.min((now - lastFrameNanos) / TICK_NANOS, 2.0);
        lastFrameNanos = now;

        Player p = mc.player;
        if (p == null || mc.level == null) return;
        if (mc.screen != null || ActionLock.active) { driver.cancel(); aiming = false; neuroActive = false; return; }

        if (neuroActive) { driver.frame(p, HvhClient.partialTick()); return; }
        if (aiming) { legitStep(p, ticks); return; }

    }

    /** Random value in [-a, a]. Returns 0 for a <= 0: ThreadLocalRandom throws when origin == bound. */
    private static double symmetric(double a) {
        return a <= 0.0 ? 0.0 : ThreadLocalRandom.current().nextDouble(-a, a);
    }

    /** Легит: раз в тик выбирает точку и шум; реальный поворот камеры делает legitStep каждый кадр. */
    private void legitAim(Player p) {
        if (target != legitTarget || (multiPoint.value && ++legitRollCd >= 20)) {
            legitTarget = target;
            legitRollCd = 0;
            double spread = multiPoint.value ? multiSpread.value : 0.0;
            legitOffset = (float) (symmetric(spread) / 100.0);
        }
        double frac = Mth.clamp(aimHeight.value / 100.0 + legitOffset, 0.0, 1.0);
        float[] r = legitAngles(target, frac);
        double n = aimNoise.value;
        float curYaw = p.getYRot();
        legitYaw = curYaw + Mth.wrapDegrees(r[0] - curYaw) + (float) symmetric(n);
        legitPitch = Mth.clamp(r[1] + (float) symmetric(n), -90.0F, 90.0F);
        aiming = true;
    }

    /** Легит: доводит камеру к цели за кадр; скорость и её рандом меняются каждый кадр. */
    private void legitStep(Player p, double ticks) {
        if (ticks <= 0.0 || target == null) return;
        // Доводка: как только прицел уже на хитбоксе, поворот останавливается (игрок двигает мышь сам)
        if (aimMode.value.equals("Доводка") && onHitbox(p, target)) return;
        double rnd = speedRandom.value / 100.0;
        double frac = Math.min(1.0, aimSpeed.value / 100.0 * (1.0 + symmetric(rnd)));
        double k = 1.0 - Math.pow(1.0 - frac, ticks);
        p.setYRot(p.getYRot() + (float) (Mth.wrapDegrees(legitYaw - p.getYRot()) * k));
        if (vertical.value) p.setXRot(Mth.clamp(p.getXRot() + (float) ((legitPitch - p.getXRot()) * k), -90.0F, 90.0F));
    }

    /** True when the current view ray already goes through the target's hitbox. */
    private boolean onHitbox(Player p, LivingEntity e) {
        Vec3 eye = p.getEyePosition(1.0F);
        double yr = Math.toRadians(p.getYRot()), pr = Math.toRadians(p.getXRot());
        Vec3 look = new Vec3(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3 end = eye.add(look.scale(Math.max(range.value, 8.0) + 1.0));
        return e.getBoundingBox().clip(eye, end).isPresent();
    }

    /** Точка цели: высота в долях роста + предсказание движения, без привязки к голове/центру. */
    private float[] legitAngles(LivingEntity e, double frac) {
        Player p = mc.player;
        Vec3 eye = Interp.pos(p, 1.0F).add(0.0, p.getEyePosition().y - p.getY(), 0.0);
        if (predictSelf.value) { Vec3 mv = p.getDeltaMovement(); eye = eye.add(mv.x, 0.0, mv.z); }
        Vec3 c = Interp.pos(e, 1.0F).add(0.0, e.getBbHeight() * frac, 0.0);
        double k = predict.value;
        if (k > 0) {
            double dx = e.getX() - e.xo, dz = e.getZ() - e.zo;
            if (dx * dx + dz * dz < 256.0) c = c.add(dx * k, 0.0, dz * k);
        }
        double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        return new float[] {(float) (Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F,
            (float) (-(Mth.atan2(dy, h) * 180.0 / Math.PI))};
    }

    /**
     * Круг FOV на экране. Радиус в GUI-пикселях: r = (h/2) * tan(fov/2) / tan(vfov/2),
     * тот же угол, что и у проверки целей (yaw-разница в validTarget).
     */
    public static void renderFov(GuiGraphics g) {
        if (HvhClient.modules == null || mc.player == null || mc.level == null || mc.screen != null || mc.options.hideGui) return;
        AimAssist a = HvhClient.modules.aimAssist;
        if (a == null || !a.isEnabled() || !a.showFov.value) return;
        int w = g.guiWidth(), h = g.guiHeight();
        double vfov = Math.toRadians(mc.options.fov().get());
        double half = Math.toRadians(a.fov.value / 2.0);
        double r = (h / 2.0) * Math.tan(half) / Math.tan(vfov / 2.0);
        int cx = w / 2, cy = h / 2;
        int seg = 180, color = 0x80FFFFFF;
        for (int i = 0; i < seg; i++) {
            double ang = i * 2.0 * Math.PI / seg;
            int x = cx + (int) Math.round(Math.cos(ang) * r);
            int y = cy + (int) Math.round(Math.sin(ang) * r);
            g.fill(x, y, x + 1, y + 1, color);
        }
    }

    private List<LivingEntity> findTargets() {
        Player p = mc.player;
        double max = range.value;
        return mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(max), e -> validTarget(e, max))
            .stream().sorted(Comparator.comparingDouble(this::scoreDistance)).toList();
    }

    private boolean validTarget(LivingEntity e, double maxRange) {
        Player p = mc.player;
        if (e == p || !e.isAlive() || e.isRemoved() || e.isSpectator()) return false;
        boolean friend = e instanceof Player otherPlayer && FriendsManager.isFriend(otherPlayer);
        if (friend && !friends.value) return false;
        if (p.distanceTo(e) > maxRange || (e.isInvisible() && !invisible.value)) return false;
        boolean pl = e instanceof Player;
        boolean villager = "entity.minecraft.villager".equals(e.getType().getDescriptionId());
        boolean mob = e instanceof Mob && !villager;
        if (!(pl && (players.value || friend)) && !(villager && villagers.value) && !(mob && mobs.value)) return false;
        // Friends form their own target group. The generic "naked players" filter does not cancel it.
        if (!friend && !naked.value && e instanceof Player other && isBare(other)) return false;
        if (!throughWalls.value && !p.hasLineOfSight(e)) return false;
        return angleTo(e) <= fov.value / 2.0;
    }

    /** A player with nothing in any of the four armor slots. */
    private static boolean isBare(Player o) {
        return o.getItemBySlot(EquipmentSlot.HEAD).isEmpty() && o.getItemBySlot(EquipmentSlot.CHEST).isEmpty()
            && o.getItemBySlot(EquipmentSlot.LEGS).isEmpty() && o.getItemBySlot(EquipmentSlot.FEET).isEmpty();
    }

    private LivingEntity chooseTarget(List<LivingEntity> targets) {
        return targets.stream().min(this::compareTargets).orElse(null);
    }

    private int compareTargets(LivingEntity a, LivingEntity b) {
        return switch (priority.value) {
            case "Здоровье" -> Double.compare(a.getHealth(), b.getHealth());
            case "Броня" -> Integer.compare(a.getArmorValue(), b.getArmorValue());
            case "Угол обзора" -> Double.compare(angleTo(a), angleTo(b));
            case "Авто" -> { int angle = Double.compare(angleTo(a), angleTo(b)); yield angle != 0 ? angle : Double.compare(scoreDistance(a), scoreDistance(b)); }
            default -> Double.compare(scoreDistance(a), scoreDistance(b));
        };
    }

    private double scoreDistance(Entity e) { return mc.player.distanceTo(e); }

    private double angleTo(Entity e) {
        Player p = mc.player;
        double dx = e.getX() - p.getX(), dz = e.getZ() - p.getZ();
        float yaw = (float)(Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        return Math.abs(Mth.wrapDegrees(yaw - p.getYRot()));
    }

    /** Точка наведения цели в момент pt (доля тика), как её рисует игра; предсказание - на "Предсказание (тики)" вперёд. */
    private Vec3 predictedPoint(Entity e, float pt) {
        double up = aimPoint.value.equals("Голова") && e instanceof LivingEntity living
            ? living.getEyePosition().y - living.getY()
            : e.getBoundingBox().getCenter().y - e.getY();
        Vec3 c = Interp.pos(e, pt).add(0.0, up, 0.0);
        double k = predict.value;
        if (k > 0) {
            double dx = e.getX() - e.xo, dz = e.getZ() - e.zo;
            if (dx * dx + dz * dz < 256.0) c = c.add(dx * k, 0.0, dz * k);   // не через телепорт
        }
        return c;
    }

    private float[] rotations(Entity e, float pt) {
        Player p = mc.player;
        Vec3 eye = Interp.pos(p, pt).add(0.0, p.getEyePosition().y - p.getY(), 0.0);
        if (predictSelf.value) { Vec3 mv = p.getDeltaMovement(); eye = eye.add(mv.x, 0.0, mv.z); }
        Vec3 c = predictedPoint(e, pt);
        double dx = c.x - eye.x, dy = c.y - eye.y, dz = c.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        return new float[] {(float)(Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F,
            (float)(-(Mth.atan2(dy, h) * 180.0 / Math.PI))};
    }

    private boolean isWeapon(ItemStack s) { Item i = s.getItem(); return s.is(ItemTags.SWORDS) || i instanceof AxeItem || i instanceof MaceItem; }

    @Override protected void onEnable() {
        lockedTarget = null; driver.clear(); warnedNoModel = false; legitTarget = null;
        aiming = false; neuroActive = false; lastFrameNanos = 0L;
        NeuroAim.ensureLoaded();
    }
    @Override protected void onDisable() {
        target = null; lockedTarget = null; legitTarget = null; driver.clear();
        aiming = false; neuroActive = false;
    }
}
