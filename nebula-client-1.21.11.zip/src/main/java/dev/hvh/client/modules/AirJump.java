package dev.hvh.client.modules;

import dev.hvh.client.module.*;

/** Jump again in mid-air each time you press the jump key. */
public class AirJump extends Mod {
    private boolean wasDown;

    public AirJump() { super("Air Jump", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        boolean down = mc.options.keyJump.isDown();
        if (down && !wasDown && !p.onGround() && mc.screen == null) p.jumpFromGround();
        wasDown = down;
    }
}
