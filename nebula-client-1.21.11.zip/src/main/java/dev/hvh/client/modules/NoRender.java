package dev.hvh.client.modules;

import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LightningBolt;

/** Render-only suppressions. These options do not alter the client world or server state. */
public final class NoRender extends Mod {
    /** True only while the vanilla first-person screen effects (fire/water/in-wall overlays) are being drawn. */
    public static volatile boolean inScreenEffects;

    public final Setting.Bool fireOverlay = add(new Setting.Bool("Огонь на экране", true));
    public final Setting.Bool totemAnimation = add(new Setting.Bool("Анимация тотема", true));
    public final Setting.Bool weather = add(new Setting.Bool("Скрыть осадки", true));
    public final Setting.Bool lightning = add(new Setting.Bool("Скрыть молнии", true));
    public final Setting.Bool entityFire = add(new Setting.Bool("Огонь на сущностях", false));
    public final Setting.Bool particles = add(new Setting.Bool("Скрыть частицы", false));

    public NoRender() { super("NoRender", Category.VISUALS); }

    @Override protected void onDisable() { inScreenEffects = false; }
    @Override public void onTick() { inScreenEffects = false; } // safety net: never leave the flag stuck

    public boolean hideWeather() {
        return isEnabled() && weather.value || dev.hvh.client.HvhClient.modules != null
            && dev.hvh.client.HvhClient.modules.worldAmbient != null
            && dev.hvh.client.HvhClient.modules.worldAmbient.clearWeather();
    }
    public boolean hideParticles() { return isEnabled() && particles.value; }
    public boolean hideFireOverlay() { return isEnabled() && fireOverlay.value; }
    public boolean hideEntityFire() { return isEnabled() && entityFire.value; }
    public boolean hideTotemAnimation() { return isEnabled() && totemAnimation.value; }
    public boolean shouldHide(Entity e) { return isEnabled() && lightning.value && e instanceof LightningBolt; }
}
