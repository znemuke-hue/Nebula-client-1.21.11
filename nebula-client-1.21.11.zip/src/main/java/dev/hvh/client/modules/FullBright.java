package dev.hvh.client.modules;

import dev.hvh.client.module.*;
import dev.hvh.client.setting.Setting;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Gamma: lightmap is filled with white (LightmapMixin). Potion: client-side Night Vision effect. */
public class FullBright extends Mod {
    private final Setting.Mode mode = add(new Setting.Mode("Режим", "Гамма", "Гамма", "Зелье"));

    public FullBright() { super("Full Bright", Category.VISUALS); }

    public boolean gamma() { return isEnabled() && mode.value.equals("Гамма"); }

    @Override public void onTick() {
        if (mc.player == null || !mode.value.equals("Зелье")) return;
        MobEffectInstance e = mc.player.getEffect(MobEffects.NIGHT_VISION);
        if (e == null || e.getDuration() < 260) mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 420, 0));
    }

    @Override protected void onDisable() {
        if (mc.player != null && mode.value.equals("Зелье")) mc.player.removeEffect(MobEffects.NIGHT_VISION);
    }
}
