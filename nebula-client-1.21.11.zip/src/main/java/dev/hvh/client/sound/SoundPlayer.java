package dev.hvh.client.sound;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC10;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.system.libc.LibCStdlib;

/**
 * Plays .ogg (Vorbis) files straight through the game's own OpenAL device: decoded with STB Vorbis, one OpenAL buffer
 * per file (re-decoded if the file changes), one short-lived source per play. Not tied to resource packs, so any file
 * dropped into the sounds folder works. Everything is wrapped so a bad file can never crash the game; the last problem
 * is kept in {@link #error} for the picker screen.
 */
final class SoundPlayer {
    private static final class Buf { int id; long modified; }

    private static final Map<Path, Buf> CACHE = new HashMap<>();
    private static final List<Integer> LIVE = new ArrayList<>();
    private static final int MAX_LIVE = 16;
    private static final long MAX_BYTES = 24L * 1024 * 1024;

    static String error = "";

    private SoundPlayer() {}

    static void play(Path file, float gain) { play(file, gain, 1.0f); }

    /** pitch=1 is original; lower values slow the sound and lower its tone. */
    static void play(Path file, float gain, float pitch) {
        try {
            if (ALC10.alcGetCurrentContext() == 0L) { error = "No audio device"; return; }
            cleanup();
            if (LIVE.size() >= MAX_LIVE) return;
            Buf b = buffer(file);
            if (b == null) return;
            AL10.alGetError();
            int src = AL10.alGenSources();
            AL10.alSourcei(src, AL10.AL_BUFFER, b.id);
            AL10.alSourcef(src, AL10.AL_GAIN, Math.max(0f, Math.min(1f, gain)));
            AL10.alSourcef(src, AL10.AL_PITCH, Math.max(0.5f, Math.min(1.5f, pitch)));
            AL10.alSourcei(src, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE); // same volume wherever you are
            AL10.alSource3f(src, AL10.AL_POSITION, 0f, 0f, 0f);
            AL10.alSourcePlay(src);
            LIVE.add(src);
            error = "";
        } catch (Throwable t) {
            error = short_(t);
        }
    }

    private static void cleanup() {
        LIVE.removeIf(src -> {
            if (AL10.alGetSourcei(src, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING) return false;
            AL10.alDeleteSources(src);
            return true;
        });
    }

    private static Buf buffer(Path file) throws Exception {
        long modified = Files.getLastModifiedTime(file).toMillis();
        Buf cached = CACHE.get(file);
        if (cached != null && cached.modified == modified) return cached;
        if (Files.size(file) > MAX_BYTES) { error = "File too big (max 24 MB)"; return null; }

        byte[] data = Files.readAllBytes(file);
        ByteBuffer mem = MemoryUtil.memAlloc(data.length);
        ShortBuffer pcm = null;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            mem.put(data).flip();
            IntBuffer channels = stack.mallocInt(1), rate = stack.mallocInt(1);
            pcm = STBVorbis.stb_vorbis_decode_memory(mem, channels, rate);
            if (pcm == null) { error = "Not a valid .ogg (Vorbis) file: " + file.getFileName(); return null; }
            int ch = channels.get(0);
            int format = ch == 1 ? AL10.AL_FORMAT_MONO16 : ch == 2 ? AL10.AL_FORMAT_STEREO16 : -1;
            if (format < 0) { error = "Only mono / stereo .ogg supported"; return null; }
            AL10.alGetError();
            int id = AL10.alGenBuffers();
            AL10.alBufferData(id, format, pcm, rate.get(0));
            if (AL10.alGetError() != AL10.AL_NO_ERROR) { AL10.alDeleteBuffers(id); error = "OpenAL could not load the sound"; return null; }
            if (cached != null) { AL10.alDeleteBuffers(cached.id); AL10.alGetError(); } // file was replaced
            Buf b = new Buf();
            b.id = id; b.modified = modified;
            CACHE.put(file, b);
            return b;
        } finally {
            MemoryUtil.memFree(mem);
            if (pcm != null) LibCStdlib.free(pcm);
        }
    }

    private static String short_(Throwable t) {
        String m = t.getMessage();
        String s = t.getClass().getSimpleName() + (m == null ? "" : ": " + m);
        return s.length() > 90 ? s.substring(0, 90) : s;
    }
}
