package dev.hvh.client.sound;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Mod;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Client Sounds. Every event has its own folder inside config/nebula/sounds/<Folder>; drop .ogg files in there and pick
 * one per event in game (Client Sounds module -> Choose sounds). Enable/disable sounds can also be set per module.
 *
 * Selection per key ("GuiOpen" or "ModuleEnable:KillAura"): not set = first file of the folder (module keys: the global
 * choice), NONE = silent, otherwise the file name.
 */
public final class ClientSounds {
    public enum Event {
        GUI_OPEN("GuiOpen", "Open menu"),
        GUI_CLOSE("GuiClose", "Close menu"),
        GUI_SCROLL("GuiScroll", "Scroll in menu"),
        GUI_CLICK("GuiClick", "Menu click"),
        MODULE_ENABLE("ModuleEnable", "Module enabled"),
        MODULE_DISABLE("ModuleDisable", "Module disabled"),
        HIT("Hit", "You hit someone"),
        KILL("Kill", "Your target died"),
        TOTEM_POP("TotemPop", "You popped a totem"),
        TOTEM_POP_ENCHANTED("TotemPopEnchanted", "You popped an enchanted totem"),
        DEATH("Death", "You died"),
        JOIN("Join", "Joining a world / server");
        public final String folder, title;
        Event(String folder, String title) { this.folder = folder; this.title = title; }
    }

    public static final String NONE = "<none>";
    /** Special choice: rotate through the built-in default sounds in this event folder. */
    public static final String DEFAULTS = "<defaults>";
    /** Multi-select value: "random:" + file names joined by "|", or "random:*" = every file of the folder. */
    public static final String RANDOM = "random:", RANDOM_ALL = "random:*";

    /** Set by a screen that is opened FROM the click GUI, so the click GUI does not play its close sound for it. */
    public static boolean keepGui;
    /** Counts module toggles; the click GUI uses it to tell "a module was toggled" from "a button was clicked". */
    public static int moduleToggles;

    private static final Map<String, String> SELECTION = new HashMap<>();
    private static final long[] LAST = new long[Event.values().length];
    private static final Map<Event, List<Path>> LIST_CACHE = new HashMap<>();
    private static final Map<Event, Long> LIST_TIME = new HashMap<>();
    private static final Map<String, List<Path>> BAGS = new HashMap<>();     // shuffle bags: random ORDER, no repeats until all played
    private static final Map<String, Path> LAST_PICK = new HashMap<>();
    private static final Map<Integer, Long> HITS = new HashMap<>();          // entity id -> when you last hit it
    private static final Random RNG = new Random();
    /** Packaged presets, copied into each event folder without overwriting user files. */
    private static final List<String> DEFAULT_SOUND_FILES = List.of(
        "default-soft.ogg", "default-retro.ogg", "default-pop.ogg",
        "default-click.ogg", "default-chime.ogg", "default-deep.ogg", "default-whoosh.ogg",
        "default-bubble_off.ogg", "default-bubble_on.ogg",
        "default-celestial_off.ogg", "default-celestial_on.ogg",
        "default-twinkle_off.ogg", "default-twinkle_on.ogg",
        "default-blin.ogg", "default-clickgui_open.ogg", "default-easy.ogg",
        "default-krasavchik.ogg", "default-molodec.ogg", "default-na-koleni.ogg",
        "default-next.ogg", "default-pechalb.ogg", "default-sosat-sosat.ogg",
        "default-spawn.ogg", "default-talik-nahui.ogg", "default-totem-totem.ogg",
        "default-typing.ogg", "default-udachky.ogg", "default-welcome.ogg"
    );
    private static boolean wasDead;

    private ClientSounds() {}

    // ------------------------------------------------------------------ folders / config

    public static Path root() { return Minecraft.getInstance().gameDirectory.toPath().resolve("config/nebula/sounds"); }
    public static Path dir(Event e) { return root().resolve(e.folder); }
    private static Path selectionFile() { return root().resolve("selection.properties"); }

    public static void init() {
        ensureFolders();
        load();
    }

    public static void ensureFolders() {
        try {
            Files.createDirectories(root());
            for (Event e : Event.values()) {
                Files.createDirectories(dir(e));
                // Built-in presets are copied only when missing: user files are never overwritten.
                for (String preset : DEFAULT_SOUND_FILES) {
                    Path target = dir(e).resolve(preset);
                    if (!Files.exists(target)) {
                        try (InputStream in = ClientSounds.class.getResourceAsStream("/nebula-defaults/sounds/" + preset)) {
                            if (in != null) Files.copy(in, target);
                        } catch (Exception ignored) { }
                    }
                }
            }
            Path readme = root().resolve("README.txt");
            if (!Files.exists(readme)) {
                StringBuilder sb = new StringBuilder("Nebula Client sounds\n\n")
                    .append("Put .ogg (Vorbis) files into the folder of the event you want:\n\n");
                for (Event e : Event.values()) sb.append("  ").append(e.folder).append("  -  ").append(e.title).append('\n');
                sb.append("\nBuilt-in sounds include the default-*.ogg presets packaged with the client. They are restored if missing.\n")
                  .append("Then in game: Client Sounds module -> Choose sounds. Pick a file for each event\n")
                  .append("(enable / disable sounds can also be set for a single module).\n")
                  .append("Use \"Дефолт\" to rotate through built-in sounds, or \"Multi-select\" to choose any files.\n")
                  .append("Files ending in _on.ogg play at original pitch; *_off.ogg files play lower and slightly quieter.\n")
                  .append("Module disable and GUI close events are lowered automatically unless the selected file ends in _on.ogg.\n");
                Files.writeString(readme, sb.toString());
            }
        } catch (Exception ignored) { }
    }

    private static void load() {
        SELECTION.clear();
        try {
            if (!Files.exists(selectionFile())) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(selectionFile())) { p.load(in); }
            for (String k : p.stringPropertyNames()) SELECTION.put(k, p.getProperty(k));
        } catch (Exception ignored) { }
    }

    private static void save() {
        try {
            ensureFolders();
            Properties p = new Properties();
            p.putAll(SELECTION);
            try (OutputStream out = Files.newOutputStream(selectionFile())) { p.store(out, "Nebula Client sound selection"); }
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ selection

    private static String key(Event e, String module) { return module == null ? e.folder : e.folder + ":" + module; }

    /** Raw stored choice: null = not set, NONE = silent, else a file name. */
    public static String getSelection(Event e, String module) { return SELECTION.get(key(e, module)); }

    public static void setSelection(Event e, String module, String value) {
        if (value == null) SELECTION.remove(key(e, module)); else SELECTION.put(key(e, module), value);
        save();
    }

    public static boolean hasOverride(String module) {
        return SELECTION.containsKey(key(Event.MODULE_ENABLE, module)) || SELECTION.containsKey(key(Event.MODULE_DISABLE, module));
    }

    /** All .ogg files of an event folder, fresh from disk. */
    public static List<Path> scan(Event e) {
        List<Path> out = new ArrayList<>();
        ensureFolders();
        try (Stream<Path> s = Files.list(dir(e))) {
            s.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().toLowerCase().endsWith(".ogg"))
                .sorted().limit(300).forEach(out::add);
        } catch (Exception ignored) { }
        return out;
    }

    private static List<Path> files(Event e) {
        long now = System.currentTimeMillis();
        Long t = LIST_TIME.get(e);
        if (t == null || now - t > 1500) { LIST_CACHE.put(e, scan(e)); LIST_TIME.put(e, now); }
        return LIST_CACHE.get(e);
    }

    public static boolean isRandom(String raw) { return raw != null && raw.startsWith(RANDOM); }
    public static boolean isDefaults(String raw) { return DEFAULTS.equals(raw); }

    /** File names ticked in a multi-select value (only files that exist). "random:*" = all of them. */
    public static List<String> randomNames(Event e, String raw) {
        List<String> all = new ArrayList<>();
        for (Path p : scan(e)) all.add(p.getFileName().toString());
        if (!isRandom(raw) || raw.equals(RANDOM_ALL)) return all;
        List<String> out = new ArrayList<>();
        for (String n : raw.substring(RANDOM.length()).split("\\|")) if (!n.isEmpty() && all.contains(n) && !out.contains(n)) out.add(n);
        return out;
    }

    public static String encodeRandom(List<String> names) { return RANDOM + String.join("|", names); }

    /** Every file that may play for this event (and module): 0 = silent, 1 = a fixed file, more = random order. */
    private static List<Path> candidates(Event e, String module) {
        String sel = module == null ? null : SELECTION.get(key(e, module));
        if (sel == null) sel = SELECTION.get(key(e, null));
        if (NONE.equals(sel)) return List.of();
        List<Path> fs = files(e);
        if (isDefaults(sel)) return fs.stream().filter(p -> p.getFileName().toString().startsWith("default-")).toList();
        if (sel == null) return fs.isEmpty() ? List.of() : List.of(fs.get(0));
        if (isRandom(sel)) {
            if (sel.equals(RANDOM_ALL)) return new ArrayList<>(fs);
            List<String> names = new ArrayList<>(List.of(sel.substring(RANDOM.length()).split("\\|")));
            List<Path> out = new ArrayList<>();
            for (Path p : fs) if (names.contains(p.getFileName().toString())) out.add(p);
            return out;
        }
        for (Path p : fs) if (p.getFileName().toString().equals(sel)) return List.of(p);
        return List.of();
    }

    public static boolean canPlay(Event e, String module) { return !candidates(e, module).isEmpty(); }

    /** The file to play now: a fixed one, or the next of a shuffled round (random order, no repeat until all were played). */
    private static Path pick(Event e, String module) {
        List<Path> c = candidates(e, module);
        if (c.isEmpty()) return null;
        if (c.size() == 1) return c.get(0);
        String eff = (module != null && SELECTION.containsKey(key(e, module))) ? key(e, module) : key(e, null);
        List<Path> bag = BAGS.computeIfAbsent(eff, k -> new ArrayList<>());
        bag.retainAll(c);
        if (bag.isEmpty()) {
            bag.addAll(c);
            Collections.shuffle(bag, RNG);
            Path last = LAST_PICK.get(eff);
            if (last != null && bag.size() > 1 && bag.get(0).equals(last)) Collections.swap(bag, 0, 1 + RNG.nextInt(bag.size() - 1));
        }
        Path p = bag.remove(0);
        LAST_PICK.put(eff, p);
        return p;
    }

    // ------------------------------------------------------------------ playing

    private static boolean enabled() {
        return HvhClient.modules != null && HvhClient.modules.clientSounds.isEnabled();
    }

    private static float gain() {
        return (float) (HvhClient.modules.clientSounds.volume.value / 100.0);
    }

    public static void play(Event e) { play(e, null); }

    public static void play(Event e, String module) {
        try {
            if (!enabled()) return;
            long now = System.currentTimeMillis();
            int i = e.ordinal();
            if (now - LAST[i] < (e == Event.GUI_SCROLL ? 70 : 25)) return;
            LAST[i] = now;
            Path p = pick(e, module);
            if (p != null) playWithTone(e, p, gain());
        } catch (Throwable ignored) { }
    }

    /** Called by Mod.setEnabled. */
    public static void onModule(Mod m, boolean on) {
        moduleToggles++;
        if (Minecraft.getInstance().player == null) return; // config load / startup
        play(on ? Event.MODULE_ENABLE : Event.MODULE_DISABLE, m.name);
    }

    // ------------------------------------------------------------------ game events

    /** Called when you attack something (remembered so a totem pop right after can be credited to you). */
    public static void noteHit(Entity e) {
        long now = System.currentTimeMillis();
        HITS.put(e.getId(), now);
        if (HITS.size() > 32) HITS.values().removeIf(t -> now - t > 5000);
    }

    private static boolean hitRecently(Entity e, long ms) {
        Long t = HITS.get(e.getId());
        return t != null && System.currentTimeMillis() - t < ms;
    }

    /** Someone's totem popped (entity event 35). Plays the enchanted variant when the popped totem had a glint. */
    public static void onTotemPop(Entity e) {
        try {
            if (e == null || e == Minecraft.getInstance().player || HvhClient.modules == null) return;
            if (HvhClient.modules.clientSounds.onlyMyPops.value && !hitRecently(e, 2500)) return;
            boolean enchanted = false;
            if (e instanceof LivingEntity le) {
                ItemStack main = le.getMainHandItem(), off = le.getOffhandItem();
                ItemStack totem = main.is(Items.TOTEM_OF_UNDYING) ? main : off.is(Items.TOTEM_OF_UNDYING) ? off : ItemStack.EMPTY;
                enchanted = !totem.isEmpty() && totem.hasFoil();
            }
            // enchanted totem without its own sound set up: fall back to the normal pop sound
            if (enchanted && canPlay(Event.TOTEM_POP_ENCHANTED, null)) play(Event.TOTEM_POP_ENCHANTED);
            else play(Event.TOTEM_POP);
        } catch (Throwable ignored) { }
    }

    /** Called when the server logs you into a world (not on dimension changes). */
    public static void onJoin() { play(Event.JOIN); }

    /** Every client tick: detects your own death. */
    public static void tick() {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) { wasDead = false; return; }
        boolean dead = p.getHealth() <= 0f;
        if (dead && !wasDead) play(Event.DEATH);
        wasDead = dead;
    }

    /** Picker preview without event context; explicit *_off files still preview at a lower tone. */
    public static void preview(Path file) { preview(null, file); }

    /** Picker preview for a particular event, so disable/close sounds preview with the same lower tone. */
    public static void preview(Event event, Path file) {
        try {
            float g = HvhClient.modules != null ? gain() : 0.7f;
            playWithTone(event, file, g);
        } catch (Throwable ignored) { }
    }

    /** *_on remains untouched; *_off is lowered, and disable/close events also get the off treatment by default. */
    private static void playWithTone(Event event, Path file, float volume) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        boolean explicitlyOn = name.endsWith("_on.ogg");
        boolean explicitlyOff = name.endsWith("_off.ogg");
        boolean off = !explicitlyOn && (explicitlyOff || event == Event.MODULE_DISABLE || event == Event.GUI_CLOSE);
        SoundPlayer.play(file, volume * (off ? 0.84f : 1.0f), off ? 0.68f : 1.0f);
    }

    /** Number of built-in sounds currently copied into an event folder. */
    public static int defaultSoundCount(Event e) {
        return (int) scan(e).stream().filter(p -> p.getFileName().toString().startsWith("default-")).count();
    }

    public static String lastError() { return SoundPlayer.error; }
}
