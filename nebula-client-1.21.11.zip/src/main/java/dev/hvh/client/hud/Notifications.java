package dev.hvh.client.hud;

import java.util.ArrayList;
import java.util.List;

/** Small toast notifications (module toggled, etc.). Rendered by Hud. */
public final class Notifications {
    public record Note(String title, String text, long born) {}

    public static final long LIFE_MS = 2600;
    private static final List<Note> LIST = new ArrayList<>();

    private Notifications() {}

    public static void push(String title, String text) {
        LIST.add(new Note(title, text, System.currentTimeMillis()));
        if (LIST.size() > 5) LIST.remove(0);
    }

    public static List<Note> active() {
        long now = System.currentTimeMillis();
        LIST.removeIf(n -> now - n.born() > LIFE_MS);
        return LIST;
    }
}
