package dev.hvh.client.hud;

import dev.hvh.client.Config;
import dev.hvh.client.HvhClient;
import dev.hvh.client.gui.CustomBackground;
import dev.hvh.client.gui.Draw;
import dev.hvh.client.gui.Logo;
import dev.hvh.client.gui.Theme;
import dev.hvh.client.module.Binds;
import dev.hvh.client.module.Mod;
import dev.hvh.client.modules.HudModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

/**
 * Nebula HUD, laid out after the Fantasy screenshots: watermark, info card (server / fps / tps / ping), coords pill,
 * bind list, swap items (Z X C V), attack-charge ring, effects, target, team and inventory.
 * Everything is drawn in REAL screen pixels. Chat open = edit mode: drag with LMB, hold RMB + scroll to scale.
 */
public final class Hud {
    private static final Minecraft mc = Minecraft.getInstance();
    private static final int CYAN = 0xFF38BDF8;

    /** One movable HUD element. dx/dy = offset from its default anchor as a fraction of the screen. */
    public static final class Elem {
        final String id;
        float dx, dy, scale = 1f;
        int x, y, w, h;
        boolean drawn;
        Elem(String id) { this.id = id; }
    }

    private record Row(String name, String amp, String time) {}
    private record Mate(String name, float hp, float max) {}

    private static final Elem WM = new Elem("watermark"), INFO = new Elem("info"), COORDS = new Elem("coords"),
        MODS = new Elem("modules"), SWAP = new Elem("swapitems"), COOL = new Elem("cooldown"),
        POTS = new Elem("potions"), TARGET = new Elem("target"), TEAM = new Elem("team"), INV = new Elem("inventory"),
        NOTES = new Elem("notifications");
    private static final Elem[] ELS = { WM, INFO, COORDS, MODS, SWAP, COOL, POTS, TARGET, TEAM, INV, NOTES };

    // live data (updated in tick)
    private static double px, pz, bps, bpsShown;
    private static int tickN;
    private static Object lastLevel;
    private static long joinMs = System.currentTimeMillis();
    private static long tpsNs, tpsGt;
    private static double tps = 20;
    private static LivingEntity target;
    private static long targetSeen;
    private static boolean killPlayed;
    private static float hpAnim, targetAlpha;

    // layout
    private static float gs = 1f, S = 1f, S0 = 1f;
    private static int rw, rh;

    // edit mode
    private static boolean editing, wasEditing, wasDown, dirty;
    private static Elem dragEl, hoverEl;
    private static double lastX, lastY;

    private Hud() {}

    private static int u(double v) { return (int) Math.round(v * S); }
    private static int u0(double v) { return (int) Math.round(v * S0); }

    // ------------------------------------------------------------------ tick

    public static void tick() {
        if (mc.player == null || mc.level == null) return;
        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            joinMs = System.currentTimeMillis();
            px = mc.player.getX(); pz = mc.player.getZ();
            tpsNs = 0; tps = 20;
        }
        double dx = mc.player.getX() - px, dz = mc.player.getZ() - pz;
        px = mc.player.getX(); pz = mc.player.getZ();
        bps += (Math.sqrt(dx * dx + dz * dz) * 20.0 - bps) * 0.25;
        if (tickN++ % 5 == 0) bpsShown = bps; // fewer distinct strings -> fewer text rebakes

        // TPS: game ticks counted over one real second
        long now = System.nanoTime(), gt = mc.level.getGameTime();
        if (tpsNs == 0) { tpsNs = now; tpsGt = gt; }
        else if (now - tpsNs >= 1_000_000_000L) {
            double secs = (now - tpsNs) / 1e9;
            tps = Math.max(0, Math.min(20, (gt - tpsGt) / secs));
            tpsNs = now; tpsGt = gt;
        }

        // Target HUD is driven by hits (see hit()). Keep a dead target on screen (HP 0) until it times out.
        if (target != null && target.isRemoved()) target = null;
        // Kill sound: the entity you hit in the last few seconds just died
        if (target != null && !killPlayed && !target.isAlive() && System.currentTimeMillis() - targetSeen < 3000) {
            killPlayed = true;
            dev.hvh.client.sound.ClientSounds.play(dev.hvh.client.sound.ClientSounds.Event.KILL);
        }
    }

    /** Called when the local player attacks an entity (manual click or KillAura): that entity becomes the Target HUD target. */
    public static void hit(Entity e) {
        if (e instanceof LivingEntity le && le != mc.player) {
            if (le != target) killPlayed = false;
            target = le; targetSeen = System.currentTimeMillis();
            dev.hvh.client.sound.ClientSounds.noteHit(le);
            dev.hvh.client.sound.ClientSounds.play(dev.hvh.client.sound.ClientSounds.Event.HIT);
        }
    }

    // ---------------------------------------------------------------- render

    public static void render(GuiGraphics g) {
        Binds.poll(); // module keybinds, every frame
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        HudModule h = HvhClient.modules.hud;
        if (!h.isEnabled()) return;

        gs = (float) Math.max(1, mc.getWindow().getGuiScale());
        rw = Math.round(mc.getWindow().getGuiScaledWidth() * gs);
        rh = Math.round(mc.getWindow().getGuiScaledHeight() * gs);
        S0 = Math.max(0.75f, Math.min(3f, mc.getWindow().getHeight() / 720f));

        editing = mc.screen instanceof ChatScreen;
        CustomBackground.clearGuiViewport();
        if (editing) pollEdit(); else if (wasEditing) endEdit();
        wasEditing = editing;
        for (Elem e : ELS) e.drawn = false;

        g.pose().pushMatrix();
        g.pose().scale(1f / gs, 1f / gs);

        if (h.watermark.value) watermark(g);
        if (h.info.value) info(g);
        if (h.coords.value) coords(g);
        if (h.modules.value) modules(g);
        if (h.swapItems.value) swapItems(g);
        if (h.cooldown.value) cooldown(g);
        if (h.potions.value) potions(g);
        if (h.target.value) target(g);
        if (h.team.value) team(g);
        if (h.inventory.value) inventory(g);
        if (h.notifications.value) notifications(g);
        if (editing) hint(g);

        Draw.flush();
        g.pose().popMatrix();
    }

    // ------------------------------------------------------------- edit mode

    // Mouse is polled straight from GLFW (MouseHandler's pressed flags are not reliable while a screen is open).
    private static final double[] CUR_X = new double[1], CUR_Y = new double[1];

    private static boolean mouseDown(int button) {
        return GLFW.glfwGetMouseButton(mc.getWindow().handle(), button) == GLFW.GLFW_PRESS;
    }
    private static double mouseX() {
        GLFW.glfwGetCursorPos(mc.getWindow().handle(), CUR_X, CUR_Y);
        return CUR_X[0] * rw / (double) mc.getWindow().getScreenWidth();
    }
    private static double mouseY() {
        GLFW.glfwGetCursorPos(mc.getWindow().handle(), CUR_X, CUR_Y);
        return CUR_Y[0] * rh / (double) mc.getWindow().getScreenHeight();
    }

    private static Elem elemAt(double mx, double my) {
        for (int i = ELS.length - 1; i >= 0; i--) {
            Elem e = ELS[i];
            if (e.drawn && mx >= e.x && mx < e.x + e.w && my >= e.y && my < e.y + e.h) return e;
        }
        return null;
    }

    private static void pollEdit() {
        double mx = mouseX(), my = mouseY();
        boolean down = mouseDown(GLFW.GLFW_MOUSE_BUTTON_LEFT);
        hoverEl = elemAt(mx, my);
        if (down && !wasDown) { dragEl = hoverEl; lastX = mx; lastY = my; }
        if (down && dragEl != null) {
            dragEl.dx += (float) ((mx - lastX) / rw);
            dragEl.dy += (float) ((my - lastY) / rh);
            lastX = mx; lastY = my;
            dirty = true;
        }
        if (!down && wasDown) dragEl = null;
        wasDown = down;
    }

    private static void endEdit() {
        dragEl = null; hoverEl = null; wasDown = false;
        if (dirty) { dirty = false; Config.save(); }
    }

    /** Called from MouseHandlerMixin. Returns true when the scroll was used to scale an element. */
    public static boolean onScroll(double yOffset) {
        if (!(mc.screen instanceof ChatScreen) || !mouseDown(GLFW.GLFW_MOUSE_BUTTON_RIGHT) || rw == 0) return false;
        if (HvhClient.modules == null || !HvhClient.modules.hud.isEnabled()) return false;
        Elem e = elemAt(mouseX(), mouseY());
        if (e == null) return false;
        e.scale = Math.max(0.5f, Math.min(2.5f, e.scale + (float) Math.signum(yOffset) * 0.05f));
        dirty = true;
        return true;
    }

    private static void outline(GuiGraphics g, Elem e) {
        if (!editing) return;
        double a = e == dragEl ? 0.95 : e == hoverEl ? 0.7 : 0.3;
        int c = Draw.alpha(CYAN, a), b = Math.max(1, u0(1));
        Draw.rect(g, e.x - b, e.y - b, e.w + b * 2, b, c);
        Draw.rect(g, e.x - b, e.y + e.h, e.w + b * 2, b, c);
        Draw.rect(g, e.x - b, e.y, b, e.h, c);
        Draw.rect(g, e.x + e.w, e.y, b, e.h, c);
    }

    private static void hint(GuiGraphics g) {
        S = S0;
        String t = "HUD editor: drag - LMB    scale - hold RMB + scroll";
        float s = S0 * 0.85f;
        Draw.text(g, t, (rw - Draw.width(t, s)) / 2, rh - u0(52), Draw.alpha(Theme.TEXT, 0.6), s);
    }

    /** Position an element: anchor + user offset, clamped to the screen. align: 0 = anchor is left edge, 0.5 = center, 1 = right edge. */
    private static void place(Elem e, int w, int h, int ax, int ay, double align) {
        int bx = ax - (int) Math.round(align * w), by = ay;
        int x = bx + Math.round(e.dx * rw), y = by + Math.round(e.dy * rh);
        int cx = Math.max(0, Math.min(rw - w, x)), cy = Math.max(0, Math.min(rh - h, y));
        if (cx != x) e.dx = (float) (cx - bx) / rw;
        if (cy != y) e.dy = (float) (cy - by) / rh;
        e.x = cx; e.y = cy; e.w = w; e.h = h; e.drawn = true;
    }

    // ---------------------------------------------------------------- helpers

    private static String clock() {
        long s = (System.currentTimeMillis() - joinMs) / 1000;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60);
    }

    private static int ping() {
        if (mc.getConnection() == null || mc.player == null) return 0;
        PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? 0 : info.getLatency();
    }

    private static int textY(int y, int h, float t) { return y + (h - Draw.height(t)) / 2; }

    /** Rounded HUD card with the glass finish. a = opacity multiplier (used for the target fade). */
    private static void card(GuiGraphics g, int x, int y, int w, int h, int r, double a) {
        Draw.round(g, x, y, w, h, r, Draw.alpha(Theme.hudPanelAt(0.5), a));
        if (a > 0.6) Draw.glassHighlight(g, x, y, w, h, r, false, Theme.Surface.HUD);
    }

    /** Header pill with an accent dot and a bold title. Returns its height. */
    private static int header(GuiGraphics g, int x, int y, int w, String title, float t, double a) {
        int hh = u(20), pad = u(8);
        card(g, x, y, w, hh, u(6), a);
        Draw.round(g, x + pad, y + (hh - u(6)) / 2, u(6), u(6), u(3), Draw.alpha(Theme.accent(), a));
        Draw.textBold(g, title, x + pad + u(12), textY(y, hh, t), Draw.alpha(Theme.TEXT, a), t);
        return hh;
    }

    /** Small rounded chip with bold text (key names, effect timers). */
    private static void chip(GuiGraphics g, String text, int rightX, int rowY, int rowH, float t) {
        int cw = Draw.boldWidth(text, t * 0.9f) + u(10), ch = u(13);
        int cx = rightX - cw, cy = rowY + (rowH - ch) / 2;
        Draw.round(g, cx, cy, cw, ch, u(4), Draw.alpha(Theme.accent(), 0.35));
        Draw.centeredBold(g, text, cx + cw / 2f, cy + (ch - Draw.height(t * 0.8f)) / 2f, Theme.TEXT, t * 0.8f);
    }

    /** Draws an item at px x px (16 units scaled to px). Counts are drawn by the game. */
    private static void icon(GuiGraphics g, ItemStack s, int x, int y, int px) {
        if (s == null || s.isEmpty()) return;
        float k = px / 16f;
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(k, k);
        g.renderItem(s, 0, 0);
        g.renderItemDecorations(mc.font, s, 0, 0);
        g.pose().popMatrix();
    }

    private static void cell(GuiGraphics g, int x, int y, int rowH, String value, String unit, float t, int maxW) {
        while (value.length() > 3 && Draw.width(value, t) > maxW) value = value.substring(0, value.length() - 1);
        int ty = textY(y, rowH, t);
        Draw.text(g, value, x, ty, Theme.TEXT, t);
        if (!unit.isEmpty()) Draw.text(g, unit, x + Draw.width(value, t) + u(3), ty, Theme.TEXT_DIM, t * 0.85f);
    }

    /** Pill: accent dot + one line of text. */
    private static void pill(GuiGraphics g, int x, int y, int w, int h, String text, float t) {
        int pad = u(8);
        card(g, x, y, w, h, u(6), 1);
        Draw.round(g, x + pad, y + (h - u(6)) / 2, u(6), u(6), u(3), Theme.accent());
        Draw.text(g, text, x + pad + u(12), textY(y, h, t), Theme.TEXT, t);
    }

    private static int barWidth(boolean logo, String[] items) {
        float t = S * 0.95f;
        int pad = u(8), sp = u(7), ls = u(26), div = Math.max(1, u(1));
        int w = pad;
        if (logo) w += ls - u(4) + sp;
        for (int i = 0; i < items.length; i++) {
            w += logo && i == 0 ? Draw.boldWidth(items[i], t) : Draw.width(items[i], t);
            if (i < items.length - 1) w += sp * 2 + div;
        }
        return w + pad;
    }

    /** Pill with separated items; first item is drawn bold when a logo is shown. */
    private static void bar(GuiGraphics g, int x, int y, boolean logo, String[] items) {
        float t = S * 0.95f;
        int h = u(20), pad = u(8), sp = u(7), ls = u(26), div = Math.max(1, u(1));
        int w = barWidth(logo, items);

        Draw.round(g, x, y, w, h, u(6), Theme.hudPanelAt(0.5));
        Draw.glassHighlight(g, x, y, w, h, u(6), true, Theme.Surface.HUD);
        int cx = x + pad;
        if (logo) { Logo.draw(g, x + u(2), y + (h - ls) / 2, ls, 0xFFFFFFFF); cx += ls - u(4) + sp; }
        for (int i = 0; i < items.length; i++) {
            boolean first = logo && i == 0;
            if (first) { Draw.textBold(g, items[i], cx, textY(y, h, t), Theme.TEXT, t); cx += Draw.boldWidth(items[i], t); }
            else { Draw.text(g, items[i], cx, textY(y, h, t), i == 0 && !logo ? Theme.TEXT : Theme.TEXT_DIM, t); cx += Draw.width(items[i], t); }
            if (i < items.length - 1) {
                cx += sp;
                Draw.rect(g, cx, y + u(5), div, h - u(10), 0x30FFFFFF);
                cx += div + sp;
            }
        }
    }

    // --------------------------------------------------------------- elements

    private static void watermark(GuiGraphics g) {
        S = S0 * WM.scale;
        String[] items = { "Nebula", mc.getUser().getName(), mc.getFps() + " Fps", clock() };
        place(WM, barWidth(true, items), u(20), u0(8), u0(8), 0);
        bar(g, WM.x, WM.y, true, items);
        outline(g, WM);
    }

    /** Card: server, fps / tps / ping in a 2x2 grid. */
    private static void info(GuiGraphics g) {
        S = S0 * INFO.scale;
        float t = S * 0.95f;
        int w = u(176), row = u(18), pad = u(8), h = pad * 2 + row * 2, half = w / 2;
        place(INFO, w, h, u0(8), u0(34), 0);
        int x = INFO.x, y = INFO.y;
        card(g, x, y, w, h, u(7), 1);
        String server = mc.getCurrentServer() != null ? mc.getCurrentServer().ip : "Singleplayer";
        cell(g, x + pad, y + pad, row, server, "", t, half - pad * 2);
        cell(g, x + half + pad, y + pad, row, String.valueOf(mc.getFps()), "fps", t, half - pad * 2);
        cell(g, x + pad, y + pad + row, row, String.valueOf(Math.round(tps)), "tps", t, half - pad * 2);
        cell(g, x + half + pad, y + pad + row, row, String.valueOf(ping()), "ms", t, half - pad * 2);
        outline(g, INFO);
    }

    private static void coords(GuiGraphics g) {
        S = S0 * COORDS.scale;
        float t = S * 0.95f;
        String s = (int) Math.floor(mc.player.getX()) + " " + (int) Math.floor(mc.player.getY()) + " " + (int) Math.floor(mc.player.getZ());
        int pad = u(8), h = u(20), w = pad + u(12) + Draw.width(s, t) + pad;
        place(COORDS, w, h, u0(8), u0(82), 0);
        pill(g, COORDS.x, COORDS.y, w, h, s, t);
        outline(g, COORDS);
    }

    /** "Список биндов": enabled modules that have a bind, key chip on the right. */
    private static void modules(GuiGraphics g) {
        S = S0 * MODS.scale;
        float t = S * 0.95f;
        List<String> names = new ArrayList<>(), keys = new ArrayList<>();
        List<Mod> on = new ArrayList<>();
        for (Mod m : HvhClient.modules.all) if (m.isEnabled() && m.bind >= 0 && m != HvhClient.modules.hud) on.add(m);
        on.sort((a, b) -> Draw.width(b.name, 1f) - Draw.width(a.name, 1f));
        for (Mod m : on) { names.add(m.name); keys.add(Binds.name(m.bind)); }
        if (names.isEmpty() && editing) { names.add("KillAura"); keys.add("R"); names.add("Sprint"); keys.add("V"); }
        if (names.isEmpty()) return;

        int w = u(150), row = u(17), pad = u(8), hh = u(20), gap = u(3), rows = names.size();
        place(MODS, w, hh + gap + rows * row + pad, u0(8), u0(110), 0);
        int x = MODS.x, y = MODS.y;
        header(g, x, y, w, "Список биндов", t, 1);
        int by = y + hh + gap;
        card(g, x, by, w, rows * row + pad, u(7), 1);
        for (int i = 0; i < rows; i++) {
            int ry = by + pad / 2 + i * row;
            Draw.text(g, names.get(i), x + pad, textY(ry, row, t), Theme.TEXT, t);
            chip(g, keys.get(i), x + w - pad, ry, row, t);
        }
        outline(g, MODS);
    }

    /** "Предметы": hotbar slots 1-4 with the Z X C V letters. */
    private static void swapItems(GuiGraphics g) {
        S = S0 * SWAP.scale;
        float t = S * 0.95f;
        int slot = u(26), gap = u(5), pad = u(8), hh = u(20), gap2 = u(3);
        int w = pad * 2 + 4 * slot + 3 * gap, bodyH = slot + pad;
        place(SWAP, w, hh + gap2 + bodyH, u0(8), rh - u0(72), 0);
        int x = SWAP.x, y = SWAP.y;
        header(g, x, y, w, "Предметы", t, 1);
        int by = y + hh + gap2;
        card(g, x, by, w, bodyH, u(7), 1);
        String keys = "ZXCV";
        for (int i = 0; i < 4; i++) {
            int sx = x + pad + i * (slot + gap), sy = by + pad / 2;
            Draw.round(g, sx, sy, slot, slot, u(5), Theme.moduleAt(0, false, 0));
            icon(g, mc.player.getInventory().getItem(i), sx + (slot - u(16)) / 2, sy + (slot - u(16)) / 2, u(16));
            String k = String.valueOf(keys.charAt(i));
            Draw.centeredBold(g, k, sx + slot - u(6), sy + slot - Draw.height(t * 0.7f) - u(1), Theme.TEXT, t * 0.7f);
        }
        outline(g, SWAP);
    }

    /** Attack-charge ring with the percentage: fills from the bottom, hole in the middle. */
    private static void cooldown(GuiGraphics g) {
        S = S0 * COOL.scale;
        float t = S * 0.9f;
        int d = u(56), ring = u(6);
        place(COOL, d, d, u0(8), rh - u0(150), 0);
        int x = COOL.x, y = COOL.y;
        float p = Math.max(0f, Math.min(1f, mc.player.getAttackStrengthScale(0f)));
        Draw.round(g, x, y, d, d, d / 2, Draw.alpha(Theme.SLIDER_BG, 0.85));
        int fh = Math.round(d * p);
        if (fh > 0) {
            Draw.scissor(g, x, y + d - fh, d, fh);
            Draw.round(g, x, y, d, d, d / 2, Theme.accent());
            Draw.unscissor(g);
        }
        Draw.round(g, x + ring, y + ring, d - 2 * ring, d - 2 * ring, (d - 2 * ring) / 2, Theme.hudPanelAt(0.5));
        String pct = Math.round(p * 100) + "%";
        Draw.centeredBold(g, pct, x + d / 2f, y + (d - Draw.height(t)) / 2f, Theme.TEXT, t);
        outline(g, COOL);
    }

    /** "Эффекты": name, amplifier, timer chip. */
    private static void potions(GuiGraphics g) {
        S = S0 * POTS.scale;
        float t = S * 0.95f;
        List<Row> rows = new ArrayList<>();
        for (MobEffectInstance e : mc.player.getActiveEffects()) {
            String n = Component.translatable(e.getDescriptionId()).getString();
            String amp = e.getAmplifier() > 0 ? String.valueOf(e.getAmplifier() + 1) : "";
            int s = e.getDuration() / 20;
            String time = e.isInfiniteDuration() || e.getDuration() < 0 ? "inf" : String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
            rows.add(new Row(n, amp, time));
        }
        if (rows.isEmpty() && editing) { rows.add(new Row("Огнестойкость", "", "3:15")); rows.add(new Row("Сила", "4", "1:14")); }
        if (rows.isEmpty()) return;

        int w = u(170), row = u(18), pad = u(8), hh = u(20), gap = u(3), n = rows.size();
        place(POTS, w, hh + gap + n * row + pad, rw - u0(8), u0(8), 1.0);
        int x = POTS.x, y = POTS.y;
        header(g, x, y, w, "Эффекты", t, 1);
        int by = y + hh + gap;
        card(g, x, by, w, n * row + pad, u(7), 1);
        for (int i = 0; i < n; i++) {
            Row r = rows.get(i);
            int ry = by + pad / 2 + i * row, ty = textY(ry, row, t);
            Draw.text(g, r.name(), x + pad, ty, Theme.TEXT, t);
            if (!r.amp().isEmpty()) Draw.text(g, r.amp(), x + pad + Draw.width(r.name(), t) + u(3), ty - u(3), Theme.TEXT_DIM, t * 0.7f);
            chip(g, r.time(), x + w - pad, ry, row, t);
        }
        outline(g, POTS);
    }

    /** "Цель": avatar, name, HP and HP bar. */
    private static void target(GuiGraphics g) {
        boolean real = target != null && System.currentTimeMillis() - targetSeen < 2500;
        targetAlpha += (((real || editing) ? 1f : 0f) - targetAlpha) * 0.2f;
        if (targetAlpha < 0.02f) return;
        S = S0 * TARGET.scale;
        float t = S, a = targetAlpha;
        boolean dummy = !real;
        String name = dummy ? "Target" : target.getName().getString();
        float maxHp = dummy ? 20f : Math.max(1f, target.getMaxHealth());
        float hp = dummy ? 20f : Math.max(0f, target.getHealth());
        hpAnim = dummy ? hp : hpAnim + (hp - hpAnim) * 0.18f;

        int w = u(160), hh = u(20), gap = u(3), bodyH = u(46);
        place(TARGET, w, hh + gap + bodyH, rw / 2, rh / 2 + u0(130), 0.5);
        int x = TARGET.x, y = TARGET.y;
        header(g, x, y, w, "Цель", t, a);
        int by = y + hh + gap;
        card(g, x, by, w, bodyH, u(7), a);

        int av = u(34), ax = x + u(6), ay = by + (bodyH - av) / 2;
        Draw.round(g, ax, ay, av, av, u(7), Draw.alpha(0xFF000000 | Theme.mix(0x1A1E36, Theme.accent() & 0xFFFFFF, 0.35), a));
        String initial = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
        Draw.centeredBold(g, initial, ax + av / 2f, ay + (av - Draw.height(t * 1.4f)) / 2f, Draw.alpha(Theme.TEXT, a), t * 1.4f);

        int tx = ax + av + u(8), tw = w - (tx - x) - u(8);
        while (name.length() > 3 && Draw.width(name, t * 0.95f) > tw) name = name.substring(0, name.length() - 2);
        Draw.textBold(g, name, tx, by + u(5), Draw.alpha(Theme.TEXT, a), t * 0.95f);
        Draw.text(g, String.format(Locale.ROOT, "HP: %.1f", hp), tx, by + u(17), Draw.alpha(Theme.TEXT_DIM, a), t * 0.85f);

        int bh = u(6), bary = by + bodyH - u(13);
        double p = Math.max(0, Math.min(1, hpAnim / maxHp));
        Draw.round(g, tx, bary, tw, bh, bh / 2, Draw.alpha(Theme.SLIDER_BG, a));
        int fw = Math.max(bh, (int) (tw * p));
        int col = 0xFF000000 | Theme.mix(0xE5484D, 0x38BDF8, p);
        Draw.round(g, tx, bary, fw, bh, bh / 2, Draw.alpha(col, a));
        outline(g, TARGET);
    }

    /** "Команда": allied players nearby, HP bar and number. */
    private static void team(GuiGraphics g) {
        S = S0 * TEAM.scale;
        float t = S * 0.95f;
        List<Mate> mates = new ArrayList<>();
        for (Player p : mc.level.players()) {
            if (p == mc.player || !mc.player.isAlliedTo(p) || mates.size() >= 5) continue;
            mates.add(new Mate(p.getName().getString(), p.getHealth(), p.getMaxHealth()));
        }
        if (mates.isEmpty() && editing) { mates.add(new Mate("piona", 12f, 20f)); mates.add(new Mate("aqich4", 0f, 20f)); }
        if (mates.isEmpty()) return;

        int w = u(170), row = u(18), pad = u(8), hh = u(20), gap = u(3), n = mates.size();
        place(TEAM, w, hh + gap + n * row + pad, rw - u0(8), u0(92), 1.0);
        int x = TEAM.x, y = TEAM.y;
        header(g, x, y, w, "Команда", t, 1);
        int by = y + hh + gap;
        card(g, x, by, w, n * row + pad, u(7), 1);
        for (int i = 0; i < n; i++) {
            Mate m = mates.get(i);
            int ry = by + pad / 2 + i * row, ty = textY(ry, row, t);
            if (m.hp() <= 0) {
                Draw.text(g, m.name(), x + pad, ty, Theme.TEXT_DIM, t);
                String dead = "Мёртв";
                Draw.text(g, dead, x + w - pad - Draw.width(dead, t), ty, Theme.TEXT_DIM, t);
                continue;
            }
            Draw.text(g, m.name(), x + pad, ty, Theme.TEXT, t);
            String hpText = String.valueOf(Math.round(m.hp()));
            int hx = x + w - pad - Draw.width(hpText, t);
            Draw.text(g, hpText, hx, ty, Theme.TEXT, t);
            int bw = u(44), bh = u(5), bx = hx - u(6) - bw, bry = ry + (row - bh) / 2;
            double p = Math.max(0, Math.min(1, m.hp() / Math.max(1f, m.max())));
            Draw.round(g, bx, bry, bw, bh, bh / 2, Theme.SLIDER_BG);
            Draw.round(g, bx, bry, Math.max(bh, (int) (bw * p)), bh, bh / 2, Theme.accent());
        }
        outline(g, TEAM);
    }

    /** "Инвентарь": main inventory 9x3, counts drawn by the game. */
    private static void inventory(GuiGraphics g) {
        S = S0 * INV.scale;
        float t = S * 0.95f;
        int cell = u(20), gap = u(2), pad = u(8), hh = u(20), gap2 = u(3);
        int w = pad * 2 + 9 * cell + 8 * gap, bodyH = pad + 3 * cell + 2 * gap;
        place(INV, w, hh + gap2 + bodyH, rw - u0(8), rh - u0(200), 1.0);
        int x = INV.x, y = INV.y;
        header(g, x, y, w, "Инвентарь", t, 1);
        int by = y + hh + gap2;
        card(g, x, by, w, bodyH, u(7), 1);
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                int cx = x + pad + c * (cell + gap), cy = by + pad / 2 + r * (cell + gap);
                Draw.round(g, cx, cy, cell, cell, u(4), Theme.moduleAt(0, false, 0));
                icon(g, mc.player.getInventory().getItem(9 + r * 9 + c), cx + (cell - u(16)) / 2, cy + (cell - u(16)) / 2, u(16));
            }
        }
        outline(g, INV);
    }

    private static void notifications(GuiGraphics g) {
        S = S0 * NOTES.scale;
        float t = S * 0.9f;
        List<Notifications.Note> list = new ArrayList<>(Notifications.active());
        boolean dummy = list.isEmpty();
        if (dummy) {
            if (!editing) return;
            list.add(new Notifications.Note("Notification", "example", System.currentTimeMillis()));
        }
        int h = u(20), pad = u(9), gap = u(4), sp = u(5), maxW = 0;
        int[] ws = new int[list.size()];
        for (int i = 0; i < ws.length; i++) {
            Notifications.Note n = list.get(i);
            ws[i] = pad * 2 + u(12) + Draw.boldWidth(n.title(), t) + sp + Draw.width(n.text(), t);
            maxW = Math.max(maxW, ws[i]);
        }
        place(NOTES, maxW, ws.length * (h + gap) - gap, rw / 2, rh / 2 + u0(44), 0.5);

        long now = System.currentTimeMillis();
        for (int i = 0; i < ws.length; i++) {
            Notifications.Note n = list.get(i);
            double in = 1, a = 1;
            if (!dummy) {
                long age = now - n.born();
                in = Math.min(1, age / 220.0);
                a = Math.max(0, Math.min(in, Math.min(1, (Notifications.LIFE_MS - age) / 420.0)));
            }
            int x = NOTES.x + (maxW - ws[i]) / 2;
            int ny = NOTES.y + i * (h + gap) + (int) Math.round((1 - in) * u(8));
            int tw = Draw.boldWidth(n.title(), t);
            Draw.round(g, x, ny, ws[i], h, u(6), Draw.alpha(Theme.hudPanelAt(0.5), a));
            Draw.glassHighlight(g, x, ny, ws[i], h, u(6), true, Theme.Surface.HUD);
            Draw.round(g, x + pad, ny + (h - u(6)) / 2, u(6), u(6), u(2), Draw.alpha(Theme.accent(), a));
            Draw.textBold(g, n.title(), x + pad + u(12), textY(ny, h, t), Draw.alpha(Theme.TEXT, a), t);
            Draw.text(g, n.text(), x + pad + u(12) + tw + sp, textY(ny, h, t), Draw.alpha(Theme.TEXT_DIM, a), t);
        }
        outline(g, NOTES);
    }

    // ----------------------------------------------------------- persistence

    public static void writeLayout(Properties p) {
        for (Elem e : ELS) {
            p.setProperty("hud." + e.id + ".dx", Float.toString(e.dx));
            p.setProperty("hud." + e.id + ".dy", Float.toString(e.dy));
            p.setProperty("hud." + e.id + ".scale", Float.toString(e.scale));
        }
    }

    public static void readLayout(Properties p) {
        for (Elem e : ELS) {
            try {
                e.dx = Float.parseFloat(p.getProperty("hud." + e.id + ".dx", "0"));
                e.dy = Float.parseFloat(p.getProperty("hud." + e.id + ".dy", "0"));
                e.scale = Math.max(0.5f, Math.min(2.5f, Float.parseFloat(p.getProperty("hud." + e.id + ".scale", "1"))));
            } catch (NumberFormatException ignored) {}
        }
    }
}
