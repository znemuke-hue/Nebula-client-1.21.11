package dev.hvh.client.cosmetics;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Small, client-side cosmetics settings store. The GUI uses the sub-tabs as examples of nested pages. */
public final class Cosmetics {
    private static final Properties DATA = new Properties();
    private static boolean loaded;

    public static boolean wings;
    public static boolean cape;
    public static boolean halo;
    public static boolean showSelf = true;
    public static boolean showOthers;
    public static int wingsColor = 0xFF9B7BFF;
    public static int capeColor = 0xFF5ED7FF;
    public static int haloColor = 0xFFFFD166;
    private static final int[] PALETTE = {
        0xFF9B7BFF, 0xFF5ED7FF, 0xFFFFD166, 0xFFFF6B8A, 0xFF8BE28B, 0xFFFFFFFF
    };

    private Cosmetics() {}

    public static int[] palette() { return PALETTE.clone(); }

    public static void load() {
        if (loaded) return;
        loaded = true;
        Path path = path();
        if (!Files.isRegularFile(path)) return;
        try (InputStream in = Files.newInputStream(path)) {
            DATA.load(in);
            wings = Boolean.parseBoolean(DATA.getProperty("wings", "false"));
            cape = Boolean.parseBoolean(DATA.getProperty("cape", "false"));
            halo = Boolean.parseBoolean(DATA.getProperty("halo", "false"));
            showSelf = Boolean.parseBoolean(DATA.getProperty("showSelf", "true"));
            showOthers = Boolean.parseBoolean(DATA.getProperty("showOthers", "false"));
            wingsColor = parseColor("wingsColor", 0xFF9B7BFF);
            capeColor = parseColor("capeColor", 0xFF5ED7FF);
            haloColor = parseColor("haloColor", 0xFFFFD166);
        } catch (IOException ignored) { }
    }

    private static int parseColor(String key, int fallback) {
        try { return (int) Long.parseLong(DATA.getProperty(key, Integer.toHexString(fallback)), 16); }
        catch (RuntimeException ignored) { return fallback; }
    }

    public static void save() {
        DATA.setProperty("wings", Boolean.toString(wings));
        DATA.setProperty("cape", Boolean.toString(cape));
        DATA.setProperty("halo", Boolean.toString(halo));
        DATA.setProperty("showSelf", Boolean.toString(showSelf));
        DATA.setProperty("showOthers", Boolean.toString(showOthers));
        DATA.setProperty("wingsColor", Integer.toHexString(wingsColor));
        DATA.setProperty("capeColor", Integer.toHexString(capeColor));
        DATA.setProperty("haloColor", Integer.toHexString(haloColor));
        try {
            Path path = path();
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                DATA.store(out, "Nebula client cosmetics");
            }
        } catch (IOException ignored) { }
    }

    private static Path path() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("nebula").resolve("cosmetics.properties");
    }

    public static void reset() {
        wings = false; cape = false; halo = false;
        showSelf = true; showOthers = false;
        wingsColor = 0xFF9B7BFF; capeColor = 0xFF5ED7FF; haloColor = 0xFFFFD166;
        save();
    }

    public static int nextColor(int color) {
        for (int i = 0; i < PALETTE.length; i++) if (PALETTE[i] == color) return PALETTE[(i + 1) % PALETTE.length];
        return PALETTE[0];
    }
}
