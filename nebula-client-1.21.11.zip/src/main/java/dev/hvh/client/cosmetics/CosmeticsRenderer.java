package dev.hvh.client.cosmetics;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.hvh.client.HvhClient;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.OptionalDouble;
import java.util.OptionalInt;

/** Procedural client-side accessories: halo, wings and a short cape. */
public final class CosmeticsRenderer {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final RenderPipeline PIPELINE = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("hvhclient", "pipeline/cosmetics"))
            .build()
    );
    private static final Vector4f WHITE = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f OFFSET = new Vector3f();
    private static final Matrix4f TEX = new Matrix4f();
    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(4 * 1024 * 1024);
    private static MappableRingBuffer ring;

    private CosmeticsRenderer() {}

    public static void render(WorldRenderContext context) {
        Cosmetics.load();
        if (MC.level == null || MC.player == null || (!Cosmetics.wings && !Cosmetics.cape && !Cosmetics.halo)) return;
        BufferBuilder builder = new BufferBuilder(ALLOCATOR, PIPELINE.getVertexFormatMode(), PIPELINE.getVertexFormat());
        VertexConsumer v = builder;
        PoseStack pose = context.matrices();
        Vec3 camera = context.worldState().cameraRenderState.pos;
        pose.pushPose();
        pose.translate(-camera.x, -camera.y, -camera.z);
        Matrix4f matrix = pose.last().pose();
        int count = 0;
        for (Player player : MC.level.players()) {
            if (player.isRemoved() || player.isSpectator()) continue;
            if (player == MC.player ? !Cosmetics.showSelf : !Cosmetics.showOthers) continue;
            double x = player.getX(), y = player.getY(), z = player.getZ();
            double h = player.getBbHeight();
            float yaw = (float)Math.toRadians(player.getYRot());
            double rx = Math.cos(yaw), rz = Math.sin(yaw);       // local right vector
            double bx = Math.sin(yaw), bz = -Math.cos(yaw);     // local back vector
            if (Cosmetics.wings) {
                wing(v, matrix, x, y, z, h, rx, rz, bx, bz, -1, Cosmetics.wingsColor);
                wing(v, matrix, x, y, z, h, rx, rz, bx, bz, 1, Cosmetics.wingsColor);
                count += 8;
            }
            if (Cosmetics.cape) {
                double sway = Math.sin(System.currentTimeMillis() / 350.0 + player.getId()) * 0.045;
                double x0=x+bx*0.12, z0=z+bz*0.12;
                face(v,matrix, x0-rx*0.22,y+h*0.82,z0-rz*0.22,
                    x0+rx*0.22,y+h*0.82,z0+rz*0.22,
                    x0+rx*0.27+bx*sway,y+0.12,z0+rz*0.27+bz*sway,
                    x0-rx*0.27+bx*sway,y+0.12,z0-rz*0.27+bz*sway, Cosmetics.capeColor);
                count += 4;
            }
            if (Cosmetics.halo) {
                double hy = y + h + 0.16, outer = 0.31, inner = 0.245;
                for (int i=0;i<32;i++) {
                    double a=i*Math.PI*2/32.0, b=(i+1)*Math.PI*2/32.0;
                    face(v,matrix, x+Math.cos(a)*outer,hy,z+Math.sin(a)*outer,
                        x+Math.cos(b)*outer,hy,z+Math.sin(b)*outer,
                        x+Math.cos(b)*inner,hy,z+Math.sin(b)*inner,
                        x+Math.cos(a)*inner,hy,z+Math.sin(a)*inner, Cosmetics.haloColor);
                    count += 4;
                }
            }
        }
        pose.popPose();
        if (count == 0) { try { builder.build(); } catch (Throwable ignored) {} return; }
        MeshData mesh = builder.buildOrThrow();
        MeshData.DrawState state = mesh.drawState();
        int size = state.vertexCount() * state.format().getVertexSize();
        if (ring == null || ring.size() < size) {
            if (ring != null) ring.close();
            ring = new MappableRingBuffer(() -> "Nebula cosmetics", GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
        }
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView view = encoder.mapBuffer(ring.currentBuffer().slice(0, mesh.vertexBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(mesh.vertexBuffer(), view.data());
        }
        GpuBuffer indices;
        VertexFormat.IndexType indexType;
        if (PIPELINE.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
            mesh.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
            indices = PIPELINE.getVertexFormat().uploadImmediateIndexBuffer(mesh.indexBuffer());
            indexType = state.indexType();
        } else {
            RenderSystem.AutoStorageIndexBuffer seq = RenderSystem.getSequentialBuffer(PIPELINE.getVertexFormatMode());
            indices = seq.getBuffer(state.indexCount()); indexType = seq.type();
        }
        GpuBufferSlice transforms = RenderSystem.getDynamicUniforms().writeTransform(RenderSystem.getModelViewMatrix(), WHITE, OFFSET, TEX);
        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
            () -> "Nebula cosmetics", MC.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
            MC.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
            pass.setPipeline(PIPELINE);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", transforms);
            pass.setVertexBuffer(0, ring.currentBuffer());
            pass.setIndexBuffer(indices, indexType);
            pass.drawIndexed(0, 0, state.indexCount(), 1);
        }
        mesh.close(); ring.rotate();
    }

    private static void wing(VertexConsumer v, Matrix4f m, double x, double y, double z, double h,
                             double rx, double rz, double bx, double bz, int side, int color) {
        double sx = x - rx * 0.16 * side + bx * 0.12;
        double sz = z - rz * 0.16 * side + bz * 0.12;
        double tipX = x + rx * 0.78 * side + bx * 0.34;
        double tipZ = z + rz * 0.78 * side + bz * 0.34;
        double lowX = x + rx * 0.60 * side + bx * 0.50;
        double lowZ = z + rz * 0.60 * side + bz * 0.50;
        double inX = x + rx * 0.18 * side + bx * 0.28;
        double inZ = z + rz * 0.18 * side + bz * 0.28;
        face(v,m,sx,y+h*0.86,sz, tipX,y+h*0.99,tipZ, lowX,y+h*0.30,lowZ, inX,y+h*0.43,inZ,color);
    }

    private static void face(VertexConsumer v, Matrix4f m,
            double x0,double y0,double z0,double x1,double y1,double z1,
            double x2,double y2,double z2,double x3,double y3,double z3,int color) {
        float r=((color>>16)&255)/255f, g=((color>>8)&255)/255f, b=(color&255)/255f, a=((color>>>24)&255)/255f;
        v.addVertex(m,(float)x0,(float)y0,(float)z0).setColor(r,g,b,a);
        v.addVertex(m,(float)x1,(float)y1,(float)z1).setColor(r,g,b,a);
        v.addVertex(m,(float)x2,(float)y2,(float)z2).setColor(r,g,b,a);
        v.addVertex(m,(float)x3,(float)y3,(float)z3).setColor(r,g,b,a);
    }

    public static void close() {
        ALLOCATOR.close();
        if (ring != null) { ring.close(); ring = null; }
    }
}
