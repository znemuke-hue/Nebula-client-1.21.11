package dev.hvh.client.gui;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.gui.GuiGraphics;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Smooth text from an MSDF/MTSDF atlas (msdf-atlas-gen json + png), no shaders.
 * Whole strings are rasterized once (exact pixel size, sub-pixel glyph positions) into a cached
 * bitmap, so drawing a string costs ONE GUI element instead of one per letter.
 */
public final class MsdfFont {
    private static final int PAD = 2;

    private record Glyph(double adv, boolean has, double pl, double pb, double pr, double pt,
                         double al, double ab, double ar, double at) {}

    private final String name;
    private final Map<Integer, Glyph> glyphs = new HashMap<>();
    private final Atlas atlas;
    private int[] src;
    private int sw, sh;
    private double range = 8, atlasSize = 64;
    private boolean yBottom = true, loaded;

    public MsdfFont(String name) {
        this.name = name;
        this.atlas = new Atlas("str_" + name, 1024, 1024);
    }

    private void load() {
        loaded = true;
        try (InputStream js = MsdfFont.class.getResourceAsStream("/assets/hvhclient/msdf/" + name + ".json");
             InputStream pn = MsdfFont.class.getResourceAsStream("/assets/hvhclient/msdf/" + name + ".png")) {
            JsonObject root = JsonParser.parseReader(new InputStreamReader(js, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject at = root.getAsJsonObject("atlas");
            range = at.get("distanceRange").getAsDouble();
            atlasSize = at.get("size").getAsDouble();
            yBottom = !at.has("yOrigin") || at.get("yOrigin").getAsString().equals("bottom");

            NativeImage img = NativeImage.read(pn);
            sw = img.getWidth(); sh = img.getHeight();
            src = new int[sw * sh];
            for (int y = 0; y < sh; y++) for (int x = 0; x < sw; x++) src[y * sw + x] = img.getPixel(x, y);
            img.close();

            for (JsonElement e : root.getAsJsonArray("glyphs")) {
                JsonObject o = e.getAsJsonObject();
                int cp = o.get("unicode").getAsInt();
                double adv = o.get("advance").getAsDouble();
                if (o.has("planeBounds") && o.has("atlasBounds")) {
                    JsonObject p = o.getAsJsonObject("planeBounds"), a = o.getAsJsonObject("atlasBounds");
                    glyphs.put(cp, new Glyph(adv, true,
                        p.get("left").getAsDouble(), p.get("bottom").getAsDouble(), p.get("right").getAsDouble(), p.get("top").getAsDouble(),
                        a.get("left").getAsDouble(), a.get("bottom").getAsDouble(), a.get("right").getAsDouble(), a.get("top").getAsDouble()));
                } else glyphs.put(cp, new Glyph(adv, false, 0, 0, 0, 0, 0, 0, 0, 0));
            }
        } catch (Exception ex) {
            throw new RuntimeException("Failed to load MSDF font " + name, ex);
        }
    }

    private int chan(int x, int y, int shift) {
        x = Math.max(0, Math.min(sw - 1, x)); y = Math.max(0, Math.min(sh - 1, y));
        return (src[y * sw + x] >> shift) & 0xFF;
    }

    private double bil(double fx, double fy, int shift) {
        int x0 = (int) Math.floor(fx), y0 = (int) Math.floor(fy);
        double tx = fx - x0, ty = fy - y0;
        double a = chan(x0, y0, shift) * (1 - tx) + chan(x0 + 1, y0, shift) * tx;
        double b = chan(x0, y0 + 1, shift) * (1 - tx) + chan(x0 + 1, y0 + 1, shift) * tx;
        return (a * (1 - ty) + b * ty) / 255.0;
    }

    private static double median(double a, double b, double c) { return Math.max(Math.min(a, b), Math.min(Math.max(a, b), c)); }

    private int alphaAt(Glyph g, double planeX, double planeY, double spr) {
        double ax = g.al + (planeX - g.pl) / (g.pr - g.pl) * (g.ar - g.al);
        double ay = g.ab + (planeY - g.pb) / (g.pt - g.pb) * (g.at - g.ab);
        ax = Math.max(g.al, Math.min(g.ar, ax));
        ay = Math.max(g.ab, Math.min(g.at, ay));
        double row = yBottom ? sh - ay : ay;
        double fx = ax - 0.5, fy = row - 0.5;
        double sd = median(bil(fx, fy, 16), bil(fx, fy, 8), bil(fx, fy, 0));
        return (int) Math.round(Math.max(0, Math.min(1, (sd - 0.5) * spr + 0.5)) * 255);
    }

    private Glyph glyph(int cp) {
        Glyph g = glyphs.get(cp);
        return g != null ? g : glyphs.get((int) '?');
    }

    private double widthD(String s, int px) {
        double w = 0;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i); i += Character.charCount(cp);
            Glyph g = glyph(cp);
            if (g != null) w += g.adv * px;
        }
        return w;
    }

    public int width(String s, int px) {
        if (!loaded) load();
        return (int) Math.round(widthD(s, px));
    }

    private static int above(int px) { return (int) Math.ceil(px * 1.05) + 1; }
    private static int below(int px) { return (int) Math.ceil(px * 0.35) + 1; }

    private Atlas.Region bake(String key, String s, int px) {
        int abv = above(px), hgt = abv + below(px);
        int w = Math.min(1024, (int) Math.ceil(widthD(s, px)) + 2 * PAD);
        Atlas.Region r = atlas.alloc(w, hgt);
        atlas.map.put(key, r);
        int[] buf = new int[w * hgt];
        double spr = Math.max(1.0, range * px / atlasSize);
        double pen = PAD;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i); i += Character.charCount(cp);
            Glyph gl = glyph(cp);
            if (gl == null) continue;
            if (gl.has) {
                int x0 = (int) Math.floor(pen + gl.pl * px) - 1, x1 = (int) Math.ceil(pen + gl.pr * px) + 1;
                int y0 = abv + (int) Math.floor(-gl.pt * px) - 1, y1 = abv + (int) Math.ceil(-gl.pb * px) + 1;
                for (int iy = Math.max(0, y0); iy < Math.min(hgt, y1); iy++)
                    for (int ix = Math.max(0, x0); ix < Math.min(w, x1); ix++) {
                        int a = alphaAt(gl, (ix + 0.5 - pen) / px, (abv - (iy + 0.5)) / px, spr);
                        if (a > buf[iy * w + ix]) buf[iy * w + ix] = a;
                    }
            }
            pen += gl.adv * px;
        }
        for (int iy = 0; iy < hgt; iy++)
            for (int ix = 0; ix < w; ix++)
                atlas.set(r.x() + ix, r.y() + iy, (buf[iy * w + ix] << 24) | 0xFFFFFF);
        return r;
    }

    public void draw(GuiGraphics g, String s, int x, int baseline, int px, int color) {
        if (s.isEmpty()) return;
        if (!loaded) load();
        String key = px + "|" + s;
        Atlas.Region r = atlas.map.get(key);
        if (r == null) r = bake(key, s, px);
        atlas.blit(g, r, x - PAD, baseline - above(px), color);
    }

    public void flush() { atlas.flush(); }
}
