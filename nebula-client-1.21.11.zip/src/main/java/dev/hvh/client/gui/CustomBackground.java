package dev.hvh.client.gui;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;

/**
 * Custom PNG/JPG backgrounds for the Click GUI and the main menu (files live in config/nebula/backgrounds).
 *
 * Decoding goes through ImageIO (any PNG/JPG/GIF/BMP), big images are box-downscaled to at most 2048 px, and every
 * failure is remembered in {@link #error(boolean)} instead of being swallowed, so the Theme page can show it.
 */
public final class CustomBackground {
    private static final int MAX_SIDE = 2048;

    private static final class BlurEntry {
        final DynamicTexture texture;
        final Identifier id;
        final int w, h;
        BlurEntry(DynamicTexture texture, Identifier id, int w, int h) { this.texture=texture; this.id=id; this.w=w; this.h=h; }
    }
    private static final class Slot {
        DynamicTexture tex;
        Identifier id;
        int w, h;
        int[] sourcePixels;
        final Map<Integer, BlurEntry> blurCache = new HashMap<>();
        // Last GUI-wallpaper destination/crop. Used only to put a cached blurred wallpaper slice
        // inside a module card; no scene/framebuffer sampling is done.
        int viewX, viewY, viewW, viewH, viewSX, viewSY, viewSW, viewSH, viewTexW, viewTexH;
        Identifier viewTexture;
        String error = "";
    }

    private static final Slot GUI = new Slot(), MENU = new Slot();
    private static boolean loadedOnce;

    private CustomBackground() {}

    private static Slot slot(boolean menu) { return menu ? MENU : GUI; }

    /** Open the in-game list of images placed in config/nebula/backgrounds. */
    public static void choose(boolean menu) {
        ensureFolder();
        dev.hvh.client.sound.ClientSounds.keepGui = true;
        Minecraft.getInstance().setScreen(new BackgroundFilePicker(menu));
    }

    public static Path backgroundsDirectory() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config/nebula/backgrounds");
    }

    public static void ensureFolder() {
        try {
            Path dir = backgroundsDirectory();
            Files.createDirectories(dir);
            Path readme = dir.resolve("README.txt");
            if (!Files.exists(readme)) Files.writeString(readme,
                "Nebula Client backgrounds\n\n" +
                "Put .png, .jpg or .jpeg images in this folder, then open Theme in game and choose GUI/Menu background.\n" +
                "Built-in presets: blue, purple, amber, aurora, rose, midnight, umbrella, night-snow and night.\n" +
                "The image is copied to the active slot when selected.\n");
            for (String preset : new String[]{
                "default-nebula-purple.png", "default-nebula-blue.png", "default-nebula-amber.png",
                "default-nebula-aurora.png", "default-nebula-rose.png", "default-nebula-midnight.png",
                "default-umbrella.png", "default-night-snow.jpeg", "default-night.jpg"
            }) {
                Path dest = dir.resolve(preset);
                if (!Files.exists(dest)) {
                    try (InputStream in = CustomBackground.class.getResourceAsStream("/nebula-defaults/backgrounds/" + preset)) {
                        if (in != null) Files.copy(in, dest);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    /** Copies the chosen file into the active slot and loads it. Returns null on success, else an error text. */
    static String copyChosen(Path chosen, boolean menu) {
        try {
            String name = chosen.getFileName().toString().toLowerCase();
            if (!(name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg"))) return "Only PNG/JPG files";
            Path dir = backgroundsDirectory();
            Files.createDirectories(dir);
            String ext = name.endsWith(".png") ? ".png" : ".jpg";
            String base = menu ? "main-menu" : "click-gui";
            Path dest = dir.resolve(base + ext);
            Files.deleteIfExists(dir.resolve(base + (ext.equals(".png") ? ".jpg" : ".png")));
            if (!chosen.toAbsolutePath().normalize().equals(dest.toAbsolutePath().normalize()))
                Files.copy(chosen, dest, StandardCopyOption.REPLACE_EXISTING);
            load(dest, menu);
            Slot s = slot(menu);
            if (s.id == null) return s.error.isEmpty() ? "Could not load image" : s.error;
            if (menu) Theme.menuBackgroundEnabled = true; else Theme.backgroundEnabled = true;
            Theme.save();
            return null;
        } catch (Exception e) {
            return shortMsg(e);
        }
    }

    /** Remove the background of a slot and switch it off. */
    static void clear(boolean menu) {
        try {
            Path dir = backgroundsDirectory();
            String base = menu ? "main-menu" : "click-gui";
            Files.deleteIfExists(dir.resolve(base + ".png"));
            Files.deleteIfExists(dir.resolve(base + ".jpg"));
        } catch (Exception ignored) {}
        Slot s = slot(menu);
        clearBlurCache(s);
        if (s.id != null) {
            try { Minecraft.getInstance().getTextureManager().release(s.id); } catch (Exception ignored) {}
        }
        s.id = null; s.tex = null; s.sourcePixels = null; s.error = "";
        s.viewW = s.viewH = 0; s.viewTexture = null;
        if (menu) Theme.menuBackgroundEnabled = false; else Theme.backgroundEnabled = false;
        Theme.save();
    }

    /** Loads the saved images once per session (screens call this from init(); picking an image loads it directly). */
    public static void ensureLoaded() { if (!loadedOnce) loadSaved(); }

    public static void loadSaved() {
        loadedOnce = true;
        ensureFolder();
        Path base = backgroundsDirectory();
        loadFirst(base.resolve("click-gui.png"), base.resolve("click-gui.jpg"), false);
        loadFirst(base.resolve("main-menu.png"), base.resolve("main-menu.jpg"), true);
    }

    private static void loadFirst(Path a, Path b, boolean menu) {
        if (Files.exists(a)) load(a, menu); else if (Files.exists(b)) load(b, menu);
    }

    private static String shortMsg(Throwable t) {
        String m = t.getMessage();
        String s = t.getClass().getSimpleName() + (m == null ? "" : ": " + m);
        return s.length() > 90 ? s.substring(0, 90) : s;
    }

    private static NativeImage read(Path path) throws Exception {
        BufferedImage img;
        try (InputStream in = Files.newInputStream(path)) { img = ImageIO.read(in); }
        if (img == null) { // format ImageIO does not know: let the game's own decoder try
            try (InputStream in = Files.newInputStream(path)) { return NativeImage.read(in); }
        }
        int sw = img.getWidth(), sh = img.getHeight();
        int k = Math.max(1, (int) Math.ceil(Math.max(sw, sh) / (double) MAX_SIDE));
        int w = Math.max(1, sw / k), h = Math.max(1, sh / k);
        int[] px = img.getRGB(0, 0, sw, sh, null, 0, sw);
        NativeImage out = new NativeImage(NativeImage.Format.RGBA, w, h, false);
        int n = k * k;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int a = 0, r = 0, g = 0, b = 0;
                for (int dy = 0; dy < k; dy++) {
                    int row = (y * k + dy) * sw + x * k;
                    for (int dx = 0; dx < k; dx++) {
                        int p = px[row + dx];
                        a += p >>> 24; r += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255;
                    }
                }
                a /= n; r /= n; g /= n; b /= n;
                out.setPixelABGR(x, y, (a << 24) | (b << 16) | (g << 8) | r);
            }
        }
        return out;
    }

    private static void clearBlurCache(Slot s) {
        for (BlurEntry entry : s.blurCache.values()) {
            try { Minecraft.getInstance().getTextureManager().release(entry.id); } catch (Exception ignored) {}
        }
        s.blurCache.clear();
    }

    private static void load(Path path, boolean menu) {
        Slot s = slot(menu);
        try {
            NativeImage image = read(path);
            int iw = image.getWidth(), ih = image.getHeight();
            int[] original = new int[iw * ih];
            for (int py = 0; py < ih; py++) for (int px = 0; px < iw; px++) original[py * iw + px] = image.getPixel(px, py);
            DynamicTexture texture = new DynamicTexture(() -> menu ? "nebula_main_menu_background" : "nebula_gui_background", image);
            texture.upload();
            Identifier id = Identifier.fromNamespaceAndPath("hvhclient", menu ? "custom_main_menu_background" : "custom_gui_background");
            // Registering over the same id makes the TextureManager close the previous texture itself.
            Minecraft.getInstance().getTextureManager().register(id, texture);
            clearBlurCache(s);
            s.tex = texture; s.id = id; s.w = iw; s.h = ih; s.sourcePixels = original;
            s.viewW = s.viewH = 0; s.viewTexture = null;
            s.error = "";
        } catch (Throwable t) {
            clearBlurCache(s);
            if (s.id != null) {
                try { Minecraft.getInstance().getTextureManager().release(s.id); } catch (Exception ignored) {}
            }
            s.id = null; s.tex = null; s.sourcePixels = null;
            s.viewW = s.viewH = 0; s.viewTexture = null;
            s.error = shortMsg(t);
        }
    }

    /**
     * Builds one cached blurred version of the custom GUI wallpaper. It is deliberately
     * downsampled to at most 1024 px per side before the separable box blur. There are only eight
     * quantized strength levels, so each image is generated at most once per background selection.
     */
    private static BlurEntry blurredTexture(Slot s, boolean menu, double strength) {
        int level = (int) Math.round(Math.max(0.0, Math.min(1.0, strength)) * 8.0);
        if (level <= 0 || s.sourcePixels == null) return null;
        BlurEntry cached = s.blurCache.get(level);
        if (cached != null) return cached;
        int scale = Math.max(1, (int) Math.ceil(Math.max(s.w, s.h) / 1024.0));
        int bw = Math.max(1, s.w / scale), bh = Math.max(1, s.h / scale);
        int[] reduced = new int[bw * bh];
        for (int y = 0; y < bh; y++) for (int x = 0; x < bw; x++) {
            int sx = Math.min(s.w - 1, x * scale), sy = Math.min(s.h - 1, y * scale);
            int a = 0, b = 0, gg = 0, r = 0, count = 0;
            for (int dy = 0; dy < scale && sy + dy < s.h; dy++) for (int dx = 0; dx < scale && sx + dx < s.w; dx++) {
                int p = s.sourcePixels[(sy + dy) * s.w + sx + dx];
                a += (p >>> 24) & 255; b += (p >>> 16) & 255; gg += (p >>> 8) & 255; r += p & 255; count++;
            }
            reduced[y * bw + x] = ((a / count) << 24) | ((b / count) << 16) | ((gg / count) << 8) | (r / count);
        }
        int radius = Math.max(1, level * 2);
        int[] horizontal = blurHorizontal(reduced, bw, bh, radius);
        int[] blurred = blurVertical(horizontal, bw, bh, radius);
        NativeImage out = new NativeImage(NativeImage.Format.RGBA, bw, bh, false);
        for (int y = 0; y < bh; y++) for (int x = 0; x < bw; x++) out.setPixelABGR(x, y, blurred[y * bw + x]);
        Identifier blurId = Identifier.fromNamespaceAndPath("hvhclient", (menu ? "blurred_menu_background_" : "blurred_gui_background_") + level);
        DynamicTexture texture = new DynamicTexture(() -> (menu ? "nebula_blurred_menu_background_" : "nebula_blurred_gui_background_") + level, out);
        texture.upload();
        Minecraft.getInstance().getTextureManager().register(blurId, texture);
        BlurEntry entry = new BlurEntry(texture, blurId, bw, bh);
        s.blurCache.put(level, entry);
        return entry;
    }

    /** Clears the crop remembered from a prior Click GUI frame, so HUD rendering cannot reuse it. */
    public static void clearGuiViewport() {
        GUI.viewW = GUI.viewH = 0; GUI.viewTexture = null;
    }

    /** Draw a blurred slice of the custom GUI wallpaper inside a module card, if one is selected. */
    public static void drawGlassRegion(GuiGraphics g, int x, int y, int w, int h, double blurStrength) {
        Slot s = GUI;
        if (!Theme.backgroundEnabled || s.viewTexture == null || s.viewW <= 0 || s.viewH <= 0 || w <= 0 || h <= 0) return;
        if (x < s.viewX || y < s.viewY || x + w > s.viewX + s.viewW || y + h > s.viewY + s.viewH) return;
        BlurEntry blurred = blurredTexture(s, false, blurStrength);
        if (blurred == null) return;
        double fx = (x - s.viewX) / (double)s.viewW, fy = (y - s.viewY) / (double)s.viewH;
        double fw = w / (double)s.viewW, fh = h / (double)s.viewH;
        // Store the viewport crop as normalized coordinates: the GUI preview might have been
        // drawn from the full-resolution image (blur=0), while this card uses a downsampled blur.
        double baseW = Math.max(1, s.viewTexW), baseH = Math.max(1, s.viewTexH);
        double cropX = s.viewSX / baseW, cropY = s.viewSY / baseH;
        double cropW = s.viewSW / baseW, cropH = s.viewSH / baseH;
        int sx = (int)Math.round((cropX + fx * cropW) * blurred.w);
        int sy = (int)Math.round((cropY + fy * cropH) * blurred.h);
        int sw = Math.max(1, (int)Math.round(fw * cropW * blurred.w));
        int sh = Math.max(1, (int)Math.round(fh * cropH * blurred.h));
        sx = Math.max(0, Math.min(blurred.w - 1, sx));
        sy = Math.max(0, Math.min(blurred.h - 1, sy));
        sw = Math.max(1, Math.min(blurred.w - sx, sw));
        sh = Math.max(1, Math.min(blurred.h - sy, sh));
        // Full opacity here is the glass's blurred backdrop; moduleOpacity controls the color tint drawn above it.
        g.blit(RenderPipelines.GUI_TEXTURED, blurred.id, x, y, (float)sx, (float)sy, w, h, sw, sh, blurred.w, blurred.h, 0xFFFFFFFF);
    }

    private static int[] blurHorizontal(int[] src, int w, int h, int radius) {
        int[] out = new int[src.length];
        for (int y = 0; y < h; y++) {
            long a=0,b=0,g=0,r=0; int count=0;
            for(int x=0;x<=Math.min(w-1,radius);x++){int p=src[y*w+x];a+=(p>>>24)&255;b+=(p>>>16)&255;g+=(p>>>8)&255;r+=p&255;count++;}
            for(int x=0;x<w;x++){
                out[y*w+x]=((int)(a/count)<<24)|((int)(b/count)<<16)|((int)(g/count)<<8)|(int)(r/count);
                int remove=x-radius; if(remove>=0){int p=src[y*w+remove];a-=(p>>>24)&255;b-=(p>>>16)&255;g-=(p>>>8)&255;r-=p&255;count--;}
                int add=x+radius+1; if(add<w){int p=src[y*w+add];a+=(p>>>24)&255;b+=(p>>>16)&255;g+=(p>>>8)&255;r+=p&255;count++;}
            }
        }
        return out;
    }

    private static int[] blurVertical(int[] src, int w, int h, int radius) {
        int[] out = new int[src.length];
        for (int x = 0; x < w; x++) {
            long a=0,b=0,g=0,r=0; int count=0;
            for(int y=0;y<=Math.min(h-1,radius);y++){int p=src[y*w+x];a+=(p>>>24)&255;b+=(p>>>16)&255;g+=(p>>>8)&255;r+=p&255;count++;}
            for(int y=0;y<h;y++){
                out[y*w+x]=((int)(a/count)<<24)|((int)(b/count)<<16)|((int)(g/count)<<8)|(int)(r/count);
                int remove=y-radius; if(remove>=0){int p=src[remove*w+x];a-=(p>>>24)&255;b-=(p>>>16)&255;g-=(p>>>8)&255;r-=p&255;count--;}
                int add=y+radius+1; if(add<h){int p=src[add*w+x];a+=(p>>>24)&255;b+=(p>>>16)&255;g+=(p>>>8)&255;r+=p&255;count++;}
            }
        }
        return out;
    }

    public static boolean has(boolean menu) { return slot(menu).id != null; }
    public static boolean hasError(boolean menu) { return !slot(menu).error.isEmpty(); }
    public static String error(boolean menu) { return slot(menu).error; }

    /** Draws the image to cover x,y,w,h (aspect ratio kept, excess cropped around the center). */
    public static void draw(GuiGraphics g, int x, int y, int w, int h, boolean menu, double opacity) {
        Slot s = slot(menu);
        if (s.id == null || w <= 0 || h <= 0 || s.w <= 0 || s.h <= 0) return;
        int alpha = (int) Math.max(0, Math.min(255, Math.round(opacity * 255)));
        BlurEntry blurred = !menu ? blurredTexture(s, false, Theme.guiBlurStrength) : null;
        Identifier drawId = blurred != null ? blurred.id : s.id;
        int iw = blurred != null ? blurred.w : s.w, ih = blurred != null ? blurred.h : s.h;
        double targetRatio = w / (double) h, imageRatio = iw / (double) ih;
        int sx = 0, sy = 0, sw = iw, sh = ih;
        if (imageRatio > targetRatio) { sw = Math.max(1, (int) Math.round(ih * targetRatio)); sx = (iw - sw) / 2; }
        else if (imageRatio < targetRatio) { sh = Math.max(1, (int) Math.round(iw / targetRatio)); sy = (ih - sh) / 2; }
        if (!menu) {
            s.viewX=x; s.viewY=y; s.viewW=w; s.viewH=h; s.viewSX=sx; s.viewSY=sy; s.viewSW=sw; s.viewSH=sh;
            s.viewTexW=iw; s.viewTexH=ih; s.viewTexture=drawId;
        }
        if (alpha == 0) return;
        int tint = (alpha << 24) | 0xFFFFFF;
        g.blit(RenderPipelines.GUI_TEXTURED, drawId, x, y, (float) sx, (float) sy, w, h, sw, sh, iw, ih, tint);
    }
}
