package dev.hvh.client.gui;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

/**
 * NORMAL:   normal[0] = overall GUI color, normal[1] = buttons/modules color.
 * GRADIENT: grad[0]->grad[1] = animated gradient of the overall GUI, grad[2]->grad[3] = animated gradient of modules.
 * Colors are RGB ints (no alpha).
 */
public final class Theme {
    public enum Mode { NORMAL, GRADIENT }
    public record Preset(String name, int... cols) {}

    public static int TEXT = 0xFFFFFFFF;
    public static int TEXT_DIM = 0xFFA3A9C4;   // follows TEXT (see setText)
    public static final int DARK = 0xFF1A1E36, DARK_HOVER = 0xFF262C4C, SLIDER_BG = 0xFF2A2E48;

    public static Mode mode = Mode.NORMAL;
    // Per-surface glass controls. Values are independent and saved in the theme config.
    public enum Surface { GUI, MODULE, HUD }
    /** Legacy setting loaded for backwards compatibility only; never drives a full-screen blur. */
    @Deprecated public static double blurStrength = 0.35;
    public static double guiBlurStrength = 0.35, moduleBlurStrength = 0.40, hudBlurStrength = 0.30;
    public static double guiOpacity = 0.55, moduleOpacity = 0.48, hudOpacity = 0.52;
    public static double guiHighlightStrength = 0.45, moduleHighlightStrength = 0.72, hudHighlightStrength = 0.48;
    public static double gradientAngle = 0.0;
    public static int glowColor = 0x8A4BE0;
    public static double glowStrength = 0.55;
    public static double guiScaleX = 1.0, guiScaleY = 1.0;
    public static double cornerRadius = 7.0;
    public static int outlineColor = 0x8A4BE0;
    public static double outlineWidth = 1.0;
    public static boolean outlineTopLeft = true, outlineTopRight = true, outlineBottomLeft = true, outlineBottomRight = true;
    public static boolean glowEnabled = true, outlineEnabled = true, backgroundEnabled = false, menuBackgroundEnabled = false;
    /** Legacy alias for configs from older versions. New UI controls use guiOpacity. */
    @Deprecated public static double guiBackgroundOpacity = 0.55;
    public static double menuBackgroundOpacity = 0.70;
    /** 0 = snappy scrolling, 1 = long, soft glide. */
    public static double scrollSmooth = 0.5;
    public static double loadingSeconds = 3.8;
    public static double hoverExpand = 3.0;
    public static double textScale = 1.0;
    public static int modulesPerRow = 2;
    /** false: module settings open in the drawer on the right; true: they open DOWN from the module (rows below move down). */
    public static boolean settingsDown = false;
    public static String language = "EN";

    public static final int[] normal = {0x121528, 0x2C3466};
    public static final int[] grad = {0x0F1226, 0x1A1F3D, 0x4568DC, 0xB06AB3};

    public static final List<Preset> NORMAL_PRESETS = List.of(
        new Preset("Midnight", 0x121528, 0x2C3466),
        new Preset("Sunset",   0x2A1220, 0xD9533F),
        new Preset("Mint",     0x0E2220, 0x2FBF9A),
        new Preset("Lime",     0x14200F, 0x7BC62D),
        new Preset("Ocean",    0x0B1A2B, 0x1F78D1),
        new Preset("Purple",   0x1B1030, 0x8A4BE0),
        new Preset("Cherry",   0x2A0F18, 0xD6355B),
        new Preset("Graphite", 0x16181D, 0x4A505E),
        new Preset("Gold",     0x241C0C, 0xD9A21B),
        new Preset("Ice",      0x10202B, 0x5FC8E8),
        new Preset("Black",    0x08080A, 0x3A3D4C),
        new Preset("White",    0xF4F5F8, 0xC9CDD9));

    public static final List<Preset> GRADIENT_PRESETS = List.of(
        new Preset("Sunset",   0x2B1330, 0x3B1A1F, 0xFF5E62, 0xFF9966),
        new Preset("Mint",     0x0C2224, 0x0E2B1F, 0x11998E, 0x38EF7D),
        new Preset("Lime",     0x11200F, 0x1B2A0B, 0x56AB2F, 0xA8E063),
        new Preset("Ocean",    0x0A1A30, 0x0B2A3F, 0x2193B0, 0x6DD5ED),
        new Preset("Aurora",   0x0F1330, 0x1A0F33, 0x00C9FF, 0x92FE9D),
        new Preset("Cherry",   0x2A0F18, 0x1D0F2A, 0xEB3349, 0xF45C43),
        new Preset("Haze",     0x1A1033, 0x2B1038, 0x7F00FF, 0xE100FF),
        new Preset("Peach",    0x2A1818, 0x2A2214, 0xFF9A8B, 0xFF6A88),
        new Preset("Midnight", 0x0F1226, 0x1A1F3D, 0x4568DC, 0xB06AB3),
        new Preset("Gold",     0x241A0A, 0x2B1408, 0xF7971E, 0xFFD200));

    static { load(); }
    private Theme() {}

    /** Single entry point for changing the text color: also derives the dimmed secondary text color. */
    public static void setText(int rgb) {
        rgb &= 0xFFFFFF;
        TEXT = 0xFF000000 | rgb;
        TEXT_DIM = 0xFF000000 | mix(rgb, 0x1A1E36, 0.40);
    }

    /** True when the current base color is light: the UI then uses dark text and darker accents. */
    public static boolean light() { return lum(mode == Mode.NORMAL ? normal[0] : grad[0]) > 0.6; }

    /** Applied together with a color preset: light palettes get dark text, dark palettes get light text. */
    public static void syncText() { setText(light() ? 0x14161F : 0xFFFFFF); }

    public static int[] active() { return mode == Mode.NORMAL ? normal : grad; }
    public static List<Preset> presets() { return mode == Mode.NORMAL ? NORMAL_PRESETS : GRADIENT_PRESETS; }

    public static int mix(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static double time() { return (System.nanoTime() / 1_000_000_000.0) * 0.10 + gradientAngle / 360.0; }

    /** Looping, flowing blend a -> b -> a; p = position 0..1 along the gradient axis. */
    private static int flow(int a, int b, double p) {
        double q = (p + time()) % 1.0;
        double tri = 1 - Math.abs(2 * q - 1);
        return mix(a, b, tri * tri * (3 - 2 * tri));
    }

    /** Color/alpha for the main GUI surface. 0 opacity means clear fill, not a black panel. */
    public static int panelAt(double p) {
        int c = mode == Mode.NORMAL ? normal[0] : flow(grad[0], grad[1], p);
        int a = (int) Math.round(255.0 * clamp01(guiOpacity));
        return (a << 24) | c;
    }

    /** HUD surfaces have their own opacity and do not inherit the click-GUI alpha. */
    public static int hudPanelAt(double p) {
        int c = mode == Mode.NORMAL ? normal[0] : flow(grad[0], grad[1], p);
        int a = (int) Math.round(255.0 * clamp01(hudOpacity));
        return (a << 24) | c;
    }

    public static int moduleAt(double p, boolean on, double hover) {
        int c = mode == Mode.NORMAL ? normal[1] : flow(grad[2], grad[3], p);
        if (!on) c = light() ? mix(c, 0xFFFFFF, 0.55) : mix(c, 0x0C0E1A, 0.72);
        if (hover > 0) c = mix(c, 0xFFFFFF, 0.10 * hover);
        // Modules use their own opacity; enabled modules remain slightly more saturated.
        double opacity = clamp01(moduleOpacity) * (on ? 0.94 : 0.76);
        return ((int) Math.round(opacity * 255.0) << 24) | c;
    }

    public static double blurFor(Surface surface) {
        return clamp01(switch (surface) { case GUI -> guiBlurStrength; case MODULE -> moduleBlurStrength; case HUD -> hudBlurStrength; });
    }

    public static double opacityFor(Surface surface) {
        return clamp01(switch (surface) { case GUI -> guiOpacity; case MODULE -> moduleOpacity; case HUD -> hudOpacity; });
    }

    public static double highlightFor(Surface surface) {
        return clamp01(switch (surface) { case GUI -> guiHighlightStrength; case MODULE -> moduleHighlightStrength; case HUD -> hudHighlightStrength; });
    }

    /** Legacy conversion kept for older integrations; do not use it to blur the full game frame. */
    @Deprecated public static int blurRadius() {
        return (int) Math.round(Math.max(0.0, Math.min(1.0, blurStrength)) * 10.0);
    }

    /** Applies click-GUI opacity to a structural surface while preserving its own alpha. */
    public static int withGuiOpacity(int argb, double multiplier) {
        int originalAlpha = (argb >>> 24) & 0xFF;
        int alpha = (int) Math.round(originalAlpha * clamp01(guiOpacity) * clamp01(multiplier));
        return (alpha << 24) | (argb & 0xFFFFFF);
    }

    public static double clamp01(double value) { return Math.max(0.0, Math.min(1.0, value)); }

    public static int accent() {
        int base = mode == Mode.NORMAL ? normal[1] : mix(grad[2], grad[3], 0.5);
        return 0xFF000000 | (light() ? mix(base, 0x000000, 0.35) : base);
    }

    private static double lum(int c) {
        return (0.299 * ((c >> 16) & 255) + 0.587 * ((c >> 8) & 255) + 0.114 * (c & 255)) / 255.0;
    }

    /** Dark text on very bright module colors (lime, gold...) so it stays readable. */
    public static int moduleText(boolean on) {
        if (!on) return TEXT_DIM;
        int c = mode == Mode.NORMAL ? normal[1] : mix(grad[2], grad[3], 0.5);
        return lum(c) > 0.62 ? 0xFF10121C : TEXT;
    }

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("hvhclient-theme.properties"); }

    public static void save() {
        try (OutputStream o = Files.newOutputStream(file())) {
            Properties p = new Properties();
            p.setProperty("mode", mode.name());
            p.setProperty("blurStrength", Double.toString(blurStrength)); // legacy key
            p.setProperty("guiBlurStrength", Double.toString(guiBlurStrength));
            p.setProperty("moduleBlurStrength", Double.toString(moduleBlurStrength));
            p.setProperty("hudBlurStrength", Double.toString(hudBlurStrength));
            p.setProperty("guiOpacity", Double.toString(guiOpacity));
            p.setProperty("moduleOpacity", Double.toString(moduleOpacity));
            p.setProperty("hudOpacity", Double.toString(hudOpacity));
            p.setProperty("guiHighlightStrength", Double.toString(guiHighlightStrength));
            p.setProperty("moduleHighlightStrength", Double.toString(moduleHighlightStrength));
            p.setProperty("hudHighlightStrength", Double.toString(hudHighlightStrength));
            p.setProperty("gradientAngle", Double.toString(gradientAngle));
            p.setProperty("glowColor", Integer.toHexString(glowColor));
            p.setProperty("glowStrength", Double.toString(glowStrength));
            p.setProperty("guiScaleX", Double.toString(guiScaleX)); p.setProperty("guiScaleY", Double.toString(guiScaleY));
            p.setProperty("cornerRadius", Double.toString(cornerRadius));
            p.setProperty("outlineColor", Integer.toHexString(outlineColor)); p.setProperty("outlineWidth", Double.toString(outlineWidth));
            p.setProperty("outlineEnabled", Boolean.toString(outlineEnabled)); p.setProperty("glowEnabled", Boolean.toString(glowEnabled));
            p.setProperty("backgroundEnabled", Boolean.toString(backgroundEnabled)); p.setProperty("menuBackgroundEnabled", Boolean.toString(menuBackgroundEnabled));
            p.setProperty("guiBackgroundOpacity", Double.toString(guiOpacity)); // legacy alias
            p.setProperty("menuBackgroundOpacity", Double.toString(menuBackgroundOpacity)); p.setProperty("scrollSmooth", Double.toString(scrollSmooth));
            p.setProperty("textColor", Integer.toHexString(TEXT & 0xFFFFFF)); p.setProperty("loadingSeconds", Double.toString(loadingSeconds));
            p.setProperty("hoverExpand", Double.toString(hoverExpand)); p.setProperty("textScale", Double.toString(textScale)); p.setProperty("modulesPerRow", Integer.toString(modulesPerRow)); p.setProperty("language", language); p.setProperty("settingsDown", Boolean.toString(settingsDown));
            p.setProperty("outlineTopLeft", Boolean.toString(outlineTopLeft)); p.setProperty("outlineTopRight", Boolean.toString(outlineTopRight));
            p.setProperty("outlineBottomLeft", Boolean.toString(outlineBottomLeft)); p.setProperty("outlineBottomRight", Boolean.toString(outlineBottomRight));
            for (int i = 0; i < normal.length; i++) p.setProperty("n" + i, Integer.toHexString(normal[i]));
            for (int i = 0; i < grad.length; i++) p.setProperty("g" + i, Integer.toHexString(grad[i]));
            p.store(o, "HvH Client theme");
        } catch (Exception ignored) {}
    }

    private static double number(Properties p, String k, double d, double min, double max) { try { return Math.max(min, Math.min(max, Double.parseDouble(p.getProperty(k, Double.toString(d))))); } catch (Exception e) { return d; } }
    private static int integer(Properties p, String k, int d) { try { return Integer.parseInt(p.getProperty(k, Integer.toHexString(d)),16) & 0xFFFFFF; } catch (Exception e) { return d; } }

    private static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(file())) { p.load(in); }
            mode = Mode.valueOf(p.getProperty("mode", "NORMAL"));
            blurStrength = number(p,"blurStrength",blurStrength,0,1); // ignored by local surfaces, retained for downgrade compatibility
            gradientAngle = number(p,"gradientAngle",gradientAngle,0,360);
            glowColor = integer(p,"glowColor",glowColor); glowStrength = number(p,"glowStrength",glowStrength,0,1);
            guiBlurStrength = number(p,"guiBlurStrength",blurStrength,0,1);
            moduleBlurStrength = number(p,"moduleBlurStrength",guiBlurStrength,0,1);
            hudBlurStrength = number(p,"hudBlurStrength",guiBlurStrength,0,1);
            guiOpacity = number(p,"guiOpacity",number(p,"guiBackgroundOpacity",guiOpacity,0,1),0,1);
            moduleOpacity = number(p,"moduleOpacity",guiOpacity,0,1);
            hudOpacity = number(p,"hudOpacity",guiOpacity,0,1);
            guiHighlightStrength = number(p,"guiHighlightStrength",glowStrength,0,1);
            moduleHighlightStrength = number(p,"moduleHighlightStrength",Math.max(glowStrength,0.65),0,1);
            hudHighlightStrength = number(p,"hudHighlightStrength",guiHighlightStrength,0,1);
            guiBackgroundOpacity = guiOpacity;
            guiScaleX = number(p,"guiScaleX",guiScaleX,0.6,1.5); guiScaleY = number(p,"guiScaleY",guiScaleY,0.6,1.5);
            cornerRadius = number(p,"cornerRadius",cornerRadius,0,20); outlineColor = integer(p,"outlineColor",outlineColor);
            outlineWidth = number(p,"outlineWidth",outlineWidth,0,5); outlineEnabled = Boolean.parseBoolean(p.getProperty("outlineEnabled",Boolean.toString(outlineEnabled)));
            glowEnabled = Boolean.parseBoolean(p.getProperty("glowEnabled",Boolean.toString(glowEnabled)));
            backgroundEnabled = Boolean.parseBoolean(p.getProperty("backgroundEnabled",Boolean.toString(backgroundEnabled)));
            menuBackgroundEnabled = Boolean.parseBoolean(p.getProperty("menuBackgroundEnabled",Boolean.toString(menuBackgroundEnabled)));
            menuBackgroundOpacity = number(p,"menuBackgroundOpacity",menuBackgroundOpacity,0,1); scrollSmooth = number(p,"scrollSmooth",scrollSmooth,0,1);
            setText(integer(p,"textColor",TEXT));
            loadingSeconds = number(p,"loadingSeconds",loadingSeconds,2,10);
            hoverExpand = number(p,"hoverExpand",hoverExpand,0,12); textScale = number(p,"textScale",textScale,0.65,1.6);
            try { modulesPerRow = Math.max(1, Math.min(4, Integer.parseInt(p.getProperty("modulesPerRow", Integer.toString(modulesPerRow))))); } catch (Exception ignored) {}
            language = p.getProperty("language", "EN").equalsIgnoreCase("RU") ? "RU" : "EN";
            settingsDown = Boolean.parseBoolean(p.getProperty("settingsDown", "false"));
            outlineTopLeft = Boolean.parseBoolean(p.getProperty("outlineTopLeft","true")); outlineTopRight = Boolean.parseBoolean(p.getProperty("outlineTopRight","true"));
            outlineBottomLeft = Boolean.parseBoolean(p.getProperty("outlineBottomLeft","true")); outlineBottomRight = Boolean.parseBoolean(p.getProperty("outlineBottomRight","true"));
            for (int i = 0; i < normal.length; i++) normal[i] = Integer.parseInt(p.getProperty("n" + i), 16) & 0xFFFFFF;
            for (int i = 0; i < grad.length; i++) grad[i] = Integer.parseInt(p.getProperty("g" + i), 16) & 0xFFFFFF;
        } catch (Exception ignored) {}
    }
}
