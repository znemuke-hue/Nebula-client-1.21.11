package dev.hvh.client.gui;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Dynamic texture atlas with shelf packing. One cached bitmap = one GUI element when drawn. */
public final class Atlas {
    public record Region(int x, int y, int w, int h) {}

    public final Map<Object, Region> map = new HashMap<>();
    private final String name;
    private final int W, H;
    private DynamicTexture tex;
    private Identifier id;
    private int penX, penY, rowH;
    private boolean dirty;

    public Atlas(String name, int w, int h) { this.name = name; this.W = w; this.H = h; }

    private void ensure() {
        if (tex != null) return;
        NativeImage img = new NativeImage(NativeImage.Format.RGBA, W, H, true);
        final String n = name;
        tex = new DynamicTexture(() -> "hvhclient_" + n, img);
        id = Identifier.fromNamespaceAndPath("hvhclient", "atlas_" + name);
        Minecraft.getInstance().getTextureManager().register(id, tex);
    }

    public Region alloc(int w, int h) {
        ensure();
        if (w > W || h > H) throw new IllegalArgumentException("Atlas " + name + ": " + w + "x" + h + " too big");
        if (penX + w > W) { penX = 0; penY += rowH; rowH = 0; }
        if (penY + h > H) { map.clear(); penX = penY = rowH = 0; } // full: start over
        Region r = new Region(penX, penY, w, h);
        penX += w; rowH = Math.max(rowH, h);
        return r;
    }

    /** argb -> texture pixel. */
    public void set(int x, int y, int argb) {
        int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        tex.getPixels().setPixelABGR(x, y, (a << 24) | (b << 16) | (g << 8) | r);
        dirty = true;
    }

    public void blit(GuiGraphics g, Region r, int x, int y, int color) {
        ensure();
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, (float) r.x, (float) r.y, r.w, r.h, r.w, r.h, W, H, color);
    }

    /** Draw a whole region stretched to w x h. */
    public void blitStretch(GuiGraphics g, Region r, int x, int y, int w, int h, int color) {
        ensure();
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, (float) r.x, (float) r.y, w, h, r.w, r.h, W, H, color);
    }

    /** Draw a sub-rectangle (sx, sy, sw, sh) of a region. */
    public void blitSub(GuiGraphics g, Region r, int sx, int sy, int sw, int sh, int x, int y, int color) {
        ensure();
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, (float) (r.x + sx), (float) (r.y + sy), sw, sh, sw, sh, W, H, color);
    }

    /** Draw sub-rectangle (sx, sy, sw, sh) of a region stretched to dw x dh. */
    public void blitSubStretch(GuiGraphics g, Region r, int sx, int sy, int sw, int sh, int x, int y, int dw, int dh, int color) {
        if (dw <= 0 || dh <= 0 || sw <= 0 || sh <= 0) return;
        ensure();
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, (float) (r.x + sx), (float) (r.y + sy), dw, dh, sw, sh, W, H, color);
    }

    public void flush() {
        if (tex != null && dirty) { tex.upload(); dirty = false; }
    }
}
