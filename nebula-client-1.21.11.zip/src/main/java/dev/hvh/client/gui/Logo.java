package dev.hvh.client.gui;

import net.minecraft.client.gui.GuiGraphics;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;

/**
 * Nebula logo. The source PNG is 1024x1024; for every requested size it is box-filtered (area average,
 * premultiplied alpha) once into an Atlas region, so it is always sharp and costs ONE GUI element.
 */
public final class Logo {
    private static final Atlas ATLAS = new Atlas("logo", 1024, 1024);
    private static int[] src;
    private static int sw, sh;

    private Logo() {}

    private static void load() {
        try (InputStream in = Logo.class.getResourceAsStream("/assets/hvhclient/textures/logo.png")) {
            BufferedImage img = ImageIO.read(in);
            sw = img.getWidth(); sh = img.getHeight();
            src = new int[sw * sh];
            img.getRGB(0, 0, sw, sh, src, 0, sw);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load Nebula logo", e);
        }
    }

    private static Atlas.Region bake(int size) {
        if (src == null) load();
        Atlas.Region r = ATLAS.alloc(size, size);
        ATLAS.map.put(size, r);
        double scale = sw / (double) size, area = scale * scale;
        for (int dy = 0; dy < size; dy++) {
            double y0 = dy * scale, y1 = y0 + scale;
            int iy0 = (int) Math.floor(y0), iy1 = Math.min(sh, (int) Math.ceil(y1));
            for (int dx = 0; dx < size; dx++) {
                double x0 = dx * scale, x1 = x0 + scale;
                int ix0 = (int) Math.floor(x0), ix1 = Math.min(sw, (int) Math.ceil(x1));
                double sa = 0, sr = 0, sg = 0, sb = 0;
                for (int iy = iy0; iy < iy1; iy++) {
                    double wy = Math.min(y1, iy + 1) - Math.max(y0, iy);
                    for (int ix = ix0; ix < ix1; ix++) {
                        double w = wy * (Math.min(x1, ix + 1) - Math.max(x0, ix));
                        int p = src[iy * sw + ix];
                        double a = (p >>> 24) / 255.0 * w;
                        sa += a; sr += ((p >> 16) & 255) * a; sg += ((p >> 8) & 255) * a; sb += (p & 255) * a;
                    }
                }
                int argb = 0;
                if (sa > 1e-9) {
                    int a = (int) Math.round(Math.min(1, sa / area) * 255);
                    argb = (a << 24) | ((int) Math.round(sr / sa) << 16) | ((int) Math.round(sg / sa) << 8) | (int) Math.round(sb / sa);
                }
                ATLAS.set(r.x() + dx, r.y() + dy, argb);
            }
        }
        return r;
    }

    /** Draws the logo as a size x size square at real-pixel coordinates. color = tint (0xFFFFFFFF = as is). */
    public static void draw(GuiGraphics g, int x, int y, int size, int color) {
        size = Math.max(8, Math.min(1000, size));
        Atlas.Region r = ATLAS.map.get(size);
        if (r == null) r = bake(size);
        ATLAS.blit(g, r, x, y, color);
    }

    public static void flush() { ATLAS.flush(); }
}
