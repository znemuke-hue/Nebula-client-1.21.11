package dev.hvh.client.gui;

import dev.hvh.client.module.Category;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

/**
 * Sidebar category icons. Outline glyphs are described as polylines on a 24-unit grid (Lucide-style, 2-unit stroke),
 * rasterized once per (category, size) into an Atlas as a white anti-aliased mask, and tinted at draw time.
 */
public final class CategoryIcons {
    private static final Atlas ATLAS = new Atlas("category_icons", 512, 512);
    private static final float STROKE = 2f;
    private static final float GRID = 24f;

    private CategoryIcons() {}

    public static void draw(GuiGraphics g, Category c, int x, int y, int size, int color) {
        String key = c.name() + size;
        Atlas.Region r = ATLAS.map.get(key);
        if (r == null) r = bake(c, size, key);
        ATLAS.blit(g, r, x, y, color);
    }

    public static void flush() { ATLAS.flush(); }

    private static Atlas.Region bake(Category c, int size, String key) {
        Atlas.Region r = ATLAS.alloc(size, size);
        ATLAS.map.put(key, r);

        float k = size / GRID;
        List<float[]> segs = new ArrayList<>();
        for (float[] poly : polylines(c)) {
            for (int i = 0; i + 3 < poly.length; i += 2) {
                segs.add(new float[]{poly[i] * k, poly[i + 1] * k, poly[i + 2] * k, poly[i + 3] * k});
            }
        }
        float half = STROKE * k / 2f;

        for (int py = 0; py < size; py++) {
            for (int px = 0; px < size; px++) {
                float cx = px + 0.5f, cy = py + 0.5f;
                float best = Float.MAX_VALUE;
                for (float[] s : segs) best = Math.min(best, distSeg(cx, cy, s[0], s[1], s[2], s[3]));
                float a = Math.max(0f, Math.min(1f, half - best + 0.5f));
                ATLAS.set(r.x() + px, r.y() + py, ((int) Math.round(a * 255f) << 24) | 0x00FFFFFF);
            }
        }
        return r;
    }

    private static float distSeg(float px, float py, float ax, float ay, float bx, float by) {
        float dx = bx - ax, dy = by - ay;
        float t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy + 1e-6f);
        t = Math.max(0f, Math.min(1f, t));
        float ex = ax + t * dx - px, ey = ay + t * dy - py;
        return (float) Math.sqrt(ex * ex + ey * ey);
    }

    private static List<float[]> polylines(Category c) {
        List<float[]> out = new ArrayList<>();
        switch (c) {
            case ALL -> {
                rect(out, 3, 3, 7, 7);
                rect(out, 14, 3, 7, 7);
                rect(out, 3, 14, 7, 7);
                rect(out, 14, 14, 7, 7);
            }
            case COMBAT -> {
                line(out, 4, 4, 16, 16);
                line(out, 20, 4, 8, 16);
                line(out, 17.8f, 14.2f, 14.2f, 17.8f);
                line(out, 16, 16, 19, 19);
                line(out, 6.2f, 14.2f, 9.8f, 17.8f);
                line(out, 8, 16, 5, 19);
            }
            case MOVEMENT -> {
                ellipse(out, 7, 13, 3.2f, 4.5f);
                ellipse(out, 17, 16, 3.2f, 4.5f);
                ellipse(out, 4.6f, 6.2f, 1.1f, 1.1f);
                ellipse(out, 7f, 5f, 1.1f, 1.1f);
                ellipse(out, 9.4f, 6.2f, 1.1f, 1.1f);
                ellipse(out, 14.6f, 8.2f, 1.1f, 1.1f);
                ellipse(out, 17f, 7f, 1.1f, 1.1f);
                ellipse(out, 19.4f, 8.2f, 1.1f, 1.1f);
            }
            case VISUALS -> {
                line(out, 4, 20, 14, 10);
                line(out, 17, 3, 17, 9);
                line(out, 14, 6, 20, 6);
                line(out, 20, 13, 20, 17);
                line(out, 18, 15, 22, 15);
            }
            case WORLD -> {
                ellipse(out, 12, 12, 9, 9);
                ellipse(out, 12, 12, 4, 9);
                line(out, 3, 12, 21, 12);
            }
            case PLAYER -> {
                ellipse(out, 12, 7.5f, 4, 4);
                arc(out, 12, 21, 8, 8, 180, 360, 16);
            }
            case MISC -> {
                rect(out, 3, 14, 7, 7);
                ellipse(out, 17.5f, 17.5f, 3.5f, 3.5f);
                out.add(new float[]{12, 3, 16.5f, 10, 7.5f, 10, 12, 3});
            }
            default -> { }
        }
        return out;
    }

    private static void line(List<float[]> out, float x1, float y1, float x2, float y2) {
        out.add(new float[]{x1, y1, x2, y2});
    }

    private static void rect(List<float[]> out, float x, float y, float w, float h) {
        out.add(new float[]{x, y, x + w, y, x + w, y + h, x, y + h, x, y});
    }

    private static void ellipse(List<float[]> out, float cx, float cy, float rx, float ry) {
        arc(out, cx, cy, rx, ry, 0, 360, 24);
    }

    private static void arc(List<float[]> out, float cx, float cy, float rx, float ry, float a0, float a1, int steps) {
        float[] p = new float[(steps + 1) * 2];
        for (int i = 0; i <= steps; i++) {
            double a = Math.toRadians(a0 + (a1 - a0) * i / (double) steps);
            p[i * 2] = (float) (cx + rx * Math.cos(a));
            p[i * 2 + 1] = (float) (cy + ry * Math.sin(a));
        }
        out.add(p);
    }
}
