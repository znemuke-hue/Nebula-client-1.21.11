package dev.hvh.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * In-game selector for images placed in config/nebula/backgrounds.
 * Drawn in real screen pixels like the rest of the Nebula UI (the old version used GUI-scaled coordinates with
 * pixel-sized text and never flushed the shape atlas, so on a phone it was tiny/blank).
 */
public final class BackgroundFilePicker extends Screen {
    private final boolean menu;
    private final Screen previous;
    private final List<Path> files = new ArrayList<>();
    private int scroll;
    private String message = "";
    private float gs = 1f, S = 1f;
    private int x, y, w, h, pad, row, top, visible;

    public BackgroundFilePicker(boolean menu) {
        super(Component.literal("Choose background image"));
        this.menu = menu;
        this.previous = Minecraft.getInstance().screen;
        scan();
    }

    private void scan() {
        files.clear();
        CustomBackground.ensureFolder();
        try (Stream<Path> stream = Files.list(CustomBackground.backgroundsDirectory())) {
            stream.filter(Files::isRegularFile)
                .filter(p -> { String n = p.getFileName().toString().toLowerCase(); return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg"); })
                .sorted()
                .limit(300)
                .forEach(files::add);
        } catch (Exception ignored) {}
        message = files.isEmpty() ? "No images yet - copy PNG/JPG files into the folder above" : "";
    }

    private int u(double v) { return (int) Math.round(v * S); }

    private void calc() {
        gs = (float) Math.max(1, minecraft.getWindow().getGuiScale());
        S = Math.max(.75f, Math.min(3f, minecraft.getWindow().getHeight() / 720f));
        Draw.SCALE = S;
        int sw = Math.round(width * gs), sh = Math.round(height * gs);
        w = Math.min(u(560), sw - u(24)); h = Math.min(u(520), sh - u(24));
        x = (sw - w) / 2; y = (sh - h) / 2; pad = u(14); row = u(32);
        top = y + u(98);
        visible = Math.max(1, (h - u(98) - u(56)) / row);
        int total = files.size() + 2;
        scroll = Math.max(0, Math.min(Math.max(0, total - visible), scroll));
    }

    private int listW() { return w - pad * 2 - u(40); }

    private String fitLeft(String s, float t, int maxW) {
        if (Draw.width(s, t) <= maxW) return s;
        while (s.length() > 4 && Draw.width("..." + s, t) > maxW) s = s.substring(1);
        return "..." + s;
    }

    private String fit(String s, float t, int maxW) {
        if (Draw.width(s, t) <= maxW) return s;
        while (s.length() > 2 && Draw.width(s + "...", t) > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int gmx, int gmy, float delta) {
        calc();
        double mx = gmx * gs, my = gmy * gs;
        g.pose().pushMatrix();
        g.pose().scale(1f / gs, 1f / gs);
        Draw.panelBg(g, x, y, w, h, u(Theme.cornerRadius));
        Draw.textBold(g, menu ? "Main menu background" : "Click GUI background", x + pad, y + u(14), Theme.TEXT, S * 1.15f);
        Draw.text(g, "Put PNG/JPG files in this folder:", x + pad, y + u(40), Theme.TEXT_DIM, S * .72f);
        Draw.text(g, fitLeft(CustomBackground.backgroundsDirectory().toAbsolutePath().toString(), S * .68f, w - pad * 2), x + pad, y + u(55), Theme.accent(), S * .68f);
        String err = CustomBackground.error(menu);
        String msg = !message.isEmpty() ? message : (!err.isEmpty() ? "Last error: " + err : "Tap an image to use it");
        Draw.text(g, fit(msg, S * .72f, w - pad * 2), x + pad, y + u(74), (!message.isEmpty() && !files.isEmpty()) || !err.isEmpty() ? 0xFFFF7A7A : Theme.TEXT_DIM, S * .72f);

        int total = files.size() + 2, lw = listW();
        Draw.scissor(g, x + pad - u(2), top, lw + u(4), visible * row);
        for (int i = scroll; i < Math.min(total, scroll + visible); i++) {
            int yy = top + (i - scroll) * row;
            boolean hov = Draw.hover(mx, my, x + pad, yy, lw, row - u(4));
            Draw.round(g, x + pad, yy, lw, row - u(4), u(6), hov ? Theme.DARK_HOVER : Theme.DARK);
            String label = i == 0 ? "None (remove background)" : i == 1
                ? "Дефолт (Nebula " + (menu ? "blue" : "purple") + ")"
                : files.get(i - 2).getFileName().toString();
            Draw.text(g, fit(label, S * .85f, lw - u(20)), x + pad + u(10), yy + (row - u(4) - Draw.height(S * .85f)) / 2, i == 0 ? Theme.TEXT_DIM : Theme.TEXT, S * .85f);
        }
        Draw.unscissor(g);

        // scroll buttons (touch friendly)
        int bx = x + w - pad - u(32), bh = u(32);
        scrollButton(g, bx, top, u(32), bh, "^", mx, my);
        scrollButton(g, bx, top + bh + u(6), u(32), bh, "v", mx, my);
        Draw.text(g, scroll + 1 + "-" + Math.min(total, scroll + visible) + " / " + total, bx - u(2), top + bh * 2 + u(14), Theme.TEXT_DIM, S * .6f);

        int by = y + h - u(44), gap = u(6), bw = (w - pad * 2 - gap * 2) / 3;
        bottomButton(g, x + pad, by, bw, u(32), "Файл...", mx, my);
        bottomButton(g, x + pad + bw + gap, by, bw, u(32), "Обновить", mx, my);
        bottomButton(g, x + pad + (bw + gap) * 2, by, bw, u(32), "Назад", mx, my);
        Draw.flush();
        g.pose().popMatrix();
    }

    private void scrollButton(GuiGraphics g, int bx, int by, int bw, int bh, String label, double mx, double my) {
        Draw.round(g, bx, by, bw, bh, u(6), Draw.hover(mx, my, bx, by, bw, bh) ? Theme.DARK_HOVER : Theme.DARK);
        Draw.centered(g, label, bx + bw / 2f, by + (bh - Draw.height(S)) / 2, Theme.TEXT, S);
    }

    private void bottomButton(GuiGraphics g, int bx, int by, int bw, int bh, String label, double mx, double my) {
        Draw.round(g, bx, by, bw, bh, u(6), Draw.hover(mx, my, bx, by, bw, bh) ? Theme.DARK_HOVER : Theme.DARK);
        Draw.centered(g, label, bx + bw / 2f, by + (bh - Draw.height(S * .82f)) / 2, Theme.TEXT, S * .82f);
    }

    private void refreshFiles() {
        scan();
        message = "Найдено изображений: " + files.size();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, files.size() + 2 - visible)));
    }

    private void chooseFile() {
        NativeFilePicker.choose(CustomBackground.backgroundsDirectory(), "Choose background image", new String[]{".png", ".jpg", ".jpeg"}, file -> {
            String err = CustomBackground.copyChosen(file, menu);
            if (err == null) close(); else message = "Не удалось: " + err;
        }, () -> {
            refreshFiles();
            message = "Файл-диалог недоступен: скопируйте PNG/JPG сюда и нажмите Обновить";
        });
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        calc();
        double mx = e.x() * gs, my = e.y() * gs;
        if (e.button() != 0) return true;
        int total = files.size() + 2, lw = listW();
        int bx = x + w - pad - u(32), bh = u(32);
        if (Draw.hover(mx, my, bx, top, u(32), bh)) { scroll = Math.max(0, scroll - 3); return true; }
        if (Draw.hover(mx, my, bx, top + bh + u(6), u(32), bh)) { scroll = Math.min(Math.max(0, total - visible), scroll + 3); return true; }
        int by = y + h - u(44), gap = u(6), bw = (w - pad * 2 - gap * 2) / 3;
        if (Draw.hover(mx, my, x + pad, by, bw, u(32))) { chooseFile(); return true; }
        if (Draw.hover(mx, my, x + pad + bw + gap, by, bw, u(32))) { refreshFiles(); return true; }
        if (Draw.hover(mx, my, x + pad + (bw + gap) * 2, by, bw, u(32))) { close(); return true; }
        if (Draw.hover(mx, my, x + pad, top, lw, visible * row)) {
            int i = scroll + (int) ((my - top) / row);
            if (i >= 0 && i < total) {
                if (i == 0) { CustomBackground.clear(menu); close(); return true; }
                Path chosen = i == 1
                    ? CustomBackground.backgroundsDirectory().resolve(menu ? "default-nebula-blue.png" : "default-nebula-purple.png")
                    : files.get(i - 2);
                String err = CustomBackground.copyChosen(chosen, menu);
                if (err == null) close(); else message = "Failed: " + err;
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        int total = files.size() + 2;
        scroll = Math.max(0, Math.min(Math.max(0, total - visible), scroll - (int) Math.signum(sy) * 2));
        return true;
    }

    private void close() { Minecraft.getInstance().setScreen(previous); }

    @Override public void onClose() { close(); }
}
