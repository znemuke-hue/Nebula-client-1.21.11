package dev.hvh.client.gui;

import dev.hvh.client.gui.Atlas.Region;
import net.minecraft.client.gui.GuiGraphics;

import java.util.HashMap;
import java.util.Map;

/**
 * Cached anti-aliased shapes. Every shape is baked once into a texture and drawn with ONE blit
 * (tinted by color), instead of hundreds of fill() calls.
 */
public final class Shapes {
    private record K(String t, int a, int b, int c, int d) {}

    private static final Atlas MASKS = new Atlas("masks", 1024, 1024);   // static shapes
    private static final Atlas DYN = new Atlas("dyn", 1024, 512);        // gradient modules + color picker
    private static final Atlas FX = new Atlas("fx", 1024, 1024);       // glow 9-slices, outline lenses and arcs
    private static final Map<K, float[]> ALPHA = new HashMap<>();
    private static final Map<K, Long> BAKED_AT = new HashMap<>();
    private static final Map<K, Integer> PICK_HUE = new HashMap<>();

    private Shapes() {}

    private static double sdfAlpha(double cx, double cy, double w, double h, double r) {
        double qx = Math.abs(cx - w / 2) - (w / 2 - r), qy = Math.abs(cy - h / 2) - (h / 2 - r);
        double d = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
        return Math.max(0, Math.min(1, 0.5 - d));
    }

    private static float[] alpha(K key, int w, int h, int r) {
        float[] a = ALPHA.get(key);
        if (a != null) return a;
        a = new float[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) a[y * w + x] = (float) sdfAlpha(x + 0.5, y + 0.5, w, h, r);
        ALPHA.put(key, a);
        return a;
    }

    /** Rounded rect, 1 element. */
    public static void mask(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        K key = new K("mask", w, h, r, 0);
        Region reg = MASKS.map.get(key);
        if (reg == null) {
            reg = MASKS.alloc(w, h);
            MASKS.map.put(key, reg);
            float[] a = alpha(key, w, h, r);
            for (int iy = 0; iy < h; iy++)
                for (int ix = 0; ix < w; ix++)
                    MASKS.set(reg.x() + ix, reg.y() + iy, ((int) Math.round(a[iy * w + ix] * 255) << 24) | 0xFFFFFF);
        }
        MASKS.blit(g, reg, x, y, color);
    }

    /** One r x r rounded corner. idx: 0 = top-left, 1 = top-right, 2 = bottom-left, 3 = bottom-right. */
    public static void corner(GuiGraphics g, int idx, int x, int y, int r, int color) {
        K key = new K("corner", r, idx, 0, 0);
        Region reg = MASKS.map.get(key);
        if (reg == null) {
            reg = MASKS.alloc(r, r);
            MASKS.map.put(key, reg);
            for (int iy = 0; iy < r; iy++)
                for (int ix = 0; ix < r; ix++) {
                    int ox = (idx & 1) != 0 ? r + ix : ix, oy = (idx & 2) != 0 ? r + iy : iy;
                    double a = sdfAlpha(ox + 0.5, oy + 0.5, 2 * r, 2 * r, r);
                    MASKS.set(reg.x() + ix, reg.y() + iy, ((int) Math.round(a * 255) << 24) | 0xFFFFFF);
                }
        }
        MASKS.blit(g, reg, x, y, color);
    }

    /** Rounded rect with the animated horizontal module gradient baked into a texture (rebaked ~40x/s). */
    public static void gradientMask(GuiGraphics g, int x, int y, int w, int h, int r, boolean on) {
        if (w <= 0 || h <= 0) return;
        K key = new K("gm", w, h, r, on ? 1 : 0);
        Region reg = DYN.map.get(key);
        long now = System.nanoTime();
        Long last = BAKED_AT.get(key);
        if (reg == null || last == null || now - last > 25_000_000L) {
            if (reg == null) { reg = DYN.alloc(w, h); DYN.map.put(key, reg); }
            float[] a = alpha(new K("mask", w, h, r, 0), w, h, r);
            int[] ramp = new int[w];
            for (int ix = 0; ix < w; ix++) ramp[ix] = Theme.moduleAt((ix + 0.5) / w, on, 0) & 0xFFFFFF;
            for (int iy = 0; iy < h; iy++)
                for (int ix = 0; ix < w; ix++)
                    DYN.set(reg.x() + ix, reg.y() + iy, ((int) Math.round(a[iy * w + ix] * 255 * Math.max(0.0, Math.min(1.0, Theme.moduleOpacity))) << 24) | ramp[ix]);
            BAKED_AT.put(key, now);
        }
        DYN.blit(g, reg, x, y, 0xFFFFFFFF);
    }

    /** Saturation/value square for a hue (rebaked only when the hue changes). */
    public static void picker(GuiGraphics g, int x, int y, int w, int h, int r, float hue) {
        K key = new K("pick", w, h, r, 0);
        Region reg = DYN.map.get(key);
        int hq = Math.round(hue * 360);
        Integer last = PICK_HUE.get(key);
        if (reg == null || last == null || last != hq) {
            if (reg == null) { reg = DYN.alloc(w, h); DYN.map.put(key, reg); }
            float[] a = alpha(new K("mask", w, h, r, 0), w, h, r);
            for (int iy = 0; iy < h; iy++) {
                float v = 1f - (iy + 0.5f) / h;
                for (int ix = 0; ix < w; ix++) {
                    int rgb = ThemeEditor.fromHsv(hq / 360f, (ix + 0.5f) / w, v);
                    DYN.set(reg.x() + ix, reg.y() + iy, ((int) Math.round(a[iy * w + ix] * 255) << 24) | rgb);
                }
            }
            PICK_HUE.put(key, hq);
        }
        DYN.blit(g, reg, x, y, 0xFFFFFFFF);
    }

    /** Vertical rainbow bar with rounded ends. */
    public static void hueBar(GuiGraphics g, int x, int y, int w, int h) {
        K key = new K("hue", w, h, 0, 0);
        Region reg = MASKS.map.get(key);
        if (reg == null) {
            reg = MASKS.alloc(w, h);
            MASKS.map.put(key, reg);
            for (int iy = 0; iy < h; iy++) {
                int rgb = ThemeEditor.fromHsv((iy + 0.5f) / h, 1f, 1f);
                for (int ix = 0; ix < w; ix++) {
                    double a = sdfAlpha(ix + 0.5, iy + 0.5, w, h, w / 2.0);
                    MASKS.set(reg.x() + ix, reg.y() + iy, ((int) Math.round(a * 255) << 24) | rgb);
                }
            }
        }
        MASKS.blit(g, reg, x, y, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ glow (9-slice, outside only)

    private static double signedDist(double px, double py, double w, double h, double r) {
        double qx = Math.abs(px - w / 2) - (w / 2 - r), qy = Math.abs(py - h / 2) - (h / 2 - r);
        return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
    }

    /**
     * Soft halo around a rounded rectangle, drawn OUTSIDE the rectangle only. The falloff is baked once per
     * (radius, spread) into a small 9-slice texture and then drawn with 8 blits (4 corners + 4 stretched edges),
     * instead of one fill() per pixel row per layer like before. Color alpha = glow intensity.
     */
    public static void glow(GuiGraphics g, int x, int y, int w, int h, int r, int spread, int color) {
        if (w <= 0 || h <= 0 || spread < 1 || (color >>> 24) == 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        final int S = spread, C = r + S, N = 2 * C + 1;
        K key = new K("glow", r, S, 0, 0);
        Region reg = FX.map.get(key);
        if (reg == null) {
            reg = FX.alloc(N, N);
            FX.map.put(key, reg);
            final double inner = 2 * r + 1;
            for (int iy = 0; iy < N; iy++)
                for (int ix = 0; ix < N; ix++) {
                    double d = signedDist(ix + 0.5 - S, iy + 0.5 - S, inner, inner, r);
                    double t = d <= 0 ? 0 : 1 - d / S;
                    double a = t <= 0 ? 0 : t * t;
                    FX.set(reg.x() + ix, reg.y() + iy, ((int) Math.round(a * 255) << 24) | 0xFFFFFF);
                }
        }
        FX.blitSub(g, reg, 0, 0, C, C, x - S, y - S, color);
        FX.blitSub(g, reg, C + 1, 0, C, C, x + w - r, y - S, color);
        FX.blitSub(g, reg, 0, C + 1, C, C, x - S, y + h - r, color);
        FX.blitSub(g, reg, C + 1, C + 1, C, C, x + w - r, y + h - r, color);
        int lw = w - 2 * r, lh = h - 2 * r;
        FX.blitSubStretch(g, reg, C, 0, 1, S, x + r, y - S, lw, S, color);
        FX.blitSubStretch(g, reg, C, C + r + 1, 1, S, x + r, y + h, lw, S, color);
        FX.blitSubStretch(g, reg, 0, C, S, 1, x - S, y + r, S, lh, color);
        FX.blitSubStretch(g, reg, C + r + 1, C, S, 1, x + w, y + r, S, lh, color);
    }

    // ------------------------------------------------------------------ outline: thread -> thickness -> thread

    private static final int LENS_LEN = 384;
    private static final double HAIR = 1.0;

    private static int lensHalf(int thickQ) { return (int) Math.ceil(thickQ / 4.0 / 2.0) + 1; }

    /** One straight side: a needle-shaped lens (hairline at both ends, full thickness in the middle). */
    private static Region lens(int thickQ, boolean vertical) {
        K key = new K("lens", thickQ, vertical ? 1 : 0, 0, 0);
        Region reg = FX.map.get(key);
        if (reg != null) return reg;
        final double maxT = thickQ / 4.0;
        final int m = lensHalf(thickQ), H = 2 * m + 1;
        reg = vertical ? FX.alloc(H, LENS_LEN) : FX.alloc(LENS_LEN, H);
        FX.map.put(key, reg);
        for (int i = 0; i < LENS_LEN; i++) {
            double u = (i + 0.5) / LENS_LEN;
            double f = 1 - Math.pow(Math.abs(2 * u - 1), 3);
            double ht = Math.max(HAIR, maxT * f) / 2;
            for (int j = 0; j < H; j++) {
                double cov = Math.max(0, Math.min(1, ht - Math.abs(j - m) + 0.5));
                int argb = ((int) Math.round(cov * 255) << 24) | 0xFFFFFF;
                if (vertical) FX.set(reg.x() + j, reg.y() + i, argb); else FX.set(reg.x() + i, reg.y() + j, argb);
            }
        }
        return reg;
    }

    /** Hairline quarter arc that continues the rounded corner (radius = corner radius setting). */
    private static Region arc(int r, int idx) {
        K key = new K("arc", r, idx, 0, 0);
        Region reg = FX.map.get(key);
        if (reg != null) return reg;
        reg = FX.alloc(r, r);
        FX.map.put(key, reg);
        double cx = (idx & 1) != 0 ? 0 : r, cy = (idx & 2) != 0 ? 0 : r;
        for (int iy = 0; iy < r; iy++)
            for (int ix = 0; ix < r; ix++) {
                double dist = Math.hypot(ix + 0.5 - cx, iy + 0.5 - cy);
                double cov = Math.max(0, Math.min(1, 1 - Math.abs(dist - (r - 0.5))));
                FX.set(reg.x() + ix, reg.y() + iy, ((int) Math.round(cov * 255) << 24) | 0xFFFFFF);
            }
        return reg;
    }

    /** One hairline quarter arc of a rounded corner (1 blit). idx: 0 = top-left, 1 = top-right, 2 = bottom-left, 3 = bottom-right. */
    public static void cornerArc(GuiGraphics g, int idx, int x, int y, int r, int color) {
        if (r < 2 || (color >>> 24) == 0) return;
        FX.blit(g, arc(r, idx), x, y, color);
    }

    /**
     * Outline that follows the rounded rectangle: every straight side is a needle-shaped lens - a thin thread at
     * both ends that swells to {@code maxWidth} in the middle and shrinks back to a thread - and the corners are a
     * hairline arc with the corner radius, so the whole thing is tied to the "Corner radius" setting.
     * tl/tr/bl/br switch the four quarters of the outline on and off. Costs 8-12 blits, all from cached textures.
     */
    public static void outline(GuiGraphics g, int x, int y, int w, int h, int r, double maxWidth, int color,
                               boolean tl, boolean tr, boolean bl, boolean br) {
        if (w < 4 || h < 4 || (color >>> 24) == 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        int thickQ = (int) Math.round(Math.max(HAIR, Math.min(24, maxWidth)) * 4);
        Region hz = lens(thickQ, false), vt = lens(thickQ, true);
        int m = lensHalf(thickQ), H = 2 * m + 1, half = LENS_LEN / 2;
        int lw = w - 2 * r, lh = h - 2 * r;
        if (lw > 0) {
            int l1 = lw / 2, l2 = lw - l1;
            if (tl) FX.blitSubStretch(g, hz, 0, 0, half, H, x + r, y - m, l1, H, color);
            if (tr) FX.blitSubStretch(g, hz, half, 0, half, H, x + r + l1, y - m, l2, H, color);
            if (bl) FX.blitSubStretch(g, hz, 0, 0, half, H, x + r, y + h - 1 - m, l1, H, color);
            if (br) FX.blitSubStretch(g, hz, half, 0, half, H, x + r + l1, y + h - 1 - m, l2, H, color);
        }
        if (lh > 0) {
            int l1 = lh / 2, l2 = lh - l1;
            if (tl) FX.blitSubStretch(g, vt, 0, 0, H, half, x - m, y + r, H, l1, color);
            if (bl) FX.blitSubStretch(g, vt, 0, half, H, half, x - m, y + r + l1, H, l2, color);
            if (tr) FX.blitSubStretch(g, vt, 0, 0, H, half, x + w - 1 - m, y + r, H, l1, color);
            if (br) FX.blitSubStretch(g, vt, 0, half, H, half, x + w - 1 - m, y + r + l1, H, l2, color);
        }
        if (r >= 2) {
            if (tl) FX.blit(g, arc(r, 0), x, y, color);
            if (tr) FX.blit(g, arc(r, 1), x + w - r, y, color);
            if (bl) FX.blit(g, arc(r, 2), x, y + h - r, color);
            if (br) FX.blit(g, arc(r, 3), x + w - r, y + h - r, color);
        }
    }

    public static void flush() { MASKS.flush(); DYN.flush(); FX.flush(); }
}
