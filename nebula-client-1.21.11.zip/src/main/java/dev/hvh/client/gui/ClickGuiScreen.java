package dev.hvh.client.gui;

import dev.hvh.client.Config;
import dev.hvh.client.ConfigProfiles;
import dev.hvh.client.cosmetics.Cosmetics;
import dev.hvh.client.friend.FriendsManager;
import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Binds;
import dev.hvh.client.module.Category;
import dev.hvh.client.module.Mod;
import dev.hvh.client.setting.Setting;
import dev.hvh.client.sound.ClientSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.DyedItemColor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

/** Nebula's compact two-column Click GUI. Right-click a module to open its settings in the right pane. */
public class ClickGuiScreen extends Screen {
    private Category category = Category.ALL;
    private Mod selected;
    private Mod panelMod;   // module whose settings panel is open (or still closing) in the "down" mode
    private enum Page { MODULES, COSMETICS, THEME, CONFIGS, FRIENDS }
    private Page page = Page.MODULES;
    private enum CosmeticsTab { WARDROBE, WINGS, CAPE, HALO, SETTINGS }
    private CosmeticsTab cosmeticsTab = CosmeticsTab.WARDROBE;
    private final ThemeEditor themeEditor = new ThemeEditor();
    private String profileName = "MyConfig";
    private boolean profileNameFocus;
    private String selectedProfile = "";
    private int profileScroll;
    private String profileMessage = "";
    private long profileMessageUntil;

    // Friends page state
    private RemotePlayer friendPreviewEntity;
    private ClientLevel friendPreviewLevel;
    private java.util.UUID friendPreviewProfile;
    private String friendNameInput = "";
    private boolean friendNameFocus;
    private String selectedFriend = "";
    private int friendListScroll;
    private int friendPaletteDrag = -1; // 0 = SV square, 1 = hue bar
    private float friendHue, friendSat, friendVal;
    private String friendPaletteOwner = "";
    private int friendPageX, friendPageY, friendPageW, friendPageH, friendLeftW, friendRightX, friendRightW;
    private int friendInputX, friendInputY, friendInputW, friendAddX, friendListY, friendListH, friendRowH;
    private int friendHighlightY, friendOverrideY, friendPreviewX, friendPreviewY, friendPreviewW, friendPreviewH;
    private int friendPickerX, friendPickerY, friendPickerSVW, friendPickerSVH, friendHueX, friendHueW;
    private int friendPaletteHexY, friendPresetsY;
    private String search = "";
    private boolean searchFocus;
    private Setting.Num dragging;
    private int dragX, dragW;
    private int themeDragIndex = -1;
    private boolean surfaceSettingsPage;
    private float gs = 1f, S = 1f;
    private int x, y, w, h, sideW, settingsW, gap, row, pad, header;
    private double moduleScroll, settingScroll, moduleScrollT, settingScrollT; // current (animated) and target scroll
    private final float[] hoverAnim = new float[256];
    private float settingsProgress = 0f;
    private long lastFrameNanos = System.nanoTime();
    private static String lang(String en,String ru){return Theme.language.equals("RU")?ru:en;}

    public ClickGuiScreen() { super(Component.literal("Nebula Client")); ClientSounds.play(ClientSounds.Event.GUI_OPEN); }
    @Override protected void init() { CustomBackground.ensureLoaded(); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { if(!ClientSounds.keepGui)ClientSounds.play(ClientSounds.Event.GUI_CLOSE); ClientSounds.keepGui=false; Binds.listening = null; Binds.listeningSetting = null; Theme.save(); Config.save(); FriendsManager.save(); super.removed(); }
    private int u(double v) { return (int)Math.round(v*S); }
    private void calc() {
        gs=(float)Math.max(1,minecraft.getWindow().getGuiScale());
        S=Math.max(.75f,Math.min(3f,minecraft.getWindow().getHeight()/720f)); Draw.SCALE=S;
        int sw=Math.round(width*gs), sh=Math.round(height*gs);
        w=Math.min(u(1080*Theme.guiScaleX),sw-u(36)); h=Math.min(u(620*Theme.guiScaleY),sh-u(32));
        x=(sw-w)/2; y=(sh-h)/2; sideW=u(172); gap=u(12); pad=u(12); header=u(54); row=u(54);
        settingsW=Math.min(u(260),Math.max(u(205),w/4));
    }
    private int contentX(){return x+sideW+u(14);}
    private int contentW(){boolean drawerPage=!Theme.settingsDown;int drawer=(drawerPage&&(selected!=null||settingsProgress>0.015f))?(int)Math.round(settingsW*settingsProgress):0; return w-sideW-u(28)-drawer-(drawer>0?gap:0);}
    // ---- settings panel that opens DOWN from the module (Theme.settingsDown) ----
    private int panelFull(int colW){if(panelMod==null)return 0;return layoutSettings(panelMod.visibleSettings(),colW-u(24)).height+u(24);}
    private int panelH(int colW){return Theme.settingsDown?(int)Math.round(panelFull(colW)*settingsProgress):0;}
    /** The panel opens right under the module and only pushes down the modules of ITS column. */
    private int shift(int i,int cols,List<Mod> mods,int colW){if(!Theme.settingsDown||panelMod==null)return 0;int si=mods.indexOf(panelMod);return si>=0&&i%cols==si%cols&&i/cols>si/cols?panelH(colW):0;}
    private int[] toggleRect(){int bw=u(170),sw0=u(190),sh0=u(28);return new int[]{x+w-u(18)-sw0-u(10)-bw,y+u(17),bw,sh0};}
    private List<Mod> visible(){List<Mod> out=new ArrayList<>(); for(Mod m:HvhClient.modules.in(category)) if((search.isEmpty()||m.name.toLowerCase().contains(search.toLowerCase())))out.add(m);return out;}
    @Override public void render(GuiGraphics g,int gmx,int gmy,float delta){
        calc(); double mx=gmx*gs,my=gmy*gs;
        long nowNanos=System.nanoTime();
        float frameSeconds=Math.min(0.05f,Math.max(0.001f,(nowNanos-lastFrameNanos)/1_000_000_000f));
        lastFrameNanos=nowNanos;
        if(themeDragIndex>=0) updateThemeSlider(gmx*gs, themeDragIndex);
        // Glass is drawn as GUI-local translucent surfaces; do not trigger a global blur of the world.
        if(friendPaletteDrag>=0) updateFriendPalette(gmx*gs, gmy*gs);
        float ease=1f-(float)Math.exp(-frameSeconds*12f);
        {   // smooth scrolling: glide towards the target; "Scroll smoothness" in Theme makes the glide longer
            double rate=22.0-19.0*Theme.scrollSmooth, k=1.0-Math.exp(-frameSeconds*rate);
            moduleScroll+=(moduleScrollT-moduleScroll)*k; settingScroll+=(settingScrollT-settingScroll)*k;
            boolean moving=Math.abs(moduleScrollT-moduleScroll)>0.75||Math.abs(settingScrollT-settingScroll)>0.75;
            if(moving)ClientSounds.play(ClientSounds.Event.GUI_SCROLL); // keeps repeating while the animation runs
            else{moduleScroll=moduleScrollT;settingScroll=settingScrollT;}
        }
        g.pose().pushMatrix();g.pose().scale(1f/gs,1f/gs);
        // Clear any stale wallpaper crop before laying out this GUI frame.
        CustomBackground.clearGuiViewport();
        // Keep the game/menu behind the Click GUI visible; the panel itself owns its background.
        Draw.panelBg(g,x,y,w,h,(int)u(Theme.cornerRadius));
        // The custom image belongs INSIDE the click-GUI panel, never behind the screen.
        if (Theme.backgroundEnabled && CustomBackground.has(false)) {
            int inset=(int)Math.ceil(u(Theme.cornerRadius)*0.30)+u(1);
            CustomBackground.draw(g,x+inset,y+inset,w-inset*2,h-inset*2,false,Theme.guiOpacity);
        }
        // sidebar
        Draw.round(g,x+u(10),y+u(10),sideW-u(20),h-u(20),u(9),Theme.withGuiOpacity(0xFF111522,0.92));
        Logo.draw(g,x+u(22),y+u(20),u(28),0xFFFFFFFF);
        Draw.textBold(g,"NEBULA",x+u(60),y+u(27),Theme.TEXT,S*1.05f);
        Draw.text(g,"CLIENT",x+u(60),y+u(42),Theme.accent(),S*.72f);
        Draw.rect(g,x+u(20),y+u(62),sideW-u(40),1,0x334F5A79);
        Draw.text(g,"GENERAL",x+u(22),y+u(76),Theme.TEXT_DIM,S*.78f);
        int cy=y+u(98);
        for(Category c:Category.values()){
            boolean active=c==category; int bh=u(34);
            if(active)Draw.round(g,x+u(14),cy,sideW-u(28),bh,u(7),0xFF252B43);
            CategoryIcons.draw(g,c,x+u(22),cy+(bh-u(16))/2,u(16),active?Theme.accent():Theme.TEXT_DIM);
            Draw.text(g,c.title,x+u(46),cy+(bh-Draw.height(S))/2,active?Theme.TEXT:Theme.TEXT_DIM,S);
            cy+=u(39);
        }
        Draw.rect(g,x+u(20),cy+u(2),sideW-u(40),1,0x334F5A79);
        Draw.text(g,"CUSTOMIZE",x+u(22),cy+u(12),Theme.TEXT_DIM,S*.72f);
        int themeY=cy+u(30);
        String[] pageNames={"Modules","Cosmetics","Theme","Configs","Friends"}; Page[] pages=Page.values();
        for(int pi=0;pi<pages.length;pi++){
            int py=themeY+pi*u(29); boolean active=page==pages[pi];
            if(active) Draw.round(g,x+u(14),py,sideW-u(28),u(26),u(7),0xFF252B43);
            Draw.round(g,x+u(22),py+u(7),u(5),u(12),u(2),active?Theme.accent():0xFF50566B);
            Draw.text(g,pageNames[pi],x+u(36),py+u(6),active?Theme.TEXT:Theme.TEXT_DIM,S*.9f);
        }
        Draw.text(g,"CLIENT",x+u(22),y+h-u(70),Theme.TEXT_DIM,S*.78f);
        Draw.text(g,"Right-click a module",x+u(22),y+h-u(50),Theme.TEXT_DIM,S*.72f);
        Draw.text(g,"to edit settings",x+u(22),y+h-u(36),Theme.TEXT_DIM,S*.72f);
        // top header and search
        int cx=contentX(), cw=contentW();
        String pageTitle=page==Page.COSMETICS?"Cosmetics":page==Page.THEME?"Theme":page==Page.CONFIGS?"Configs":page==Page.FRIENDS?"Friends":category.title;
        Draw.textBold(g,pageTitle,cx,y+u(20),Theme.TEXT,S*1.45f);
        Draw.text(g,page==Page.COSMETICS?"Wearable effects and appearance":page==Page.THEME?"Customize colors, outlines and motion":page==Page.CONFIGS?"Save and restore your setup":page==Page.FRIENDS?"Manage friends and local armor colors":"Modules and visual enhancements",cx,y+u(40),Theme.TEXT_DIM,S*.82f);
        int searchW=u(190), searchH=u(28), sx=x+w-u(18)-searchW, sy=y+u(17);
        if(page==Page.MODULES){
            int[] tb=toggleRect();boolean th=Draw.hover(mx,my,tb[0],tb[1],tb[2],tb[3]);
            Draw.round(g,tb[0],tb[1],tb[2],tb[3],u(7),th?Theme.DARK_HOVER:0xFF171C2B);
            String tl=lang(Theme.settingsDown?"Settings: down":"Settings: side",Theme.settingsDown?"Настройки: вниз":"Настройки: справа");
            Draw.centered(g,tl,tb[0]+tb[2]/2f,tb[1]+(tb[3]-Draw.height(S*.85f))/2,Theme.accent(),S*.85f);
        }
        if(page==Page.MODULES){
            Draw.round(g,sx,sy,searchW,searchH,u(7),Theme.withGuiOpacity(0xFF171C2B,0.92));
            String st=(search.isEmpty()?"Search modules":search)+(searchFocus&&(System.currentTimeMillis()/500)%2==0?"|":"");
            Draw.text(g,st,sx+u(10),sy+(searchH-Draw.height(S*.9f))/2,search.isEmpty()?Theme.TEXT_DIM:Theme.TEXT,S*.9f);
        }
        Draw.rect(g,cx,y+header,cw,1,0x334F5A79);
        int top=y+header+u(10), bottom=y+h-u(16), contentH=bottom-top;
        if(page==Page.MODULES){
        // two module columns
        List<Mod> mods=visible(); int cols=Math.max(1,Math.min(4,Theme.modulesPerRow)); int colGap=u(10), colW=(cw-colGap*(cols-1))/cols;
        int hm=(int)Math.ceil(u((float)Theme.hoverExpand)/2.0)+u(2); // room for the hover-grown card
        Draw.scissor(g,cx-hm,top,cw+hm*2,contentH);
        for(int i=0;i<mods.size();i++){
            Mod m=mods.get(i); int col=i%cols, r=i/cols; int mx0=cx+col*(colW+colGap), my0=top+r*row-(int)moduleScroll+shift(i,cols,mods,colW);
            boolean hov=Draw.hover(mx,my,mx0,my0,colW,row-u(6))&&my>=top&&my<bottom;
            int ai=i%hoverAnim.length; float target=hov?1f:0f; hoverAnim[ai]+=(target-hoverAnim[ai])*ease;
            int extra=Math.round(u((float)Theme.hoverExpand)*hoverAnim[ai]); int drawW=colW+extra, drawX=mx0-extra/2;
            Draw.moduleBg(g,drawX,my0,drawW,row-u(6),(int)u(Theme.cornerRadius),m.isEnabled(),hoverAnim[ai]*0.8);
            int textY=my0+u(10);
            if(Binds.listening==m){
                long ms=System.currentTimeMillis(); int dx=drawX+u(12), dy=textY+u(4);
                for(int dot=0;dot<3;dot++){double phase=(ms/115.0+dot*0.72)%(Math.PI*2);int jump=(int)Math.round(Math.max(0,Math.sin(phase))*u(3));int d=Math.max(2,u(3));Draw.round(g,dx+dot*u(6),dy-jump,d,d,d/2,Draw.alpha(Theme.TEXT,0.45+0.55*Math.max(0,Math.sin(phase))));}
            } else {
                Draw.text(g,m.name,drawX+u(12),textY,m.isEnabled()?Theme.TEXT:Theme.moduleText(false),S*(float)Theme.textScale);
                if(m.bind>=0){String bindLabel=Binds.name(m.bind);Draw.text(g,bindLabel,drawX+drawW-u(8)-Draw.width(bindLabel,S),textY,Draw.alpha(m.isEnabled()?Theme.TEXT:Theme.moduleText(false),0.58),S);}
            }
            String status=m.isEnabled()?"Enabled":"Disabled";
            Draw.text(g,status,drawX+u(12),my0+u(29),m.isEnabled()?Theme.accent():Theme.TEXT_DIM,S*.76f);
            if(!m.settings.isEmpty()){
                int bx=drawX+drawW-u(24),by=my0+u(14);
                Draw.round(g,bx,by,u(14),u(14),u(4),selected==m?Theme.accent():0xFF353B50);
                Draw.text(g,"···",bx+u(2),by-u(1),Theme.TEXT,S*.8f);
            }
        }
        if(Theme.settingsDown&&panelMod!=null&&settingsProgress>0.015f){
            int si=mods.indexOf(panelMod);
            if(si>=0){
                int ph=panelH(colW), px0=cx+(si%cols)*(colW+colGap), py0=top+(si/cols+1)*row-(int)moduleScroll-u(2);
                Draw.round(g,px0,py0,colW,Math.max(1,ph-u(4)),u(9),Theme.withGuiOpacity(0xFF111522,0.92));
                Draw.scissor(g,px0,py0,colW,Math.max(1,ph-u(4)));
                renderSettings(g,layoutSettings(panelMod.visibleSettings(),colW-u(24)),px0+u(12),py0+u(10),mx,my);
                Draw.unscissor(g);
            }
        }
        Draw.unscissor(g);
        } else if(page==Page.COSMETICS){
            renderCosmeticsPage(g,cx,top,cw,mx,my);
        } else if(page==Page.THEME){
            int editorW=Math.min(u(270),Math.max(u(230),cw/2));
            themeEditor.render(g,cx,top,editorW,mx,my,S);
            renderThemeExtra(g,cx+editorW+u(12),top,Math.max(u(160),cw-editorW-u(12)),mx,my);
        } else if(page==Page.CONFIGS) {
            renderConfigsPage(g,cx,top,cw,mx,my);
        } else {
            renderFriendsPage(g,cx,top,cw,mx,my);
        }
        // settings drawer on the right, opened only by right click
        settingsProgress += ((selected!=null?1f:0f)-settingsProgress)*ease;
        if(selected!=null)panelMod=selected;else if(settingsProgress<0.015f)panelMod=null;
        if((page==Page.MODULES && !Theme.settingsDown) && selected!=null && settingsProgress>0.015f){
            int px=x+w-settingsW-u(12)+Math.round(u(16)*(1f-settingsProgress)), py=y+u(12), ph=h-u(24);
            Draw.round(g,px,py,settingsW,ph,u(9),Theme.withGuiOpacity(0xFF111522,0.92));
            Draw.textBold(g,lang("MODULE SETTINGS","НАСТРОЙКИ МОДУЛЯ"),px+u(14),py+u(14),Theme.TEXT,S*.85f);
            Draw.textBold(g,selected.name,px+u(14),py+u(34),Theme.accent(),S*1.05f);
            Draw.rect(g,px+u(12),py+u(56),settingsW-u(24),1,0x334F5A79);
            int sy0=py+u(68), avail=ph-u(80); Draw.scissor(g,px+u(8),sy0,settingsW-u(16),avail);
            int iy=sy0-(int)settingScroll;
            if(selected.settings.isEmpty())Draw.text(g,lang("No settings available","Нет доступных настроек"),px+u(14),iy,Theme.TEXT_DIM,S*.85f);
            renderSettings(g,layoutSettings(selected.visibleSettings(),settingsW-u(28)),px+u(14),iy,mx,my);
            Draw.unscissor(g);
        }
        Draw.flush();g.pose().popMatrix();
    }

    private void renderThemeExtra(GuiGraphics g,int x0,int y0,int w0,double mx,double my){
        if (surfaceSettingsPage) { renderGlassSurfaces(g,x0,y0,w0,mx,my); return; }
        int panelH=u(566); Draw.panelBg(g,x0,y0,w0,panelH,(int)u(Theme.cornerRadius));
        Draw.textBold(g,"EFFECTS & COLORS",x0+u(9),y0+u(10),Theme.TEXT,S*.85f);
        themeAction(g,x0+w0-u(96),y0+u(6),u(88),u(18),lang("Glass surfaces","Стеклянные поверхности"),mx,my);
        String[] labels={lang("Gradient angle","Угол градиента"),lang("Glow intensity","Интенсивность свечения"),lang("GUI width","Ширина GUI"),lang("GUI height","Высота GUI"),lang("Corner radius","Радиус углов"),lang("Outline thickness","Толщина контура"),lang("Loading duration","Длительность загрузки"),lang("Hover expand","Расширение при наведении"),lang("Text size","Размер текста"),lang("Modules per row","Модулей в ряд")};
        double[] vals={Theme.gradientAngle/360.0,Theme.glowStrength,(Theme.guiScaleX-.6)/.9,(Theme.guiScaleY-.6)/.9,Theme.cornerRadius/20.0,Theme.outlineWidth/5.0,(Theme.loadingSeconds-2)/8,Theme.hoverExpand/12.0,(Theme.textScale-.65)/.95,(Theme.modulesPerRow-1)/3.0};
        int rowH=u(21), sliderW=Math.max(u(55),w0-u(90));
        for(int i=0;i<labels.length;i++){
            int yy=y0+u(30)+i*rowH; Draw.text(g,labels[i],x0+u(9),yy,Theme.TEXT_DIM,S*.68f);
            String value=switch(i){case 0->Math.round(Theme.gradientAngle)+"°";case 1->String.format("%.2f",Theme.glowStrength);case 2->String.format("%.0f%%",Theme.guiScaleX*100);case 3->String.format("%.0f%%",Theme.guiScaleY*100);case 4->String.format("%.1f",Theme.cornerRadius);case 5->String.format("%.1f",Theme.outlineWidth);case 6->String.format("%.1fs",Theme.loadingSeconds);case 7->String.format("%.1f",Theme.hoverExpand);case 8->String.format("%.2fx",Theme.textScale);default->Integer.toString(Theme.modulesPerRow);};
            Draw.text(g,value,x0+w0-u(35),yy,Theme.TEXT,S*.65f);
            int bx=x0+w0-sliderW-u(9),by=yy+u(12); Draw.round(g,bx,by,sliderW,u(4),u(2),Theme.SLIDER_BG); Draw.round(g,bx,by,Math.max(u(3),(int)(sliderW*Math.max(0,Math.min(1,vals[i])))),u(4),u(2),Theme.accent());
        }
        String[] cn={lang("Outline","Контур"),lang("Glow","Свечение"),lang("Text","Текст")};
        int[] cc={Theme.outlineColor,Theme.glowColor,Theme.TEXT&0xFFFFFF};
        for(int r=0;r<3;r++){
            int yy=y0+u(266+r*24); Draw.text(g,cn[r]+" #"+String.format("%06X",cc[r]&0xFFFFFF),x0+u(9),yy+u(2),Theme.TEXT_DIM,S*.68f);
            boolean act=themeEditor.selectedExtra()==(r==0?2:r==1?1:0); int chipW=u(46),chipX=x0+w0-u(9)-chipW;
            if(act)Draw.round(g,chipX-u(1),yy-u(1),chipW+u(2),u(17),u(4),0xFFEAF0FF);
            Draw.round(g,chipX,yy,chipW,u(15),u(3),0xFF000000|cc[r]);
        }
        themeAction(g,x0+u(8),y0+u(338),w0-u(16),u(17),"Outline: "+(Theme.outlineEnabled?"ON":"OFF"),mx,my);
        themeAction(g,x0+u(8),y0+u(357),w0-u(16),u(17),"GUI background: "+(Theme.backgroundEnabled?"ON":"OFF"),mx,my);
        themeAction(g,x0+u(8),y0+u(376),w0-u(16),u(17),"Select from backgrounds folder"+(CustomBackground.has(false)?" ✓":CustomBackground.hasError(false)?" (!)":""),mx,my);
        themeAction(g,x0+u(8),y0+u(395),w0-u(16),u(17),"Main menu background: "+(Theme.menuBackgroundEnabled?"ON":"OFF"),mx,my);
        themeAction(g,x0+u(8),y0+u(414),w0-u(16),u(17),"Select menu image from folder"+(CustomBackground.has(true)?" ✓":CustomBackground.hasError(true)?" (!)":""),mx,my);
        Draw.text(g,lang("Menu image opacity  ","Непрозрачность меню  ")+Math.round(Theme.menuBackgroundOpacity*100)+"%",x0+u(9),y0+u(431),Theme.TEXT_DIM,S*.65f);
        int bx=x0+u(9),bw=w0-u(18); Draw.round(g,bx,y0+u(443),bw,u(4),u(2),Theme.SLIDER_BG); Draw.round(g,bx,y0+u(443),Math.max(u(3),(int)(bw*Theme.menuBackgroundOpacity)),u(4),u(2),Theme.accent());
        Draw.text(g,lang("Scroll smoothness  ","Плавность скролла  ")+Math.round(Theme.scrollSmooth*100)+"%",x0+u(9),y0+u(451),Theme.TEXT_DIM,S*.65f); Draw.round(g,bx,y0+u(463),bw,u(4),u(2),Theme.SLIDER_BG); Draw.round(g,bx,y0+u(463),Math.max(u(3),(int)(bw*Theme.scrollSmooth)),u(4),u(2),Theme.accent());
        Draw.text(g,lang("Outline corners","Углы контура"),x0+u(9),y0+u(482),Theme.TEXT_DIM,S*.65f); String[] corners={"TL","TR","BL","BR"}; boolean[] states={Theme.outlineTopLeft,Theme.outlineTopRight,Theme.outlineBottomLeft,Theme.outlineBottomRight};
        for(int i=0;i<4;i++){int bx0=x0+u(9)+i*u(38),by=y0+u(495);Draw.round(g,bx0,by,u(33),u(16),u(4),states[i]?Theme.accent():Theme.DARK);Draw.centered(g,corners[i],bx0+u(16),by+u(3),Theme.TEXT,S*.62f);}
        Draw.text(g,lang("Language","Язык"),x0+u(9),y0+u(531),Theme.TEXT_DIM,S*.68f); themeAction(g,x0+u(75),y0+u(525),u(78),u(19),Theme.language.equals("RU")?"Русский":"English",mx,my);
    }

    private void renderGlassSurfaces(GuiGraphics g,int x0,int y0,int w0,double mx,double my){
        Draw.panelBg(g,x0,y0,w0,u(566),(int)u(Theme.cornerRadius));
        Draw.textBold(g,lang("GLASS SURFACES","СТЕКЛЯННЫЕ ПОВЕРХНОСТИ"),x0+u(9),y0+u(10),Theme.TEXT,S*.85f);
        themeAction(g,x0+w0-u(91),y0+u(6),u(83),u(18),lang("← Effects","← Эффекты"),mx,my);
        String[] names={lang("GUI background","Фон GUI"),lang("Module cards","Карточки модулей"),lang("HUD elements","Элементы HUD")};
        String[] blur={lang("Blur / frosting","Блюр / матовость"),lang("Blur / frosting","Блюр / матовость"),lang("Blur / frosting","Блюр / матовость")};
        String[] opacity={lang("Background opacity","Прозрачность фона"),lang("Background opacity","Прозрачность фона"),lang("Background opacity","Прозрачность фона")};
        String[] highlights={lang("Highlight strength","Сила бликов"),lang("Highlight strength","Сила бликов"),lang("Highlight strength","Сила бликов")};
        for(int group=0;group<3;group++){
            int top=y0+u(42)+group*u(145), cardH=u(136);
            Draw.round(g,x0+u(8),top,w0-u(16),cardH,u(8),Theme.withGuiOpacity(0xFF111522,0.78));
            Draw.glassHighlight(g,x0+u(8),top,w0-u(16),cardH,u(8),true,Theme.Surface.GUI);
            Draw.textBold(g,names[group],x0+u(17),top+u(7),Theme.TEXT,S*.74f);
            drawSurfaceSlider(g,x0+u(16),top+u(27),w0-u(32),blur[group],surfaceValue(group,0),mx);
            drawSurfaceSlider(g,x0+u(16),top+u(55),w0-u(32),opacity[group],surfaceValue(group,1),mx);
            drawSurfaceSlider(g,x0+u(16),top+u(83),w0-u(32),highlights[group],surfaceValue(group,2),mx);
        }
        Draw.text(g,lang("Values are independent for each surface and are saved automatically.","Значения независимы для каждой поверхности и сохраняются автоматически."),x0+u(10),y0+u(490),Theme.TEXT_DIM,S*.61f);
        Draw.text(g,lang("Blur here controls the glass/frost finish; native full-screen blur is disabled.","Блюр здесь управляет матовым стеклом; глобальный блюр экрана отключён."),x0+u(10),y0+u(505),Theme.TEXT_DIM,S*.58f);
    }

    private double surfaceValue(int group,int kind){
        return switch(group){
            case 0 -> kind==0?Theme.guiBlurStrength:kind==1?Theme.guiOpacity:Theme.guiHighlightStrength;
            case 1 -> kind==0?Theme.moduleBlurStrength:kind==1?Theme.moduleOpacity:Theme.moduleHighlightStrength;
            default -> kind==0?Theme.hudBlurStrength:kind==1?Theme.hudOpacity:Theme.hudHighlightStrength;
        };
    }

    private void drawSurfaceSlider(GuiGraphics g,int sx,int sy,int sw,String label,double value,double mx){
        Draw.text(g,label,sx,sy,Theme.TEXT_DIM,S*.62f);
        Draw.text(g,Math.round(value*100)+"%",sx+sw-Draw.width(Math.round(value*100)+"%",S*.62f),sy,Theme.TEXT,S*.62f);
        int barY=sy+u(12); Draw.round(g,sx,barY,sw,u(4),u(2),Theme.SLIDER_BG);
        Draw.round(g,sx,barY,Math.max(u(3),(int)(sw*Theme.clamp01(value))),u(4),u(2),Theme.accent());
    }
    private void themeAction(GuiGraphics g,int x0,int y0,int w0,int h0,String label,double mx,double my){Draw.round(g,x0,y0,w0,h0,u(4),Draw.hover(mx,my,x0,y0,w0,h0)?Theme.DARK_HOVER:Theme.DARK);Draw.text(g,label,x0+u(6),y0+u(4),Theme.TEXT,S*.65f);}

    private String settingLabel(String name){
        if(!Theme.language.equals("RU"))return name;
        return switch(name.toLowerCase()){
            case "enabled" -> "Включено"; case "mode" -> "Режим"; case "speed" -> "Скорость";
            case "range" -> "Дальность"; case "delay" -> "Задержка"; case "distance" -> "Расстояние";
            case "height" -> "Высота"; case "width" -> "Ширина"; case "radius" -> "Радиус";
            case "timer" -> "Таймер"; case "strength" -> "Сила"; case "amount" -> "Количество";
            case "show notifications" -> "Показывать уведомления"; case "only ground" -> "Только на земле";
            case "aim mode" -> "Режим наведения"; case "move correction" -> "Коррекция движения";
            case "attack range" -> "Дальность атаки"; case "aim extra range" -> "Доп. дальность наведения";
            case "attacks per second" -> "Атак в секунду"; case "switch delay ms" -> "Задержка смены (мс)";
            case "fov" -> "Угол обзора"; case "aim speed" -> "Скорость наведения";
            case "smart crits" -> "Умные криты"; case "priority" -> "Приоритет"; case "sprint" -> "Спринт";
            case "prediction ticks" -> "Тики предсказания"; case "predict self" -> "Предсказывать своё движение";
            case "pre-attack rotate" -> "Наведение перед атакой"; case "stick distance" -> "Удерживаемая дистанция";
            case "keep target" -> "Удерживать цель"; case "players" -> "Игроки"; case "friends" -> "Друзья"; case "mobs" -> "Мобы";
            case "villagers" -> "Жители"; case "invisible" -> "Невидимые"; case "naked players" -> "Игроки без брони";
            case "don't attack in container" -> "Не атаковать в интерфейсе"; case "don't attack while eating" -> "Не атаковать во время еды";
            case "don't attack while flying" -> "Не атаковать при полёте"; case "weapon only" -> "Только с оружием";
            case "critical hits only" -> "Только критические удары"; case "through walls" -> "Сквозь стены";
            case "break shield" -> "Ломать щит"; case "auto axe switch" -> "Автовыбор топора";
            case "wait for attack cooldown" -> "Ждать перезарядку атаки"; case "swap bind" -> "Клавиша свапа";
            case "swap 1" -> "Свап 1"; case "swap 2" -> "Свап 2"; case "volume" -> "Громкость";
            case "choose sounds" -> "Выбрать звуки"; case "only totems i popped" -> "Только мои срабатывания тотема";
            case "knockback" -> "Отбрасывание"; case "kb horizontal" -> "Отбрасывание по горизонтали";
            case "kb vertical" -> "Отбрасывание по вертикали"; case "explosions" -> "Взрывы";
            case "expl horizontal" -> "Взрывы по горизонтали"; case "expl vertical" -> "Взрывы по вертикали";
            case "entity reach" -> "Дальность взаимодействия с сущностями"; case "block reach" -> "Дальность взаимодействия с блоками";
            case "check enchanted" -> "Проверять зачарованный тотем"; case "check cooldown" -> "Проверять перезарядку";
            case "health" -> "Здоровье"; case "mace smash" -> "Удар булавой"; case "mace extra height" -> "Доп. высота булавы";
            case "mace target range" -> "Дальность цели булавы"; case "delay (ticks)" -> "Задержка (тики)";
            case "anti-kick" -> "Защита от кика"; case "vanilla speed (b/s)" -> "Скорость Vanilla (б/с)";
            case "timer multiplier" -> "Множитель таймера"; case "only on ground" -> "Только на земле";
            case "watermark" -> "Водяной знак"; case "info bar" -> "Информационная панель"; case "hotkeys" -> "Клавиши модулей";
            case "potions" -> "Эффекты зелий"; case "target hud" -> "Панель цели"; case "notifications" -> "Уведомления";
            case "minimum speed (b/s)" -> "Мин. скорость (б/с)"; case "set speed (b/s, 0 = keep)" -> "Задать скорость (0 = без изменений)";
            case "players only" -> "Только игроки"; case "entities" -> "Сущности"; case "expand" -> "Расширение";
            case "walls" -> "Стены"; case "water" -> "Вода"; case "random min radius" -> "Мин. случайный радиус";
            case "random max radius" -> "Макс. случайный радиус"; case "random switch time (ticks)" -> "Время смены (тики)";
            case "random: cross through target" -> "Случайно проходить сквозь цель"; case "cross chance %" -> "Шанс прохода %";
            case "auto jump" -> "Автопрыжок"; case "need movement key" -> "Требуется клавиша движения";
            case "remove sliding" -> "Убрать скольжение"; case "avoid walls" -> "Избегать стен"; case "avoid edges / void" -> "Избегать краёв и пустоты";
            case "only in air" -> "Только в воздухе"; case "speed (b/s)" -> "Скорость (б/с)";
            case "no slow" -> "Без замедления";
            case "fall damage" -> "Урон от падения";
            case "critical" -> "Критический удар";
            case "jump" -> "Прыжок";
            case "auto sprint" -> "Автоспринт"; case "ground friction" -> "Трение на земле";
            case "step height" -> "Высота шага"; case "entity hitboxes" -> "Хитбоксы сущностей";
            case "attack while using item" -> "Атака при использовании предмета"; case "horizontal" -> "Горизонтально";
            case "vertical" -> "Вертикально";
            case "target esp" -> "Подсветка цели";
            default -> name;
        };
    }
    private String settingValue(String value) {
        if (!Theme.language.equals("RU")) return value;
        return switch (value) {
            case "Silent" -> "Тихий"; case "Snap" -> "Резкий"; case "Smooth" -> "Плавный"; case "None" -> "Нет";
            case "Free" -> "Свободно"; case "Targeted" -> "По цели"; case "Distance" -> "Дистанция";
            case "Field of view" -> "Угол обзора"; case "Health" -> "Здоровье"; case "Armor" -> "Броня";
            case "Auto" -> "Авто"; case "Smart" -> "Умный"; case "Always" -> "Всегда"; case "Keep" -> "Сохранять";
            case "Packet" -> "Пакетный"; case "UpdatedNCP" -> "Обновлённый NCP"; case "OldNCP" -> "Старый NCP";
            case "Abilities" -> "Способности"; case "Motion" -> "Движение"; case "Timer" -> "Таймер";
            case "Circle" -> "Круг"; case "Random" -> "Случайный"; case "Vanilla" -> "Ванильный";
            case "Ball" -> "Шар"; case "Totem" -> "Тотем"; case "Ench. Totem" -> "Зачар. тотем";
            case "Damage" -> "Урон"; case "HVH" -> "HVH";
            default -> value;
        };
    }
    private void updateThemeSlider(double mx,int idx){
        int cx=contentX(),cw=contentW(),ew=Math.min(u(270),Math.max(u(230),cw/2)),tx=cx+ew+u(12),tw=Math.max(u(160),cw-ew-u(12));
        if(idx>=100){
            int item=idx-100, group=item/3, kind=item%3;
            double sliderW=Math.max(1,tw-u(32)), left=tx+u(16);
            double v=Math.max(0,Math.min(1,(mx-left)/sliderW));
            if(group==0){if(kind==0)Theme.guiBlurStrength=v;else if(kind==1)Theme.guiOpacity=v;else Theme.guiHighlightStrength=v;}
            else if(group==1){if(kind==0)Theme.moduleBlurStrength=v;else if(kind==1)Theme.moduleOpacity=v;else Theme.moduleHighlightStrength=v;}
            else {if(kind==0)Theme.hudBlurStrength=v;else if(kind==1)Theme.hudOpacity=v;else Theme.hudHighlightStrength=v;}
            Theme.guiBackgroundOpacity=Theme.guiOpacity;
            return;
        }
        double sliderW=Math.max(u(55),tw-u(90)), left=tx+tw-sliderW-u(9);
        if(idx>=10){left=tx+u(9);sliderW=Math.max(1,tw-u(18));}
        double v=Math.max(0,Math.min(1,(mx-left)/sliderW));
        switch(idx){case 0->Theme.gradientAngle=v*360;case 1->Theme.glowStrength=v;case 2->Theme.guiScaleX=.6+v*.9;case 3->Theme.guiScaleY=.6+v*.9;case 4->Theme.cornerRadius=v*20;case 5->Theme.outlineWidth=v*5;case 6->Theme.loadingSeconds=2+v*8;case 7->Theme.hoverExpand=v*12;case 8->Theme.textScale=.65+v*.95;case 9->Theme.modulesPerRow=1+(int)Math.round(v*3);case 10->Theme.menuBackgroundOpacity=v;case 11->Theme.scrollSmooth=v;default->{}}
    }
    // Cosmetics is a separate page with nested tabs. Add another CosmeticsTab and a matching
    // switch branch below to extend the wardrobe without mixing it into module categories.
    private void renderCosmeticsPage(GuiGraphics g,int x0,int y0,int w0,double mx,double my){
        Cosmetics.load();
        int tabY=y0, tabGap=u(6), tabW=(w0-tabGap*(CosmeticsTab.values().length-1))/CosmeticsTab.values().length;
        for(int i=0;i<CosmeticsTab.values().length;i++){
            CosmeticsTab tab=CosmeticsTab.values()[i]; int tx=x0+i*(tabW+tabGap); boolean active=tab==cosmeticsTab;
            Draw.round(g,tx,tabY,tabW,u(28),u(6),active?Theme.accent():0xFF171C2B);
            Draw.centered(g,cosmeticsTabName(tab),tx+tabW/2f,tabY+u(8),active?Theme.TEXT:Theme.TEXT_DIM,S*.72f);
        }
        int py=tabY+u(40), cardW=Math.min(w0,u(520));
        Draw.panelBg(g,x0,py,cardW,u(270),(int)u(Theme.cornerRadius));
        Draw.textBold(g,cosmeticsTabName(cosmeticsTab).toUpperCase(),x0+u(14),py+u(12),Theme.TEXT,S*.9f);
        switch(cosmeticsTab){
            case WARDROBE -> {
                Draw.text(g,"Quick wardrobe overview",x0+u(14),py+u(31),Theme.TEXT_DIM,S*.72f);
                cosmeticRow(g,x0+u(12),py+u(55),cardW-u(24),"Wings","Procedural back accessory",Cosmetics.wings,mx,my);
                cosmeticRow(g,x0+u(12),py+u(96),cardW-u(24),"Cape","Short animated cape",Cosmetics.cape,mx,my);
                cosmeticRow(g,x0+u(12),py+u(137),cardW-u(24),"Halo","Floating ring above the head",Cosmetics.halo,mx,my);
            }
            case WINGS -> {
                Draw.text(g,"Choose the wing style and color",x0+u(14),py+u(32),Theme.TEXT_DIM,S*.72f);
                cosmeticRow(g,x0+u(12),py+u(58),cardW-u(24),"Enable wings","Shown on your player / selected players",Cosmetics.wings,mx,my);
                palette(g,x0+u(14),py+u(111),"Wing color",Cosmetics.wingsColor,mx,my);
            }
            case CAPE -> {
                Draw.text(g,"A simple flowing cape rendered locally",x0+u(14),py+u(32),Theme.TEXT_DIM,S*.72f);
                cosmeticRow(g,x0+u(12),py+u(58),cardW-u(24),"Enable cape","Color and slight movement animation",Cosmetics.cape,mx,my);
                palette(g,x0+u(14),py+u(111),"Cape color",Cosmetics.capeColor,mx,my);
            }
            case HALO -> {
                Draw.text(g,"A thin ring floating above the player",x0+u(14),py+u(32),Theme.TEXT_DIM,S*.72f);
                cosmeticRow(g,x0+u(12),py+u(58),cardW-u(24),"Enable halo","Visible above the head",Cosmetics.halo,mx,my);
                palette(g,x0+u(14),py+u(111),"Halo color",Cosmetics.haloColor,mx,my);
            }
            case SETTINGS -> {
                Draw.text(g,"Choose who can see local cosmetics",x0+u(14),py+u(32),Theme.TEXT_DIM,S*.72f);
                cosmeticRow(g,x0+u(12),py+u(58),cardW-u(24),"Show on me","Render accessories on your own player",Cosmetics.showSelf,mx,my);
                cosmeticRow(g,x0+u(12),py+u(99),cardW-u(24),"Show on others","Render accessories on other players too",Cosmetics.showOthers,mx,my);
                configButton(g,x0+u(12),py+u(153),cardW-u(24),u(26),"Reset cosmetics",mx,my);
                Draw.text(g,"Saved to config/nebula/cosmetics.properties",x0+u(14),py+u(191),Theme.TEXT_DIM,S*.66f);
            }
        }
        Draw.text(g,"Client-side cosmetic preview • no server resource pack required",x0+u(4),py+u(286),Theme.TEXT_DIM,S*.68f);
    }

    private String cosmeticsTabName(CosmeticsTab tab){
        return switch(tab){case WARDROBE->"Wardrobe";case WINGS->"Wings";case CAPE->"Cape";case HALO->"Halo";case SETTINGS->"Settings";};
    }

    private void cosmeticRow(GuiGraphics g,int rx,int ry,int rw,String title,String desc,boolean enabled,double mx,double my){
        boolean hov=Draw.hover(mx,my,rx,ry,rw,u(34));
        Draw.round(g,rx,ry,rw,u(34),u(6),hov?Theme.DARK_HOVER:0xFF171C2B);
        Draw.text(g,title,rx+u(9),ry+u(5),enabled?Theme.TEXT:Theme.TEXT_DIM,S*.78f);
        Draw.text(g,desc,rx+u(9),ry+u(19),Theme.TEXT_DIM,S*.61f);
        Draw.round(g,rx+rw-u(39),ry+u(10),u(28),u(14),u(7),enabled?Theme.accent():0xFF3A4054);
        Draw.round(g,rx+rw-u(enabled?23:37),ry+u(12),u(10),u(10),u(5),0xFFFFFFFF);
    }

    private void palette(GuiGraphics g,int px,int py,String title,int selectedColor,double mx,double my){
        Draw.text(g,title,px,py,Theme.TEXT_DIM,S*.74f);
        int[] colors=Cosmetics.palette(); int sw=u(24),gap0=u(7);
        for(int i=0;i<colors.length;i++){
            int bx=px+i*(sw+gap0), by=py+u(17); boolean active=colors[i]==selectedColor;
            if(active)Draw.round(g,bx-u(2),by-u(2),sw+u(4),sw+u(4),u(6),Theme.TEXT);
            Draw.round(g,bx,by,sw,sw,u(5),colors[i]);
        }
    }

    private boolean clickCosmetics(double mx,double my,int btn,int x0,int y0,int w0){
        if(btn!=0)return true;
        int tabGap=u(6),tabW=(w0-tabGap*(CosmeticsTab.values().length-1))/CosmeticsTab.values().length;
        for(int i=0;i<CosmeticsTab.values().length;i++){
            int tx=x0+i*(tabW+tabGap);
            if(Draw.hover(mx,my,tx,y0,tabW,u(28))){cosmeticsTab=CosmeticsTab.values()[i];return true;}
        }
        int py=y0+u(40), cardW=Math.min(w0,u(520)), rx=x0+u(12), rw=cardW-u(24);
        switch(cosmeticsTab){
            case WARDROBE -> {
                if(Draw.hover(mx,my,rx,py+u(55),rw,u(34)))Cosmetics.wings=!Cosmetics.wings;
                else if(Draw.hover(mx,my,rx,py+u(96),rw,u(34)))Cosmetics.cape=!Cosmetics.cape;
                else if(Draw.hover(mx,my,rx,py+u(137),rw,u(34)))Cosmetics.halo=!Cosmetics.halo;
                else return true;
            }
            case WINGS -> {
                if(Draw.hover(mx,my,rx,py+u(58),rw,u(34)))Cosmetics.wings=!Cosmetics.wings;
                else { int c=paletteColorAt(mx,my,x0+u(14),py+u(111)); if(c!=-1)Cosmetics.wingsColor=c; else return true; }
            }
            case CAPE -> {
                if(Draw.hover(mx,my,rx,py+u(58),rw,u(34)))Cosmetics.cape=!Cosmetics.cape;
                else { int c=paletteColorAt(mx,my,x0+u(14),py+u(111)); if(c!=-1)Cosmetics.capeColor=c; else return true; }
            }
            case HALO -> {
                if(Draw.hover(mx,my,rx,py+u(58),rw,u(34)))Cosmetics.halo=!Cosmetics.halo;
                else { int c=paletteColorAt(mx,my,x0+u(14),py+u(111)); if(c!=-1)Cosmetics.haloColor=c; else return true; }
            }
            case SETTINGS -> {
                if(Draw.hover(mx,my,rx,py+u(58),rw,u(34)))Cosmetics.showSelf=!Cosmetics.showSelf;
                else if(Draw.hover(mx,my,rx,py+u(99),rw,u(34)))Cosmetics.showOthers=!Cosmetics.showOthers;
                else if(Draw.hover(mx,my,rx,py+u(153),rw,u(26)))Cosmetics.reset();
                else return true;
            }
        }
        Cosmetics.save(); return true;
    }

    private int paletteColorAt(double mx,double my,int px,int py){
        int[] colors=Cosmetics.palette(); int sw=u(24),gap0=u(7);
        for(int i=0;i<colors.length;i++)if(Draw.hover(mx,my,px+i*(sw+gap0),py+u(17),sw,sw))return colors[i];
        return -1;
    }

    private void renderConfigsPage(GuiGraphics g,int x0,int y0,int w0,double mx,double my){
        int pw0=Math.min(u(340),w0), px=x0, py=y0; Draw.panelBg(g,px,py,pw0,u(340),u(9));
        Draw.textBold(g,"CONFIG PROFILES",px+u(12),py+u(12),Theme.TEXT,S*.95f);
        Draw.round(g,px+u(10),py+u(38),pw0-u(20),u(28),u(6),0xFF171C2B);
        Draw.text(g,profileName+(profileNameFocus&&System.currentTimeMillis()/500%2==0?"|":""),px+u(18),py+u(47),Theme.TEXT,S*.85f);
        configButton(g,px+u(10),py+u(74),pw0-u(20),u(25),"Save current config",mx,my);
        int yy=py+u(108); List<String> names=ConfigProfiles.list();
        profileScroll=Math.max(0,Math.min(profileScroll,Math.max(0,names.size()-7)));
        for(int i=profileScroll;i<Math.min(names.size(),profileScroll+7);i++){String n=names.get(i);boolean sel=n.equals(selectedProfile);Draw.round(g,px+u(10),yy,pw0-u(20),u(24),u(5),sel?Theme.accent():Theme.DARK);Draw.text(g,n,px+u(17),yy+u(6),sel?Theme.TEXT:Theme.TEXT_DIM,S*.8f);yy+=u(28);}
        int by=py+u(310), gap=u(5), bw=(pw0-u(28)-gap*2)/3;
        configButton(g,px+u(10),by,bw,u(22),"Load",mx,my);
        configButton(g,px+u(14)+bw,by,bw,u(22),"Delete",mx,my);
        configButton(g,px+u(18)+bw*2+gap*2,by,bw,u(22),"File...",mx,my);
        String msg=System.currentTimeMillis()<profileMessageUntil?profileMessage:"Saved in config/nebula/configs";Draw.text(g,msg,px+u(10),py+u(366),Theme.TEXT_DIM,S*.65f);
    }
    // ---- Friends page: persistent list, shared/per-friend armor palette and a live leather-armor preview ----
    private void renderFriendsPage(GuiGraphics g, int x0, int y0, int w0, double mx, double my) {
        friendPageX = x0; friendPageY = y0; friendPageW = w0;
        friendPageH = Math.max(u(260), y + h - u(16) - y0);
        int gap0 = u(10);
        friendLeftW = Math.min(u(286), Math.max(u(160), (w0 - gap0) / 2));
        friendLeftW = Math.min(friendLeftW, Math.max(u(150), w0 - gap0 - u(180)));
        friendRightX = x0 + friendLeftW + gap0;
        friendRightW = Math.max(u(180), w0 - friendLeftW - gap0);
        Draw.panelBg(g, x0, y0, friendLeftW, friendPageH, u(9));
        Draw.textBold(g, lang("FRIEND LIST", "СПИСОК ДРУЗЕЙ"), x0 + u(12), y0 + u(10), Theme.TEXT, S * .88f);
        Draw.text(g, lang("Names are saved locally", "Имена сохраняются локально"), x0 + u(12), y0 + u(26), Theme.TEXT_DIM, S * .68f);

        friendInputX = x0 + u(10); friendInputY = y0 + u(42);
        friendAddX = x0 + friendLeftW - u(59);
        friendInputW = friendLeftW - u(78);
        Draw.round(g, friendInputX, friendInputY, friendInputW, u(25), u(5), friendNameFocus ? 0xFF242B42 : 0xFF171C2B);
        String inputText = friendNameInput + (friendNameFocus && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "");
        Draw.text(g, inputText.isEmpty() ? lang("Player name", "Ник игрока") : inputText, friendInputX + u(8), friendInputY + u(7), friendNameInput.isEmpty() && !friendNameFocus ? Theme.TEXT_DIM : Theme.TEXT, S * .78f);
        configButton(g, friendAddX, friendInputY, u(49), u(25), lang("Add +", "Добавить +"), mx, my);

        friendListY = y0 + u(76); friendListH = friendPageH - u(86); friendRowH = u(31);
        List<FriendsManager.Entry> entries = new ArrayList<>(FriendsManager.all());
        int visibleRows = Math.max(1, friendListH / friendRowH);
        friendListScroll = Math.max(0, Math.min(friendListScroll, Math.max(0, entries.size() - visibleRows)));
        Draw.scissor(g, x0 + u(6), friendListY, friendLeftW - u(12), friendListH);
        for (int i = friendListScroll; i < Math.min(entries.size(), friendListScroll + visibleRows + 1); i++) {
            FriendsManager.Entry entry = entries.get(i);
            int rowY = friendListY + (i - friendListScroll) * friendRowH;
            boolean active = entry.name.equalsIgnoreCase(selectedFriend);
            boolean hover = Draw.hover(mx, my, x0 + u(8), rowY, friendLeftW - u(16), friendRowH - u(3));
            Draw.round(g, x0 + u(8), rowY, friendLeftW - u(16), friendRowH - u(3), u(5), active ? 0xFF292F48 : hover ? Theme.DARK_HOVER : 0xFF171C2B);
            Draw.round(g, x0 + u(15), rowY + u(8), u(12), u(12), u(3), 0xFF000000 | FriendsManager.colorFor(entry.name));
            Draw.text(g, entry.name, x0 + u(34), rowY + u(8), active ? Theme.TEXT : Theme.TEXT_DIM, S * .82f);
            int removeX = x0 + friendLeftW - u(31);
            Draw.centered(g, "×", removeX + u(8), rowY + u(7), Theme.TEXT_DIM, S * 1.0f);
            if (entry.customColor) Draw.round(g, removeX - u(9), rowY + u(9), u(5), u(5), u(2), Theme.accent());
        }
        Draw.unscissor(g);
        if (entries.isEmpty()) Draw.text(g, lang("No friends yet", "Пока нет друзей"), x0 + u(13), friendListY + u(12), Theme.TEXT_DIM, S * .8f);

        Draw.panelBg(g, friendRightX, y0, friendRightW, friendPageH, u(9));
        friendHighlightY = y0 + u(10);
        int toggleW = friendRightW - u(20);
        Draw.round(g, friendRightX + u(10), friendHighlightY, toggleW, u(24), u(5), FriendsManager.highlightEnabled ? Theme.accent() : Theme.DARK);
        Draw.text(g, "Выделение друзей", friendRightX + u(17), friendHighlightY + u(6), FriendsManager.highlightEnabled ? Theme.TEXT : Theme.TEXT_DIM, S * .78f);
        Draw.text(g, FriendsManager.highlightEnabled ? "ON" : "OFF", friendRightX + friendRightW - u(38), friendHighlightY + u(6), Theme.TEXT, S * .75f);

        syncFriendPalette();
        FriendsManager.Entry chosen = FriendsManager.find(selectedFriend);
        int headerY = y0 + u(43);
        String editorLabel = chosen == null ? "Общий цвет друзей" : "Цвет: " + chosen.name;
        Draw.textBold(g, editorLabel, friendRightX + u(10), headerY, Theme.TEXT, S * .82f);
        friendOverrideY = y0 + u(59);
        friendOverrideX = friendRightX + u(10);
        friendOverrideW = friendRightW - u(20);
        if (chosen != null) {
            Draw.round(g, friendOverrideX, friendOverrideY, friendOverrideW, u(21), u(5), chosen.customColor ? Theme.accent() : Theme.DARK);
            Draw.text(g, "Индивидуальный цвет: " + (chosen.customColor ? "ON" : "OFF"), friendOverrideX + u(7), friendOverrideY + u(5), chosen.customColor ? Theme.TEXT : Theme.TEXT_DIM, S * .72f);
        } else {
            Draw.text(g, "Настрой общий цвет для остальных", friendRightX + u(10), friendOverrideY + u(5), Theme.TEXT_DIM, S * .66f);
        }

        friendPreviewX = friendRightX + u(10); friendPreviewY = y0 + u(88);
        friendPreviewW = Math.min(u(132), Math.max(u(88), friendRightW / 3));
        friendPreviewH = Math.min(u(205), friendPageH - u(104));
        Draw.round(g, friendPreviewX, friendPreviewY, friendPreviewW, friendPreviewH, u(7), 0xFF151A28);
        Draw.text(g, lang("LEATHER", "КОЖАНАЯ БРОНЯ"), friendPreviewX + u(8), friendPreviewY + u(8), Theme.TEXT_DIM, S * .60f);
        Draw.text(g, lang("PREVIEW", "ПРЕВЬЮ"), friendPreviewX + u(8), friendPreviewY + u(20), Theme.TEXT_DIM, S * .68f);
        drawFriendDoll(g, friendPreviewX, friendPreviewY, friendPreviewW, friendPreviewH, getActiveFriendColor(), mx, my);
        if (!FriendsManager.highlightEnabled) Draw.text(g, lang("Preview only", "Только превью"), friendPreviewX + u(8), friendPreviewY + friendPreviewH - u(17), Theme.TEXT_DIM, S * .62f);

        friendPickerX = friendPreviewX + friendPreviewW + u(14);
        friendPickerY = y0 + u(91);
        int paletteAvail = friendRightW - friendPreviewW - u(40);
        friendPickerSVW = Math.max(u(68), paletteAvail - u(23));
        // Clamp for narrower GUI widths while preserving the hue strip.
        friendPickerSVW = Math.min(friendPickerSVW, Math.max(u(68), friendRightX + friendRightW - friendPickerX - u(30)));
        friendPickerSVH = Math.min(u(105), Math.max(u(70), friendPageH - u(193)));
        friendHueX = friendPickerX + friendPickerSVW + u(7); friendHueW = u(12);
        Shapes.picker(g, friendPickerX, friendPickerY, friendPickerSVW, friendPickerSVH, u(5), friendHue);
        int knob = u(9), kx = friendPickerX + Math.round(friendSat * friendPickerSVW), ky = friendPickerY + Math.round((1f - friendVal) * friendPickerSVH);
        Draw.round(g, kx - knob / 2, ky - knob / 2, knob, knob, knob / 2, 0xFFFFFFFF);
        Draw.round(g, kx - knob / 2 + u(2), ky - knob / 2 + u(2), knob - u(4), knob - u(4), Math.max(1, (knob - u(4)) / 2), 0xFF000000 | getActiveFriendColor());
        Shapes.hueBar(g, friendHueX, friendPickerY, friendHueW, friendPickerSVH);
        int hueMarkerY = friendPickerY + Math.round(friendHue * friendPickerSVH);
        Draw.round(g, friendHueX - u(2), hueMarkerY - u(3), friendHueW + u(4), u(6), u(3), 0xFFFFFFFF);
        friendPaletteHexY = friendPickerY + friendPickerSVH + u(8);
        String colorHex = String.format("#%06X", getActiveFriendColor() & 0xFFFFFF);
        Draw.text(g, colorHex, friendPickerX, friendPaletteHexY, Theme.TEXT, S * .78f);
        Draw.text(g, chosen != null && chosen.customColor ? lang("Individual", "Личный") : lang("Shared", "Общий"), friendPickerX + u(64), friendPaletteHexY, Theme.TEXT_DIM, S * .65f);
        friendPresetsY = friendPaletteHexY + u(23);
        int[] presets = friendPresets();
        int pGap = u(4), pSize = Math.max(u(12), Math.min(u(20), (friendRightX + friendRightW - friendPickerX - u(6) - (presets.length - 1) * pGap) / presets.length));
        friendPresetW = pSize;
        for (int i = 0; i < presets.length; i++) {
            int px = friendPickerX + i * (pSize + pGap);
            Draw.round(g, px, friendPresetsY, pSize, pSize, u(4), 0xFF000000 | presets[i]);
            if ((getActiveFriendColor() & 0xFFFFFF) == presets[i]) Draw.round(g, px - u(1), friendPresetsY - u(1), pSize + u(2), pSize + u(2), u(4), 0x99FFFFFF);
        }
        Draw.text(g, lang("Click a name to preview its color", "Нажми на ник, чтобы увидеть его цвет"), friendRightX + u(10), y0 + friendPageH - u(24), Theme.TEXT_DIM, S * .65f);
    }

    private int friendOverrideX, friendOverrideW, friendPresetW;
    private static int[] friendPresets() {
        return new int[]{0x7CFC00, 0x42E8FF, 0x478BFF, 0x9D5CFF, 0xFF4FBC, 0xFF9638, 0xFF4545, 0xF5F7FF};
    }

    /** Render a real Minecraft player model with dyed leather armor in the Friends palette preview. */
    private void drawFriendDoll(GuiGraphics g, int x0, int y0, int w0, int h0, int rgb, double mouseX, double mouseY) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || !(client.level instanceof ClientLevel level)) return;

        // If this friend is online, use their actual profile/skin. For an offline friend, use the local skin as a placeholder.
        Player skinSource = client.player;
        if (selectedFriend != null && !selectedFriend.isBlank()) {
            for (Player candidate : level.players()) {
                if (candidate.getName().getString().equalsIgnoreCase(selectedFriend)) {
                    skinSource = candidate;
                    break;
                }
            }
        }
        com.mojang.authlib.GameProfile profile = skinSource.getGameProfile();
        if (friendPreviewEntity == null || friendPreviewLevel != level
                || friendPreviewProfile == null || !friendPreviewProfile.equals(profile.id())) {
            friendPreviewEntity = new RemotePlayer(level, profile);
            friendPreviewLevel = level;
            friendPreviewProfile = profile.id();
        }

        RemotePlayer model = friendPreviewEntity;
        model.setPos(0.0, 0.0, 0.0);
        model.setYRot(180.0F);
        model.setXRot(0.0F);
        model.yRotO = 180.0F;
        model.xRotO = 0.0F;
        model.setYBodyRot(180.0F);
        model.setYHeadRot(180.0F);
        model.setItemSlot(EquipmentSlot.HEAD, dyedLeather(Items.LEATHER_HELMET, rgb));
        model.setItemSlot(EquipmentSlot.CHEST, dyedLeather(Items.LEATHER_CHESTPLATE, rgb));
        model.setItemSlot(EquipmentSlot.LEGS, dyedLeather(Items.LEATHER_LEGGINGS, rgb));
        model.setItemSlot(EquipmentSlot.FEET, dyedLeather(Items.LEATHER_BOOTS, rgb));

        int left = x0 + u(3);
        int top = y0 + u(30);
        int right = x0 + w0 - u(3);
        int bottom = y0 + h0 - u(17);
        if (right <= left || bottom <= top) return;

        // The renderer uses the game's real skin, body model, armor layers and shading.
        g.enableScissor(left, top, right, bottom);
        try {
            int modelScale = Math.max(u(20), Math.min(u(38), w0 / 3));
            InventoryScreen.renderEntityInInventoryFollowsMouse(
                    g, left, top, right, bottom, modelScale, 0.0F,
                    (float) mouseX, (float) mouseY, model);
        } finally {
            g.disableScissor();
        }
    }

    private static ItemStack dyedLeather(Item item, int rgb) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.DYED_COLOR, new DyedItemColor(rgb & 0xFFFFFF));
        return stack;
    }

    private static int opaque(int rgb) { return 0xFF000000 | (rgb & 0xFFFFFF); }

    private static int shade(int rgb, float factor) {
        int r = Math.max(0, Math.min(255, Math.round(((rgb >>> 16) & 255) * factor)));
        int g = Math.max(0, Math.min(255, Math.round(((rgb >>> 8) & 255) * factor)));
        int b = Math.max(0, Math.min(255, Math.round((rgb & 255) * factor)));
        return (r << 16) | (g << 8) | b;
    }

    private String activeFriendPaletteKey() {
        return FriendsManager.hasCustomColor(selectedFriend) ? selectedFriend.toLowerCase(java.util.Locale.ROOT) : "@global";
    }

    private int getActiveFriendColor() {
        return "@global".equals(activeFriendPaletteKey()) ? FriendsManager.globalColor : FriendsManager.colorFor(selectedFriend);
    }

    private void setActiveFriendColor(int rgb) {
        if ("@global".equals(activeFriendPaletteKey())) FriendsManager.setGlobalColor(rgb);
        else FriendsManager.setFriendColor(selectedFriend, rgb);
    }

    private void syncFriendPalette() {
        String owner = activeFriendPaletteKey();
        if (owner.equals(friendPaletteOwner)) return;
        friendPaletteOwner = owner;
        float[] hsv = rgbToHsv(getActiveFriendColor());
        friendHue = hsv[0]; friendSat = hsv[1]; friendVal = hsv[2];
    }

    private void applyFriendHsv() { setActiveFriendColor(hsvToRgb(friendHue, friendSat, friendVal)); }

    private void updateFriendPalette(double mx, double my) {
        if (friendPaletteDrag == 0) {
            friendSat = Math.max(0, Math.min(1, (float) ((mx - friendPickerX) / Math.max(1, friendPickerSVW))));
            friendVal = 1f - Math.max(0, Math.min(1, (float) ((my - friendPickerY) / Math.max(1, friendPickerSVH))));
        } else {
            friendHue = Math.max(0, Math.min(1, (float) ((my - friendPickerY) / Math.max(1, friendPickerSVH))));
        }
        applyFriendHsv();
    }

    private static float[] rgbToHsv(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min, h0;
        if (d == 0) h0 = 0;
        else if (max == r) h0 = ((g - b) / d) % 6;
        else if (max == g) h0 = (b - r) / d + 2;
        else h0 = (r - g) / d + 4;
        h0 /= 6f; if (h0 < 0) h0 += 1f;
        return new float[]{h0, max == 0 ? 0 : d / max, max};
    }

    private static int hsvToRgb(float h0, float s0, float v0) {
        float hh = (h0 % 1f) * 6f; int i = (int) hh; float f = hh - i;
        float p0 = v0 * (1 - s0), q = v0 * (1 - s0 * f), t = v0 * (1 - s0 * (1 - f)), r0, g0, b0;
        switch (i) {
            case 0 -> { r0 = v0; g0 = t; b0 = p0; }
            case 1 -> { r0 = q; g0 = v0; b0 = p0; }
            case 2 -> { r0 = p0; g0 = v0; b0 = t; }
            case 3 -> { r0 = p0; g0 = q; b0 = v0; }
            case 4 -> { r0 = t; g0 = p0; b0 = v0; }
            default -> { r0 = v0; g0 = p0; b0 = q; }
        }
        return (Math.round(r0 * 255) << 16) | (Math.round(g0 * 255) << 8) | Math.round(b0 * 255);
    }

    private void addFriendFromInput() {
        if (FriendsManager.add(friendNameInput)) {
            selectedFriend = friendNameInput.trim();
            friendNameInput = "";
            friendNameFocus = false;
            friendListScroll = Math.max(0, FriendsManager.all().size() - 1);
            syncFriendPalette();
        } else {
            profileMessage = "Проверь ник (1–16: буквы, цифры, _)";
            profileMessageUntil = System.currentTimeMillis() + 1800;
        }
    }

    private boolean friendsClicked(double mx, double my, int btn) {
        if (btn != 0) return true;
        if (Draw.hover(mx, my, friendInputX, friendInputY, friendInputW, u(25))) {
            friendNameFocus = true; profileNameFocus = false; searchFocus = false; return true;
        }
        if (Draw.hover(mx, my, friendAddX, friendInputY, u(49), u(25))) { addFriendFromInput(); return true; }
        if (Draw.hover(mx, my, friendRightX + u(10), friendHighlightY, friendRightW - u(20), u(24))) {
            FriendsManager.highlightEnabled = !FriendsManager.highlightEnabled; FriendsManager.save(); friendNameFocus = false; return true;
        }
        if (Draw.hover(mx, my, friendPageX + u(8), friendListY, friendLeftW - u(16), friendListH)) {
            List<FriendsManager.Entry> entries = new ArrayList<>(FriendsManager.all());
            int idx = friendListScroll + (int) ((my - friendListY) / Math.max(1, friendRowH));
            if (idx >= 0 && idx < entries.size()) {
                FriendsManager.Entry entry = entries.get(idx);
                int removeX = friendPageX + friendLeftW - u(31);
                if (mx >= removeX - u(7) && mx <= removeX + u(12)) {
                    FriendsManager.remove(entry.name);
                    if (entry.name.equalsIgnoreCase(selectedFriend)) selectedFriend = "";
                    syncFriendPalette();
                } else {
                    selectedFriend = entry.name;
                    friendNameFocus = false;
                    syncFriendPalette();
                }
            }
            return true;
        }
        FriendsManager.Entry chosen = FriendsManager.find(selectedFriend);
        if (chosen != null && Draw.hover(mx, my, friendOverrideX, friendOverrideY, friendOverrideW, u(21))) {
            FriendsManager.setCustomColor(chosen.name, !chosen.customColor);
            syncFriendPalette();
            return true;
        }
        if (Draw.hover(mx, my, friendPickerX, friendPickerY, friendPickerSVW, friendPickerSVH)) {
            friendPaletteDrag = 0; updateFriendPalette(mx, my); return true;
        }
        if (Draw.hover(mx, my, friendHueX, friendPickerY, friendHueW, friendPickerSVH)) {
            friendPaletteDrag = 1; updateFriendPalette(mx, my); return true;
        }
        int[] presets = friendPresets();
        int gap0 = u(4), size = friendPresetW;
        for (int i = 0; i < presets.length; i++) {
            int px = friendPickerX + i * (size + gap0);
            if (Draw.hover(mx, my, px - u(1), friendPresetsY - u(1), size + u(2), size + u(2))) {
                float[] hsv = rgbToHsv(presets[i]);
                friendHue = hsv[0]; friendSat = hsv[1]; friendVal = hsv[2];
                setActiveFriendColor(presets[i]); FriendsManager.save();
                return true;
            }
        }
        friendNameFocus = false;
        return true;
    }

    private void chooseConfigFile(){
        NativeFilePicker.choose(ConfigProfiles.directory(),"Choose config (.properties / .cfg)",new String[]{".properties",".cfg"},file->{
            String imported=ConfigProfiles.importFrom(file);
            if(imported==null){profileMessage="Import failed";}else{selectedProfile=imported;profileMessage="Imported: "+imported;profileScroll=0;}
            profileMessageUntil=System.currentTimeMillis()+2200;
        },()->{
            profileMessage="Файл-диалог недоступен: скопируйте конфиг в config/nebula/configs";
            profileMessageUntil=System.currentTimeMillis()+3000;
        });
    }

    private void configButton(GuiGraphics g,int bx,int by,int bw,int bh,String label,double mx,double my){Draw.round(g,bx,by,bw,bh,u(5),Draw.hover(mx,my,bx,by,bw,bh)?Theme.DARK_HOVER:Theme.DARK);Draw.centered(g,label,bx+bw/2f,by+(bh-Draw.height(S*.8f))/2,Theme.TEXT,S*.8f);}

    // ---- settings sections: header + chips (Bool = on/off chip, Mode = one chip per option), rows for sliders / buttons ----
    private static final class SItem { Setting<?> s; int opt=-1, kind, x, y, w, h; String text; }   // kind: 0 header, 1 label, 2 bool chip, 3 mode chip, 4 row
    private static final class SLayout { final List<SItem> items=new ArrayList<>(); int height; }
    private SItem item(SLayout L,int kind,Setting<?> s,String text,int x,int y,int w,int h){SItem it=new SItem();it.kind=kind;it.s=s;it.text=text;it.x=x;it.y=y;it.w=w;it.h=h;L.items.add(it);return it;}
    private SLayout layoutSettings(List<Setting<?>> list,int width){
        SLayout L=new SLayout(); int y=0,cx=0,chipH=u(22),gap=u(6); boolean open=false; String cur=null;
        java.util.Map<String,Integer> count=new java.util.HashMap<>();
        for(Setting<?> s:list)if(s.group!=null)count.merge(s.group,1,Integer::sum);
        for(Setting<?> s:list){
            boolean boolChip=s instanceof Setting.Bool&&s.chip!=null&&s.group!=null, modeChip=s instanceof Setting.Mode&&s.group!=null;
            if(s.group!=null&&!s.group.equals(cur)){
                if(open){y+=chipH+gap;open=false;cx=0;}
                if(cur!=null)y+=u(6);
                item(L,0,s,s.group+":",0,y,width,u(18)); y+=u(20); cur=s.group;
            }
            if(boolChip){
                String t=s.chip; int cw=Draw.width(t,S*.8f)+u(18);
                if(open&&cx+cw>width){y+=chipH+gap;cx=0;}
                item(L,2,s,t,cx,y,cw,chipH); cx+=cw+gap; open=true;
            } else if(modeChip){
                if(open){y+=chipH+gap;open=false;cx=0;}
                Setting.Mode m=(Setting.Mode)s;
                if(count.getOrDefault(s.group,0)>1){item(L,1,s,settingLabel(s.name),0,y,width,u(14));y+=u(15);}
                for(int i=0;i<m.modes.length;i++){
                    String t=settingValue(m.modes[i]); int cw=Draw.width(t,S*.8f)+u(18);
                    if(open&&cx+cw>width){y+=chipH+gap;cx=0;}
                    SItem it=item(L,3,s,t,cx,y,cw,chipH); it.opt=i; cx+=cw+gap; open=true;
                }
                y+=chipH+gap;open=false;cx=0;
            } else {
                if(open){y+=chipH+gap;open=false;cx=0;}
                item(L,4,s,"",0,y,width,u(34)); y+=u(34);
            }
        }
        if(open)y+=chipH+gap;
        L.height=y; return L;
    }
    private void drawChip(GuiGraphics g,String t,int x,int y,int w,int h,boolean on,double mx,double my){
        boolean hov=Draw.hover(mx,my,x,y,w,h);
        Draw.moduleBg(g,x,y,w,h,Math.min(u(7),h/2),on,hov?0.8:0);
        Draw.centered(g,t,x+w/2f,y+(h-Draw.height(S*.8f))/2f,on?Theme.TEXT:Theme.moduleText(false),S*.8f);
    }
    private void renderSettings(GuiGraphics g,SLayout L,int ox,int oy,double mx,double my){
        for(SItem it:L.items){
            int ix=ox+it.x,iy=oy+it.y;
            switch(it.kind){
                case 0 -> Draw.textBold(g,it.text,ix,iy+u(2),Theme.TEXT,S*.85f);
                case 1 -> Draw.text(g,it.text,ix,iy,Theme.TEXT_DIM,S*.72f);
                case 2 -> drawChip(g,it.text,ix,iy,it.w,it.h,((Setting.Bool)it.s).value,mx,my);
                case 3 -> {Setting.Mode m=(Setting.Mode)it.s;drawChip(g,it.text,ix,iy,it.w,it.h,m.modes[it.opt].equals(m.value),mx,my);}
                default -> drawSetting(g,it.s,ix,iy,it.w,mx);
            }
        }
    }
    /** Click on a settings layout drawn at (ox, oy). True when something was hit. */
    private boolean clickSettings(SLayout L,int ox,int oy,double mx,double my,Setting.Key prevKey){
        for(SItem it:L.items){
            if(it.kind<2)continue;
            int ix=ox+it.x,iy=oy+it.y,pad=it.kind==4?u(6):0;
            if(!Draw.hover(mx,my,ix-pad,iy,it.w+pad*2,it.kind==4?it.h-u(2):it.h))continue;
            if(it.kind==2){Setting.Bool b=(Setting.Bool)it.s;b.value=!b.value;}
            else if(it.kind==3){Setting.Mode m=(Setting.Mode)it.s;m.value=m.modes[it.opt];}
            else{
                Setting<?> s=it.s;
                if(s instanceof Setting.Bool b)b.value=!b.value;
                else if(s instanceof Setting.Mode m)m.next();
                else if(s instanceof Setting.Action a)a.run.run();
                else if(s instanceof Setting.Key k){if(prevKey!=k)Binds.listeningSetting=k;}
                else if(s instanceof Setting.Num n){dragging=n;dragW=u(78);dragX=ix+it.w-dragW;n.set(n.min+(mx-dragX)/(double)dragW*(n.max-n.min));}
            }
            Config.save(); return true;
        }
        return false;
    }
    private void drawSetting(GuiGraphics g,Setting<?> s,int sx,int sy,int sw,double mx){
        int ty=sy+u(4); Draw.text(g,settingLabel(s.name),sx,ty,Theme.TEXT_DIM,S*.86f);
        if(s instanceof Setting.Bool b){int tw=u(28),th=u(14),tx=sx+sw-tw,yy=sy+u(3);Draw.round(g,tx,yy,tw,th,th/2,b.value?Theme.accent():Theme.SLIDER_BG);int d=th-u(4);Draw.round(g,b.value?tx+tw-d-u(2):tx+u(2),yy+u(2),d,d,d/2,Theme.TEXT);}
        else if(s instanceof Setting.Num n){int bw=u(78),bx=sx+sw-bw,bh=u(5),by=sy+u(25);if(dragging==n)n.set(n.min+(mx-dragX)/(double)dragW*(n.max-n.min));double p=Math.max(0,Math.min(1,(n.value-n.min)/(n.max-n.min)));Draw.round(g,bx,by,bw,bh,bh/2,Theme.SLIDER_BG);Draw.round(g,bx,by,Math.max(bh,(int)(bw*p)),bh,bh/2,Theme.accent());String v=String.valueOf(Math.round(n.value*100)/100.0);Draw.text(g,v,bx-Draw.width(v,S*.75f)-u(5),ty,Theme.TEXT,S*.75f);}
        else if(s instanceof Setting.Mode m){String mv=settingValue(m.value);Draw.text(g,mv,sx+sw-Draw.width(mv,S*.8f),ty,Theme.accent(),S*.8f);}
        else if(s instanceof Setting.Action)Draw.text(g,"Open >",sx+sw-Draw.width("Open >",S*.8f),ty,Theme.accent(),S*.8f);
        else if(s instanceof Setting.Key k){String kl=Binds.listeningSetting==k?"...":k.value<0?"NONE":Binds.name(k.value);Draw.text(g,kl,sx+sw-Draw.width(kl,S*.8f),ty,Theme.accent(),S*.8f);}
    }
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean dbl){
        int togglesBefore=ClientSounds.moduleToggles;
        boolean handled=mouseClicked0(e,dbl);
        if(handled&&togglesBefore==ClientSounds.moduleToggles)ClientSounds.play(ClientSounds.Event.GUI_CLICK);
        return handled;
    }
    private boolean mouseClicked0(MouseButtonEvent e,boolean dbl){
        calc();double mx=e.x()*gs,my=e.y()*gs;int btn=e.button();Setting.Key prevKey=Binds.listeningSetting;Binds.listeningSetting=null;
        int searchW=u(190),searchH=u(28),sx=x+w-u(18)-searchW,searchY=y+u(17);searchFocus=(page==Page.MODULES)&&Draw.hover(mx,my,sx,searchY,searchW,searchH);
        if(page==Page.MODULES&&btn==0){int[] tb=toggleRect();if(Draw.hover(mx,my,tb[0],tb[1],tb[2],tb[3])){Theme.settingsDown=!Theme.settingsDown;Theme.save();searchFocus=false;return true;}}
        int cy=y+u(98);for(Category c:Category.values()){if(Draw.hover(mx,my,x+u(14),cy,sideW-u(28),u(34))){category=c;page=Page.MODULES;search="";searchFocus=false;moduleScroll=moduleScrollT=0;selected=null;return true;}cy+=u(39);}
        if((page==Page.MODULES&&!Theme.settingsDown)&&selected!=null){int px=x+w-settingsW-u(12),py=y+u(12);if(btn==1&&Draw.hover(mx,my,px,py,settingsW,h)){selected=null;return true;}int sy0=py+u(68),avail=h-u(24)-u(80);if(btn==0&&my>=sy0&&my<sy0+avail&&clickSettings(layoutSettings(selected.visibleSettings(),settingsW-u(28)),px+u(14),sy0-(int)settingScroll,mx,my,prevKey))return true;}
        int customizeY=y+u(98)+Category.values().length*u(39)+u(30);
        for(int pi=0;pi<Page.values().length;pi++){int py=customizeY+pi*u(29);if(Draw.hover(mx,my,x+u(14),py,sideW-u(28),u(26))){if(page!=Page.values()[pi])search="";page=Page.values()[pi];selected=null;searchFocus=false;profileNameFocus=false;moduleScroll=moduleScrollT=0;return true;}}
        int cx=contentX(),cw=contentW(),cg=u(10),cols=Math.max(1,Math.min(4,Theme.modulesPerRow)),colW=(cw-cg*(cols-1))/cols,top=y+header+u(10),bottom=y+h-u(16);
        if(page==Page.COSMETICS){
            int top0=y+header+u(10);
            return clickCosmetics(mx,my,btn,cx,top0,cw);
        }
        if(page==Page.THEME){
            int ew=Math.min(u(270),Math.max(u(230),cw/2));
            if(themeEditor.mouseClicked(mx,my,btn))return true;
            int tx=cx+ew+u(12),ty=top,tw=Math.max(u(160),cw-ew-u(12));
            if(!Draw.hover(mx,my,tx,ty,tw,u(566)))return true;
            if(btn!=0)return true;
            if(surfaceSettingsPage){
                if(Draw.hover(mx,my,tx+tw-u(94),ty+u(5),u(86),u(20))){surfaceSettingsPage=false;themeDragIndex=-1;return true;}
                for(int group=0;group<3;group++){
                    int cardTop=ty+u(42)+group*u(145);
                    if(Draw.hover(mx,my,tx+u(8),cardTop,tw-u(16),u(136))){
                        for(int kind=0;kind<3;kind++){
                            int rowY=cardTop+u(27+kind*28);
                            if(Draw.hover(mx,my,tx+u(14),rowY-u(2),tw-u(28),u(18))){themeDragIndex=100+group*3+kind;updateThemeSlider(mx,themeDragIndex);Theme.save();return true;}
                        }
                        return true;
                    }
                }
                return true;
            }
            if(Draw.hover(mx,my,tx+tw-u(100),ty+u(4),u(92),u(22))){surfaceSettingsPage=true;themeDragIndex=-1;return true;}
            if(my>=ty+u(30)&&my<ty+u(240)){int idx=(int)((my-(ty+u(30)))/u(21));if(idx>=0&&idx<10){themeDragIndex=idx;updateThemeSlider(mx,idx);Theme.save();return true;}}
            for(int r=0;r<3;r++)if(my>=ty+u(263+r*24)&&my<ty+u(283+r*24)){themeEditor.selectExtra(r==0?2:r==1?1:0);return true;}
            if(Draw.hover(mx,my,tx+u(8),ty+u(338),tw-u(16),u(17))){Theme.outlineEnabled=!Theme.outlineEnabled;Theme.save();return true;}
            if(Draw.hover(mx,my,tx+u(8),ty+u(357),tw-u(16),u(17))){Theme.backgroundEnabled=!Theme.backgroundEnabled;Theme.save();return true;}
            if(Draw.hover(mx,my,tx+u(8),ty+u(376),tw-u(16),u(17))){CustomBackground.choose(false);return true;}
            if(Draw.hover(mx,my,tx+u(8),ty+u(395),tw-u(16),u(17))){Theme.menuBackgroundEnabled=!Theme.menuBackgroundEnabled;Theme.save();return true;}
            if(Draw.hover(mx,my,tx+u(8),ty+u(414),tw-u(16),u(17))){CustomBackground.choose(true);return true;}
            if(Draw.hover(mx,my,tx+u(8),ty+u(439),tw-u(16),u(14))){themeDragIndex=10;updateThemeSlider(mx,10);Theme.save();return true;}
            if(Draw.hover(mx,my,tx+u(8),ty+u(459),tw-u(16),u(14))){themeDragIndex=11;updateThemeSlider(mx,11);Theme.save();return true;}
            int by=ty+u(495);for(int i=0;i<4;i++)if(Draw.hover(mx,my,tx+u(9)+i*u(38),by,u(33),u(16))){switch(i){case 0->Theme.outlineTopLeft=!Theme.outlineTopLeft;case 1->Theme.outlineTopRight=!Theme.outlineTopRight;case 2->Theme.outlineBottomLeft=!Theme.outlineBottomLeft;case 3->Theme.outlineBottomRight=!Theme.outlineBottomRight;}Theme.save();return true;}
            if(Draw.hover(mx,my,tx+u(75),ty+u(525),u(78),u(19))){Theme.language=Theme.language.equals("RU")?"EN":"RU";Theme.save();return true;}
            return true;
        }
        if(page==Page.CONFIGS){int pw0=Math.min(u(340),cw),px=cx,py=top;if(Draw.hover(mx,my,px,py,pw0,u(390))){if(btn!=0)return true;if(Draw.hover(mx,my,px+u(10),py+u(38),pw0-u(20),u(28))){profileNameFocus=true;searchFocus=false;return true;}if(Draw.hover(mx,my,px+u(10),py+u(74),pw0-u(20),u(25))){boolean ok=ConfigProfiles.save(profileName);profileMessage=ok?"Saved/overwritten: "+profileName:"Save failed";profileMessageUntil=System.currentTimeMillis()+1800;selectedProfile=ConfigProfiles.normalizeName(profileName);profileScroll=0;return true;}int yy=py+u(108);List<String> names=ConfigProfiles.list();profileScroll=Math.max(0,Math.min(profileScroll,Math.max(0,names.size()-7)));for(String n:names.stream().skip(profileScroll).limit(7).toList()){if(Draw.hover(mx,my,px+u(10),yy,pw0-u(20),u(24))){selectedProfile=n;return true;}yy+=u(28);}int by=py+u(310),gap=u(5),bw=(pw0-u(28)-gap*2)/3;if(Draw.hover(mx,my,px+u(10),by,bw,u(22))){boolean ok=ConfigProfiles.load(selectedProfile);profileMessage=ok?"Loaded: "+selectedProfile:"Select a config";profileMessageUntil=System.currentTimeMillis()+1800;return true;}if(Draw.hover(mx,my,px+u(14)+bw,by,bw,u(22))){boolean ok=ConfigProfiles.delete(selectedProfile);profileMessage=ok?"Deleted":"Delete failed";profileMessageUntil=System.currentTimeMillis()+1800;selectedProfile="";profileScroll=Math.max(0,profileScroll-1);return true;}if(Draw.hover(mx,my,px+u(18)+bw*2+gap*2,by,bw,u(22))){chooseConfigFile();return true;}return true;}}
        if(page==Page.FRIENDS) return friendsClicked(mx,my,btn);
        if(page!=Page.MODULES)return super.mouseClicked(e,dbl);
        List<Mod> mods=visible();
        if(Theme.settingsDown&&panelMod!=null&&selected!=null){
            int si=mods.indexOf(panelMod);
            if(si>=0){
                int ph=panelH(colW),px0=cx+(si%cols)*(colW+cg),py0=top+(si/cols+1)*row-(int)moduleScroll-u(2);
                if(Draw.hover(mx,my,px0,py0,colW,Math.max(1,ph-u(4)))&&my>=top&&my<bottom){
                    if(btn==1){selected=null;return true;}
                    if(btn==0)clickSettings(layoutSettings(panelMod.visibleSettings(),colW-u(24)),px0+u(12),py0+u(10),mx,my,prevKey);
                    return true;
                }
            }
        }
        for(int i=0;i<mods.size();i++){Mod m=mods.get(i);int col=i%cols,r=i/cols,mx0=cx+col*(colW+cg),my0=top+r*row-(int)moduleScroll+shift(i,cols,mods,colW);if(Draw.hover(mx,my,mx0,my0,colW,row-u(6))&&my>=top&&my<bottom){if(btn==1){selected=selected==m?null:m;settingScroll=settingScrollT=0;}else if(btn==0){m.toggle();Config.save();}else if(btn==2)Binds.listening=Binds.listening==m?null:m;return true;}}
        if(btn!=2)Binds.listening=null;
        return super.mouseClicked(e,dbl);
    }
    @Override public boolean mouseReleased(MouseButtonEvent e){dragging=null;themeDragIndex=-1;if(friendPaletteDrag>=0)FriendsManager.save();friendPaletteDrag=-1;themeEditor.mouseReleased();Theme.save();Config.save();return super.mouseReleased(e);}
    @Override public boolean mouseScrolled(double mx,double my,double sx,double sy){
        double ms0=moduleScrollT,ss0=settingScrollT;
        boolean handled=mouseScrolled0(mx,my,sx,sy);
        if(ms0!=moduleScrollT||ss0!=settingScrollT)ClientSounds.play(ClientSounds.Event.GUI_SCROLL);
        return handled;
    }
    private boolean mouseScrolled0(double mx,double my,double sx,double sy){calc();double px=mx*gs,py=my*gs;if(page==Page.FRIENDS){if(Draw.hover(px,py,friendPageX,friendListY,friendLeftW,friendListH)){int count=FriendsManager.all().size();int visible=Math.max(1,friendListH/Math.max(1,friendRowH));friendListScroll=Math.max(0,Math.min(Math.max(0,count-visible),friendListScroll-(int)Math.signum(sy)*2));return true;}return false;}if(page==Page.CONFIGS){int cx0=contentX(),cw0=contentW(),top0=y+header+u(10),pw0=Math.min(u(340),cw0);if(Draw.hover(px,py,cx0+u(8),top0+u(104),pw0-u(16),u(198))){int count=ConfigProfiles.list().size();profileScroll=Math.max(0,Math.min(Math.max(0,count-7),profileScroll-(int)Math.signum(sy)*2));return true;}return false;}if(page!=Page.MODULES)return false;if(selected!=null&&(!Theme.settingsDown)&&Draw.hover(px,py,x+w-settingsW-u(12),y+u(60),settingsW,h-u(72))){settingScrollT=Math.max(0,Math.min(Math.max(0,layoutSettings(selected.visibleSettings(),settingsW-u(28)).height-(h-u(24)-u(80))),settingScrollT-sy*u(24)));return true;}int cols0=Math.max(1,Math.min(4,Theme.modulesPerRow)),colW0=(contentW()-u(10)*(cols0-1))/cols0;int count=visible().size();int rows=(count+cols0-1)/cols0;int itemStep=row;int viewport=h-header-u(30);moduleScrollT=Math.max(0,Math.min(Math.max(0,rows*itemStep+(page==Page.MODULES?panelH(colW0):0)-viewport),moduleScrollT-sy*u(28)));return true;}
    @Override public boolean keyPressed(KeyEvent e){if(Binds.listeningSetting!=null){int k=e.key();Setting.Key ks=Binds.listeningSetting;if(k==GLFW.GLFW_KEY_BACKSPACE||k==GLFW.GLFW_KEY_DELETE){ks.value=-1;ks.down=false;}else if(k!=GLFW.GLFW_KEY_ESCAPE){ks.value=k;ks.down=true;}Binds.listeningSetting=null;Config.save();return true;}if(Binds.listening!=null){int k=e.key();if(k==GLFW.GLFW_KEY_BACKSPACE||k==GLFW.GLFW_KEY_DELETE)Binds.listening.bind=-1;else if(k!=GLFW.GLFW_KEY_ESCAPE){Binds.listening.bind=k;Binds.listening.bindDown=true;}Binds.listening=null;Config.save();return true;}if(page==Page.CONFIGS && profileNameFocus && e.key()==GLFW.GLFW_KEY_BACKSPACE && !profileName.isEmpty()){profileName=profileName.substring(0,profileName.length()-1);return true;}if(page==Page.FRIENDS&&friendNameFocus){if(e.key()==GLFW.GLFW_KEY_BACKSPACE&&!friendNameInput.isEmpty()){friendNameInput=friendNameInput.substring(0,friendNameInput.length()-1);return true;}if(e.key()==GLFW.GLFW_KEY_ENTER){addFriendFromInput();return true;}if(e.key()==GLFW.GLFW_KEY_ESCAPE){friendNameFocus=false;return true;}}if(searchFocus){if(e.key()==GLFW.GLFW_KEY_BACKSPACE&&!search.isEmpty()){search=search.substring(0,search.length()-1);return true;}if(e.key()==GLFW.GLFW_KEY_ENTER||e.key()==GLFW.GLFW_KEY_ESCAPE){searchFocus=false;return true;}}if(e.key()==GLFW.GLFW_KEY_ESCAPE&&selected!=null){selected=null;return true;}return super.keyPressed(e);}
    @Override public boolean charTyped(CharacterEvent e){if(page==Page.CONFIGS&&profileNameFocus&&e.codepoint()>=32&&e.codepoint()<127&&profileName.length()<32){profileName+=Character.toString(e.codepoint());return true;}if(page==Page.FRIENDS&&friendNameFocus&&e.codepoint()>=32&&e.codepoint()<127&&friendNameInput.length()<16){friendNameInput+=Character.toString(e.codepoint());return true;}if(searchFocus){search+=Character.toString(e.codepoint());moduleScroll=moduleScrollT=0;return true;}return super.charTyped(e);}
}
