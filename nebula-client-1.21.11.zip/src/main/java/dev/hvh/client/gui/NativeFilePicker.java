package dev.hvh.client.gui;

import net.minecraft.client.Minecraft;

import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Opens the operating-system file chooser where AWT desktop dialogs are available. On headless/mobile runtimes,
 * opens the target directory in the platform file manager instead; the in-game picker can then be refreshed.
 */
public final class NativeFilePicker {
    private NativeFilePicker() {}

    public static void choose(Path directory, String title, String[] extensions,
                              Consumer<Path> onChosen, Runnable onFallback) {
        try { Files.createDirectories(directory); } catch (Exception ignored) { }
        try {
            if (GraphicsEnvironment.isHeadless()) {
                fallback(directory, onFallback);
                return;
            }
            EventQueue.invokeLater(() -> {
                Path selected = null;
                boolean unavailable = false;
                try {
                    FileDialog dialog = new FileDialog((Frame) null, title, FileDialog.LOAD);
                    dialog.setDirectory(directory.toAbsolutePath().toString());
                    dialog.setFilenameFilter((dir, name) -> {
                        String n = name.toLowerCase(Locale.ROOT);
                        return Arrays.stream(extensions).anyMatch(ext -> n.endsWith(ext.toLowerCase(Locale.ROOT)));
                    });
                    dialog.setVisible(true);
                    String file = dialog.getFile();
                    String dir = dialog.getDirectory();
                    if (file != null && dir != null) selected = Path.of(dir, file);
                    dialog.dispose();
                } catch (Throwable e) {
                    unavailable = true;
                }
                Path result = selected;
                boolean failed = unavailable;
                Minecraft.getInstance().execute(() -> {
                    if (result != null) onChosen.accept(result);
                    else if (failed) {
                        openDirectory(directory);
                        onFallback.run();
                    }
                });
            });
        } catch (Throwable unavailable) {
            fallback(directory, onFallback);
        }
    }

    private static void fallback(Path directory, Runnable onFallback) {
        openDirectory(directory);
        Minecraft.getInstance().execute(onFallback);
    }

    public static void openDirectory(Path directory) {
        try { Files.createDirectories(directory); } catch (Exception ignored) { }
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(directory.toFile());
            }
        } catch (Throwable ignored) {
            // Some mobile/headless runtimes do not expose a desktop file manager.
            // The caller's in-game file list remains available as a fallback.
        }
    }
}
