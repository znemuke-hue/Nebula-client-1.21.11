package dev.hvh.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Short branded startup screen, matching the reference splash: near-black background, logo/title and spinner. */
public final class NebulaLoadingScreen extends Screen {
    private final long started = System.nanoTime();
    private static final int WHITE = 0xFFF5F4FF;
    public NebulaLoadingScreen() { super(Component.literal("Nebula Client")); }
    @Override public boolean isPauseScreen(){ return false; }
    @Override public boolean shouldCloseOnEsc(){ return false; }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta){
        int w=width,h=height; double t=(System.nanoTime()-started)/1_000_000_000.0;
        g.fill(0,0,w,h,0xFF050509);
        // Subtle violet/cyan light pools and restrained vignette.
        g.fill(w/2-w/3,h/2-70,w/2+w/3,h/2+110,0x100D0B2C);
        g.fill(w/2-w/4,h/2-35,w/2+w/4,h/2+70,0x080A2340);
        int logo=u(Math.min(74,Math.max(48,h*.11)));
        Logo.draw(g,w/2-logo/2,h/2-logo-36,logo,WHITE);
        float scale=Math.max(.9f,Math.min(1.8f,h/520f));
        Draw.centeredBold(g,"Nebula Client",w/2f,h/2f+4,WHITE,scale*1.75f);
        Draw.centered(g,"INITIALIZING CLIENT",w/2f,h/2f+34*scale,0xFF8D91B0,scale*.72f);
        int r=Math.max(3,Math.round(5*scale)), cx=w/2,cy=h/2+78* Math.round(scale);
        for(int i=0;i<12;i++){
            double a=t*4.2+i*Math.PI*2/12;
            int alpha=(int)(45+210*((i+12-(int)(t*8)%12)%12)/11.0);
            int px=cx+(int)(Math.cos(a)*16*scale),py=cy+(int)(Math.sin(a)*16*scale);
            g.fill(px-r,py-r,px+r+1,py+r+1,(alpha<<24)|0xA99BFF);
        }
        int bw=Math.min(210,w/2),bh=Math.max(2,Math.round(3*scale)),bx=cx-bw/2,by=cy+30;
        g.fill(bx,by,bx+bw,by+bh,0xFF202235);
        float progress=(float)Math.min(1,t/2.8);g.fill(bx,by,bx+(int)(bw*progress),by+bh,0xFF8C83FF);
        Draw.centered(g,progress>=1?"READY":"Loading modules…",w/2f,by+12*scale,0xFF777D9B,scale*.72f);
        Draw.flush();
        if(t>=2.8 && minecraft!=null) minecraft.setScreen(new NebulaTitleScreen());
    }
    private int u(double n){return (int)Math.round(n);}
}
