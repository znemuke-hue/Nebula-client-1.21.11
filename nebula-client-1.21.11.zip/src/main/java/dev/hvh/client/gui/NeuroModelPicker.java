package dev.hvh.client.gui;

import dev.hvh.client.neuro.NeuroAim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * In-game selector for the AimAssist "Нейро" model. Lists the .onnx files of config/nebula/models and of the download
 * folders; tapping one copies it into the models folder (if needed), loads it and remembers it.
 * Same look and real-pixel layout as the other Nebula pickers.
 */
public final class NeuroModelPicker extends Screen {
    private final Screen previous;
    private final List<Path> files = new ArrayList<>();
    private int scroll;
    private String message = "";
    private boolean messageIsError;
    private float gs = 1f, S = 1f;
    private int x, y, w, h, pad, row, top, visible;

    public static void open() {
        dev.hvh.client.sound.ClientSounds.keepGui = true;
        Minecraft.getInstance().setScreen(new NeuroModelPicker());
    }

    private NeuroModelPicker() {
        super(Component.literal("Нейро модель"));
        this.previous = Minecraft.getInstance().screen;
        NeuroAim.ensureLoaded();
        files.addAll(NeuroAim.candidates());
        if (files.isEmpty()) message = "Моделей нет - скопируй .onnx в папку выше (или в Download)";
    }

    private int u(double v) { return (int) Math.round(v * S); }

    private void calc() {
        gs = (float) Math.max(1, minecraft.getWindow().getGuiScale());
        S = Math.max(.75f, Math.min(3f, minecraft.getWindow().getHeight() / 720f));
        Draw.SCALE = S;
        int sw = Math.round(width * gs), sh = Math.round(height * gs);
        w = Math.min(u(560), sw - u(24)); h = Math.min(u(540), sh - u(24));
        x = (sw - w) / 2; y = (sh - h) / 2; pad = u(14); row = u(32);
        top = y + u(112);
        visible = Math.max(1, (h - u(112) - u(56)) / row);
        int total = files.size() + 2;
        scroll = Math.max(0, Math.min(Math.max(0, total - visible), scroll));
    }

    private int listW() { return w - pad * 2 - u(40); }

    private String fitLeft(String s, float t, int maxW) {
        if (Draw.width(s, t) <= maxW) return s;
        while (s.length() > 4 && Draw.width("..." + s, t) > maxW) s = s.substring(1);
        return "..." + s;
    }

    private String fit(String s, float t, int maxW) {
        if (Draw.width(s, t) <= maxW) return s;
        while (s.length() > 2 && Draw.width(s + "...", t) > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int gmx, int gmy, float delta) {
        calc();
        double mx = gmx * gs, my = gmy * gs;
        g.pose().pushMatrix();
        g.pose().scale(1f / gs, 1f / gs);
        Draw.panelBg(g, x, y, w, h, u(Theme.cornerRadius));
        Draw.textBold(g, "Нейро: выбор модели", x + pad, y + u(14), Theme.TEXT, S * 1.15f);
        Draw.text(g, "Положи обученный .onnx в эту папку:", x + pad, y + u(40), Theme.TEXT_DIM, S * .72f);
        Draw.text(g, fitLeft(NeuroAim.modelsDir().toAbsolutePath().toString(), S * .68f, w - pad * 2), x + pad, y + u(55), Theme.accent(), S * .68f);

        String sel = NeuroAim.selectedName().isEmpty() ? "не выбрана" : NeuroAim.selectedName() + "  (" + NeuroAim.info() + ")";
        Draw.text(g, fit("Сейчас: " + sel, S * .72f, w - pad * 2), x + pad, y + u(74), Theme.TEXT, S * .72f);
        boolean err = messageIsError || (!NeuroAim.error().isEmpty() && message.isEmpty());
        String msg = !message.isEmpty() ? message : (!NeuroAim.error().isEmpty() ? "Ошибка: " + NeuroAim.error() : "Нажми на файл, чтобы использовать его");
        Draw.text(g, fit(msg, S * .72f, w - pad * 2), x + pad, y + u(90), err ? 0xFFFF7A7A : Theme.TEXT_DIM, S * .72f);

        int total = files.size() + 2, lw = listW();
        Draw.scissor(g, x + pad - u(2), top, lw + u(4), visible * row);
        for (int i = scroll; i < Math.min(total, scroll + visible); i++) {
            int yy = top + (i - scroll) * row;
            boolean hov = Draw.hover(mx, my, x + pad, yy, lw, row - u(4));
            Draw.round(g, x + pad, yy, lw, row - u(4), u(6), hov ? Theme.DARK_HOVER : Theme.DARK);
            String label;
            boolean selected = false;
            if (i == 0) {
                label = "Дефолт (сбалансированная ротация)";
                selected = NeuroAim.selectedName().equals("default-balanced.onnx") && NeuroAim.model() != null;
            } else if (i == 1) {
                label = "Нет (выключить нейро-модель)";
                selected = NeuroAim.model() == null;
            } else {
                Path f = files.get(i - 2);
                String n = f.getFileName().toString();
                selected = n.equals(NeuroAim.selectedName()) && NeuroAim.model() != null;
                label = (selected ? "✓ " : "") + n + (NeuroAim.inModelsDir(f) ? "" : "   [Download]");
            }
            if (selected) Draw.round(g, x + pad, yy, lw, row - u(4), u(6), Theme.accent());
            Draw.text(g, fit(label, S * .85f, lw - u(20)), x + pad + u(10), yy + (row - u(4) - Draw.height(S * .85f)) / 2, selected ? Theme.accent() : (i < 2 ? Theme.TEXT_DIM : Theme.TEXT), S * .85f);
        }
        Draw.unscissor(g);

        int bx = x + w - pad - u(32), bh = u(32);
        scrollButton(g, bx, top, u(32), bh, "^", mx, my);
        scrollButton(g, bx, top + bh + u(6), u(32), bh, "v", mx, my);
        Draw.text(g, scroll + 1 + "-" + Math.min(total, scroll + visible) + " / " + total, bx - u(2), top + bh * 2 + u(14), Theme.TEXT_DIM, S * .6f);

        int by = y + h - u(44), gap = u(6), bw = (w - pad * 2 - gap * 2) / 3;
        bottomButton(g, x + pad, by, bw, u(32), "Файл...", mx, my);
        bottomButton(g, x + pad + bw + gap, by, bw, u(32), "Обновить", mx, my);
        bottomButton(g, x + pad + (bw + gap) * 2, by, bw, u(32), "Назад", mx, my);
        Draw.flush();
        g.pose().popMatrix();
    }

    private void scrollButton(GuiGraphics g, int bx, int by, int bw, int bh, String label, double mx, double my) {
        Draw.round(g, bx, by, bw, bh, u(6), Draw.hover(mx, my, bx, by, bw, bh) ? Theme.DARK_HOVER : Theme.DARK);
        Draw.centered(g, label, bx + bw / 2f, by + (bh - Draw.height(S)) / 2, Theme.TEXT, S);
    }

    private void bottomButton(GuiGraphics g, int bx, int by, int bw, int bh, String label, double mx, double my) {
        Draw.round(g, bx, by, bw, bh, u(6), Draw.hover(mx, my, bx, by, bw, bh) ? Theme.DARK_HOVER : Theme.DARK);
        Draw.centered(g, label, bx + bw / 2f, by + (bh - Draw.height(S * .82f)) / 2, Theme.TEXT, S * .82f);
    }

    private void refreshFiles() {
        NeuroAim.ensureDir();
        files.clear();
        files.addAll(NeuroAim.candidates());
        message = "Найдено моделей: " + files.size();
        messageIsError = false;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, files.size() + 2 - visible)));
    }

    private void chooseFile() {
        NativeFilePicker.choose(NeuroAim.modelsDir(), "Choose Neuro ONNX model", new String[]{".onnx"}, file -> {
            String err = NeuroAim.select(file);
            if (err == null) close(); else { message = "Не удалось: " + err; messageIsError = true; }
        }, () -> {
            refreshFiles();
            message = "Файл-диалог недоступен: скопируйте .onnx в папку и нажмите Обновить";
        });
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        calc();
        double mx = e.x() * gs, my = e.y() * gs;
        if (e.button() != 0) return true;
        int total = files.size() + 2, lw = listW();
        int bx = x + w - pad - u(32), bh = u(32);
        if (Draw.hover(mx, my, bx, top, u(32), bh)) { scroll = Math.max(0, scroll - 3); return true; }
        if (Draw.hover(mx, my, bx, top + bh + u(6), u(32), bh)) { scroll = Math.min(Math.max(0, total - visible), scroll + 3); return true; }
        int by = y + h - u(44), gap = u(6), bw = (w - pad * 2 - gap * 2) / 3;
        if (Draw.hover(mx, my, x + pad, by, bw, u(32))) { chooseFile(); return true; }
        if (Draw.hover(mx, my, x + pad + bw + gap, by, bw, u(32))) { refreshFiles(); return true; }
        if (Draw.hover(mx, my, x + pad + (bw + gap) * 2, by, bw, u(32))) { close(); return true; }
        if (Draw.hover(mx, my, x + pad, top, lw, visible * row)) {
            int i = scroll + (int) ((my - top) / row);
            if (i >= 0 && i < total) {
                if (i == 0) {
                    String err = NeuroAim.select(NeuroAim.modelsDir().resolve("default-balanced.onnx"));
                    if (err == null) close(); else { message = "Не удалось: " + err; messageIsError = true; }
                    return true;
                }
                if (i == 1) { NeuroAim.select(null); refreshFiles(); message = "Модель отключена"; messageIsError = false; return true; }
                String err = NeuroAim.select(files.get(i - 2));
                if (err == null) close(); else { message = "Не удалось: " + err; messageIsError = true; }
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        int total = files.size() + 2;
        scroll = Math.max(0, Math.min(Math.max(0, total - visible), scroll - (int) Math.signum(sy) * 2));
        return true;
    }

    private void close() { Minecraft.getInstance().setScreen(previous); }

    @Override public void onClose() { close(); }
}
