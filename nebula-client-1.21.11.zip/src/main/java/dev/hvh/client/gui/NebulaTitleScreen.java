package dev.hvh.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.AlertScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.CommonComponents;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.Random;

/** A custom Nebula Client title screen with a built-in space background and useful client tips. */
public class NebulaTitleScreen extends Screen {
    private static final int CYAN = 0xFF65D8FF;
    private static final int VIOLET = 0xFF9B8CFF;
    private static final int SOFT_WHITE = 0xFFF4F6FF;
    private static final int MUTED = 0xFFB9C4E5;
    private static final int BG_W = 1024, BG_H = 576;
    private static final Atlas BG = new Atlas("menu_bg", BG_W, BG_H);
    private static Atlas.Region bg;

    private record Btn(String en, String ru, String hintEn, String hintRu, Runnable action) {}

    private final Btn[] btns;
    private final float[] hover;
    private final float[][] stars = new float[42][4]; // x, y (0..1), size, phase
    private final long t0 = System.nanoTime();
    private float gs = 1f, S = 1f;

    private static final String[] TIPS_EN = {
        "Press Right Shift to open the Click GUI.",
        "Right-click any module to edit its settings.",
        "Search helps you find modules in seconds.",
        "Theme lets you tune colors, outlines and UI scale.",
        "Save and restore your setup on the Configs page."
    };
    private static final String[] TIPS_RU = {
        "Нажми Right Shift, чтобы открыть Click GUI.",
        "ПКМ по модулю открывает его настройки.",
        "Поиск помогает быстрее находить модули.",
        "В Theme настраиваются цвета, обводки и масштаб.",
        "Сохраняй настройки на странице Configs."
    };

    public NebulaTitleScreen() {
        super(Component.literal("Nebula Client"));
        btns = new Btn[] {
            new Btn("Singleplayer", "Одиночная игра", "Play offline worlds", "Играй в одиночных мирах",
                () -> minecraft.setScreen(new SelectWorldScreen(this))),
            new Btn("Multiplayer", "Сетевая игра", "Join a server", "Подключись к серверу",
                () -> minecraft.setScreen(new JoinMultiplayerScreen(this))),
            new Btn("Modules", "Модули клиента", "Manage Nebula features", "Управляй функциями Nebula",
                () -> minecraft.setScreen(new ClickGuiScreen())),
            new Btn("Settings", "Настройки", "Game and interface", "Игра и интерфейс",
                () -> minecraft.setScreen(new OptionsScreen(this, minecraft.options))),
            new Btn("Accounts", "Аккаунты", "Open In-Game Account Switcher", "Открыть In-Game Account Switcher",
                this::openAccounts),
            new Btn("Quit Minecraft", "Выйти из Minecraft", "", "", () -> minecraft.stop())
        };
        hover = new float[btns.length];
        Random r = new Random(17);
        for (float[] s : stars) {
            s[0] = r.nextFloat();
            s[1] = r.nextFloat();
            s[2] = r.nextFloat() < 0.16f ? 2f : 1f;
            s[3] = r.nextFloat() * 6.28f;
        }
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }

    private static String lang(String en, String ru) {
        return Theme.language.equals("RU") ? ru : en;
    }

    private int u(double v) { return (int) Math.round(v * S); }
    private int rw() { return Math.round(width * gs); }
    private int rh() { return Math.round(height * gs); }

    private void calc() {
        gs = (float) Math.max(1, minecraft.getWindow().getGuiScale());
        S = Math.max(0.75f, Math.min(3f, minecraft.getWindow().getHeight() / 720f));
        Draw.SCALE = S;
    }

    private int marginX() { return u(64); }
    private int gridGap() { return u(11); }
    private int cardW() { return Math.min(u(235), Math.max(u(165), Math.round(rw() * 0.21f))); }
    private int cardH() { return u(58); }
    private int gridY() { return u(235); }
    private int cardX(int i) { return marginX() + (i % 2) * (cardW() + gridGap()); }
    private int cardY(int i) { return gridY() + (i / 2) * (cardH() + gridGap()); }
    private int cardW(int i) { return i == btns.length - 2 ? quitW() : cardW(); }
    private int mainRows() { return ((btns.length - 1) + 1) / 2; }
    private int quitY() { return gridY() + mainRows() * (cardH() + gridGap()) + u(7); }
    private int quitW() { return cardW() * 2 + gridGap(); }
    private int quitH() { return u(38); }
    private int tipY() { return quitY() + quitH() + u(18); }
    private int tipW() { return quitW(); }
    private int tipH() { return u(92); }

    /** Opens the real IAS account screen without making IAS a compile-time dependency. */
    private void openAccounts() {
        try {
            Class<?> type = Class.forName("ru.vidtu.ias.screen.AccountScreen", true,
                NebulaTitleScreen.class.getClassLoader());
            Object result = type.getConstructor(Screen.class).newInstance(this);
            if (result instanceof Screen accountScreen) {
                minecraft.setScreen(accountScreen);
                return;
            }
        } catch (ReflectiveOperationException | LinkageError ignored) {
            // IAS is optional. Show a helpful notice below when it is absent or incompatible.
        }
        String title = lang("Account Switcher unavailable", "Менеджер аккаунтов недоступен");
        String message = lang(
            "Install the Fabric version of In-Game Account Switcher for Minecraft 1.21.11, then reopen this menu.",
            "Установи Fabric-версию In-Game Account Switcher для Minecraft 1.21.11 и снова открой это меню."
        );
        minecraft.setScreen(new AlertScreen(() -> minecraft.setScreen(this), Component.literal(title),
            Component.literal(message), CommonComponents.GUI_BACK, true));
    }

    /** Load the bundled 16:9 background into an atlas texture once. A procedural fallback is kept for safety. */
    private static void bakeBackground() {
        if (bg != null) return;
        bg = BG.alloc(BG_W, BG_H);
        boolean loaded = false;
        try (InputStream in = NebulaTitleScreen.class.getResourceAsStream("/assets/hvhclient/textures/menu_background.png")) {
            if (in != null) {
                BufferedImage source = ImageIO.read(in);
                if (source != null) {
                    BufferedImage scaled = new BufferedImage(BG_W, BG_H, BufferedImage.TYPE_INT_ARGB);
                    Graphics2D graphics = scaled.createGraphics();
                    graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                    graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                    graphics.drawImage(source, 0, 0, BG_W, BG_H, null);
                    graphics.dispose();
                    for (int y = 0; y < BG_H; y++) {
                        for (int x = 0; x < BG_W; x++) {
                            int pixel = scaled.getRGB(x, y);
                            if ((pixel >>> 24) == 0) pixel = 0xFF050713;
                            BG.set(bg.x() + x, bg.y() + y, pixel);
                        }
                    }
                    loaded = true;
                }
            }
        } catch (Exception ignored) {
            // Use the procedural fallback below if a packaged texture cannot be decoded.
        }

        if (!loaded) {
            double[][] glows = {
                {0.30, 0.50, 250, 80, 55, 220, 0.36},
                {0.18, 0.78, 190, 35, 85, 230, 0.18},
                {0.78, 0.92, 220, 30, 140, 225, 0.14},
                {0.92, 0.06, 170, 110, 50, 220, 0.12}
            };
            for (int y = 0; y < BG_H; y++) {
                for (int x = 0; x < BG_W; x++) {
                    double r = 4, g = 5, b = 12;
                    for (double[] gl : glows) {
                        double dx = x - gl[0] * BG_W, dy = y - gl[1] * BG_H;
                        double d = Math.sqrt(dx * dx + dy * dy) / gl[2];
                        double k = Math.exp(-d * d * 2.6) * gl[6];
                        r += gl[3] * k; g += gl[4] * k; b += gl[5] * k;
                    }
                    double vx = (x / (double) BG_W - 0.5) * 2, vy = (y / (double) BG_H - 0.5) * 2;
                    double vig = 1 - 0.28 * Math.min(1, (vx * vx + vy * vy) / 2);
                    int ri = (int) Math.min(255, r * vig), gi = (int) Math.min(255, g * vig), bi = (int) Math.min(255, b * vig);
                    BG.set(bg.x() + x, bg.y() + y, 0xFF000000 | (ri << 16) | (gi << 8) | bi);
                }
            }
        }
        BG.flush();
    }

    @Override
    protected void init() {
        bakeBackground();
        CustomBackground.ensureLoaded();
    }

    /** A living constellation core replaces the ordinary chevrons and empty space on the right. */
    private void drawNebulaCore(GuiGraphics g, double time) {
        int x = Math.max(marginX() + quitW() + u(35), Math.round(rw() * 0.60f));
        int w = Math.min(u(370), rw() - x - marginX());
        int y = Math.round(rh() * 0.245f);
        int h = Math.min(u(370), rh() - y - u(105));
        if (w < u(190) || h < u(220)) return;

        Draw.round(g, x, y, w, h, u(14), 0xB70A1024);
        Draw.round(g, x + u(1), y + u(1), w - u(2), u(2), u(1), Draw.alpha(CYAN, 0.62));
        Draw.textBold(g, lang("NEBULA CORE", "ЯДРО NEBULA"), x + u(17), y + u(15), SOFT_WHITE, S * 0.88f);
        Draw.text(g, lang("LIVE CLIENT SYSTEM", "СИСТЕМА КЛИЕНТА"), x + u(17), y + u(34), MUTED, S * 0.66f);

        int pillW = u(69), pillH = u(20), pillX = x + w - pillW - u(14), pillY = y + u(15);
        Draw.round(g, pillX, pillY, pillW, pillH, u(7), 0x8C14352F);
        Draw.round(g, pillX + u(8), pillY + u(7), u(5), u(5), u(3), 0xFF68F2C0);
        Draw.text(g, "ONLINE", pillX + u(18), pillY + u(4), 0xFFB7F7DD, S * 0.62f);

        int cx = x + w / 2;
        int cy = y + Math.round(h * 0.49f);
        int radius = Math.max(u(30), Math.min(w / 3, Math.round(h * 0.255f)));
        double pulse = 0.5 + 0.5 * Math.sin(time * 1.65);
        int halo = radius + u(14) + (int) Math.round(pulse * u(3));
        Draw.round(g, cx - halo, cy - halo, halo * 2, halo * 2, halo,
            Draw.alpha(0xFF524DE5, 0.075 + pulse * 0.05));
        Draw.round(g, cx - radius, cy - radius, radius * 2, radius * 2, radius,
            Draw.alpha(0xFF223C84, 0.30));

        // Two constellations of independent points form an animated orbital shape—no plain line art.
        for (int i = 0; i < 18; i++) {
            double a = time * (0.28 + (i % 3) * 0.035) + Math.PI * 2.0 * i / 18.0;
            double rr = radius * (0.88 + 0.035 * Math.sin(time * 1.3 + i));
            int dx = cx + (int) Math.round(Math.cos(a) * rr);
            int dy = cy + (int) Math.round(Math.sin(a) * rr * 0.68);
            int d = u(i % 5 == 0 ? 4 : 2);
            int color = i % 4 == 0 ? VIOLET : CYAN;
            Draw.round(g, dx - d / 2, dy - d / 2, d, d, Math.max(1, d / 2), Draw.alpha(color, 0.65 + 0.30 * pulse));
        }
        for (int i = 0; i < 11; i++) {
            double a = -time * 0.21 + Math.PI * 2.0 * i / 11.0;
            double rr = radius * 0.59;
            int dx = cx + (int) Math.round(Math.cos(a) * rr);
            int dy = cy + (int) Math.round(Math.sin(a) * rr * 0.42);
            int d = u(i % 3 == 0 ? 3 : 2);
            Draw.round(g, dx - d / 2, dy - d / 2, d, d, Math.max(1, d / 2), Draw.alpha(i % 2 == 0 ? VIOLET : 0xFFD8E8FF, 0.82));
        }

        int core = u(17) + (int) Math.round(pulse * u(3));
        Draw.round(g, cx - core, cy - core, core * 2, core * 2, core, Draw.alpha(0xFF4B6EFF, 0.40));
        int inner = Math.max(u(7), core / 2);
        Draw.round(g, cx - inner, cy - inner, inner * 2, inner * 2, inner, 0xFF9BE7FF);
        Draw.round(g, cx - u(3), cy - u(3), u(6), u(6), u(3), 0xFFFFFFFF);

        int footerY = y + h - u(54);
        Draw.round(g, x + u(16), footerY - u(9), w - u(32), u(1), u(1), 0x456D7CA8);
        Draw.textBold(g, lang("READY FOR LAUNCH", "ГОТОВ К ЗАПУСКУ"), x + u(17), footerY + u(1), 0xFFDCE7FF, S * 0.72f);
        Draw.text(g, lang("RIGHT SHIFT  /  CLICK GUI", "RIGHT SHIFT  /  МОДУЛИ"), x + u(17), footerY + u(21), MUTED, S * 0.62f);
    }

    /** Small custom constellation badge on each destination button. */
    private void drawButtonOrb(GuiGraphics g, int cx, int cy, int size, double time, int index, int accent) {
        int r = Math.max(u(5), size / 2);
        for (int i = 0; i < 7; i++) {
            double a = time * (0.42 + index * 0.025) + Math.PI * 2.0 * i / 7.0;
            int dx = cx + (int) Math.round(Math.cos(a) * r);
            int dy = cy + (int) Math.round(Math.sin(a) * r * 0.78);
            int d = Math.max(1, u(i == 0 ? 3 : 2));
            Draw.round(g, dx - d / 2, dy - d / 2, d, d, Math.max(1, d / 2), Draw.alpha(i % 3 == 0 ? VIOLET : accent, 0.88));
        }
        int c = Math.max(2, u(4));
        Draw.round(g, cx - c / 2, cy - c / 2, c, c, Math.max(1, c / 2), 0xFFEAF8FF);
    }

    @Override
    public void render(GuiGraphics g, int gmx, int gmy, float delta) {
        calc();
        double mx = gmx * gs, my = gmy * gs;
        double time = (System.nanoTime() - t0) / 1_000_000_000.0;

        g.pose().pushMatrix();
        g.pose().scale(1f / gs, 1f / gs);

        // Space artwork first; a mild tint keeps text and cards crisp without hiding the planet.
        BG.blitStretch(g, bg, 0, 0, rw(), rh(), 0xFFFFFFFF);
        if (Theme.menuBackgroundEnabled)
            CustomBackground.draw(g, 0, 0, rw(), rh(), true, Theme.menuBackgroundOpacity);
        Draw.rect(g, 0, 0, rw(), rh(), 0x26030818);

        for (float[] s : stars) {
            double a = 0.15 + 0.42 * (0.5 + 0.5 * Math.sin(time * 1.15 + s[3]));
            int size = Math.max(1, Math.round(S * s[2]));
            Draw.rect(g, Math.round(s[0] * rw()), Math.round(s[1] * rh()), size, size,
                Draw.alpha(0xFFDDE7FF, a));
        }

        // Original animated client core on the right, replacing generic arrow/line decoration.
        drawNebulaCore(g, time);

        // Brand block: use the client's existing logo, no extra logo file is required.
        int logoSize = u(78);
        int logoX = marginX();
        int logoY = u(91) + (int) Math.round(Math.sin(time * 0.8) * u(2));
        Logo.draw(g, logoX, logoY, logoSize, 0xFFFFFFFF);

        int titleX = logoX + logoSize + u(12);
        int titleY = u(101);
        Draw.textBold(g, "NEBULA", titleX, titleY, SOFT_WHITE, S * 2.18f);
        Draw.text(g, lang("CLIENT  /  MINECRAFT 1.21.11", "КЛИЕНТ  /  MINECRAFT 1.21.11"),
            titleX + u(1), titleY + u(35), MUTED, S * 0.82f);

        int chipY = titleY + u(56);
        Draw.round(g, titleX, chipY, u(106), u(21), u(7), 0xB5121830);
        Draw.round(g, titleX + u(8), chipY + u(7), u(6), u(6), u(3), CYAN);
        Draw.text(g, lang("FABRIC CLIENT", "КЛИЕНТ FABRIC"), titleX + u(20), chipY + u(4), 0xFFE3E9FF, S * 0.72f);

        // Main destinations. Accounts gets a full-width row so it is easy to find.
        for (int i = 0; i < btns.length - 1; i++) {
            Btn b = btns[i];
            int x = cardX(i), y = cardY(i), w = cardW(i), h = cardH();
            boolean isHovered = Draw.hover(mx, my, x, y, w, h);
            hover[i] += ((isHovered ? 1f : 0f) - hover[i]) * 0.22f;
            Draw.moduleBg(g, x, y, w, h, u(9), false, hover[i]);
            int accent = (i == 0 || i == 2 || i == 4) ? CYAN : VIOLET;
            Draw.round(g, x + u(12), y + u(14), u(3), h - u(28), u(2), Draw.alpha(accent, 0.92));
            Draw.textBold(g, lang(b.en(), b.ru()), x + u(24), y + u(10), SOFT_WHITE, S * 1.02f);
            Draw.text(g, lang(b.hintEn(), b.hintRu()), x + u(24), y + u(32),
                Draw.alpha(MUTED, 0.92), S * 0.73f);
            drawButtonOrb(g, x + w - u(23), y + h / 2, u(15), time, i, accent);
        }

        // Deliberately understated exit action, separate from the main destinations.
        int qx = marginX(), qy = quitY(), qw = quitW(), qh = quitH();
        int quitIndex = btns.length - 1;
        boolean quitHovered = Draw.hover(mx, my, qx, qy, qw, qh);
        hover[quitIndex] += ((quitHovered ? 1f : 0f) - hover[quitIndex]) * 0.22f;
        Draw.moduleBg(g, qx, qy, qw, qh, u(8), false, hover[quitIndex]);
        Draw.centered(g, lang(btns[quitIndex].en(), btns[quitIndex].ru()), qx + qw / 2f,
            qy + (qh - Draw.height(S * 0.86f)) / 2f,
            Draw.alpha(SOFT_WHITE, quitHovered ? 0.98 : 0.72), S * 0.86f);

        // Rotating practical tips instead of news, social links or credits.
        int tx = marginX(), ty = tipY(), tw = tipW(), th = tipH();
        Draw.round(g, tx, ty, tw, th, u(10), 0xB20B1022);
        Draw.round(g, tx + u(13), ty + u(16), u(3), th - u(32), u(2), VIOLET);
        int tipIndex = ((int) (time / 6.5)) % TIPS_EN.length;
        String tip = Theme.language.equals("RU") ? TIPS_RU[tipIndex] : TIPS_EN[tipIndex];
        Draw.textBold(g, lang("NEBULA QUICK TIP", "СОВЕТ NEBULA"), tx + u(25), ty + u(13),
            0xFF9BA9FF, S * 0.76f);
        String index = String.format("%02d / %02d", tipIndex + 1, TIPS_EN.length);
        Draw.text(g, index, tx + tw - u(68), ty + u(13), Draw.alpha(MUTED, 0.72), S * 0.68f);
        Draw.text(g, tip, tx + u(25), ty + u(42), SOFT_WHITE, S * 0.88f);

        // Quiet footer; no creator tag or promotional links.
        String footerLeft = "NEBULA CLIENT  •  FABRIC 1.21.11";
        Draw.text(g, footerLeft, marginX(), rh() - u(25), Draw.alpha(MUTED, 0.62), S * 0.72f);
        String footerRight = lang("CUSTOMIZE YOUR EXPERIENCE", "НАСТРОЙ ПОД СЕБЯ");
        int footerX = rw() - u(64) - Draw.width(footerRight, S * 0.72f);
        Draw.text(g, footerRight, footerX, rh() - u(25), Draw.alpha(MUTED, 0.52), S * 0.72f);

        Draw.flush();
        g.pose().popMatrix();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        calc();
        double mx = e.x() * gs, my = e.y() * gs;
        if (e.button() == 0) {
            for (int i = 0; i < btns.length - 1; i++) {
                if (Draw.hover(mx, my, cardX(i), cardY(i), cardW(i), cardH())) {
                    btns[i].action().run();
                    return true;
                }
            }
            if (Draw.hover(mx, my, marginX(), quitY(), quitW(), quitH())) {
                btns[btns.length - 1].action().run();
                return true;
            }
        }
        return super.mouseClicked(e, dbl);
    }
}
