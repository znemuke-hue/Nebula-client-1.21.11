package dev.hvh.client.gui;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Guard for Minecraft's native GUI blur barrier. That barrier is full-frame, so it is intentionally
 * disabled for Nebula glass surfaces: local surfaces must never blur the game outside the GUI.
 * Custom GUI wallpapers use a cached, downsampled image blur in CustomBackground instead.
 */
public final class GlassBlur {
    private GlassBlur() {}
    public static void beginFrame() {}
    @Deprecated public static boolean request(GuiGraphics graphics) { return false; }
}
