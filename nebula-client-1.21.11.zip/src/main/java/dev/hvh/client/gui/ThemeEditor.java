package dev.hvh.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/** Theme panel: mode switch, color slots, SV square + hue bar, Copy/Paste, presets. Real-pixel layout. */
public final class ThemeEditor {
    private enum Drag { NONE, SV, HUE }

    private float S = 1f;
    private int sel = 0;
    private float h, s, v;
    private Drag drag = Drag.NONE;
    private String toast = "";
    private long toastUntil;

    private int x, y, w, ph, pad, ix, iw, gap;
    private int modeY, modeH, swY, swH, svX, svY, svW, svH, hueX, hueW, hexY, btnY, btnH, prevY, chipsY, chipH, chipStep;

    public ThemeEditor() { loadSel(); }

    private int u(double a) { return (int) Math.round(a * S); }

    private void layout(int px, int py, int pw, float scale) {
        S = scale; x = px; y = py; w = pw; ph = u(356); pad = u(6); gap = u(6);
        ix = x + pad; iw = w - pad * 2;
        modeY = y + u(34); modeH = u(20);
        swY = y + u(60); swH = u(22);
        svY = y + u(100); svH = u(92); hueW = u(16); svW = iw - hueW - gap; svX = ix; hueX = ix + svW + gap;
        hexY = y + u(197);
        btnY = y + u(212); btnH = u(18);
        prevY = y + u(237); chipsY = y + u(252); chipH = u(17); chipStep = u(20);
    }

    // Slots: the theme colors (2 in Normal, 4 in Gradient) followed by Text, Glow and Outline.
    private int base() { return Theme.active().length; }
    private int slots() { return base() + 3; }
    private int[] cols() { return Theme.active(); }

    private int get(int i) {
        int b = base();
        if (i < b) return Theme.active()[i];
        return switch (i - b) {
            case 0 -> Theme.TEXT & 0xFFFFFF;
            case 1 -> Theme.glowColor & 0xFFFFFF;
            default -> Theme.outlineColor & 0xFFFFFF;
        };
    }
    private void set(int i, int rgb) {
        rgb &= 0xFFFFFF;
        int b = base();
        if (i < b) Theme.active()[i] = rgb;
        else switch (i - b) {
            case 0 -> Theme.setText(rgb);
            case 1 -> Theme.glowColor = rgb;
            default -> Theme.outlineColor = rgb;
        }
    }

    /** Select Text (0), Glow (1) or Outline (2) in the palette. */
    public void selectExtra(int k) { sel = base() + Math.max(0, Math.min(2, k)); loadSel(); }
    public int selectedExtra() { return sel - base(); }

    private void loadSel() {
        if (sel >= slots()) sel = 0;
        float[] hsv = toHsv(get(sel));
        h = hsv[0]; s = hsv[1]; v = hsv[2];
    }
    private void applyHsv() { set(sel, fromHsv(h, s, v)); }

    private static float[] toHsv(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min, hh;
        if (d == 0) hh = 0;
        else if (max == r) hh = ((g - b) / d) % 6;
        else if (max == g) hh = (b - r) / d + 2;
        else hh = (r - g) / d + 4;
        hh /= 6f; if (hh < 0) hh += 1f;
        return new float[]{hh, max == 0 ? 0 : d / max, max};
    }

    static int fromHsv(float h, float s, float v) {
        float hh = (h % 1f) * 6f; int i = (int) hh; float f = hh - i;
        float p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f)), r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
    }

    private static String hex(int rgb) { return String.format("#%06X", rgb & 0xFFFFFF); }

    // ---------------------------------------------------------------- render

    public void render(GuiGraphics g, int px, int py, int pw, double mx, double my, float scale) {
        layout(px, py, pw, scale);
        if (drag != Drag.NONE) updateDrag(mx, my);

        Draw.panelBg(g, x, y, w, ph, u(7));
        Draw.centeredBold(g, "Theme Editor", x + w / 2f, y + (u(30) - Draw.height(S * 1.1f)) / 2f, Theme.TEXT, S * 1.1f);

        // mode switch
        int mw = iw / 2;
        Draw.round(g, ix, modeY, iw, modeH, u(5), Theme.DARK);
        boolean grad = Theme.mode == Theme.Mode.GRADIENT;
        Draw.round(g, grad ? ix + mw : ix, modeY, mw, modeH, u(5), Theme.accent());
        int ty = modeY + (modeH - Draw.height(S * 0.9f)) / 2;
        Draw.centered(g, "Normal", ix + mw / 2f, ty, grad ? Theme.TEXT_DIM : Theme.moduleText(true), S * 0.9f);
        Draw.centered(g, "Gradient", ix + mw + mw / 2f, ty, grad ? Theme.moduleText(true) : Theme.TEXT_DIM, S * 0.9f);

        // color slots
        int n = slots();
        int sw = (iw - (n - 1) * gap) / n;
        String[] names = grad ? new String[]{"GUI 1", "GUI 2", "Mod 1", "Mod 2", "Text", "Glow", "Line"} : new String[]{"GUI", "Buttons", "Text", "Glow", "Line"};
        for (int i = 0; i < n; i++) {
            int sx = ix + i * (sw + gap);
            if (i == sel) Draw.round(g, sx - u(2), swY - u(2), sw + u(4), swH + u(4), u(7), 0xFFE6E9F5);
            Draw.round(g, sx, swY, sw, swH, u(5), 0xFF000000 | get(i));
            Draw.centered(g, names[i], sx + sw / 2f, swY + swH + u(5), i == sel ? Theme.TEXT : Theme.TEXT_DIM, S * 0.72f);
        }

        // SV square + hue bar: baked textures (1 element each)
        int cur = get(sel);
        Shapes.picker(g, svX, svY, svW, svH, u(6), h);
        int kd = u(13), kx = svX + Math.round(s * svW), ky = svY + Math.round((1 - v) * svH);
        Draw.round(g, kx - kd / 2, ky - kd / 2, kd, kd, kd / 2, 0xFFFFFFFF);
        Draw.round(g, kx - kd / 2 + u(2), ky - kd / 2 + u(2), kd - u(4), kd - u(4), (kd - u(4)) / 2, 0xFF000000 | cur);

        Shapes.hueBar(g, hueX, svY, hueW, svH);
        int hy = svY + Math.round(h * svH);
        Draw.round(g, hueX - u(2), hy - u(3), hueW + u(4), u(6), u(3), 0xFFE6E9F5);

        // hex / toast
        String label = System.currentTimeMillis() < toastUntil ? toast : hex(cur);
        Draw.centered(g, label, x + w / 2f, hexY, Theme.TEXT_DIM, S * 0.9f);

        // Copy / Paste
        int bwid = (iw - gap) / 2;
        button(g, ix, btnY, bwid, btnH, "Copy", mx, my);
        button(g, ix + bwid + gap, btnY, bwid, btnH, "Paste", mx, my);

        // presets
        Draw.text(g, "Presets", ix, prevY, Theme.TEXT_DIM, S * 0.85f);
        List<Theme.Preset> ps = Theme.presets();
        int cw = (iw - gap / 2) / 2;
        for (int i = 0; i < ps.size(); i++) {
            int cx = ix + (i % 2) * (cw + gap / 2), cy = chipsY + (i / 2) * chipStep;
            boolean hov = Draw.hover(mx, my, cx, cy, cw, chipH);
            Draw.round(g, cx, cy, cw, chipH, u(5), hov ? Theme.DARK_HOVER : Theme.DARK);
            drawPreview(g, ps.get(i), cx + u(5), cy + (chipH - u(8)) / 2);
            Draw.text(g, ps.get(i).name(), cx + u(34), cy + (chipH - Draw.height(S * 0.85f)) / 2, Theme.TEXT, S * 0.85f);
        }
    }

    private void button(GuiGraphics g, int bx, int by, int bw, int bh, String label, double mx, double my) {
        Draw.round(g, bx, by, bw, bh, u(5), Draw.hover(mx, my, bx, by, bw, bh) ? Theme.DARK_HOVER : Theme.DARK);
        Draw.centered(g, label, bx + bw / 2f, by + (bh - Draw.height(S * 0.9f)) / 2, Theme.TEXT, S * 0.9f);
    }

    /** Color dots: GUI color(s) and module color(s). */
    private void drawPreview(GuiGraphics g, Theme.Preset p, int px, int py) {
        int[] c = p.cols();
        int[] dots = c.length == 4 ? new int[]{Theme.mix(c[0], c[1], 0.5), c[2], c[3]} : new int[]{c[0], c[1]};
        int d = u(8), step = u(10);
        for (int i = 0; i < dots.length; i++)
            Draw.round(g, px + i * step, py, d, d, d / 2, 0xFF000000 | dots[i]);
    }

    // ----------------------------------------------------------------- input

    private void updateDrag(double mx, double my) {
        if (drag == Drag.SV) {
            s = (float) Math.max(0, Math.min(1, (mx - svX) / svW));
            v = 1f - (float) Math.max(0, Math.min(1, (my - svY) / svH));
        } else if (drag == Drag.HUE) {
            h = (float) Math.max(0, Math.min(0.9999, (my - svY) / svH));
        }
        applyHsv();
    }

    private void toast(String t) { toast = t; toastUntil = System.currentTimeMillis() + 1200; }

    public boolean mouseClicked(double mx, double my, int btn) {
        if (!Draw.hover(mx, my, x, y, w, ph)) return false;
        if (btn != 0) return true;

        if (Draw.hover(mx, my, ix, modeY, iw, modeH)) {
            int extra = sel - base();
            Theme.mode = mx < ix + iw / 2.0 ? Theme.Mode.NORMAL : Theme.Mode.GRADIENT;
            if (extra >= 0) sel = base() + extra;
            loadSel(); Theme.save(); return true;
        }
        int n = slots(), sw = (iw - (n - 1) * gap) / n;
        for (int i = 0; i < n; i++)
            if (Draw.hover(mx, my, ix + i * (sw + gap), swY, sw, swH)) { sel = i; loadSel(); return true; }

        if (Draw.hover(mx, my, svX, svY, svW, svH)) { drag = Drag.SV; updateDrag(mx, my); return true; }
        if (Draw.hover(mx, my, hueX - u(3), svY, hueW + u(6), svH)) { drag = Drag.HUE; updateDrag(mx, my); return true; }

        int bwid = (iw - gap) / 2;
        if (Draw.hover(mx, my, ix, btnY, bwid, btnH)) {
            Minecraft.getInstance().keyboardHandler.setClipboard(hex(get(sel)));
            toast("Copied"); return true;
        }
        if (Draw.hover(mx, my, ix + bwid + gap, btnY, bwid, btnH)) {
            try {
                String t = Minecraft.getInstance().keyboardHandler.getClipboard().trim();
                if (t.startsWith("#")) t = t.substring(1);
                if (t.length() != 6) throw new NumberFormatException();
                set(sel, Integer.parseInt(t, 16) & 0xFFFFFF);
                loadSel(); Theme.save(); toast("Pasted");
            } catch (Exception e) { toast("Bad hex"); }
            return true;
        }

        List<Theme.Preset> ps = Theme.presets();
        int cw = (iw - gap / 2) / 2;
        for (int i = 0; i < ps.size(); i++) {
            int cx = ix + (i % 2) * (cw + gap / 2), cy = chipsY + (i / 2) * chipStep;
            if (Draw.hover(mx, my, cx, cy, cw, chipH)) {
                System.arraycopy(ps.get(i).cols(), 0, cols(), 0, ps.get(i).cols().length);
                Theme.syncText();
                loadSel(); Theme.save(); return true;
            }
        }
        return true;
    }

    public void mouseReleased() {
        if (drag != Drag.NONE) { drag = Drag.NONE; Theme.save(); }
    }
}
