package dev.hvh.client.gui;

import dev.hvh.client.HvhClient;
import dev.hvh.client.module.Mod;
import dev.hvh.client.sound.ClientSounds;
import dev.hvh.client.sound.ClientSounds.Event;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * In-game sound selector (same look as the background picker).
 * Events -> pick an event -> pick one of the .ogg files in that event's folder (tap = choose + preview).
 * "Per-module sounds" lets a single module have its own enable / disable sound.
 */
public final class SoundPickerScreen extends Screen {
    private enum State { EVENTS, FILES, MODULES, MODULE_ROWS }

    private record Row(String label, String value, Runnable action, boolean dim, boolean marked) {}

    private final Screen previous;
    private final List<Row> rows = new ArrayList<>();
    private State state = State.EVENTS;
    private Event event;
    private String message = "";
    private Mod module;          // null = global choice
    private int scroll;
    private float gs = 1f, S = 1f;
    private int x, y, w, h, pad, row, top, visible;

    public static void open() {
        ClientSounds.ensureFolders();
        ClientSounds.keepGui = true; // opened from the click GUI: no "close menu" sound
        Minecraft.getInstance().setScreen(new SoundPickerScreen());
    }

    private SoundPickerScreen() {
        super(Component.literal("Client sounds"));
        this.previous = Minecraft.getInstance().screen;
        build();
    }

    // ------------------------------------------------------------------ content

    private String modName() { return module == null ? null : module.name; }

    private String currentLabel(Event e, String mod) {
        String raw = ClientSounds.getSelection(e, mod);
        if (raw == null) {
            if (mod != null) return "global";
            List<Path> fs = ClientSounds.scan(e);
            return fs.isEmpty() ? "no files" : "auto: " + fs.get(0).getFileName();
        }
        if (ClientSounds.NONE.equals(raw)) return "none";
        if (ClientSounds.isDefaults(raw)) return "дефолт (" + ClientSounds.scan(e).stream().filter(p -> p.getFileName().toString().startsWith("default-")).count() + ")";
        if (ClientSounds.isRandom(raw)) return "random (" + ClientSounds.randomNames(e, raw).size() + " files)";
        return raw;
    }

    private void go(State s) { state = s; scroll = 0; message = ""; build(); }

    private void build() {
        rows.clear();
        switch (state) {
            case EVENTS -> {
                for (Event e : Event.values())
                    rows.add(new Row(e.title + "  [" + e.folder + "]", currentLabel(e, null), () -> { event = e; module = null; go(State.FILES); }, false, false));
                rows.add(new Row("Per-module sounds (enable / disable)  >", "", () -> go(State.MODULES), false, false));
            }
            case FILES -> {
                String mn = modName();
                String raw = ClientSounds.getSelection(event, mn);
                boolean multi = ClientSounds.isRandom(raw);
                List<String> ticked = multi ? ClientSounds.randomNames(event, raw) : List.of();
                rows.add(new Row("Дефолт (стандартные варианты)", ClientSounds.defaultSoundCount(event) + " sounds", () -> { ClientSounds.setSelection(event, mn, ClientSounds.DEFAULTS); message = "Включены стандартные звуки"; build(); }, true, ClientSounds.isDefaults(raw)));
                rows.add(new Row(module == null ? "Auto (first file)" : "Use global setting", "", () -> { ClientSounds.setSelection(event, mn, null); message = "Автовыбор включён"; build(); }, true, raw == null));
                rows.add(new Row("None (silent)", "", () -> { ClientSounds.setSelection(event, mn, ClientSounds.NONE); build(); }, true, ClientSounds.NONE.equals(raw)));
                // Multi-select: tick several files, they are played in random order (a shuffled round, no repeats until all played)
                rows.add(new Row("Multi-select (random order)", multi ? "ON" : "OFF", () -> {
                    if (multi) ClientSounds.setSelection(event, mn, ClientSounds.RANDOM_ALL.equals(raw) || ticked.isEmpty() ? null : ticked.get(0));
                    else ClientSounds.setSelection(event, mn, ClientSounds.RANDOM_ALL);
                    build();
                }, true, multi));
                for (Path p : ClientSounds.scan(event)) {
                    String name = p.getFileName().toString();
                    if (multi) {
                        rows.add(new Row(name, "", () -> {
                            List<String> cur = new ArrayList<>(ticked);
                            boolean added = !cur.remove(name);
                            if (added) cur.add(name);
                            ClientSounds.setSelection(event, mn, cur.isEmpty() ? null : ClientSounds.encodeRandom(cur));
                            if (added) ClientSounds.preview(event, p);
                            build();
                        }, false, ticked.contains(name)));
                    } else {
                        rows.add(new Row(name, "", () -> { ClientSounds.setSelection(event, mn, name); ClientSounds.preview(event, p); build(); }, false, name.equals(raw)));
                    }
                }
            }
            case MODULES -> {
                for (Mod m : HvhClient.modules.all)
                    rows.add(new Row(m.name, ClientSounds.hasOverride(m.name) ? "custom" : "", () -> { module = m; go(State.MODULE_ROWS); }, false, false));
            }
            case MODULE_ROWS -> {
                rows.add(new Row("Enable sound", currentLabel(Event.MODULE_ENABLE, module.name), () -> { event = Event.MODULE_ENABLE; go(State.FILES); }, false, false));
                rows.add(new Row("Disable sound", currentLabel(Event.MODULE_DISABLE, module.name), () -> { event = Event.MODULE_DISABLE; go(State.FILES); }, false, false));
            }
        }
    }

    private String title() {
        return switch (state) {
            case EVENTS -> "Client Sounds";
            case FILES -> (module == null ? "" : module.name + " - ") + event.title;
            case MODULES -> "Per-module sounds";
            case MODULE_ROWS -> module.name;
        };
    }

    private String hint() {
        return switch (state) {
            case EVENTS -> "Pick what you want to change";
            case FILES -> "Tap a file to use it (you hear it). Multi-select: tick several, they play in random order";
            case MODULES -> "Pick a module";
            case MODULE_ROWS -> "Pick which sound to change";
        };
    }

    private Path folderShown() {
        return state == State.FILES ? ClientSounds.dir(event) : ClientSounds.root();
    }

    private void back() {
        switch (state) {
            case EVENTS -> Minecraft.getInstance().setScreen(previous);
            case FILES -> go(module == null ? State.EVENTS : State.MODULE_ROWS);
            case MODULES -> go(State.EVENTS);
            case MODULE_ROWS -> go(State.MODULES);
        }
    }

    // ------------------------------------------------------------------ layout (same approach as BackgroundFilePicker)

    private int u(double v) { return (int) Math.round(v * S); }

    private void calc() {
        gs = (float) Math.max(1, minecraft.getWindow().getGuiScale());
        S = Math.max(.75f, Math.min(3f, minecraft.getWindow().getHeight() / 720f));
        Draw.SCALE = S;
        int sw = Math.round(width * gs), sh = Math.round(height * gs);
        w = Math.min(u(560), sw - u(24)); h = Math.min(u(520), sh - u(24));
        x = (sw - w) / 2; y = (sh - h) / 2; pad = u(14); row = u(32);
        top = y + u(98);
        visible = Math.max(1, (h - u(98) - u(56)) / row);
        scroll = Math.max(0, Math.min(Math.max(0, rows.size() - visible), scroll));
    }

    private int listW() { return w - pad * 2 - u(40); }

    private String fitLeft(String s, float t, int maxW) {
        if (Draw.width(s, t) <= maxW) return s;
        while (s.length() > 4 && Draw.width("..." + s, t) > maxW) s = s.substring(1);
        return "..." + s;
    }

    private String fit(String s, float t, int maxW) {
        if (Draw.width(s, t) <= maxW) return s;
        while (s.length() > 2 && Draw.width(s + "...", t) > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int gmx, int gmy, float delta) {
        calc();
        double mx = gmx * gs, my = gmy * gs;
        g.pose().pushMatrix();
        g.pose().scale(1f / gs, 1f / gs);
        Draw.panelBg(g, x, y, w, h, u(Theme.cornerRadius));
        Draw.textBold(g, fit(title(), S * 1.15f, w - pad * 2), x + pad, y + u(14), Theme.TEXT, S * 1.15f);
        Draw.text(g, "Sound files (.ogg) go in:", x + pad, y + u(40), Theme.TEXT_DIM, S * .72f);
        Draw.text(g, fitLeft(folderShown().toAbsolutePath().toString(), S * .68f, w - pad * 2), x + pad, y + u(55), Theme.accent(), S * .68f);
        String err = ClientSounds.lastError();
        boolean showErr = !err.isEmpty();
        String msg = showErr ? "Last error: " + err : (!message.isEmpty() ? message : hint());
        Draw.text(g, fit(msg, S * .72f, w - pad * 2), x + pad, y + u(74), showErr ? 0xFFFF7A7A : Theme.TEXT_DIM, S * .72f);

        int total = rows.size(), lw = listW();
        Draw.scissor(g, x + pad - u(2), top, lw + u(4), visible * row);
        for (int i = scroll; i < Math.min(total, scroll + visible); i++) {
            Row r = rows.get(i);
            int yy = top + (i - scroll) * row;
            boolean hov = Draw.hover(mx, my, x + pad, yy, lw, row - u(4));
            Draw.round(g, x + pad, yy, lw, row - u(4), u(6), r.marked() ? Theme.accent() : hov ? Theme.DARK_HOVER : Theme.DARK);
            float ts = S * .85f;
            int ty = yy + (row - u(4) - Draw.height(ts)) / 2;
            String value = r.value().isEmpty() ? "" : fit(r.value(), S * .72f, (int) (lw * .40f));
            int labelMax = lw - u(20) - (value.isEmpty() ? 0 : Draw.width(value, S * .72f) + u(10));
            Draw.text(g, fit((r.marked() ? "* " : "") + r.label(), ts, labelMax), x + pad + u(10), ty, r.dim() ? Theme.TEXT_DIM : Theme.TEXT, ts);
            if (!value.isEmpty())
                Draw.text(g, value, x + pad + lw - u(10) - Draw.width(value, S * .72f), yy + (row - u(4) - Draw.height(S * .72f)) / 2, Theme.accent(), S * .72f);
        }
        Draw.unscissor(g);

        // scroll buttons (touch friendly)
        int bx = x + w - pad - u(32), bh = u(32);
        scrollButton(g, bx, top, u(32), bh, "^", mx, my);
        scrollButton(g, bx, top + bh + u(6), u(32), bh, "v", mx, my);
        Draw.text(g, Math.min(total, scroll + 1) + "-" + Math.min(total, scroll + visible) + " / " + total, bx - u(2), top + bh * 2 + u(14), Theme.TEXT_DIM, S * .6f);

        int by = y + h - u(44), gap = u(6), bw = (w - pad * 2 - gap * 2) / 3;
        bottomButton(g, x + pad, by, bw, u(32), "Файл...", mx, my);
        bottomButton(g, x + pad + bw + gap, by, bw, u(32), "Обновить", mx, my);
        bottomButton(g, x + pad + (bw + gap) * 2, by, bw, u(32), state == State.EVENTS ? "Закрыть" : "Назад", mx, my);
        Draw.flush();
        g.pose().popMatrix();
    }

    private void scrollButton(GuiGraphics g, int bx, int by, int bw, int bh, String label, double mx, double my) {
        Draw.round(g, bx, by, bw, bh, u(6), Draw.hover(mx, my, bx, by, bw, bh) ? Theme.DARK_HOVER : Theme.DARK);
        Draw.centered(g, label, bx + bw / 2f, by + (bh - Draw.height(S)) / 2, Theme.TEXT, S);
    }

    private void bottomButton(GuiGraphics g, int bx, int by, int bw, int bh, String label, double mx, double my) {
        Draw.round(g, bx, by, bw, bh, u(6), Draw.hover(mx, my, bx, by, bw, bh) ? Theme.DARK_HOVER : Theme.DARK);
        Draw.centered(g, label, bx + bw / 2f, by + (bh - Draw.height(S * .82f)) / 2, Theme.TEXT, S * .82f);
    }

    private void chooseSoundFile() {
        Path folder = state == State.FILES ? ClientSounds.dir(event) : ClientSounds.root();
        if (state != State.FILES) {
            NativeFilePicker.openDirectory(folder);
            message = "Откройте событие, чтобы выбрать звук";
            return;
        }
        NativeFilePicker.choose(folder, "Choose sound (.ogg)", new String[]{".ogg"}, file -> {
            try {
                if (!Files.isRegularFile(file) || !file.getFileName().toString().toLowerCase().endsWith(".ogg")) {
                    message = "Нужен файл .ogg";
                    return;
                }
                Path dest = folder.resolve(file.getFileName().toString());
                if (!file.toAbsolutePath().normalize().equals(dest.toAbsolutePath().normalize()))
                    Files.copy(file, dest, StandardCopyOption.REPLACE_EXISTING);
                ClientSounds.setSelection(event, modName(), dest.getFileName().toString());
                ClientSounds.preview(event, dest);
                message = "Выбран: " + dest.getFileName();
                build();
            } catch (Exception ex) {
                message = "Не удалось: " + (ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage());
            }
        }, () -> {
            message = "Файл-диалог недоступен: скопируйте .ogg в папку и нажмите Обновить";
            build();
        });
    }

    private void refreshFiles() {
        ClientSounds.ensureFolders();
        build();
        message = state == State.FILES ? "Загружено файлов: " + ClientSounds.scan(event).size() : "Список обновлён";
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        calc();
        double mx = e.x() * gs, my = e.y() * gs;
        if (e.button() != 0) return true;
        int total = rows.size(), lw = listW();
        int bx = x + w - pad - u(32), bh = u(32);
        if (Draw.hover(mx, my, bx, top, u(32), bh)) { scroll = Math.max(0, scroll - 3); ClientSounds.play(Event.GUI_SCROLL); return true; }
        if (Draw.hover(mx, my, bx, top + bh + u(6), u(32), bh)) { scroll = Math.min(Math.max(0, total - visible), scroll + 3); ClientSounds.play(Event.GUI_SCROLL); return true; }
        int by = y + h - u(44), gap = u(6), bw = (w - pad * 2 - gap * 2) / 3;
        if (Draw.hover(mx, my, x + pad, by, bw, u(32))) { chooseSoundFile(); return true; }
        if (Draw.hover(mx, my, x + pad + bw + gap, by, bw, u(32))) { refreshFiles(); return true; }
        if (Draw.hover(mx, my, x + pad + (bw + gap) * 2, by, bw, u(32))) { ClientSounds.play(Event.GUI_CLICK); back(); return true; }
        if (Draw.hover(mx, my, x + pad, top, lw, visible * row)) {
            int i = scroll + (int) ((my - top) / row);
            if (i >= 0 && i < total) {
                if (state != State.FILES || i < 3) ClientSounds.play(Event.GUI_CLICK); // file rows preview their own sound
                rows.get(i).action().run();
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        int old = scroll;
        scroll = Math.max(0, Math.min(Math.max(0, rows.size() - visible), scroll - (int) Math.signum(sy) * 2));
        if (old != scroll) ClientSounds.play(Event.GUI_SCROLL);
        return true;
    }

    @Override public void onClose() { back(); }
}
