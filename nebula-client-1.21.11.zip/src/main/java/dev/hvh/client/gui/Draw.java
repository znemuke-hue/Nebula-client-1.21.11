package dev.hvh.client.gui;

import net.minecraft.client.gui.GuiGraphics;

/**
 * All rendering lives here. Drawn in REAL screen pixels (the screen undoes GUI scale).
 * Performance rule: few GUI elements. Shapes and strings are cached bitmaps (1 element each).
 */
public final class Draw {
    public static final MsdfFont MEDIUM = new MsdfFont("inter_medium");
    public static final MsdfFont BOLD = new MsdfFont("inter_semibold");
    public static float BASE_PX = 12f, CAP = 0.73f;
    public static float TEXT_Y = 0f;

    private static final long MASK_MAX_AREA = 70000;

    private static int px(float t) { return Math.max(7, Math.round(BASE_PX * t)); }

    public static int alpha(int c, double k) {
        int a = (int) Math.round(((c >>> 24) & 0xFF) * k);
        return (Math.max(0, Math.min(255, a)) << 24) | (c & 0xFFFFFF);
    }

    public static void rect(GuiGraphics g, int x, int y, int w, int h, int c) {
        g.fill(x, y, x + w, y + h, c);
    }

    /** Anti-aliased rounded rectangle: 1 element (small) or 3 fills + 4 corners (large). */
    public static void round(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) { rect(g, x, y, w, h, c); return; }
        if ((long) w * h <= MASK_MAX_AREA) { Shapes.mask(g, x, y, w, h, r, c); return; }
        g.fill(x + r, y, x + w - r, y + r, c);
        g.fill(x, y + r, x + w, y + h - r, c);
        g.fill(x + r, y + h - r, x + w - r, y + h, c);
        Shapes.corner(g, 0, x, y, r, c);
        Shapes.corner(g, 1, x + w - r, y, r, c);
        Shapes.corner(g, 2, x, y + h - r, r, c);
        Shapes.corner(g, 3, x + w - r, y + h - r, r, c);
    }

    public static void panelBg(GuiGraphics g, int x, int y, int w, int h, int r) {
        externalGlow(g,x,y,w,h,r);
        if (Theme.mode == Theme.Mode.NORMAL) { round(g, x, y, w, h, r, Theme.panelAt(0)); drawOutline(g,x,y,w,h,r); glassHighlight(g,x,y,w,h,r,false,Theme.Surface.GUI); return; }
        r = Math.min(r, Math.min(w, h) / 2);
        if (h < 120 || r <= 1) { round(g, x, y, w, h, r, Theme.panelAt(0.5)); drawOutline(g,x,y,w,h,r); glassHighlight(g,x,y,w,h,r,false,Theme.Surface.GUI); return; }
        // animated vertical gradient from a few gradient quads + 4 corners
        int mid = h - 2 * r, segs = 10;
        g.fillGradient(x + r, y, x + w - r, y + r, Theme.panelAt(0), Theme.panelAt(r / (double) h));
        for (int k = 0; k < segs; k++) {
            int y0 = y + r + mid * k / segs, y1 = y + r + mid * (k + 1) / segs;
            g.fillGradient(x, y0, x + w, y1, Theme.panelAt((y0 - y) / (double) h), Theme.panelAt((y1 - y) / (double) h));
        }
        g.fillGradient(x + r, y + h - r, x + w - r, y + h, Theme.panelAt((h - r) / (double) h), Theme.panelAt(1));
        int top = Theme.panelAt(r / 2.0 / h), bot = Theme.panelAt(1 - r / 2.0 / h);
        Shapes.corner(g, 0, x, y, r, top);
        Shapes.corner(g, 1, x + w - r, y, r, top);
        Shapes.corner(g, 2, x, y + h - r, r, bot);
        Shapes.corner(g, 3, x + w - r, y + h - r, r, bot);
        drawOutline(g,x,y,w,h,r);
        glassHighlight(g,x,y,w,h,r,false,Theme.Surface.GUI);
    }

    /** UI scale of the screen currently being drawn (set by the screens); scales glow spread and outline width. */
    public static float SCALE = 1f;

    /** Needle-shaped outline: thread -> configured width -> thread on every side, hugging the corner radius. */
    private static void drawOutline(GuiGraphics g,int x,int y,int w,int h,int r) {
        if (!Theme.outlineEnabled || Theme.outlineWidth <= 0.01) return;
        int c = 0xF2000000 | (Theme.outlineColor & 0xFFFFFF);
        Shapes.outline(g, x, y, w, h, r, Theme.outlineWidth * Math.max(1f, SCALE), c,
            Theme.outlineTopLeft, Theme.outlineTopRight, Theme.outlineBottomLeft, Theme.outlineBottomRight);
    }

    /** Outside-only halo: one baked 9-slice (8 blits) instead of thousands of per-row fills. */
    private static void externalGlow(GuiGraphics g,int x,int y,int w,int h,int r) {
        if (!Theme.glowEnabled || Theme.glowStrength <= 0.01 || w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        int spread = (int) Math.round((4 + Theme.glowStrength * 14) * Math.max(1f, SCALE)) & ~1; // even steps keep the cache small
        int alpha = (int) Math.round((0.16 + 0.34 * Theme.glowStrength) * 255);
        Shapes.glow(g, x, y, w, h, r, Math.max(2, spread), (alpha << 24) | (Theme.glowColor & 0xFFFFFF));
    }

    public static void moduleBg(GuiGraphics g, int x, int y, int w, int h, int r, boolean on, double hover) {
        if (on) externalGlow(g,x,y,w,h,r);
        // If a custom GUI wallpaper is active, sample only its pre-blurred cached variant into the card.
        // This stays inside Nebula's GUI and never invokes the game-wide blur pass.
        CustomBackground.drawGlassRegion(g, x, y, w, h, Theme.moduleBlurStrength);
        if (Theme.mode == Theme.Mode.NORMAL) { round(g, x, y, w, h, r, Theme.moduleAt(0, on, hover)); drawOutline(g,x,y,w,h,r); glassHighlight(g,x,y,w,h,r,on || hover > 0.02,Theme.Surface.MODULE); return; }
        r = Math.min(r, Math.min(w, h) / 2);
        Shapes.gradientMask(g, x, y, w, h, r, on);
        if (hover > 0.02) Shapes.mask(g, x, y, w, h, r, ((int) (hover * 0x22) << 24) | 0xFFFFFF);
        drawOutline(g,x,y,w,h,r);
        glassHighlight(g,x,y,w,h,r,on || hover > 0.02,Theme.Surface.MODULE);
    }

    /** Backwards-compatible GUI-surface highlight. */
    public static void glassHighlight(GuiGraphics g, int x, int y, int w, int h, int r, boolean emphasized) {
        glassHighlight(g, x, y, w, h, r, emphasized, Theme.Surface.GUI);
    }

    /**
     * Lightweight glass finish. The per-surface blur value controls frost/milky diffusion, while
     * highlight strength controls only reflection intensity. No per-widget FBO or shader is created.
     * A true region-sampled blur needs a dedicated render-target pass; Minecraft's native stratum
     * blur is screen-wide and is deliberately not used here.
     */
    public static void glassHighlight(GuiGraphics g, int x, int y, int w, int h, int r, boolean emphasized, Theme.Surface surface) {
        if (w < 6 || h < 4) return;
        double shine = Theme.highlightFor(surface);
        double frost = Theme.blurFor(surface);
        if (shine <= 0.001 && frost <= 0.001) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        int inset = Math.max(1, r / 2);
        int top = Math.max(1, Math.min(4, h / 8));
        double opacity = Theme.opacityFor(surface);
        // Frost slightly lifts the surface without smearing text or touching the game framebuffer.
        int frostAlpha = (int) Math.round(frost * (emphasized ? 0.105 : 0.065) * 255.0);
        int shineAlpha = (int) Math.round(shine * (emphasized ? 0.22 : 0.12) * (1.0 - opacity * 0.45) * 255.0);
        int baseAlpha = Math.min(255, frostAlpha + shineAlpha);
        int topColor = (baseAlpha << 24) | 0xFFFFFF;
        int fadeColor = ((int) (baseAlpha * 0.12) << 24) | 0xFFFFFF;
        if (w > inset * 2 && baseAlpha > 0) g.fillGradient(x + inset, y + 1, x + w - inset, y + 1 + top, topColor, fadeColor);
        int edgeAlpha = (int) Math.round((emphasized ? 0x32 : 0x1B) * shine);
        if (edgeAlpha > 0) g.fill(x + inset, y + 1, x + w - inset, y + 2, (edgeAlpha << 24) | 0xFFFFFF);
        if (emphasized && shine > 0.02 && Theme.glowEnabled && Theme.glowStrength > 0.05) {
            int accentAlpha = (int) Math.round(40 * Theme.glowStrength * shine);
            if (accentAlpha > 0) g.fill(x + inset, y + 2, x + w - inset, y + 3, (accentAlpha << 24) | (Theme.glowColor & 0xFFFFFF));
        }
    }

    private static void draw(MsdfFont f, GuiGraphics g, String s, float x, float y, int c, float t) {
        int p = px(t);
        int baseline = Math.round(y) + Math.round(p * CAP) + Math.round(TEXT_Y * t);
        f.draw(g, s, Math.round(x), baseline, p, c);
    }

    public static void text(GuiGraphics g, String s, float x, float y, int c, float t) { draw(MEDIUM, g, s, x, y, c, t); }
    public static void textBold(GuiGraphics g, String s, float x, float y, int c, float t) { draw(BOLD, g, s, x, y, c, t); }

    public static void centered(GuiGraphics g, String s, float cx, float y, int c, float t) {
        draw(MEDIUM, g, s, cx - MEDIUM.width(s, px(t)) / 2f, y, c, t);
    }
    public static void centeredBold(GuiGraphics g, String s, float cx, float y, int c, float t) {
        draw(BOLD, g, s, cx - BOLD.width(s, px(t)) / 2f, y, c, t);
    }

    public static int width(String s, float t) { return MEDIUM.width(s, px(t)); }
    public static int boldWidth(String s, float t) { return BOLD.width(s, px(t)); }
    public static int height(float t) { return Math.round(px(t) * CAP); }

    public static void flush() { MEDIUM.flush(); BOLD.flush(); Shapes.flush(); Logo.flush(); CategoryIcons.flush(); }

    public static void scissor(GuiGraphics g, int x, int y, int w, int h) { g.enableScissor(x, y, x + w, y + h); }
    public static void unscissor(GuiGraphics g) { g.disableScissor(); }

    public static boolean hover(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
