package dev.hvh.client.neuro;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * Shared "Нейро" aiming engine (AimAssist and KillAura use the same one, with the same model and the same strength).
 *
 * The model was trained on per-TICK data: its input is the state at the start of a tick and its output is how far the
 * camera turned during that tick. So the model still runs exactly once per tick (that is what keeps its behaviour the
 * same as in the training data, it even sees its own previous turn through vel_yaw / vel_pitch), but the turn it
 * returns is NOT applied in one jump at the start of the tick (that was the 20 Hz stepping). It is spread over the
 * rendered frames of the tick: every frame turns the camera by (output * fraction of the tick that has passed since
 * the previous frame). At the end of the tick the whole output has been applied, so the numbers are the same as before,
 * only the motion in between is smooth. Whatever is left when the next tick starts is flushed first.
 *
 * Call order:  every tick  flush() -> track() -> step()   |   every rendered frame  frame()
 */
public final class NeuroDriver {
    // camera / attack tracking (measured at the start of every tick)
    private boolean haveLast;
    private float lastYaw, lastPitch, velYaw, velPitch;
    private float lastCooldown = 1F;
    private int sinceAttack = 40;

    // target angular rate (per tick)
    private boolean haveWanted;
    private float lastWantedYaw, lastWantedPitch;
    private UUID lastWantedTarget;

    // the turn the model asked for this tick and how much of it the frames have already applied (0..1)
    private float pendYaw, pendPitch, done = 1F;

    /** Total yaw turned by the driver since the last {@link #takeOwnYaw()}: lets KillAura tell its own turn from the mouse. */
    private float ownYaw;

    /** Forget everything (module switched on / mode changed): the next tick starts from the camera as it is. */
    public void clear() {
        haveLast = false; haveWanted = false; lastWantedTarget = null;
        pendYaw = 0F; pendPitch = 0F; done = 1F; ownYaw = 0F;
        velYaw = 0F; velPitch = 0F; sinceAttack = 40; lastCooldown = 1F;
    }

    /** Drop the unfinished turn (no target / screen opened) but keep the camera tracking. */
    public void cancel() {
        pendYaw = 0F; pendPitch = 0F; done = 1F;
        haveWanted = false;
    }

    /** Net yaw the driver itself turned since the last call (and resets it). */
    public float takeOwnYaw() { float v = ownYaw; ownYaw = 0F; return v; }

    /** START of the tick, first call: apply what is left of the previous tick's turn so no motion is lost. */
    public void flush(Player p) {
        if (done < 1F && (pendYaw != 0F || pendPitch != 0F)) turn(p, pendYaw * (1F - done), pendPitch * (1F - done));
        pendYaw = 0F; pendPitch = 0F; done = 1F;
    }

    /** START of the tick, after flush(): measure camera speed and attack timing of the tick that just finished. */
    public void track(Player p) {
        float cy = p.getYRot(), cp = p.getXRot();
        velYaw = haveLast ? Mth.wrapDegrees(cy - lastYaw) : 0F;
        velPitch = haveLast ? cp - lastPitch : 0F;
        lastYaw = cy; lastPitch = cp; haveLast = true;
        float cd = p.getAttackStrengthScale(0F);
        if (cd < lastCooldown - 0.3F) sinceAttack = 0; else sinceAttack = Math.min(40, sinceAttack + 1);
        lastCooldown = cd;
    }

    /**
     * START of the tick, after track(): build the 14 features, run the model once and store the turn for this tick.
     * Returns false when there is no usable model (nothing is turned).
     */
    public boolean step(Player p, LivingEntity target, boolean vertical, double strengthFactor) {
        return step(p, target, vertical, strengthFactor, -1.0, 0.0);
    }

    /**
     * Same, with the drift guards (the model has a small constant lean, so the crosshair may settle beside the target):
     * @param maxOffDeg  how far (degrees) the crosshair may leave the target's hitbox edge; negative = no limit
     * @param homing     0..1: share of the remaining error (after the model's turn) that is closed on top of it
     */
    public boolean step(Player p, LivingEntity target, boolean vertical, double strengthFactor, double maxOffDeg, double homing) {
        NeuroAim.ensureLoaded();
        OnnxMlp model = NeuroAim.model();
        if (model == null || target == null) { cancel(); return false; }

        // aim point: the target's x/z, height = your eye height clamped into the lower part of the hitbox
        Vec3 eye = p.getEyePosition();
        double minY = target.getY(), h = target.getBbHeight();
        double ay = Mth.clamp(eye.y, minY, minY + Math.max(0.0, h - 0.4));
        double dx = target.getX() - eye.x, dy = ay - eye.y, dz = target.getZ() - eye.z;
        double hd = Math.sqrt(dx * dx + dz * dz);
        float wantedYaw = (float) (Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        float wantedPitch = (float) (-(Mth.atan2(dy, hd) * 180.0 / Math.PI));
        float camYaw = p.getYRot(), camPitch = p.getXRot();

        boolean same = haveWanted && target.getUUID().equals(lastWantedTarget);
        float rateYaw = same ? Mth.wrapDegrees(wantedYaw - lastWantedYaw) : 0F;
        float ratePitch = same ? wantedPitch - lastWantedPitch : 0F;
        haveWanted = true; lastWantedYaw = wantedYaw; lastWantedPitch = wantedPitch; lastWantedTarget = target.getUUID();

        Vec3 mv = p.getDeltaMovement();
        float[] in = new float[NeuroAim.INPUTS];
        in[0] = Mth.wrapDegrees(wantedYaw - camYaw);
        in[1] = wantedPitch - camPitch;
        in[2] = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        in[3] = velYaw;
        in[4] = velPitch;
        in[5] = sinceAttack;
        in[6] = lastCooldown;
        in[7] = target.getBbHeight();
        in[8] = rateYaw;
        in[9] = ratePitch;
        in[10] = (float) Math.sqrt(mv.x * mv.x + mv.z * mv.z);
        in[11] = p.isSprinting() ? 1F : 0F;
        in[12] = p.onGround() ? 1F : 0F;
        in[13] = target.getBbWidth();

        float[] out;
        try { out = model.run(in); } catch (RuntimeException e) { cancel(); return false; }
        float k = (float) strengthFactor;
        float dyaw = out[0] * k, dpitch = out[1] * k;
        if (!Float.isFinite(dyaw) || !Float.isFinite(dpitch)) { cancel(); return false; }
        pendYaw = Mth.clamp(dyaw, -90F, 90F);
        pendPitch = vertical ? Mth.clamp(dpitch, -60F, 60F) : 0F;

        // ---- drift guards: only act when the crosshair is already close (never speed up the first approach) ----
        double horiz = Math.max(0.05, Math.sqrt((target.getX() - eye.x) * (target.getX() - eye.x) + (target.getZ() - eye.z) * (target.getZ() - eye.z)));
        if (homing > 0.0) {
            float eYaw = wantedYaw - (camYaw + pendYaw);                 // error left after the model's turn
            eYaw = Mth.wrapDegrees(eYaw);
            if (Math.abs(eYaw) <= ENGAGE) pendYaw += (float) (eYaw * homing);
            if (vertical) {
                float ePitch = wantedPitch - (camPitch + pendPitch);
                if (Math.abs(ePitch) <= ENGAGE) pendPitch += (float) (ePitch * homing);
            }
        }
        if (maxOffDeg >= 0.0) {
            double halfW = Math.toDegrees(Math.atan2(target.getBbWidth() / 2.0, horiz)) + maxOffDeg;
            float rPre = Mth.wrapDegrees(camYaw - wantedYaw);
            pendYaw += pull(rPre, rPre + pendYaw, -halfW, halfW);
            if (vertical) {
                double top = -Math.toDegrees(Math.atan2(target.getY() + target.getBbHeight() - eye.y, horiz));   // smaller pitch = up
                double bottom = -Math.toDegrees(Math.atan2(target.getY() - eye.y, horiz));
                pendPitch += pull(camPitch, camPitch + pendPitch, top - maxOffDeg, bottom + maxOffDeg);
            }
        }
        done = 0F;
        return true;
    }

    /** Only guard when the crosshair is within this many degrees of the allowed range (not while it is still arriving). */
    private static final double ENGAGE = 10.0;
    /** One tick never pulls back by more than this: the correction stays a smooth nudge, not a snap. */
    private static final double MAX_PULL = 5.0;

    /** Correction (added to this tick's turn) that brings the post-turn value back into [lo, hi]. */
    private static float pull(float pre, float post, double lo, double hi) {
        double outside = pre < lo ? lo - pre : (pre > hi ? pre - hi : 0.0);
        if (outside > ENGAGE) return 0F;
        double corr = post > hi ? hi - post : (post < lo ? lo - post : 0.0);
        return (float) Mth.clamp(corr, -MAX_PULL, MAX_PULL);
    }

    /**
     * Every rendered frame: turn the camera by the part of this tick's turn that belongs to the time since the last
     * frame. {@code partial} = fraction (0..1) of the current tick that has passed.
     */
    public void frame(Player p, float partial) {
        if (done >= 1F || (pendYaw == 0F && pendPitch == 0F)) return;
        float to = Mth.clamp(Math.max(partial, done), 0F, 1F);
        float frac = to - done;
        if (frac <= 0F) return;
        done = to;
        turn(p, pendYaw * frac, pendPitch * frac);
    }

    /** Turns the camera like the mouse does (vanilla Entity#turn): the previous rotation moves along, so the view does not lag. */
    private void turn(Player p, float dYaw, float dPitch) {
        float x0 = p.getXRot();
        float x1 = Mth.clamp(x0 + dPitch, -90.0F, 90.0F);
        p.setYRot(p.getYRot() + dYaw);
        p.setXRot(x1);
        p.yRotO += dYaw;
        p.xRotO += x1 - x0;
        ownYaw += dYaw;
    }
}
