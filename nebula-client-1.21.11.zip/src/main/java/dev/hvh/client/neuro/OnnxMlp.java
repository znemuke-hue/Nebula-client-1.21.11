package dev.hvh.client.neuro;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tiny dependency-free ONNX runner for feed-forward networks (MLP). It reads the .onnx protobuf itself, so the mod
 * needs no native onnxruntime library and works on every platform (PC and phone alike).
 *
 * Supported ops: Gemm, MatMul, Add, Sub, Mul, Div, Relu, LeakyRelu, Tanh, Sigmoid, Clip, Constant and the
 * pass-through ops Identity / Flatten / Reshape / Squeeze / Unsqueeze / Cast / Dropout. Float32 / float64 weights.
 * A model with any other op is rejected with a readable message.
 */
public final class OnnxMlp {
    private static final class Tensor {
        float[] d; int[] shape;
        Tensor(float[] d, int... shape) { this.d = d; this.shape = shape; }
    }

    private static final class Node {
        String op, name; List<String> in = new ArrayList<>(), out = new ArrayList<>();
        Map<String, Float> f = new HashMap<>(); Map<String, Long> i = new HashMap<>(); Map<String, Tensor> t = new HashMap<>();
    }

    private final Map<String, Tensor> consts = new HashMap<>();
    private final List<Node> nodes = new ArrayList<>();
    private String inputName, outputName;
    public final int inputSize;     // -1 when the file does not say
    public final String info;

    // ------------------------------------------------------------------------------------------ protobuf reader
    private static final class Pb {
        final byte[] b; int p; final int end;
        Pb(byte[] b, int p, int end) { this.b = b; this.p = p; this.end = end; }
        boolean more() { return p < end; }
        long varint() throws IOException {
            long r = 0; int s = 0;
            while (true) {
                if (p >= end) throw new IOException("truncated file");
                int c = b[p++] & 0xFF; r |= (long) (c & 0x7F) << s;
                if ((c & 0x80) == 0) return r;
                s += 7; if (s > 63) throw new IOException("bad varint");
            }
        }
        int fixed32() throws IOException { if (p + 4 > end) throw new IOException("truncated file"); int v = ByteBuffer.wrap(b, p, 4).order(ByteOrder.LITTLE_ENDIAN).getInt(); p += 4; return v; }
        Pb sub() throws IOException {
            int len = (int) varint();
            if (len < 0 || p + len > end) throw new IOException("truncated file");
            Pb s = new Pb(b, p, p + len); p += len; return s;
        }
        String str() throws IOException { Pb s = sub(); return new String(b, s.p, s.end - s.p, StandardCharsets.UTF_8); }
        void skip(int wt) throws IOException {
            switch (wt) {
                case 0 -> varint();
                case 1 -> p += 8;
                case 2 -> sub();
                case 5 -> p += 4;
                default -> throw new IOException("unsupported protobuf wire type " + wt);
            }
        }
    }

    // ------------------------------------------------------------------------------------------ loading
    public static OnnxMlp load(Path file) throws IOException {
        return new OnnxMlp(Files.readAllBytes(file));
    }

    private OnnxMlp(byte[] data) throws IOException {
        Pb m = new Pb(data, 0, data.length);
        Pb graph = null;
        while (m.more()) {
            int tag = (int) m.varint(), f = tag >>> 3, wt = tag & 7;
            if (f == 7 && wt == 2) graph = m.sub(); else m.skip(wt);
        }
        if (graph == null) throw new IOException("это не ONNX-модель (нет графа)");

        List<String> inputs = new ArrayList<>(), outputs = new ArrayList<>();
        int dim = -1;
        while (graph.more()) {
            int tag = (int) graph.varint(), f = tag >>> 3, wt = tag & 7;
            if (f == 1 && wt == 2) nodes.add(readNode(graph.sub()));
            else if (f == 5 && wt == 2) { Object[] t = readTensor(graph.sub()); consts.put((String) t[0], (Tensor) t[1]); }
            else if (f == 11 && wt == 2) { Object[] vi = readValueInfo(graph.sub()); inputs.add((String) vi[0]); if (!consts.containsKey(vi[0]) ) dim = (Integer) vi[1]; }
            else if (f == 12 && wt == 2) outputs.add((String) readValueInfo(graph.sub())[0]);
            else graph.skip(wt);
        }
        // graph inputs of older exporters also list the weights - the real input is the one that is not a constant
        for (String n : inputs) if (!consts.containsKey(n)) { inputName = n; break; }
        if (inputName == null) throw new IOException("в модели нет входа");
        if (outputs.isEmpty()) throw new IOException("в модели нет выхода");
        outputName = outputs.get(0);
        inputSize = dim;
        for (Node n : nodes) check(n);
        info = nodes.size() + " слоёв, вход " + (dim > 0 ? dim : "?");
    }

    private static final java.util.Set<String> OPS = java.util.Set.of("Gemm", "MatMul", "Add", "Sub", "Mul", "Div", "Relu", "LeakyRelu",
        "Tanh", "Sigmoid", "Clip", "Constant", "Identity", "Flatten", "Reshape", "Squeeze", "Unsqueeze", "Cast", "Dropout");

    private void check(Node n) throws IOException {
        if (!OPS.contains(n.op)) throw new IOException("слой \"" + n.op + "\" не поддерживается (нужна обычная полносвязная сеть)");
        if (n.op.equals("Constant") && n.t.containsKey("value")) consts.put(n.out.get(0), n.t.get("value"));
    }

    private Node readNode(Pb p) throws IOException {
        Node n = new Node();
        while (p.more()) {
            int tag = (int) p.varint(), f = tag >>> 3, wt = tag & 7;
            switch (f) {
                case 1 -> n.in.add(p.str());
                case 2 -> n.out.add(p.str());
                case 3 -> n.name = p.str();
                case 4 -> n.op = p.str();
                case 5 -> readAttr(p.sub(), n);
                default -> p.skip(wt);
            }
        }
        if (n.op == null) throw new IOException("слой без типа");
        return n;
    }

    private void readAttr(Pb p, Node n) throws IOException {
        String name = null; Float fv = null; Long iv = null; Tensor tv = null;
        while (p.more()) {
            int tag = (int) p.varint(), f = tag >>> 3, wt = tag & 7;
            if (f == 1) name = p.str();
            else if (f == 2 && wt == 5) fv = Float.intBitsToFloat(p.fixed32());
            else if (f == 3 && wt == 0) iv = p.varint();
            else if (f == 5 && wt == 2) tv = (Tensor) readTensor(p.sub())[1];
            else p.skip(wt);
        }
        if (name == null) return;
        if (fv != null) n.f.put(name, fv);
        if (iv != null) n.i.put(name, iv);
        if (tv != null) n.t.put(name, tv);
    }

    private Object[] readTensor(Pb p) throws IOException {
        List<Integer> dims = new ArrayList<>(); String name = ""; int type = 1;
        byte[] raw = null; int rawOff = 0, rawLen = 0;
        List<Float> fl = new ArrayList<>(); List<Double> dbl = new ArrayList<>();
        while (p.more()) {
            int tag = (int) p.varint(), f = tag >>> 3, wt = tag & 7;
            if (f == 1) { if (wt == 2) { Pb s = p.sub(); while (s.more()) dims.add((int) s.varint()); } else dims.add((int) p.varint()); }
            else if (f == 2 && wt == 0) type = (int) p.varint();
            else if (f == 4) { if (wt == 2) { Pb s = p.sub(); while (s.more()) fl.add(Float.intBitsToFloat(s.fixed32())); } else fl.add(Float.intBitsToFloat(p.fixed32())); }
            else if (f == 8 && wt == 2) name = p.str();
            else if (f == 9 && wt == 2) { Pb s = p.sub(); raw = p.b; rawOff = s.p; rawLen = s.end - s.p; }
            else if (f == 10 && wt == 2) { Pb s = p.sub(); while (s.more()) dbl.add(Double.longBitsToDouble(ByteBuffer.wrap(s.b, s.p, 8).order(ByteOrder.LITTLE_ENDIAN).getLong())); s.p = s.end; }
            else p.skip(wt);
        }
        int total = 1; for (int d : dims) total *= d;
        float[] out;
        if (raw != null) {
            ByteBuffer bb = ByteBuffer.wrap(raw, rawOff, rawLen).order(ByteOrder.LITTLE_ENDIAN);
            if (type == 1) { out = new float[rawLen / 4]; for (int i = 0; i < out.length; i++) out[i] = bb.getFloat(); }
            else if (type == 11) { out = new float[rawLen / 8]; for (int i = 0; i < out.length; i++) out[i] = (float) bb.getDouble(); }
            else if (type == 7) { out = new float[rawLen / 8]; for (int i = 0; i < out.length; i++) out[i] = bb.getLong(); }
            else throw new IOException("тип весов " + type + " не поддерживается (нужен float32)");
        } else if (!fl.isEmpty()) { out = new float[fl.size()]; for (int i = 0; i < out.length; i++) out[i] = fl.get(i); }
        else { out = new float[dbl.size()]; for (int i = 0; i < out.length; i++) out[i] = dbl.get(i).floatValue(); }
        if (dims.isEmpty()) dims.add(out.length);
        int[] shape = new int[dims.size()]; for (int i = 0; i < shape.length; i++) shape[i] = dims.get(i);
        if (total != out.length && total > 0 && out.length > 0) throw new IOException("повреждённый тензор \"" + name + "\"");
        return new Object[] {name, new Tensor(out, shape)};
    }

    /** -> {name, last dimension (-1 if unknown)} */
    private Object[] readValueInfo(Pb p) throws IOException {
        String name = ""; int last = -1;
        while (p.more()) {
            int tag = (int) p.varint(), f = tag >>> 3, wt = tag & 7;
            if (f == 1 && wt == 2) name = p.str();
            else if (f == 2 && wt == 2) { // TypeProto -> tensor_type(1) -> shape(2) -> dim(1) -> dim_value(1)
                Pb tp = p.sub();
                while (tp.more()) { int t2 = (int) tp.varint(); if ((t2 >>> 3) == 1 && (t2 & 7) == 2) {
                    Pb tt = tp.sub();
                    while (tt.more()) { int t3 = (int) tt.varint(); if ((t3 >>> 3) == 2 && (t3 & 7) == 2) {
                        Pb sh = tt.sub();
                        while (sh.more()) { int t4 = (int) sh.varint(); if ((t4 >>> 3) == 1 && (t4 & 7) == 2) {
                            Pb dm = sh.sub(); last = -1;
                            while (dm.more()) { int t5 = (int) dm.varint(); if ((t5 >>> 3) == 1 && (t5 & 7) == 0) last = (int) dm.varint(); else dm.skip(t5 & 7); }
                        } else sh.skip(t4 & 7); }
                    } else tt.skip(t3 & 7); }
                } else tp.skip(t2 & 7); }
            } else p.skip(wt);
        }
        return new Object[] {name, last};
    }

    // ------------------------------------------------------------------------------------------ inference
    /** Runs one sample. Not thread-safe against load, but cheap: allocate-per-call is fine at 20 Hz. */
    public float[] run(float[] input) {
        Map<String, Tensor> v = new HashMap<>(consts);
        v.put(inputName, new Tensor(input.clone(), 1, input.length));
        for (Node n : nodes) {
            if (n.op.equals("Constant")) continue;
            Tensor a = n.in.isEmpty() ? null : v.get(n.in.get(0));
            Tensor r = switch (n.op) {
                case "Gemm" -> gemm(n, a, v.get(n.in.get(1)), n.in.size() > 2 ? v.get(n.in.get(2)) : null);
                case "MatMul" -> matmul(a, v.get(n.in.get(1)));
                case "Add", "Sub", "Mul", "Div" -> bin(n.op, a, v.get(n.in.get(1)));
                case "Relu" -> map(a, x -> x > 0 ? x : 0);
                case "LeakyRelu" -> { float al = n.f.getOrDefault("alpha", 0.01f); yield map(a, x -> x >= 0 ? x : al * x); }
                case "Tanh" -> map(a, x -> (float) Math.tanh(x));
                case "Sigmoid" -> map(a, x -> (float) (1.0 / (1.0 + Math.exp(-x))));
                case "Clip" -> {
                    float lo = n.in.size() > 1 && v.get(n.in.get(1)) != null ? v.get(n.in.get(1)).d[0] : n.f.getOrDefault("min", -Float.MAX_VALUE);
                    float hi = n.in.size() > 2 && v.get(n.in.get(2)) != null ? v.get(n.in.get(2)).d[0] : n.f.getOrDefault("max", Float.MAX_VALUE);
                    yield map(a, x -> Math.max(lo, Math.min(hi, x)));
                }
                default -> a; // Identity, Flatten, Reshape, Squeeze, Unsqueeze, Cast, Dropout
            };
            v.put(n.out.get(0), r);
        }
        return v.get(outputName).d;
    }

    private interface F { float ap(float x); }
    private static Tensor map(Tensor a, F f) { float[] o = new float[a.d.length]; for (int i = 0; i < o.length; i++) o[i] = f.ap(a.d[i]); return new Tensor(o, a.shape); }

    private static Tensor bin(String op, Tensor a, Tensor b) {
        int n = Math.max(a.d.length, b.d.length);
        float[] o = new float[n];
        for (int i = 0; i < n; i++) {
            float x = a.d[i % a.d.length], y = b.d[i % b.d.length];
            o[i] = switch (op) { case "Add" -> x + y; case "Sub" -> x - y; case "Mul" -> x * y; default -> x / y; };
        }
        return new Tensor(o, a.d.length >= b.d.length ? a.shape : b.shape);
    }

    private static Tensor matmul(Tensor a, Tensor b) {
        int k = b.shape[b.shape.length - 2], n = b.shape[b.shape.length - 1], m = a.d.length / k;
        float[] o = new float[m * n];
        for (int r = 0; r < m; r++) for (int j = 0; j < n; j++) {
            float s = 0; for (int i = 0; i < k; i++) s += a.d[r * k + i] * b.d[i * n + j];
            o[r * n + j] = s;
        }
        return new Tensor(o, m, n);
    }

    private static Tensor gemm(Node nd, Tensor a, Tensor b, Tensor c) {
        boolean tb = nd.i.getOrDefault("transB", 0L) != 0, ta = nd.i.getOrDefault("transA", 0L) != 0;
        float alpha = nd.f.getOrDefault("alpha", 1f), beta = nd.f.getOrDefault("beta", 1f);
        int k = tb ? b.shape[1] : b.shape[0], n = tb ? b.shape[0] : b.shape[1], m = a.d.length / k;
        float[] o = new float[m * n];
        for (int r = 0; r < m; r++) for (int j = 0; j < n; j++) {
            float s = 0;
            for (int i = 0; i < k; i++) {
                float x = ta ? a.d[i * m + r] : a.d[r * k + i];
                float w = tb ? b.d[j * k + i] : b.d[i * n + j];
                s += x * w;
            }
            o[r * n + j] = alpha * s + (c == null ? 0 : beta * c.d[(r * n + j) % c.d.length]);
        }
        return new Tensor(o, m, n);
    }
}
