package dev.hvh.client.neuro;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * Builds the 14 model features and runs the model. The "head" rotation is passed in by the caller: the real camera
 * (AimAssist) or a virtual head that only the server sees (KillAura, silent). Call {@link #track} once per tick.
 */
public final class NeuroTracker {
    private boolean haveLast;
    private float lastYaw, lastPitch, velYaw, velPitch;
    private float lastCooldown = 1F;
    private int sinceAttack = 40;
    private boolean haveWanted;
    private float lastWantedYaw, lastWantedPitch;
    private UUID lastWantedTarget;

    public void reset() { haveLast = false; haveWanted = false; lastCooldown = 1F; sinceAttack = 40; }
    public void forgetTarget() { haveWanted = false; }

    /** Every tick: head speed of the last tick and attack timing. */
    public void track(Player p, float yaw, float pitch) {
        velYaw = haveLast ? Mth.wrapDegrees(yaw - lastYaw) : 0F;
        velPitch = haveLast ? pitch - lastPitch : 0F;
        lastYaw = yaw; lastPitch = pitch; haveLast = true;
        float cd = p.getAttackStrengthScale(0F);
        if (cd < lastCooldown - 0.3F) sinceAttack = 0; else sinceAttack = Math.min(40, sinceAttack + 1);
        lastCooldown = cd;
    }

    /** -> {yaw turn, pitch turn} in degrees for this tick, or null when there is no usable model. */
    public float[] infer(Player p, LivingEntity target, float yaw, float pitch, double strengthPercent) {
        NeuroAim.ensureLoaded();
        OnnxMlp model = NeuroAim.model();
        if (model == null) return null;

        Vec3 eye = p.getEyePosition();
        double minY = target.getY(), h = target.getBbHeight();
        double ay = Mth.clamp(eye.y, minY, minY + h - 0.4);   // aim point: x/z of the target, eye height clamped into the lower hitbox
        double dx = target.getX() - eye.x, dy = ay - eye.y, dz = target.getZ() - eye.z;
        double hd = Math.sqrt(dx * dx + dz * dz);
        float wantedYaw = (float)(Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        float wantedPitch = (float)(-(Mth.atan2(dy, hd) * 180.0 / Math.PI));

        boolean same = haveWanted && target.getUUID().equals(lastWantedTarget);
        float rateYaw = same ? Mth.wrapDegrees(wantedYaw - lastWantedYaw) : 0F;
        float ratePitch = same ? wantedPitch - lastWantedPitch : 0F;
        haveWanted = true; lastWantedYaw = wantedYaw; lastWantedPitch = wantedPitch; lastWantedTarget = target.getUUID();

        Vec3 mv = p.getDeltaMovement();
        float[] in = new float[NeuroAim.INPUTS];
        in[0] = Mth.wrapDegrees(wantedYaw - yaw);
        in[1] = wantedPitch - pitch;
        in[2] = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        in[3] = velYaw;
        in[4] = velPitch;
        in[5] = sinceAttack;
        in[6] = lastCooldown;
        in[7] = target.getBbHeight();
        in[8] = rateYaw;
        in[9] = ratePitch;
        in[10] = (float) Math.sqrt(mv.x * mv.x + mv.z * mv.z);
        in[11] = p.isSprinting() ? 1F : 0F;
        in[12] = p.onGround() ? 1F : 0F;
        in[13] = target.getBbWidth();

        float[] out;
        try { out = model.run(in); } catch (RuntimeException e) { return null; }
        float k = (float)(strengthPercent / 100.0);
        float dyaw = out[0] * k, dpitch = out[1] * k;
        if (!Float.isFinite(dyaw) || !Float.isFinite(dpitch)) return null;
        return new float[] {Mth.clamp(dyaw, -90F, 90F), Mth.clamp(dpitch, -60F, 60F)};
    }
}
