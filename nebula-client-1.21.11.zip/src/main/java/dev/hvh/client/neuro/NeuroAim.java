package dev.hvh.client.neuro;

import net.minecraft.client.Minecraft;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Model storage for AimAssist "Нейро": .onnx files live in config/nebula/models, the chosen one is remembered in
 * config/nebula/models/selected.txt. The model contract (14 inputs -> 2 outputs) is described in train_neuro_aim.py.
 */
public final class NeuroAim {
    private NeuroAim() {}

    public static final int INPUTS = 14;

    private static OnnxMlp model;
    private static String selectedName = "";
    private static String error = "";
    private static boolean loadedOnce;

    public static Path modelsDir() { return Minecraft.getInstance().gameDirectory.toPath().resolve("config/nebula/models"); }
    private static Path selectedFile() { return modelsDir().resolve("selected.txt"); }

    public static void ensureDir() {
        try {
            Files.createDirectories(modelsDir());
            Path readme = modelsDir().resolve("README.txt");
            if (!Files.exists(readme)) Files.writeString(readme,
                "Nebula Client Neuro rotation models\n\n" +
                "Built-in presets: default-soft.onnx, default-balanced.onnx, default-fast.onnx, default-BS.onnx and default-nebula_aim_trained.onnx.\n" +
                "These are small linear presets accepted by the client's built-in ONNX runner; you can replace them with your own 14-input / 2-output model.\n");
            for (String preset : List.of(
                "default-soft.onnx", "default-balanced.onnx", "default-fast.onnx",
                "default-BS.onnx", "default-nebula_aim_trained.onnx"
            )) {
                Path target = modelsDir().resolve(preset);
                if (!Files.exists(target)) {
                    try (java.io.InputStream in = NeuroAim.class.getResourceAsStream("/nebula-defaults/models/" + preset)) {
                        if (in != null) Files.copy(in, target);
                    }
                }
            }
        } catch (Exception ignored) { }
    }

    /** Loads the remembered model once (called when the module is switched on / the picker opens). */
    public static void ensureLoaded() {
        if (loadedOnce) return;
        loadedOnce = true;
        ensureDir();
        try {
            if (!Files.exists(selectedFile())) return;
            String name = Files.readString(selectedFile()).trim();
            if (!name.isEmpty()) load(modelsDir().resolve(name));
        } catch (Exception e) { error = String.valueOf(e.getMessage()); }
    }

    public static OnnxMlp model() { return model; }
    public static String selectedName() { return selectedName; }
    public static String error() { return error; }
    public static String info() { return model == null ? "" : model.info; }

    /** Every .onnx in the models folder plus the usual download folders (a tapped external file is copied in). */
    public static List<Path> candidates() {
        List<Path> out = new ArrayList<>();
        ensureDir();
        scan(modelsDir(), out);
        // The balanced preset is exposed as a dedicated "Дефолт" row in the picker.
        out.removeIf(p -> p.getFileName().toString().equalsIgnoreCase("default-balanced.onnx"));
        List<String> names = new ArrayList<>();
        for (Path p : out) names.add(p.getFileName().toString());
        String home = System.getProperty("user.home", "");
        for (String d : new String[] {"/storage/emulated/0/Download", "/storage/emulated/0/Documents", home + "/Downloads", home + "/Download"}) {
            List<Path> ext = new ArrayList<>();
            scan(Path.of(d), ext);
            for (Path p : ext) if (!names.contains(p.getFileName().toString())) { out.add(p); names.add(p.getFileName().toString()); }
        }
        return out;
    }

    private static void scan(Path dir, List<Path> out) {
        try (Stream<Path> s = Files.list(dir)) {
            s.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().toLowerCase().endsWith(".onnx"))
                .sorted().limit(200).forEach(out::add);
        } catch (Exception ignored) {}
    }

    public static boolean inModelsDir(Path p) {
        try { return p.toAbsolutePath().normalize().startsWith(modelsDir().toAbsolutePath().normalize()); } catch (Exception e) { return false; }
    }

    /** Selects a model (null = none). Returns null on success or a readable error. */
    public static String select(Path file) {
        loadedOnce = true;
        ensureDir();
        if (file == null) {
            model = null; selectedName = ""; error = "";
            try { Files.deleteIfExists(selectedFile()); } catch (Exception ignored) {}
            return null;
        }
        try {
            Path target = file;
            if (!inModelsDir(file)) {
                target = modelsDir().resolve(file.getFileName().toString());
                Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING);
            }
            load(target);
            Files.writeString(selectedFile(), target.getFileName().toString());
            return null;
        } catch (Exception e) {
            return String.valueOf(e.getMessage());
        }
    }

    private static void load(Path p) throws Exception {
        OnnxMlp m = OnnxMlp.load(p);
        if (m.inputSize > 0 && m.inputSize != INPUTS)
            throw new Exception("модель ждёт " + m.inputSize + " входов, нужно " + INPUTS);
        float[] test = m.run(new float[INPUTS]);
        if (test.length < 2) throw new Exception("у модели должно быть 2 выхода (yaw, pitch)");
        model = m; selectedName = p.getFileName().toString(); error = "";
    }
}
