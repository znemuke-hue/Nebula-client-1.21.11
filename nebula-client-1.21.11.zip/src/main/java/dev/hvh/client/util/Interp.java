package dev.hvh.client.util;

import dev.hvh.client.HvhClient;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Per-frame interpolation of entity positions.
 *
 * Entity#getBoundingBox() / getX() only change once per client tick (20 Hz), so anything drawn from them directly
 * looks like it runs at 20 FPS. Rendering code must blend between the previous and the current tick position with
 * the fraction of the tick that has already elapsed ({@link HvhClient#partialTick()}), exactly like vanilla does.
 */
public final class Interp {
    private Interp() {}

    /** Teleports / respawns: do not slide the box across the map. */
    private static final double MAX_STEP_SQ = 16.0 * 16.0;

    public static AABB box(Entity e, float pt) {
        AABB b = e.getBoundingBox();
        double dx = e.getX() - e.xo, dy = e.getY() - e.yo, dz = e.getZ() - e.zo;
        if (dx * dx + dy * dy + dz * dz > MAX_STEP_SQ) return b;
        double back = pt - 1.0; // 0 at the end of the tick, -1 at its start
        return b.move(dx * back, dy * back, dz * back);
    }

    public static Vec3 pos(Entity e, float pt) {
        double dx = e.getX() - e.xo, dy = e.getY() - e.yo, dz = e.getZ() - e.zo;
        if (dx * dx + dy * dy + dz * dz > MAX_STEP_SQ) return new Vec3(e.getX(), e.getY(), e.getZ());
        return new Vec3(e.xo + dx * pt, e.yo + dy * pt, e.zo + dz * pt);
    }
}
