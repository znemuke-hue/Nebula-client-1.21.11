package dev.hvh.client.util;

import dev.hvh.client.HvhClient;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Method;

/**
 * World -> screen projection for the Nametags / TargetESP overlays.
 *
 * GameRenderer#projectPointToScreen uses camera state that is not the one the world is drawn with: it trails the
 * mouse by a frame (so overlays "slide" while you turn) and its field of view can differ. Here the projection is
 * rebuilt every frame from the live camera (position + yaw/pitch). The vertical field of view comes from
 *   - "Хук FOV": the value GameRenderer#getFov returned (captured by ZoomMixin), or
 *   - "Калибровка": measured against the engine projection while the camera is standing still (then the engine
 *     is not lagging, so it can be used as a ruler), or
 *   - "Движок": the old engine projection (fallback / for comparison).
 * Entity positions are interpolated with the real partial tick read from the HUD callback's DeltaTracker.
 */
public final class Projector {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final long FRESH = 250_000_000L;
    private static final long CALIB_KEEP = 600_000_000_000L; // a measured FOV stays valid for 10 min (HvH: you rarely stand still)

    // FOV reported by getFov (the hand is drawn with a constant 70, the world with option * effects)
    private static volatile double hookFov = -1;
    private static volatile long hookAt, seventyAt;

    // calibration against the engine projection while the camera is still
    private static double calibTan = -1;
    private static long calibAt, lastCalib;
    private static float prevYaw, prevPitch;
    private static int still;

    // per-frame data
    private static long lastBegin;
    private static float framePt = -1;
    private static boolean ptReal;
    private static Method ptMethod;
    private static Class<?> ptClass;

    private Projector() {}

    // ------------------------------------------------------------------ inputs

    /** Called by ZoomMixin with every value GameRenderer#getFov returns. */
    public static void onFov(double v) {
        if (!Double.isFinite(v) || v <= 0) return;
        if (v < 5.0) v = Math.toDegrees(v); // some versions use radians
        long now = System.nanoTime();
        if (Math.abs(v - 70.0) > 1.0E-3) { hookFov = v; hookAt = now; } else seventyAt = now;
    }

    /** Once per frame, from the HUD callback. Reads the real partial tick and calibrates while the camera is still. */
    public static void beginFrame(Object deltaTracker) {
        long now = System.nanoTime();
        if (now - lastBegin < 1_000_000L) return; // already done for this frame
        lastBegin = now;
        float rp = realPartial(deltaTracker);
        ptReal = rp >= 0f;
        framePt = ptReal ? Math.min(1f, rp) : HvhClient.partialTick();

        Entity cam = MC.getCameraEntity();
        if (cam == null || !MC.options.getCameraType().isFirstPerson()) { still = 0; return; }
        float yaw = cam.getYRot(), pitch = cam.getXRot();
        if (Math.abs(yaw - prevYaw) < 0.02f && Math.abs(pitch - prevPitch) < 0.02f) still++; else still = 0;
        prevYaw = yaw; prevPitch = pitch;
        if (still >= 2 && now - lastCalib > 100_000_000L) { lastCalib = now; calibrate(cam); }
    }

    /** The partial tick the game itself uses this frame (falls back to a wall-clock estimate). */
    public static float partial() { return framePt >= 0f ? framePt : HvhClient.partialTick(); }

    private static float realPartial(Object d) {
        if (d == null) return -1f;
        try {
            if (ptClass != d.getClass()) {
                ptClass = d.getClass();
                ptMethod = null;
                for (Method m : ptClass.getMethods())
                    if (m.getName().equals("getGameTimeDeltaPartialTick") && m.getParameterCount() == 1
                        && m.getParameterTypes()[0] == boolean.class) { ptMethod = m; m.setAccessible(true); break; }
            }
            if (ptMethod == null) return -1f;
            Object r = ptMethod.invoke(d, true);
            return r instanceof Number n ? n.floatValue() : -1f;
        } catch (Throwable t) { ptMethod = null; return -1f; }
    }

    // ------------------------------------------------------------------ camera basis

    private static double[] basis(Entity cam) {
        // Same rotation the world camera uses: blended between the previous and the current tick (getViewYRot).
        float pt = partial();
        double yaw = Math.toRadians(cam.yRotO + (cam.getYRot() - cam.yRotO) * pt);
        double pitch = Math.toRadians(cam.xRotO + (cam.getXRot() - cam.xRotO) * pt);
        double sy = Math.sin(yaw), cy = Math.cos(yaw), sp = Math.sin(pitch), cp = Math.cos(pitch);
        double fx = -sy * cp, fy = -sp, fz = cy * cp;          // forward (yaw 0 = +Z, positive pitch = down)
        double rx = -cy, rz = -sy;                               // right (no Y part)
        double ux = -fy * rz, uy = rz * fx - rx * fz, uz = rx * fy; // up = right x forward
        return new double[] {fx, fy, fz, rx, rz, ux, uy, uz};
    }

    private static void calibrate(Entity cam) {
        try {
            Vec3 c = cam.getEyePosition(partial());
            double[] b = basis(cam);
            // A far probe above/right of the view centre: tiny camera-position differences do not matter there.
            Vec3 probe = new Vec3(c.x + b[0] * 40 + b[3] * 14 + b[5] * 8,
                                  c.y + b[1] * 40 + b[6] * 8,
                                  c.z + b[2] * 40 + b[4] * 14 + b[7] * 8);
            Vec3 e = MC.gameRenderer.projectPointToScreen(probe);
            if (e == null || !Double.isFinite(e.x) || !Double.isFinite(e.y) || e.z < -1 || e.z > 1 || Math.abs(e.y) < 0.05) return;
            double tan = (8.0 / 40.0) / e.y;
            if (!(tan > 0.1 && tan < 5.0)) return;
            calibTan = calibTan < 0 ? tan : calibTan + (tan - calibTan) * 0.3;
            calibAt = System.nanoTime();
        } catch (Throwable ignored) { }
    }

    private static double hookTan() {
        long now = System.nanoTime();
        double f = -1;
        if (hookFov > 0 && now - hookAt < FRESH) f = hookFov;
        else if (now - seventyAt < FRESH) f = 70.0;
        return f > 0 ? Math.tan(Math.toRadians(f) * 0.5) : -1;
    }

    private static double calTan() { return calibTan > 0 && System.nanoTime() - calibAt < CALIB_KEEP ? calibTan : -1; }

    private static String mode() {
        return HvhClient.modules != null && HvhClient.modules.nametags != null ? HvhClient.modules.nametags.projSource.value : "Авто";
    }

    private static double fix() {
        return HvhClient.modules != null && HvhClient.modules.nametags != null ? HvhClient.modules.nametags.fovFix.value : 0.0;
    }

    private static double chooseTan(String mode) {
        return switch (mode) {
            case "Калибровка" -> calTan();
            case "Хук FOV" -> hookTan();
            case "Движок" -> -1;
            default -> { double h = hookTan(); yield h > 0 ? h : calTan(); }
        };
    }

    // ------------------------------------------------------------------ projection

    /** Same contract as GameRenderer#projectPointToScreen: x/y in -1..1 (y up), z = 0 in front, null behind. */
    public static Vec3 project(Vec3 p) {
        Entity cam = MC.getCameraEntity();
        double tan = chooseTan(mode());
        if (tan <= 0 || cam == null || !MC.options.getCameraType().isFirstPerson())
            return MC.gameRenderer.projectPointToScreen(p);
        return ownProject(cam, p, tan);
    }

    private static Vec3 ownProject(Entity cam, Vec3 p, double tan) {
        double fix = fix();
        if (fix != 0.0) tan = Math.tan(Math.max(0.05, Math.min(1.5, Math.atan(tan) + Math.toRadians(fix) * 0.5)));
        Vec3 c = cam.getEyePosition(partial());
        double[] b = basis(cam);
        double dx = p.x - c.x, dy = p.y - c.y, dz = p.z - c.z;
        double zc = dx * b[0] + dy * b[1] + dz * b[2];
        if (zc < 0.05) return null;
        double xc = dx * b[3] + dz * b[4];
        double yc = dx * b[5] + dy * b[6] + dz * b[7];
        double aspect = MC.getWindow().getWidth() / (double) Math.max(1, MC.getWindow().getHeight());
        return new Vec3(xc / (zc * tan * aspect), yc / (zc * tan), 0.0);
    }

    /**
     * Apparent size on screen (GUI pixels) of a 1-block segment at {@code p} that faces the camera. Unlike the height of
     * a world-vertical segment this does not collapse to zero when the point is straight above / below the camera.
     * Returns -1 when it cannot be measured (point or probes behind the camera).
     */
    public static double pixelsPerBlock(Vec3 p, double guiW, double guiH) {
        Entity cam = MC.getCameraEntity();
        if (cam == null) return -1;
        Vec3 a = project(p);
        if (a == null) return -1;
        double[] b = basis(cam);
        double best = -1;
        Vec3 up = project(p.add(b[5], b[6], b[7]));
        if (up != null) best = Math.max(best, Math.hypot((up.x - a.x) * 0.5 * guiW, (up.y - a.y) * 0.5 * guiH));
        Vec3 right = project(p.add(b[3], 0.0, b[4]));
        if (right != null) best = Math.max(best, Math.hypot((right.x - a.x) * 0.5 * guiW, (right.y - a.y) * 0.5 * guiH));
        return best;
    }

    // ------------------------------------------------------------------ diagnostics (.proj)

    public static String report() {
        long now = System.nanoTime();
        StringBuilder sb = new StringBuilder();
        double h = hookTan(), k = calTan();
        sb.append("режим=").append(mode()).append(", поправка=").append(fix()).append("°\n");
        sb.append("FOV хук: ").append(h > 0 ? String.format("%.1f°", Math.toDegrees(Math.atan(h)) * 2) : "нет")
          .append(" (последний ").append(hookAt == 0 ? "-" : (now - hookAt) / 1_000_000 + " мс")
          .append(")\nFOV калибровка: ").append(k > 0 ? String.format("%.1f°", Math.toDegrees(Math.atan(k)) * 2) : "нет")
          .append(" (still=").append(still).append(")\n");
        sb.append("partial tick: ").append(ptReal ? "из игры" : "по часам").append(" = ").append(String.format("%.2f", partial()));
        try {
            Entity cam = MC.getCameraEntity();
            if (cam != null && MC.player != null && MC.level != null && h > 0 | k > 0) {
                LivingEntity best = null; double bd = 1e9;
                for (LivingEntity e : MC.level.getEntitiesOfClass(LivingEntity.class, MC.player.getBoundingBox().inflate(40), e -> e != MC.player)) {
                    double d = e.distanceToSqr(MC.player);
                    if (d < bd) { bd = d; best = e; }
                }
                if (best != null) {
                    Vec3 pos = Interp.pos(best, partial()).add(0, best.getBbHeight() * 0.5, 0);
                    Vec3 eng = MC.gameRenderer.projectPointToScreen(pos);
                    Vec3 own = project(pos);
                    if (eng != null && own != null) {
                        double w = MC.getWindow().getWidth(), hh = MC.getWindow().getHeight();
                        sb.append(String.format("\nближайшая цель: движок→свой сдвиг %.0f px по X, %.0f px по Y",
                            (own.x - eng.x) * 0.5 * w, -(own.y - eng.y) * 0.5 * hh));
                    }
                }
            }
        } catch (Throwable ignored) { }
        return sb.toString();
    }
}
