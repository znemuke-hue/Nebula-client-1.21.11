package dev.hvh.client.util;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;

import java.util.Arrays;
import java.util.function.BooleanSupplier;

/**
 * Quiet window for Auto Totem / Auto Swap.
 *
 * What an anti-cheat "Multi Action" check looks at is several things happening at the same time - a container click
 * together with moving, sprinting, sneaking, attacking, using an item, mining or the camera being turned by a module.
 * So every swap goes through this lock:
 *
 *  - for {@link #LOCK_TICKS} ticks KillAura / TriggerBot / AimAssist do not run (no aim, no attacks) - they read {@link #active};
 *  - for the same ticks the movement keys, jump, sprint, sneak, attack and use are released and queued clicks are thrown
 *    away, so mining and the sprint stop by themselves (vanilla does that when the keys are up);
 *  - an item that is being used (eating, drinking, a drawn bow, a raised shield) is cancelled explicitly the moment the
 *    lock starts: the "release use item" packet goes out two ticks BEFORE the swap click, so the swap never happens
 *    while you are still eating;
 *  - the click is sent at the start of tick {@link #SWAP_AT} - after quiet ticks, with quiet ticks around it;
 *  - when the lock ends, everything you are STILL holding is pressed again (W/A/S/D, Space, Sneak, LMB, RMB, sprint key,
 *    toggle sprint / sneak) and a sprint that was running comes back, so you simply keep moving.
 *
 * Tick layout (see HvhClient): {@link #preTick} runs BEFORE the modules' onPreTick, {@link #enforce} AFTER them, so
 * nothing a module does in between (KillAura's W-tap, ...) can press a key again.
 *
 * Tick numbering: the tick in which {@link #request} is called is tick 0 (its keys are already released, the click has
 * not been sent). Tick 1, 2, 3 are counted by {@link #preTick}; at tick 4 the lock ends and the keys come back before
 * vanilla reads them - so exactly 4 player ticks (0..3) are quiet.
 */
public final class ActionLock {
    private static final Minecraft mc = Minecraft.getInstance();

    /** How many ticks everything stays stopped. */
    public static final int LOCK_TICKS = 4;
    /** The click is sent at the start of this tick (counted from the request). */
    public static final int SWAP_AT = 2;

    /** True from the request until the lock is over (or cancelled). */
    public static volatile boolean active;

    private static String owner = "";
    private static BooleanSupplier action;
    private static int age;
    private static boolean swapped, wasSprinting;
    /** Which keys were down when the lock started (used only for keys whose physical state cannot be read). */
    private static final boolean[] wasDown = new boolean[9];
    /** Toggle keys (vanilla "toggle sprint / sneak") that were switched OFF by the lock and must be switched back ON. */
    private static final boolean[] flipped = new boolean[9];

    private ActionLock() {}

    public static boolean ownedBy(String who) { return active && owner.equals(who); }

    /**
     * Starts the lock. {@code doSwap} runs once, at tick {@link #SWAP_AT}, and says whether it swapped something.
     * Returns false when another request is already running (nothing is changed then).
     */
    public static boolean request(String who, BooleanSupplier doSwap) {
        LocalPlayer p = mc.player;
        if (active || p == null || mc.options == null) return false;
        owner = who;
        action = doSwap;
        age = 0;
        swapped = false;
        wasSprinting = p.isSprinting();   // remembered BEFORE the keys go up
        KeyMapping[] now = keys();
        for (int i = 0; i < now.length; i++) wasDown[i] = now[i].isDown();
        Arrays.fill(flipped, false);
        active = true;
        hold(p);
        return true;
    }

    /** Aborts without swapping and gives the keys back. */
    public static void cancel() { finish(); }

    /** START of the tick, before any module: runs the state machine. */
    public static void preTick() {
        if (!active) return;
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.options == null || !p.isAlive()) { finish(); return; }

        age++;
        if (age >= LOCK_TICKS) { finish(); return; }   // the quiet window is over: keys come back before vanilla reads them
        hold(p);

        if (!swapped && age >= SWAP_AT) {
            boolean did = false;
            try {
                did = action.getAsBoolean();
            } catch (Throwable ignored) { }
            swapped = true;
            if (!did) finish();   // nothing was swapped (no item / container open): do not keep you frozen for nothing
        }
    }

    /** END of the modules' onPreTick: a module may have pressed a key again - release it once more. */
    public static void enforce() {
        if (!active) return;
        LocalPlayer p = mc.player;
        if (p == null || mc.options == null) return;
        hold(p);
    }

    private static KeyMapping[] keys() {
        Options o = mc.options;
        return new KeyMapping[] { o.keyUp, o.keyDown, o.keyLeft, o.keyRight, o.keyJump, o.keySprint, o.keyShift, o.keyAttack, o.keyUse };
    }

    /** Releases everything that counts as an action and throws away the clicks queued by the mouse. */
    private static void hold(LocalPlayer p) {
        KeyMapping[] ks = keys();
        for (int i = 0; i < ks.length; i++) release(ks[i], i);
        while (mc.options.keyAttack.consumeClick()) { }
        while (mc.options.keyUse.consumeClick()) { }
        if (p.isSprinting()) p.setSprinting(false);
        // eating / drinking / bow / shield: cancel it for real (sends the release packet), do not wait for vanilla
        if (p.isUsingItem() && mc.gameMode != null) mc.gameMode.releaseUsingItem(p);
    }

    private static void release(KeyMapping k, int i) {
        if (!k.isDown()) return;
        k.setDown(false);
        if (k.isDown()) {
            // A "toggle" key (Options > toggle sprint / sneak): setDown(false) does nothing there, only a press flips it.
            k.setDown(true);
            if (!k.isDown()) flipped[i] = true;   // flipped off - remember to flip it on again
        }
    }

    private static void finish() {
        boolean was = active;
        active = false;
        swapped = false;
        action = null;
        owner = "";
        if (!was || mc.options == null) return;

        KeyMapping[] ks = keys();
        // toggle keys that were switched off come back on (their state is not a physical key, so this is always done)
        for (int i = 0; i < ks.length; i++) {
            if (flipped[i] && !ks[i].isDown()) ks[i].setDown(true);
        }
        Arrays.fill(flipped, false);

        if (mc.screen != null) return;   // a screen is open: vanilla re-reads the keys itself when it closes
        // give back what you are still holding: W/A/S/D, Space, Sneak, sprint key, LMB, RMB
        for (int i = 0; i < ks.length; i++) {
            KeyMapping k = ks[i];
            if (k.isDown()) continue;
            // physical state straight from GLFW; if the bound key is unknown, trust what was held when the lock started
            boolean held = Keys.resolvable(k) ? Keys.physical(k) : wasDown[i];
            if (held) k.setDown(true);
        }
        // a sprint that was running (double-tap W has no key to press again) comes back when W is down again
        LocalPlayer p = mc.player;
        if (wasSprinting && p != null && p.isAlive() && !p.isSprinting()
            && mc.options.keyUp.isDown() && !mc.options.keyShift.isDown() && p.getFoodData().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
        wasSprinting = false;
    }
}
