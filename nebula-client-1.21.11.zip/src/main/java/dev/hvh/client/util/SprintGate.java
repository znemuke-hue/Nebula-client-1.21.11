package dev.hvh.client.util;

/**
 * While {@link #hold} is true the local player cannot START sprinting (every setSprinting(true) is turned into false,
 * see LivingEntitySprintMixin). KillAura / TriggerBot use it to keep the sprint off during a W-tap, so the vanilla client
 * itself sends STOP_SPRINTING / START_SPRINTING - in the normal place, right before the movement packet of a tick.
 */
public final class SprintGate {
    private SprintGate() {}
    public static volatile boolean hold;
    /** Movement correction: the corrected input has no forward part, so the sprint must stay off (a sprint needs W). */
    public static volatile boolean moveHold;
}
