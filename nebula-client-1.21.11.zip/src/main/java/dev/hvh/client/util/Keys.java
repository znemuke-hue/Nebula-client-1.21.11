package dev.hvh.client.util;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * The REAL state of a key / mouse button, read straight from GLFW.
 *
 * While a screen is open vanilla does not feed key presses into the key mappings, so {@code keyUp.isDown()} says
 * nothing about whether W is held. GuiMove, the swap lock and FreeCam need the truth.
 *
 * Which GLFW key a mapping is bound to is taken from its save string ("key.keyboard.w", "key.mouse.right", ...). Those
 * strings are plain data, identical in every environment. The earlier approach called methods of the key class by NAME
 * through reflection - in a normal (obfuscated) Minecraft those names do not exist, so every key looked "not pressed"
 * and nothing was ever given back. The reflection stays only as the last fallback for keys the table does not know.
 */
public final class Keys {
    private static final Minecraft mc = Minecraft.getInstance();
    private static final Map<String, Integer> CACHE = new HashMap<>();
    private static final int MOUSE = 1000;       // codes >= 1000 are mouse buttons (code - 1000)
    private static Method getValue, getType;
    private static boolean resolved;

    private Keys() {}

    /** True when we know which physical key / button the mapping is bound to (so {@link #physical} is the truth, not a guess). */
    public static boolean resolvable(KeyMapping k) { return code(k) >= 0; }

    /** True while the key (or mouse button) this mapping is bound to is physically held down right now. */
    public static boolean physical(KeyMapping k) {
        try {
            int c = code(k);
            if (c >= MOUSE) return GLFW.glfwGetMouseButton(mc.getWindow().handle(), c - MOUSE) == GLFW.GLFW_PRESS;
            if (c >= 0) return InputConstants.isKeyDown(mc.getWindow(), c);
            return viaReflection(k);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * What a movement key must be set to after a module let go of it for a moment (KillAura / TriggerBot W-tap, ...):
     * the REAL state of the key. A key you released in the meantime stays released instead of getting stuck down;
     * when the bound key is unknown the old behaviour (pressed again) is kept.
     */
    public static boolean restoreState(KeyMapping k) {
        if (mc.screen != null) return false;
        return resolvable(k) ? physical(k) : true;
    }

    private static int code(KeyMapping k) {
        String name;
        try { name = k.saveString(); } catch (Throwable t) { return -1; }
        if (name == null) return -1;
        Integer c = CACHE.get(name);
        if (c == null) { c = parse(name); CACHE.put(name, c); }
        return c;
    }

    private static int parse(String name) {
        if (name.startsWith("key.mouse.")) {
            String t = name.substring("key.mouse.".length());
            switch (t) {
                case "left": return MOUSE;
                case "right": return MOUSE + 1;
                case "middle": return MOUSE + 2;
                default:
                    try { int n = Integer.parseInt(t) - 1; return n >= 0 && n < 8 ? MOUSE + n : -1; } catch (Exception e) { return -1; }
            }
        }
        if (!name.startsWith("key.keyboard.")) return -1;
        String t = name.substring("key.keyboard.".length());
        if (t.length() == 1) {
            char c = t.charAt(0);
            if (c >= 'a' && c <= 'z') return GLFW.GLFW_KEY_A + (c - 'a');
            if (c >= '0' && c <= '9') return GLFW.GLFW_KEY_0 + (c - '0');
        }
        if (t.length() >= 2 && t.charAt(0) == 'f') {
            try { int n = Integer.parseInt(t.substring(1)); if (n >= 1 && n <= 25) return GLFW.GLFW_KEY_F1 + n - 1; } catch (Exception ignored) { }
        }
        if (t.startsWith("keypad.")) {
            String s = t.substring(7);
            if (s.length() == 1 && s.charAt(0) >= '0' && s.charAt(0) <= '9') return GLFW.GLFW_KEY_KP_0 + (s.charAt(0) - '0');
        }
        switch (t) {
            case "space": return GLFW.GLFW_KEY_SPACE;
            case "left.shift": return GLFW.GLFW_KEY_LEFT_SHIFT;
            case "right.shift": return GLFW.GLFW_KEY_RIGHT_SHIFT;
            case "left.control": return GLFW.GLFW_KEY_LEFT_CONTROL;
            case "right.control": return GLFW.GLFW_KEY_RIGHT_CONTROL;
            case "left.alt": return GLFW.GLFW_KEY_LEFT_ALT;
            case "right.alt": return GLFW.GLFW_KEY_RIGHT_ALT;
            case "left.win": return GLFW.GLFW_KEY_LEFT_SUPER;
            case "right.win": return GLFW.GLFW_KEY_RIGHT_SUPER;
            case "tab": return GLFW.GLFW_KEY_TAB;
            case "enter": return GLFW.GLFW_KEY_ENTER;
            case "backspace": return GLFW.GLFW_KEY_BACKSPACE;
            case "escape": return GLFW.GLFW_KEY_ESCAPE;
            case "up": return GLFW.GLFW_KEY_UP;
            case "down": return GLFW.GLFW_KEY_DOWN;
            case "left": return GLFW.GLFW_KEY_LEFT;
            case "right": return GLFW.GLFW_KEY_RIGHT;
            case "insert": return GLFW.GLFW_KEY_INSERT;
            case "delete": return GLFW.GLFW_KEY_DELETE;
            case "home": return GLFW.GLFW_KEY_HOME;
            case "end": return GLFW.GLFW_KEY_END;
            case "page.up": return GLFW.GLFW_KEY_PAGE_UP;
            case "page.down": return GLFW.GLFW_KEY_PAGE_DOWN;
            case "caps.lock": return GLFW.GLFW_KEY_CAPS_LOCK;
            case "grave.accent": return GLFW.GLFW_KEY_GRAVE_ACCENT;
            case "minus": return GLFW.GLFW_KEY_MINUS;
            case "equal": return GLFW.GLFW_KEY_EQUAL;
            case "left.bracket": return GLFW.GLFW_KEY_LEFT_BRACKET;
            case "right.bracket": return GLFW.GLFW_KEY_RIGHT_BRACKET;
            case "backslash": return GLFW.GLFW_KEY_BACKSLASH;
            case "semicolon": return GLFW.GLFW_KEY_SEMICOLON;
            case "apostrophe": return GLFW.GLFW_KEY_APOSTROPHE;
            case "comma": return GLFW.GLFW_KEY_COMMA;
            case "period": return GLFW.GLFW_KEY_PERIOD;
            case "slash": return GLFW.GLFW_KEY_SLASH;
            default: return -1;
        }
    }

    // ---- last fallback: the bound key object read by method NAME (only works where the names are not obfuscated)

    private static void resolve(Object key) {
        if (resolved) return;
        resolved = true;
        getValue = find(key, "getValue", "value");
        getType = find(key, "getType", "type");
    }

    private static Method find(Object o, String... names) {
        for (String n : names) {
            try {
                Method m = o.getClass().getMethod(n);
                m.setAccessible(true);
                return m;
            } catch (Throwable ignored) { }
        }
        return null;
    }

    private static boolean viaReflection(KeyMapping k) {
        try {
            Object key = KeyBindingHelper.getBoundKeyOf(k);
            if (key == null) return false;
            resolve(key);
            if (getValue == null || getType == null) return false;
            int v = ((Number) getValue.invoke(key)).intValue();
            if (v < 0) return false;
            Object type = getType.invoke(key);
            String t = type instanceof Enum<?> e ? e.name() : String.valueOf(type);
            long window = mc.getWindow().handle();
            if (t.equals("MOUSE")) return GLFW.glfwGetMouseButton(window, v) == GLFW.GLFW_PRESS;
            if (t.equals("KEYSYM")) return GLFW.glfwGetKey(window, v) == GLFW.GLFW_PRESS;
            return false;
        } catch (Throwable t) {
            return false;
        }
    }
}
