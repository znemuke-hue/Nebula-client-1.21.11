package dev.hvh.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.Slot;

import java.lang.reflect.Method;

/**
 * Inventory helpers for Auto Totem / Auto Swap.
 *
 * swapToOffhand() sends a normal "swap with offhand" container click (button 40), exactly what pressing F over a slot
 * does. The container-click method is looked up by its signature (int, int, int, enum, Player) and the enum constant
 * by the name SWAP, so the code does not depend on how Mojang named MultiPlayerGameMode#handleInventoryMouseClick /
 * handleContainerInput and ClickType / ContainerInput in your exact Minecraft version.
 */
public final class InvUtil {
    private static final Minecraft mc = Minecraft.getInstance();
    private static Method click;
    private static Object swap;
    private static boolean resolved;

    /**
     * True only while one of OUR modules (Auto Totem / Auto Swap) is sending its click. GuiMove's legit mode holds back the
     * clicks YOU make in a container while you are moving; the modules' own clicks (and the replayed ones) must never be caught by it.
     */
    public static volatile boolean internal;

    private InvUtil() {}

    private static boolean resolve() {
        if (resolved) return click != null;
        resolved = true;
        try {
            for (Method m : MultiPlayerGameMode.class.getMethods()) {
                Class<?>[] t = m.getParameterTypes();
                if (t.length != 5 || t[0] != int.class || t[1] != int.class || t[2] != int.class || !t[3].isEnum()
                    || !t[4].isAssignableFrom(LocalPlayer.class)) continue;
                for (Object c : t[3].getEnumConstants()) {
                    if (((Enum<?>) c).name().equals("SWAP")) { click = m; swap = c; return true; }
                }
            }
        } catch (Throwable ignored) { }
        return false;
    }

    /** Menu slot id (in the player's own inventory menu) of a player-inventory index (0-8 hotbar, 9-35 main), or -1. */
    private static int menuSlot(LocalPlayer p, int invIndex) {
        for (Slot s : p.inventoryMenu.slots)
            if (s.container == p.getInventory() && s.getContainerSlot() == invIndex) return s.index;
        return -1;
    }

    /** True while no other container (chest, ender chest, ...) is open, so the player's own menu is the active one. */
    public static boolean canClick() {
        LocalPlayer p = mc.player;
        return p != null && mc.gameMode != null && p.containerMenu == p.inventoryMenu && resolve();
    }

    /**
     * Sends a container click that was held back (GuiMove, legit mode) exactly as it was made. Marked {@link #internal},
     * so GuiMove does not catch it a second time.
     */
    public static boolean click(int containerId, int slot, int button, Object clickType) {
        try {
            LocalPlayer p = mc.player;
            if (p == null || mc.gameMode == null || clickType == null || !resolve()) return false;
            internal = true;
            try {
                click.invoke(mc.gameMode, containerId, slot, button, clickType, p);
            } finally {
                internal = false;
            }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Swaps the item in player-inventory slot {@code invIndex} (0-35) with the offhand. */
    public static boolean swapToOffhand(int invIndex) {
        try {
            LocalPlayer p = mc.player;
            if (!canClick() || invIndex < 0 || invIndex > 35) return false;
            int slot = menuSlot(p, invIndex);
            if (slot < 0) return false;
            internal = true;
            try {
                click.invoke(mc.gameMode, p.inventoryMenu.containerId, slot, 40, swap, p);
            } finally {
                internal = false;
            }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
